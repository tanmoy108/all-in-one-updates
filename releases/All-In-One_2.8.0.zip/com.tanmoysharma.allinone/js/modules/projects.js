/* All In One — Projects tab: template library (one-click import) + template editor */
(function (w) {
    'use strict';
    var MK = w.MK;
    var CATS = ['SaaS', 'Carousel', 'Grid', 'Slideshow', 'Promo', 'Logo', 'Text', 'Social', 'Lower third', 'Other'];
    var lib = { items: [], cat: '', loaded: false };
    var ed = { compId: 0, data: null };

    function defRoot() { return MK.paths.join(MK.paths.data, 'Projects'); }
    function root() { var r = (MK.settings.projects || {}).libRoot; return r || defRoot(); }
    function fs() { return MK.require('fs'); }
    function pth() { return MK.require('path'); }
    function esc(s) { return MK.esc(String(s === undefined || s === null ? '' : s)); }
    function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
    function cleanName(s) {
        return String(s || 'Project').replace(/\.aepx?$/i, '').replace(/-\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2}-utc$/i, '')
            .replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim().replace(/\b\w/g, function (c) { return c.toUpperCase(); }).slice(0, 60) || 'Project';
    }
    function guessCat(name) {
        var n = String(name).toLowerCase();
        if (/saas|app|website|web|ui|dashboard/.test(n)) { return 'SaaS'; }
        if (/carousel|slider/.test(n)) { return 'Carousel'; }
        if (/grid|box|mosaic/.test(n)) { return 'Grid'; }
        if (/slideshow|photo|memories|gallery|frame/.test(n)) { return 'Slideshow'; }
        if (/logo|reveal/.test(n)) { return 'Logo'; }
        if (/title|text|typo/.test(n)) { return 'Text'; }
        if (/insta|story|reel|social|tiktok/.test(n)) { return 'Social'; }
        if (/lower/.test(n)) { return 'Lower third'; }
        if (/promo|product|ad\b|sale|delivery/.test(n)) { return 'Promo'; }
        return 'Other';
    }
    function fmtSize(b) { return b > 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : (b / 1048576).toFixed(0) + ' MB'; }

    /* ---------- disk ---------- */
    function walk(dir, depth, cb) {
        if (depth < 0) { return; }
        MK.fs.list(dir).forEach(function (f) {
            if (/^(__MACOSX|\.DS_Store|Thumbs\.db|Adobe After Effects Auto-Save|.*Logs)$/i.test(f)) { return; }
            var full = pth().join(dir, f);
            if (MK.fs.isDir(full)) { cb(full, true); walk(full, depth - 1, cb); } else { cb(full, false); }
        });
    }
    function findAeps(dir, depth) {
        var out = [];
        walk(dir, depth === undefined ? 4 : depth, function (p, isDir) { if (!isDir && /\.aepx?$/i.test(p) && !/auto-save/i.test(p)) { out.push(p); } });
        return out;
    }
    // prefer the newest AE version file (e.g. "...CC2023.aep" over "...CC2019.aep"), then the shortest path
    function sortAeps(list) {
        var score = function (p) {
            var b = pth().basename(p), m = /20\d\d/.exec(b);
            if (m) { return parseInt(m[0], 10); }
            m = /cc\s?(\d{2})(?!\d)/i.exec(b);
            if (m) { return 2000 + parseInt(m[1], 10); }
            m = /cs(\d)/i.exec(b);
            return m ? 1000 + parseInt(m[1], 10) : 0;
        };
        return list.slice().sort(function (a, b) { return score(b) - score(a) || a.length - b.length; });
    }
    function pickAep(list) { return sortAeps(list)[0]; }
    function findPreview(dir) {
        var vid = '', img = '';
        walk(dir, 3, function (p, isDir) {
            if (isDir) { return; }
            var b = pth().basename(p).toLowerCase();
            if (!/preview|prev\b|thumb|demo|cover|poster/.test(b)) { return; }
            if (!vid && /\.(mp4|webm)$/.test(b)) { vid = p; }
            if (!img && /\.(jpe?g|png|gif|webp)$/.test(b)) { img = p; }
        });
        return { video: vid, image: img };
    }
    function dirSize(dir) { var n = 0; walk(dir, 12, function (p, isDir) { if (!isDir) { n += MK.fs.size(p); } }); return n; }
    function copyDir(src, dst, onProgress) {
        var files = [], total = 0;
        walk(src, 12, function (p, isDir) { if (!isDir) { var s = MK.fs.size(p); files.push([p, s]); total += s; } });
        var done = 0, i = 0;
        return new Promise(function (resolve, reject) {
            (function next() {
                if (i >= files.length) { return resolve(); }
                var f = files[i++], out = pth().join(dst, pth().relative(src, f[0]));
                try { MK.fs.mkdirp(pth().dirname(out)); } catch (e) { return reject(e); }
                fs().copyFile(f[0], out, function (err) {
                    if (err) { return reject(err); }
                    done += f[1];
                    if (onProgress) { onProgress(total ? done / total : 1); }
                    next();
                });
            })();
        });
    }
    function rmrf(p) {
        if (!MK.fs.exists(p)) { return; }
        if (MK.fs.isDir(p)) { MK.fs.list(p).forEach(function (f) { rmrf(pth().join(p, f)); }); fs().rmdirSync(p); } else { fs().unlinkSync(p); }
    }
    function metaPath(it) { return pth().join(it.dir, 'meta.json'); }
    // paths inside the entry folder are saved as "@/…" so the library works from any PC (Google Drive etc.)
    var PATH_KEYS = ['aep', 'previewVideo', 'previewImage'];
    function toRel(dir, p) {
        if (!p || /^@\//.test(p)) { return p; }
        var rel = pth().relative(dir, p);
        return (rel && rel.indexOf('..') !== 0 && !pth().isAbsolute(rel)) ? '@/' + rel.replace(/\\/g, '/') : p;
    }
    function fromRel(dir, id, p) {
        if (!p) { return p; }
        if (/^@\//.test(p)) { return pth().join.apply(null, [dir].concat(p.slice(2).split('/'))); }
        // an absolute path written on another PC: re-base it onto this entry folder
        if (!MK.fs.exists(p) && id) {
            var parts = p.split(/[\\\/]/), i = parts.lastIndexOf(id);
            if (i >= 0 && i < parts.length - 1) { var q = pth().join.apply(null, [dir].concat(parts.slice(i + 1))); if (MK.fs.exists(q)) { return q; } }
        }
        return p;
    }
    function saveMeta(it) {
        var o = {};
        for (var k in it) { if (k !== 'dir') { o[k] = PATH_KEYS.indexOf(k) >= 0 ? toRel(it.dir, it[k]) : it[k]; } }
        MK.fs.writeJSON(metaPath(it), o);
    }

    function scan() {
        var r = root(); MK.fs.mkdirp(r);
        lib.items = MK.fs.list(r).map(function (d) {
            var dir = pth().join(r, d), m = MK.fs.readJSON(pth().join(dir, 'meta.json'), null);
            if (!m) { return null; }
            m.dir = dir;
            PATH_KEYS.forEach(function (k) { m[k] = fromRel(dir, m.id || d, m[k]); });
            return m;
        }).filter(Boolean).sort(function (a, b) { return (b.added || 0) - (a.added || 0); });
        lib.loaded = true;
    }
    function cats() {
        var all = CATS.slice();
        lib.items.forEach(function (it) { if (it.cat && all.indexOf(it.cat) < 0) { all.push(it.cat); } });
        return all;
    }

    /* ---------- library UI ---------- */
    function renderCats() {
        var row = MK.$('#pjCats'), counts = {};
        lib.items.forEach(function (it) { counts[it.cat] = (counts[it.cat] || 0) + 1; });
        row.innerHTML = '';
        [''].concat(cats()).forEach(function (c) {
            if (c && !counts[c]) { return; }
            var b = document.createElement('button');
            b.className = 'chip' + (c === lib.cat ? ' active' : '');
            b.textContent = (c || MK.t('pj.all')) + ' ' + (c ? counts[c] : lib.items.length);
            b.onclick = function () { lib.cat = c; renderCats(); render(); };
            row.appendChild(b);
        });
    }
    function thumbOf(it) {
        var t = pth().join(it.dir, 'thumb.png');
        if (it.previewImage && MK.fs.exists(it.previewImage)) { return it.previewImage; }
        return MK.fs.exists(t) ? t : '';
    }
    function render() {
        var grid = MK.$('#pjGrid'), q = MK.$('#pjSearch').value.trim().toLowerCase();
        grid.innerHTML = '';
        var shown = lib.items.filter(function (it) {
            return (!lib.cat || it.cat === lib.cat) && (!q || (it.name + ' ' + it.cat + ' ' + (it.main ? it.main.name : '')).toLowerCase().indexOf(q) >= 0);
        });
        MK.$('#pjEmpty').classList.toggle('hidden', lib.items.length > 0);
        shown.forEach(function (it) {
            var card = document.createElement('div');
            card.className = 'lcard pj-card';
            var m = it.main || {};
            var badge = m.w ? m.w + '×' + m.h + ' · ' + Math.round(m.dur || 0) + 's' : '';
            card.innerHTML = '<div class="thumb">' + (thumbOf(it) || it.previewVideo ? '' : esc(it.name.slice(0, 22))) + '</div>' +
                (badge ? '<span class="badge">' + esc(badge) + '</span>' : '') +
                (it.linked ? '<span class="badge link" title="' + esc(MK.t('pj.linked')) + '">🔗</span>' : '') +
                '<div class="meta"><span title="' + esc(it.name) + '">' + esc(it.name) + '</span><b class="pj-more" title="' + esc(MK.t('pj.edit')) + '">⋯</b></div>' +
                '<div class="state">' + esc(MK.t('pj.importing')) + '</div>';
            var th = card.querySelector('.thumb'), img = thumbOf(it);
            if (img) { th.style.backgroundImage = 'url("' + MK.fs.fileUrl(img) + '")'; }
            if (it.previewVideo && MK.fs.exists(it.previewVideo)) {
                var v;
                card.addEventListener('mouseenter', function () {
                    if (!v) {
                        v = document.createElement('video');
                        v.src = MK.fs.fileUrl(it.previewVideo); v.muted = true; v.loop = true; v.playsInline = true;
                        v.style.cssText = 'width:100%;height:100%;object-fit:cover';
                        th.innerHTML = ''; th.appendChild(v);
                    }
                    try { v.play(); } catch (e) {}
                });
                card.addEventListener('mouseleave', function () { if (v) { v.pause(); } });
            }
            card.querySelector('.pj-more').addEventListener('click', function (e) { e.stopPropagation(); editEntry(it); });
            card.addEventListener('click', function () { importEntry(it, card); });
            grid.appendChild(card);
        });
    }

    function importEntry(it, card) {
        if (card && card.classList.contains('loading')) { return; }
        if (!MK.fs.exists(it.aep)) { MK.toast(MK.t(it.linked ? 'pj.otherPc' : 'pj.missingAep', { p: it.aep }), 'err'); return; }
        var mode = MK.segValue(MK.$('#pjMode'), 'data-v') || 'open';
        if (card) { card.classList.add('loading'); }
        MK.host('proj.importProject', { path: it.aep, main: it.main ? it.main.name : '', name: it.name, mode: mode, fit: MK.$('#pjFit').checked }, { timeout: 600000 })
            .then(function (r) {
                if (card) { card.classList.remove('loading'); card.classList.add('done'); setTimeout(function () { card.classList.remove('done'); }, 1500); }
                MK.toast(MK.t(r.placed ? 'pj.okPlaced' : 'pj.okOpened', { n: r.comp.name }));
                it.used = (it.used || 0) + 1; it.lastUsed = Date.now(); saveMeta(it);
                if (MK.$('#pjOpenEd').checked) { openEditor(r.comp.id); }
            }, function (e) { if (card) { card.classList.remove('loading'); } MK.fail(e); });
    }

    function catSelect(cur) {
        return '<select name="cat">' + cats().map(function (c) { return '<option' + (c === cur ? ' selected' : '') + '>' + esc(c) + '</option>'; }).join('') + '</select>' +
            '<input type="text" name="newCat" placeholder="' + esc(MK.t('pj.newCat')) + '">';
    }

    function editEntry(it) {
        var comps = (it.comps || []).map(function (c) { return '<option' + (it.main && c.name === it.main.name ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('');
        MK.modal({
            title: it.name,
            okText: MK.t('pj.save'),
            html: '<label>' + esc(MK.t('pj.name')) + '<input type="text" name="name" value="' + esc(it.name) + '"></label>' +
                '<label>' + esc(MK.t('pj.cat')) + catSelect(it.cat) + '</label>' +
                (comps ? '<label>' + esc(MK.t('pj.mainComp')) + '<select name="main">' + comps + '</select></label>' : '') +
                '<p class="hint">' + esc(it.aep) + '</p>' +
                '<label class="check"><input type="checkbox" name="thumb"><span>' + esc(MK.t('pj.remakeThumb')) + '</span></label>' +
                '<label class="check"><input type="checkbox" name="folder"><span>' + esc(MK.t('pj.openFolder')) + '</span></label>' +
                '<label class="check danger"><input type="checkbox" name="del"><span>' + esc(MK.t(it.linked ? 'pj.delLinked' : 'pj.delCopied')) + '</span></label>'
        }).then(function (r) {
            if (!r) { return; }
            if (r.del) {
                rmrf(it.dir); scan(); renderCats(); render(); MK.toast(MK.t('pj.deleted')); return;
            }
            it.name = (r.name || it.name).trim();
            it.cat = (r.newCat || '').trim() || r.cat || it.cat;
            if (r.main) { var mc = (it.comps || []).filter(function (c) { return c.name === r.main; })[0]; if (mc) { it.main = mc; } }
            saveMeta(it);
            if (r.folder) { MK.host('app.openFolder', { path: pth().dirname(it.aep) }).catch(MK.fail); }
            var p = r.thumb ? remakeThumb(it) : Promise.resolve();
            return p.then(function () { renderCats(); render(); MK.toast(MK.t('ok.saved')); });
        }).catch(MK.fail);
    }
    function remakeThumb(it) {
        var bar = MK.$('#pjProgress');
        MK.progress(bar, null, MK.t('pj.thumbing'));
        var t = pth().join(it.dir, 'thumb.png');
        return MK.host('proj.inspect', { path: it.aep, main: it.main ? it.main.name : '', thumb: t, at: 0.3 + Math.random() * 0.4 }, { timeout: 600000 })
            .then(function () { it.previewImage = ''; saveMeta(it); MK.progressHide(bar); }, function (e) { MK.progressHide(bar); throw e; });
    }

    /* ---------- adding ---------- */
    // template root for a single .aep: its folder, or the parent when the .aep sits in a "Project" sub-folder
    function rootForAep(aep) {
        var d = pth().dirname(aep);
        if (/^(project|projects|aep|after ?effects?|ae|cc ?\d+|source)$/i.test(pth().basename(d))) { return pth().dirname(d); }
        return d;
    }
    function askAdd(title, countLine, name, cat, size, allowName) {
        return MK.modal({
            title: title,
            okText: MK.t('pj.add'),
            html: (countLine ? '<p>' + esc(countLine) + '</p>' : '') +
                (allowName ? '<label>' + esc(MK.t('pj.name')) + '<input type="text" name="name" value="' + esc(name) + '"></label>' : '') +
                '<label>' + esc(MK.t('pj.cat')) + catSelect(cat) + '</label>' +
                (allowName ? '' : '<label class="check"><input type="checkbox" name="autoCat" checked><span>' + esc(MK.t('pj.autoCat')) + '</span></label>') +
                '<label>' + esc(MK.t('pj.store')) + '<select name="mode"><option value="copy">' + esc(MK.t('pj.copy')) + (size ? ' (' + fmtSize(size) + ')' : '') + '</option><option value="link">' + esc(MK.t('pj.link')) + '</option></select></label>' +
                '<p class="hint">' + esc(MK.t('pj.storeHint')) + '</p>'
        });
    }

    function addOne(t, opts, bar, label) {
        var id = uid(), dir = pth().join(root(), id);
        MK.fs.mkdirp(dir);
        var it = { id: id, name: t.name, cat: t.cat, added: Date.now(), linked: opts.mode !== 'copy', src: t.root };
        var stage = Promise.resolve(t.root);
        if (opts.mode === 'copy') {
            var dst = pth().join(dir, 'files');
            stage = copyDir(t.root, dst, function (f) { MK.progress(bar, f, label + ' · ' + MK.t('pj.copying', { p: Math.round(f * 100) })); }).then(function () { return dst; });
        }
        return stage.then(function (base) {
            var pv = findPreview(base);
            it.previewVideo = pv.video; it.previewImage = pv.image;
            MK.progress(bar, null, label + ' · ' + MK.t('pj.reading'));
            // newest AE version first; if this AE can't open it, try the other .aep files of the template
            var order = [t.aep].concat((t.aeps || []).filter(function (a) { return a !== t.aep; }));
            var tryOne = function (i) {
                it.aep = pth().join(base, pth().relative(t.root, order[i]));
                return MK.host('proj.inspect', { path: it.aep, main: t.main || '', thumb: pv.image ? '' : pth().join(dir, 'thumb.png') }, { timeout: 600000 })
                    .then(function (r) { it.main = r.main; it.comps = r.comps; delete it.error; },
                        function (e) { it.error = MK.errText(e); if (i + 1 < order.length) { return tryOne(i + 1); } });
            };
            return tryOne(0);
        }).then(function () { saveMeta(Object.assign(it, { dir: dir })); return it; }, function (e) { try { rmrf(dir); } catch (e2) {} throw e; });
    }

    function runAdds(list, opts) {
        var bar = MK.$('#pjProgress'), done = 0, fails = [];
        return list.reduce(function (p, t, i) {
            return p.then(function () {
                var label = (i + 1) + '/' + list.length + ' ' + t.name;
                return addOne(t, opts, bar, label).then(function (it) { done++; if (it.error) { fails.push(t.name + ': ' + it.error); } scan(); renderCats(); render(); },
                    function (e) { fails.push(t.name + ': ' + MK.errText(e)); });
            });
        }, Promise.resolve()).then(function () {
            MK.progressHide(bar);
            if (fails.length) { MK.toast(MK.t('pj.addedSome', { n: done, f: fails.join(' · ') }), 'warn'); } else { MK.toast(MK.t('pj.added', { n: done })); }
        });
    }

    function addAep(btn) {
        MK.busy(btn, function () {
            return MK.host('app.chooseFile', { title: MK.t('pj.chooseAep'), filter: 'After Effects project:*.aep;*.aepx' }).then(function (aep) {
                if (!aep) { return; }
                var r0 = rootForAep(aep), name = cleanName(pth().basename(r0) === pth().basename(pth().dirname(aep)) ? pth().basename(r0) : pth().basename(aep));
                return askAdd(MK.t('pj.addOne'), '', name, guessCat(name + ' ' + aep), dirSize(r0), true).then(function (r) {
                    if (!r) { return; }
                    return runAdds([{ root: r0, aep: aep, aeps: sortAeps(findAeps(r0, 4)), name: (r.name || name).trim(), cat: (r.newCat || '').trim() || r.cat }], { mode: r.mode });
                });
            });
        });
    }

    function addFolder(btn) {
        MK.busy(btn, function () {
            return MK.host('app.chooseFolder', { title: MK.t('pj.chooseFolder') }).then(function (dir) {
                if (!dir) { return; }
                var found = [];
                MK.fs.list(dir).forEach(function (f) {
                    var sub = pth().join(dir, f);
                    if (!MK.fs.isDir(sub)) { return; }
                    var aeps = findAeps(sub, 4);
                    if (aeps.length) { found.push({ root: sub, aep: pickAep(aeps), aeps: sortAeps(aeps), name: cleanName(f) }); }
                });
                if (!found.length) {
                    var top = findAeps(dir, 3);
                    if (top.length) { found.push({ root: dir, aep: pickAep(top), aeps: sortAeps(top), name: cleanName(pth().basename(dir)) }); }
                }
                if (!found.length) { MK.toast(MK.t('pj.noneFound'), 'warn'); return; }
                var known = {}; lib.items.forEach(function (it) { known[it.src] = true; });
                var fresh = found.filter(function (t) { return !known[t.root]; });
                if (!fresh.length) { MK.toast(MK.t('pj.allKnown'), 'warn'); return; }
                var size = fresh.reduce(function (s, t) { return s + dirSize(t.root); }, 0);
                return askAdd(MK.t('pj.addMany'), MK.t('pj.foundN', { n: fresh.length, s: fresh.slice(0, 6).map(function (t) { return t.name; }).join(', ') + (fresh.length > 6 ? '…' : '') }), '', 'Other', size, false)
                    .then(function (r) {
                        if (!r) { return; }
                        var cat = (r.newCat || '').trim() || r.cat;
                        fresh.forEach(function (t) { t.cat = r.autoCat ? guessCat(t.name) : cat; });
                        return runAdds(fresh, { mode: r.mode });
                    });
            });
        });
    }

    function addCurrent(btn) {
        MK.busy(btn, function () {
            return MK.host('proj.peekCurrent', {}).then(function (c) {
                if (!c.path) { MK.toast(MK.t('pj.saveFirst'), 'warn'); return; }
                if (c.dirty) { MK.toast(MK.t('pj.dirty'), 'warn'); }
                var r0 = pth().dirname(c.path), name = cleanName(c.name);
                return askAdd(MK.t('pj.addCur'), c.comp ? MK.t('pj.mainIs', { n: c.comp }) : '', name, guessCat(name), dirSize(r0), true).then(function (r) {
                    if (!r) { return; }
                    return runAdds([{ root: r0, aep: c.path, name: (r.name || name).trim(), cat: (r.newCat || '').trim() || r.cat, main: c.comp }], { mode: r.mode });
                });
            });
        });
    }


    /* ---------- save the selected comp (with its files) into the library ---------- */
    function saveComp(btn) {
        MK.busy(btn, function () {
            return MK.host('proj.peekSaveTarget', {}).then(function (t) {
                var name = cleanName(t.comps[0]);
                return MK.modal({
                    title: MK.t('pj.saveComp'),
                    okText: MK.t('pj.save'),
                    html: '<p class="hint">' + esc(MK.t('pj.saveWhat', { c: t.comps.join(', '), w: t.main.w, h: t.main.h, d: t.main.dur })) + '</p>' +
                        '<label>' + esc(MK.t('pj.name')) + '<input type="text" name="name" value="' + esc(name) + '"></label>' +
                        '<label>' + esc(MK.t('pj.cat')) + catSelect(guessCat(name)) + '</label>' +
                        '<label class="check"><input type="checkbox" name="collect" checked><span>' + esc(MK.t('pj.collect', { n: t.files, s: fmtSize(t.size) })) + '</span></label>' +
                        (t.missing ? '<p class="hint warn">' + esc(MK.t('pj.missingN', { n: t.missing })) + '</p>' : '') +
                        '<p class="hint">' + esc(MK.t(t.saved ? (t.dirty ? 'pj.willSave' : 'pj.willReopen') : 'pj.untitledNote')) + '</p>'
                }).then(function (r) {
                    if (!r) { return; }
                    var id = uid(), dir = pth().join(root(), id), bar = MK.$('#pjProgress');
                    MK.fs.mkdirp(dir);
                    MK.progress(bar, null, MK.t('pj.saving'));
                    return MK.host('proj.rawSaveComp', { dir: dir, name: (r.name || name).trim(), collect: !!r.collect, thumb: pth().join(dir, 'thumb.png'), untitledDir: MK.paths.join(MK.paths.data, 'Untitled Projects') }, { timeout: 3600000 })
                        .then(function (x) {
                            var it = { id: id, name: (r.name || name).trim(), cat: (r.newCat || '').trim() || r.cat, added: Date.now(), linked: false, src: 'saved:' + x.aep,
                                aep: x.aep, main: x.main, comps: x.comps, previewVideo: '', previewImage: '', dir: dir };
                            saveMeta(it);
                            MK.progressHide(bar);
                            scan(); renderCats(); render();
                            MK.toast(MK.t('pj.savedComp', { n: it.name, f: x.copied }) + (x.missing.length ? ' · ' + MK.t('pj.missingN', { n: x.missing.length }) : ''), x.missing.length ? 'warn' : '');
                            if (x.untitled) { MK.toast(MK.t('pj.untitledSaved', { p: x.untitled }), 'warn'); }
                        }, function (e) { MK.progressHide(bar); try { rmrf(dir); } catch (e2) {} throw e; });
                });
            });
        });
    }

    /* ---------- library location (e.g. a Google Drive folder shared by every PC) ---------- */
    function chooseLibRoot(btn) {
        MK.busy(btn, function () {
            return MK.host('app.chooseFolder', { title: MK.t('pj.libPick') }).then(function (picked) {
                if (!picked) { return; }
                var target = /all in one library$/i.test(picked) ? picked : pth().join(picked, 'All In One Library');
                var cur = root(), same = pth().resolve(cur).toLowerCase() === pth().resolve(target).toLowerCase();
                if (same) { MK.toast(MK.t('pj.libSame')); return; }
                var linked = lib.items.filter(function (it) { return it.linked && MK.fs.exists(it.src || ''); }).length;
                return MK.modal({
                    title: MK.t('pj.libTitle'),
                    okText: MK.t('ui.ok'),
                    html: '<p class="hint mono">' + esc(target) + '</p>' +
                        (lib.items.length ? '<label class="check"><input type="checkbox" name="move" checked><span>' + esc(MK.t('pj.libMove', { n: lib.items.length })) + '</span></label>' : '') +
                        (linked ? '<label class="check"><input type="checkbox" name="pull" checked><span>' + esc(MK.t('pj.libPull', { n: linked })) + '</span></label>' : '') +
                        '<p class="hint">' + esc(MK.t('pj.libHint')) + '</p>'
                }).then(function (r) {
                    if (!r) { return; }
                    MK.fs.mkdirp(target);
                    var bar = MK.$('#pjProgress'), items = r.move ? lib.items.slice() : [];
                    return items.reduce(function (p, it, i) {
                        return p.then(function () {
                            var dst = pth().join(target, it.id || pth().basename(it.dir));
                            if (MK.fs.exists(pth().join(dst, 'meta.json'))) { return; } // already there (other PC put it)
                            var label = (i + 1) + '/' + items.length + ' ' + it.name;
                            return copyDir(it.dir, dst, function (f) { MK.progress(bar, f, label + ' · ' + MK.t('pj.copying', { p: Math.round(f * 100) })); }).then(function () {
                                var n = Object.assign({}, it, { dir: dst });
                                PATH_KEYS.forEach(function (k) { if (it[k] && pth().relative(it.dir, it[k]).indexOf('..') !== 0) { n[k] = pth().join(dst, pth().relative(it.dir, it[k])); } });
                                if (r.pull && it.linked && MK.fs.exists(it.src || '')) {
                                    var files = pth().join(dst, 'files');
                                    return copyDir(it.src, files, function (f) { MK.progress(bar, f, label + ' · ' + MK.t('pj.copying', { p: Math.round(f * 100) })); }).then(function () {
                                        PATH_KEYS.forEach(function (k) { if (it[k] && pth().relative(it.src, it[k]).indexOf('..') !== 0) { n[k] = pth().join(files, pth().relative(it.src, it[k])); } });
                                        n.linked = false;
                                        saveMeta(n);
                                    });
                                }
                                saveMeta(n);
                            });
                        });
                    }, Promise.resolve()).then(function () {
                        MK.settings.projects = Object.assign(MK.settings.projects || {}, { libRoot: target });
                        MK.saveSettings();
                        MK.progressHide(bar);
                        libLabel();
                        scan(); renderCats(); render();
                        MK.toast(MK.t('pj.libDone'));
                    }, function (e) { MK.progressHide(bar); throw e; });
                });
            });
        });
    }
    function libLabel() {
        var el = MK.$('#pjLibPath');
        if (el) { el.textContent = MK.t('pj.libNow', { p: root() }); }
    }

    /* ======================= EDITOR ======================= */
    function openEditor(compId) {
        MK.$$('#pjSeg button').forEach(function (b) { b.classList.toggle('active', b.dataset.sub === 'editor'); });
        showSub('editor');
        return loadEditor(compId);
    }
    function loadEditor(compId) {
        var box = MK.$('#edBody');
        box.innerHTML = '<div class="empty">' + esc(MK.t('pj.scanning')) + '</div>';
        return MK.host('proj.readScan', compId ? { compId: compId } : {}, { timeout: 300000 }).then(function (d) {
            ed.compId = d.comp.id; ed.data = d;
            renderEditor();
        }, function (e) { box.innerHTML = '<div class="empty">' + esc(MK.errText(e)) + '</div>'; });
    }
    function call(fn, args, el) {
        if (el) { el.classList.add('saving'); }
        return MK.host(fn, args).then(function (r) { if (el) { el.classList.remove('saving'); el.classList.add('saved'); setTimeout(function () { el.classList.remove('saved'); }, 700); } return r; },
            function (e) { if (el) { el.classList.remove('saving'); } MK.fail(e); throw e; });
    }
    function sec(id, title, count, open) {
        var d = document.createElement('details');
        d.className = 'ed-sec'; d.id = id; d.open = open !== false;
        d.innerHTML = '<summary>' + esc(title) + ' <small>' + count + '</small></summary><div class="ed-in"></div>';
        return d;
    }
    function pin(row) {
        var b = document.createElement('button');
        b.className = 'btn sm icon ed-pin'; b.title = MK.t('pj.locate'); b.textContent = '📍';
        b.onclick = function () { MK.host('proj.peekLayer', { c: row.c, l: row.l }).catch(MK.fail); };
        return b;
    }
    function renderEditor() {
        var d = ed.data, box = MK.$('#edBody');
        MK.$('#edComp').textContent = d.comp.name + '  ·  ' + d.comp.w + '×' + d.comp.h + '  ·  ' + d.comp.dur + 's' + (d.comps > 1 ? '  ·  ' + MK.t('pj.precomps', { n: d.comps - 1 }) : '');
        box.innerHTML = '';
        if (!d.texts.length && !d.colors.length && !d.media.length && !d.controls.length) { box.innerHTML = '<div class="empty">' + esc(MK.t('pj.nothing')) + '</div>'; return; }

        // controls first (template makers put the main switches there)
        if (d.controls.length) {
            var sc = sec('edControls', MK.t('pj.controls'), d.controls.length), inC = sc.querySelector('.ed-in'), lastLayer = '';
            d.controls.forEach(function (c) {
                var key = c.comp + '/' + c.layer;
                if (key !== lastLayer) { lastLayer = key; var hd = document.createElement('div'); hd.className = 'ed-group'; hd.textContent = c.layer + (c.main ? '' : '  ·  ' + c.comp); inC.appendChild(hd); }
                var row = document.createElement('div'); row.className = 'ed-row';
                var lab = document.createElement('span'); lab.className = 'ed-lab'; lab.textContent = c.name; lab.title = c.name; row.appendChild(lab);
                var send = function (v, el) { c.v = v; call('proj.setControl', { c: c.c, l: c.l, e: c.e, type: c.type, v: v }, el); };
                var inp;
                if (c.type === 'checkbox') {
                    inp = document.createElement('input'); inp.type = 'checkbox'; inp.checked = !!c.v;
                    inp.onchange = function () { send(inp.checked, row); };
                    row.appendChild(inp);
                } else if (c.type === 'color') {
                    inp = document.createElement('input'); inp.type = 'color'; inp.value = c.v || '#ffffff';
                    inp.onchange = function () { send(inp.value, row); };
                    row.appendChild(inp);
                } else if (c.type === 'point' || c.type === 'point3') {
                    (c.v || [0, 0]).forEach(function (n, i) {
                        var x = document.createElement('input'); x.type = 'number'; x.className = 'num'; x.value = n; x.step = 'any';
                        x.onchange = function () { var v = (c.v || []).slice(); v[i] = parseFloat(x.value) || 0; send(v, row); };
                        row.appendChild(x);
                    });
                } else {
                    inp = document.createElement('input'); inp.type = 'number'; inp.className = 'num'; inp.value = c.v; inp.step = 'any';
                    inp.onchange = function () { send(parseFloat(inp.value) || 0, row); };
                    row.appendChild(inp);
                }
                row.appendChild(pin(c));
                inC.appendChild(row);
            });
            box.appendChild(sc);
        }

        if (d.texts.length) {
            var st = sec('edTexts', MK.t('pj.texts'), d.texts.length), inT = st.querySelector('.ed-in');
            if (d.texts.length > 6) {
                var flt = document.createElement('input'); flt.type = 'search'; flt.className = 'ed-filter'; flt.placeholder = MK.t('pj.filterText');
                flt.oninput = function () { var q = flt.value.toLowerCase(); MK.$$('.ed-text', inT).forEach(function (el) { el.classList.toggle('hidden', q && el.dataset.k.indexOf(q) < 0); }); };
                inT.appendChild(flt);
            }
            d.texts.forEach(function (t) {
                var el = document.createElement('div'); el.className = 'ed-text';
                el.dataset.k = (t.text + ' ' + t.layer + ' ' + t.comp).toLowerCase();
                el.innerHTML = '<div class="ed-head"><span class="ed-where"></span></div><textarea rows="1"></textarea>' +
                    '<div class="ed-row"><button class="btn sm grow ed-font"></button><input type="number" class="num ed-size" min="1" step="1"><input type="color" class="ed-color"></div>';
                el.querySelector('.ed-where').textContent = t.layer + (t.main ? '' : '  ·  ' + t.comp) + (t.keyed ? '  ·  ⏱' + t.keyed : '') + (t.expr ? '  ·  ƒx' : '');
                el.querySelector('.ed-head').appendChild(pin(t));
                var ta = el.querySelector('textarea'); ta.value = t.text;
                var grow = function () { ta.style.height = 'auto'; ta.style.height = Math.min(140, ta.scrollHeight + 2) + 'px'; };
                ta.addEventListener('input', grow); setTimeout(grow, 0);
                ta.addEventListener('change', function () { t.text = ta.value; call('proj.setText', { c: t.c, l: t.l, text: ta.value.replace(/\n/g, '\r') }, el); });
                var fb = el.querySelector('.ed-font'); fb.textContent = t.font || '—'; fb.title = MK.t('pj.font');
                fb.onclick = function () { MK.fonts.pick(t.font).then(function (f) { if (!f) { return; } call('proj.setText', { c: t.c, l: t.l, font: f.ps }, el).then(function (r) { t.font = r.font; fb.textContent = r.font; }); }); };
                var sz = el.querySelector('.ed-size'); sz.value = t.size || ''; sz.title = MK.t('pj.size');
                sz.onchange = function () { var v = parseFloat(sz.value); if (v > 0) { call('proj.setText', { c: t.c, l: t.l, size: v }, el); } };
                var co = el.querySelector('.ed-color'); co.value = t.color || '#ffffff'; co.title = MK.t('pj.color');
                co.onchange = function () { call('proj.setText', { c: t.c, l: t.l, color: co.value }, el); };
                inT.appendChild(el);
            });
            box.appendChild(st);
        }

        if (d.colors.length) {
            var sco = sec('edColors', MK.t('pj.colors'), d.colors.length), inCo = sco.querySelector('.ed-in');
            var hint = document.createElement('p'); hint.className = 'hint'; hint.textContent = MK.t('pj.colorsHint'); inCo.appendChild(hint);
            var wrap = document.createElement('div'); wrap.className = 'ed-swatches';
            d.colors.forEach(function (c) {
                var lab = document.createElement('label'); lab.className = 'ed-sw'; lab.title = c.hex + ' · ' + c.n + '×';
                lab.innerHTML = '<input type="color"><small></small>';
                var inp = lab.querySelector('input'); inp.value = c.hex;
                lab.style.background = c.hex; lab.querySelector('small').textContent = c.n;
                inp.onchange = function () {
                    var to = inp.value.toLowerCase(), from = c.hex;
                    if (to === from) { return; }
                    call('proj.recolor', { compId: ed.compId, from: from, to: to }, lab).then(function (r) {
                        c.hex = to; lab.style.background = to; lab.title = to + ' · ' + c.n + '×';
                        MK.toast(MK.t('pj.recolored', { n: r.count }));
                    }, function () { inp.value = from; });
                };
                wrap.appendChild(lab);
            });
            inCo.appendChild(wrap);
            box.appendChild(sco);
        }

        if (d.media.length) {
            var sm = sec('edMedia', MK.t('pj.media'), d.media.length), inM = sm.querySelector('.ed-in');
            var keepLbl = document.createElement('label'); keepLbl.className = 'check';
            keepLbl.innerHTML = '<input type="checkbox" id="edKeep" checked><span>' + esc(MK.t('pj.keepSize')) + '</span>';
            inM.appendChild(keepLbl);
            d.media.forEach(function (m) {
                var row = document.createElement('div'); row.className = 'ed-media' + (m.missing ? ' missing' : '');
                var kind = m.audio && !m.video ? '♪' : (m.still ? '🖼' : '🎞');
                row.innerHTML = '<div class="ed-mthumb"></div><div class="ed-minfo"><b></b><small></small></div><button class="btn sm">' + esc(MK.t('pj.replace')) + '</button>';
                var th = row.querySelector('.ed-mthumb');
                if (m.still && m.path && /\.(png|jpe?g|gif|webp|bmp)$/i.test(m.path) && MK.fs.exists(m.path)) { th.style.backgroundImage = 'url("' + MK.fs.fileUrl(m.path) + '")'; } else { th.textContent = kind; }
                row.querySelector('b').textContent = m.name;
                row.querySelector('small').textContent = (m.w ? m.w + '×' + m.h : '') + (m.still ? '' : (m.dur ? '  ·  ' + m.dur + 's' : '')) + '  ·  ' + MK.t('pj.uses', { n: m.uses }) + (m.missing ? '  ·  ' + MK.t('pj.missing') : '');
                row.querySelector('button').onclick = function () {
                    var b = this;
                    MK.busy(b, function () {
                        return MK.host('app.chooseFile', { title: MK.t('pj.replace') + ': ' + m.name }).then(function (p) {
                            if (!p) { return; }
                            return call('proj.replaceMedia', { itemId: m.id, path: p, keepSize: MK.$('#edKeep').checked }, row).then(function (r) {
                                m.name = r.name; m.w = r.w; m.h = r.h; m.missing = false; m.path = p;
                                row.classList.remove('missing');
                                row.querySelector('b').textContent = r.name;
                                if (/\.(png|jpe?g|gif|webp|bmp)$/i.test(p)) { th.textContent = ''; th.style.backgroundImage = 'url("' + MK.fs.fileUrl(p) + '")'; }
                                MK.toast(MK.t('pj.replaced'));
                            });
                        });
                    });
                };
                inM.appendChild(row);
            });
            box.appendChild(sm);
        }

        var sx = sec('edComp2', MK.t('pj.compSet'), '', false), inX = sx.querySelector('.ed-in');
        inX.innerHTML = '<div class="form two"><label><span>' + esc(MK.t('pj.duration')) + '</span><input type="number" id="edDur" step="0.5" min="0.1"></label>' +
            '<label><span>FPS</span><input type="number" id="edFps" step="1" min="1"></label></div>';
        box.appendChild(sx);
        MK.$('#edDur').value = d.comp.dur; MK.$('#edFps').value = d.comp.fps;
        MK.$('#edDur').onchange = function () { call('proj.setComp', { compId: ed.compId, duration: this.value }, this.parentNode); };
        MK.$('#edFps').onchange = function () { call('proj.setComp', { compId: ed.compId, fps: this.value }, this.parentNode); };
        if (d.partial) { var pn = document.createElement('p'); pn.className = 'hint'; pn.textContent = MK.t('pj.partial'); box.appendChild(pn); }
    }

    function showSub(sub) {
        MK.$$('#tab-projects .sub').forEach(function (s) { s.classList.toggle('active', s.id === 'sub-pj-' + sub); });
    }

    MK.initProjects = function () {
        var s = MK.settings.projects || {};
        MK.$$('#pjMode button').forEach(function (b) { b.classList.toggle('active', b.dataset.v === (s.mode || 'open')); });
        if (s.fit !== undefined) { MK.$('#pjFit').checked = s.fit; }
        if (s.openEd !== undefined) { MK.$('#pjOpenEd').checked = s.openEd; }
        var save = function () { MK.settings.projects = { mode: MK.segValue(MK.$('#pjMode'), 'data-v'), fit: MK.$('#pjFit').checked, openEd: MK.$('#pjOpenEd').checked }; MK.saveSettings(); };
        MK.seg(MK.$('#pjMode'), save);
        MK.$('#pjFit').addEventListener('change', save);
        MK.$('#pjOpenEd').addEventListener('change', save);
        MK.seg(MK.$('#pjSeg'), function (b) {
            showSub(b.dataset.sub);
            if (b.dataset.sub === 'editor' && !ed.data) { loadEditor(0); }
        });
        MK.$('#pjSearch').addEventListener('input', render);
        MK.$('#pjAddAep').onclick = function () { addAep(this); };
        MK.$('#pjAddFolder').onclick = function () { addFolder(this); };
        MK.$('#pjAddCur').onclick = function () { addCurrent(this); };
        MK.$('#pjSaveComp').onclick = function () { saveComp(this); };
        MK.$('#pjOpenLib').onclick = function () { MK.fs.mkdirp(root()); MK.host('app.openFolder', { path: root() }).catch(MK.fail); };
        MK.$('#pjRefresh').onclick = function () { scan(); renderCats(); render(); };
        MK.$('#pjLibRoot').onclick = function () { chooseLibRoot(this); };
        libLabel();
        (MK.onLang = MK.onLang || []).push(libLabel);
        MK.$('#edActive').onclick = function () { loadEditor(0); };
        MK.$('#edRefresh').onclick = function () { loadEditor(ed.compId); };
        MK.tabs.onShow.projects = function () { if (!lib.loaded && MK.hasNode) { scan(); renderCats(); render(); } };
    };

    MK._proj = { scan: scan, saveMeta: saveMeta, chooseLibRoot: chooseLibRoot, root: root, cleanName: cleanName, guessCat: guessCat, pickAep: pickAep, rootForAep: rootForAep, findAeps: findAeps, findPreview: findPreview, copyDir: copyDir, lib: lib, ed: ed, render: render, renderEditor: renderEditor, renderCats: renderCats };
})(window);
