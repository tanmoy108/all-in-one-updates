/*  All In One — host bootstrap (ExtendScript, ES3)
    Loaded by CEP at panel start (manifest ScriptPath).
    The panel then calls MK_load(<extension root>) to pull in every module,
    and every action goes through MK_call("module.fn", "<uri-encoded JSON>").
*/
var MKH = MKH || {};

(function () {
    var HEX = '0123456789abcdef';

    function hex4(n) {
        return HEX.charAt((n >> 12) & 15) + HEX.charAt((n >> 8) & 15) +
               HEX.charAt((n >> 4) & 15) + HEX.charAt(n & 15);
    }

    // ASCII-only JSON string quoting (keeps Bangla & every non-ASCII char safe in transport)
    MKH.quote = function (s) {
        s = String(s);
        var out = '"';
        for (var i = 0; i < s.length; i++) {
            var c = s.charCodeAt(i);
            var ch = s.charAt(i);
            if (ch === '"') { out += '\\"'; }
            else if (ch === '\\') { out += '\\\\'; }
            else if (c === 10) { out += '\\n'; }
            else if (c === 13) { out += '\\r'; }
            else if (c === 9) { out += '\\t'; }
            else if (c < 32 || c > 126) { out += '\\u' + hex4(c); }
            else { out += ch; }
        }
        return out + '"';
    };

    MKH.stringify = function (v) {
        if (v === null || v === undefined) { return 'null'; }
        var t = typeof v;
        if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
        if (t === 'boolean') { return v ? 'true' : 'false'; }
        if (t === 'string') { return MKH.quote(v); }
        if (t === 'function') { return 'null'; }
        if (v instanceof Array) {
            var a = [];
            for (var i = 0; i < v.length; i++) { a.push(MKH.stringify(v[i])); }
            return '[' + a.join(',') + ']';
        }
        if (t === 'object') {
            var p = [];
            for (var k in v) {
                if (v.hasOwnProperty(k) && typeof v[k] !== 'function') {
                    p.push(MKH.quote(k) + ':' + MKH.stringify(v[k]));
                }
            }
            return '{' + p.join(',') + '}';
        }
        return 'null';
    };

    // Payloads only ever come from our own panel, so eval-based parsing is acceptable here.
    MKH.parse = function (s) {
        if (!s) { return {}; }
        return eval('(' + s + ')');
    };

    MKH.loaded = MKH.loaded || false;
    MKH.root = MKH.root || '';
})();

function MK_load(root) {
    try {
        MKH.root = root;
        var files = ['util', 'quick', 'ease', 'text', 'captions', 'broll', 'ai', 'tools', 'export', 'create', 'motion', 'sfx', 'counter', 'projects', 'check', 'extra'];
        for (var i = 0; i < files.length; i++) {
            var f = new File(root + '/host/ae/' + files[i] + '.jsx');
            if (!f.exists) { return MKH.stringify({ ok: false, error: 'Missing host file: ' + f.fsName }); }
            $.evalFile(f);
        }
        MKH.loaded = true;
        return MKH.stringify({ ok: true, data: { version: app.version, build: app.buildNumber } });
    } catch (e) {
        return MKH.stringify({ ok: false, error: 'Load failed: ' + e.toString() + (e.line ? ' (line ' + e.line + ')' : '') });
    }
}

function MK_call(fn, payload) {
    var undo = false;
    try {
        if (!MKH.loaded) { return MKH.stringify({ ok: false, error: 'NOT_LOADED' }); }
        var args = payload ? MKH.parse(decodeURIComponent(payload)) : {};
        var parts = String(fn).split('.');
        var mod = MKH[parts[0]];
        var f = mod ? mod[parts[1]] : null;
        if (typeof f !== 'function') { return MKH.stringify({ ok: false, error: 'Unknown function: ' + fn }); }
        // read-only helpers are prefixed with "get"/"list"/"info" and skip the undo group
        var ro = /^(get|list|info|read|choose|peek|raw)/.test(parts[1]);
        if (!ro) { app.beginUndoGroup('All In One: ' + parts[1]); undo = true; }
        var data = f(args || {});
        if (undo) { app.endUndoGroup(); undo = false; }
        return MKH.stringify({ ok: true, data: (data === undefined ? null : data) });
    } catch (e) {
        if (undo) { try { app.endUndoGroup(); } catch (e2) {} }
        var msg = (e && e.message) ? e.message : String(e);
        if (e && e.line && !/^[A-Z_]+$/.test(msg)) { msg += ' (line ' + e.line + ')'; }
        return MKH.stringify({ ok: false, error: msg });
    }
}
