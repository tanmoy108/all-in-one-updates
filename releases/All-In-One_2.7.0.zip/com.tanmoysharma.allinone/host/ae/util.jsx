/* All In One — shared ExtendScript helpers (ES3) */
MKH.util = (function () {
    var U = {};

    U.comp = function () {
        var c = app.project ? app.project.activeItem : null;
        if (!c || !(c instanceof CompItem)) { throw new Error('NO_COMP'); }
        return c;
    };

    U.compOrNull = function () {
        var c = app.project ? app.project.activeItem : null;
        return (c && c instanceof CompItem) ? c : null;
    };

    U.arr = function (coll) {
        var out = [];
        if (coll) { for (var i = 0; i < coll.length; i++) { out.push(coll[i]); } }
        return out;
    };

    U.sel = function (c, min) {
        var s = c.selectedLayers;
        if (!s || s.length < (min || 1)) { throw new Error('NO_LAYER'); }
        var out = [];
        for (var i = 0; i < s.length; i++) { out.push(s[i]); }
        return out;
    };

    U.selSorted = function (c, min) {
        var s = U.sel(c, min);
        s.sort(function (a, b) { return a.index - b.index; });
        return s;
    };

    U.textLayers = function (c) {
        var s = U.sel(c), out = [];
        for (var i = 0; i < s.length; i++) { if (s[i] instanceof TextLayer) { out.push(s[i]); } }
        if (!out.length) { throw new Error('NO_TEXT_LAYER'); }
        return out;
    };

    U.trim = function (s) { return String(s).replace(/^\s+|\s+$/g, ''); };

    U.indexOf = function (arr, v) {
        for (var i = 0; i < arr.length; i++) { if (arr[i] === v) { return i; } }
        return -1;
    };

    U.clamp = function (v, a, b) { return v < a ? a : (v > b ? b : v); };

    U.pad = function (n, w) { var s = String(n); while (s.length < w) { s = '0' + s; } return s; };

    U.deselectAll = function (c) {
        var s = c.selectedLayers;
        for (var i = 0; i < s.length; i++) { s[i].selected = false; }
    };

    U.select = function (c, layers) {
        U.deselectAll(c);
        for (var i = 0; i < layers.length; i++) { try { layers[i].selected = true; } catch (e) {} }
    };

    U.tr = function (layer) { return layer.property('ADBE Transform Group'); };

    // Any layer you can see and animate: footage, image, solid, precomp, null, adjustment, text, shape.
    // Checked by matchName / properties, NOT `instanceof AVLayer` (that is false for text and shape layers).
    U.isVisual = function (L) {
        if (!L) { return false; }
        var mn = '';
        try { mn = L.matchName; } catch (e) {}
        if (mn === 'ADBE Camera Layer' || mn === 'ADBE Light Layer') { return false; }
        if (mn === 'ADBE Text Layer' || mn === 'ADBE Vector Layer') { return true; }
        if (L.hasVideo === false) { return false; }
        var T = null;
        try { T = L.property('ADBE Transform Group'); } catch (e2) {}
        return !!(T && T.property('ADBE Opacity'));
    };
    U.isShape = function (L) { try { return L.matchName === 'ADBE Vector Layer'; } catch (e) { return false; } };

    // set x/y of a 2- or 3-value property without caring which length AE expects
    U.setXY = function (prop, x, y, z) {
        var v = prop.value;
        if (v instanceof Array) {
            v[0] = x; v[1] = y;
            if (v.length > 2 && z !== undefined) { v[2] = z; }
            prop.setValue(v);
        } else {
            prop.setValue([x, y]);
        }
    };

    U.prop = function (layer, mn) { return U.tr(layer).property(mn); };

    // Offset a (possibly keyframed / separated) position by [dx, dy]
    U.shiftPosition = function (layer, dx, dy) {
        var t = U.tr(layer);
        var pos = t.property('ADBE Position');
        var props;
        if (pos.dimensionsSeparated) {
            props = [[t.property('ADBE Position_0'), dx], [t.property('ADBE Position_1'), dy]];
            for (var p = 0; p < props.length; p++) {
                var pr = props[p][0], d = props[p][1];
                if (pr.numKeys > 0) {
                    for (var k = 1; k <= pr.numKeys; k++) { pr.setValueAtKey(k, pr.keyValue(k) + d); }
                } else { pr.setValue(pr.value + d); }
            }
            return;
        }
        if (pos.numKeys > 0) {
            for (var i = 1; i <= pos.numKeys; i++) {
                var v = pos.keyValue(i);
                v[0] += dx; v[1] += dy;
                pos.setValueAtKey(i, v);
            }
        } else {
            var cv = pos.value;
            cv[0] += dx; cv[1] += dy;
            pos.setValue(cv);
        }
    };

    U.getPos = function (layer, time) {
        var t = U.tr(layer);
        var pos = t.property('ADBE Position');
        if (pos.dimensionsSeparated) {
            return [t.property('ADBE Position_0').valueAtTime(time, false), t.property('ADBE Position_1').valueAtTime(time, false)];
        }
        return pos.valueAtTime(time, false);
    };

    U.setPosStatic = function (layer, xy) {
        var t = U.tr(layer);
        var pos = t.property('ADBE Position');
        if (pos.dimensionsSeparated) {
            var px = t.property('ADBE Position_0'), py = t.property('ADBE Position_1');
            if (px.numKeys === 0) { px.setValue(xy[0]); }
            if (py.numKeys === 0) { py.setValue(xy[1]); }
            return;
        }
        if (pos.numKeys > 0) {
            var cur = pos.valueAtTime(layer.containingComp.time, false);
            U.shiftPosition(layer, xy[0] - cur[0], xy[1] - cur[1]);
            return;
        }
        var v = pos.value;
        v[0] = xy[0]; v[1] = xy[1];
        pos.setValue(v);
    };

    U.rotZ = function (layer, time) {
        var r = U.tr(layer).property('ADBE Rotate Z');
        return r ? r.valueAtTime(time, false) : 0;
    };

    // Rotate + scale a layer-space vector into parent space (2D)
    U.layerVecToParent = function (layer, vx, vy, time) {
        var sc = U.tr(layer).property('ADBE Scale').valueAtTime(time, false);
        var a = U.rotZ(layer, time) * Math.PI / 180;
        var x = vx * sc[0] / 100, y = vy * sc[1] / 100;
        return [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)];
    };

    // Move the anchor point to a point in layer space while keeping the layer visually in place
    U.setAnchorKeep = function (layer, ax, ay, time) {
        var ap = U.tr(layer).property('ADBE Anchor Point');
        if (ap.numKeys > 0) { return false; }
        var cur = ap.value;
        var d = U.layerVecToParent(layer, ax - cur[0], ay - cur[1], time);
        var nv = cur.length > 2 ? [ax, ay, cur[2]] : [ax, ay];
        ap.setValue(nv);
        U.shiftPosition(layer, d[0], d[1]);
        return true;
    };

    // Bounding box of a layer in parent/comp space (2D, ignores parent chain)
    U.bounds = function (layer, time) {
        var r = layer.sourceRectAtTime(time, false);
        var ap = U.tr(layer).property('ADBE Anchor Point').valueAtTime(time, false);
        var pos = U.getPos(layer, time);
        var corners = [[r.left, r.top], [r.left + r.width, r.top], [r.left, r.top + r.height], [r.left + r.width, r.top + r.height]];
        var minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (var i = 0; i < 4; i++) {
            var v = U.layerVecToParent(layer, corners[i][0] - ap[0], corners[i][1] - ap[1], time);
            var x = pos[0] + v[0], y = pos[1] + v[1];
            if (x < minX) { minX = x; } if (y < minY) { minY = y; }
            if (x > maxX) { maxX = x; } if (y > maxY) { maxY = y; }
        }
        return { left: minX, top: minY, right: maxX, bottom: maxY, width: maxX - minX, height: maxY - minY };
    };

    // Walk every leaf property of a property group
    U.walk = function (group, cb) {
        for (var i = 1; i <= group.numProperties; i++) {
            var p = group.property(i);
            if (!p) { continue; }
            if (p.propertyType === PropertyType.PROPERTY) { cb(p); }
            else { U.walk(p, cb); }
        }
    };

    U.waitForFile = function (f, ms) {
        var waited = 0;
        while (!f.exists && waited < ms) { $.sleep(40); waited += 40; }
        return f.exists;
    };

    U.ensureFolder = function (path) {
        var f = new Folder(path);
        if (!f.exists) { f.create(); }
        return f;
    };

    U.projectFolder = function (name) {
        var root = app.project.rootFolder;
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof FolderItem && it.name === name && it.parentFolder === root) { return it; }
        }
        return app.project.items.addFolder(name);
    };

    return U;
})();

/* ---------- app-level info / dialogs ---------- */
MKH.app = {
    info: function () {
        var c = MKH.util.compOrNull();
        var o = {
            version: app.version,
            lang: $.locale,
            os: $.os,
            projectPath: (app.project && app.project.file) ? app.project.file.fsName : '',
            comp: null,
            selected: 0
        };
        if (c) {
            o.comp = { name: c.name, width: c.width, height: c.height, fps: c.frameRate, duration: c.duration, time: c.time };
            o.selected = c.selectedLayers.length;
        }
        return o;
    },

    listFonts: function () {
        var out = [];
        try {
            if (app.fonts && app.fonts.allFonts) {
                var fams = app.fonts.allFonts;
                for (var i = 0; i < fams.length; i++) {
                    var fam = fams[i];
                    for (var j = 0; j < fam.length; j++) {
                        out.push([fam[j].postScriptName, fam[j].familyName + ' ' + fam[j].styleName, fam[j].familyName, fam[j].styleName]);
                    }
                }
            }
        } catch (e) {}
        return out;
    },

    chooseFile: function (a) {
        var win = $.os.indexOf('Windows') >= 0;
        var f = File.openDialog(a.title || 'Choose file', win ? (a.filter || '') : null, false);
        return f ? f.fsName : '';
    },

    chooseFiles: function (a) {
        var win = $.os.indexOf('Windows') >= 0;
        var list = File.openDialog(a.title || 'Choose files', win ? (a.filter || '') : null, true);
        var out = [];
        if (list) {
            if (!(list instanceof Array)) { list = [list]; }
            for (var i = 0; i < list.length; i++) {
                if (!a.ext || new RegExp('\\.(' + a.ext + ')$', 'i').test(list[i].name)) { out.push(list[i].fsName); }
            }
        }
        return out;
    },

    chooseSave: function (a) {
        var win = $.os.indexOf('Windows') >= 0;
        var f = new File(Folder.myDocuments.fsName + '/' + (a.name || 'untitled')).saveDlg(a.title || 'Save as', win ? (a.filter || '') : null);
        return f ? f.fsName : '';
    },

    chooseFolder: function (a) {
        var f = Folder.selectDialog(a.title || 'Choose folder');
        return f ? f.fsName : '';
    },

    seek: function (a) {
        var c = MKH.util.comp();
        c.time = Math.max(0, Math.min(c.duration, parseFloat(a.time) || 0));
        return true;
    },

    openFolder: function (a) {
        var f = new Folder(a.path);
        if (!f.exists) { f.create(); }
        f.execute();
        return true;
    }
};
