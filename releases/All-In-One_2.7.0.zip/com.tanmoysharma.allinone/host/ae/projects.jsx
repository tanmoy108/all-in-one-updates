/* All In One — Project Library + Template Editor (ExtendScript, ES3)
   Library: inspect an .aep (main comp, comps, thumbnail) and import it in one click.
   Editor: list every text, colour, media file and expression control inside a comp
   (and its precomps) and change them from the panel. */
MKH.proj = (function () {
    var U = MKH.util;
    var P = {};
    var BIN = 'AIO Projects';
    var MAIN_RX = /(^|[^a-z])(final|main|render|output|master|preview|full|edit)([^a-z]|$)/i;
    var SKIP_RX = /^(_|old|backup|ref|reference|guide)|do not render|don'?t render/i;
    var CONTROL_MN = {
        'ADBE Slider Control': 'slider', 'ADBE Checkbox Control': 'checkbox', 'ADBE Color Control': 'color',
        'ADBE Point Control': 'point', 'ADBE Point3D Control': 'point3', 'ADBE Angle Control': 'angle', 'ADBE Dropdown Control': 'dropdown'
    };

    /* ---------- helpers ---------- */
    function suppress(on) { try { if (on) { app.beginSuppressDialogs(); } else { app.endSuppressDialogs(false); } } catch (e) {} }
    function r2(n, d) { var k = Math.pow(10, d || 2); return Math.round(n * k) / k; }
    function h2(n) { var s = Math.round(U.clamp(n, 0, 1) * 255).toString(16); return s.length < 2 ? '0' + s : s; }
    function hex(c) { return (c && c.length >= 3) ? '#' + h2(c[0]) + h2(c[1]) + h2(c[2]) : ''; }
    function rgb(h) {
        h = String(h).replace('#', '');
        if (h.length === 3) { h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2); }
        return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255];
    }
    function withAlpha(c, old) { return (old && old.length === 4) ? [c[0], c[1], c[2], old[3]] : c; }

    function importAep(path) {
        var f = new File(path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var item;
        suppress(true);
        try { item = app.project.importFile(new ImportOptions(f)); } finally { suppress(false); }
        if (!item) { throw new Error('IMPORT_FAILED'); }
        return item;
    }
    function walkFolder(folder, cb) {
        for (var i = 1; i <= folder.numItems; i++) {
            var it = folder.item(i);
            cb(it);
            if (it instanceof FolderItem) { walkFolder(it, cb); }
        }
    }
    function compsIn(folder) {
        var out = [];
        walkFolder(folder, function (it) { if (it instanceof CompItem) { out.push(it); } });
        return out;
    }
    function pickMain(comps) {
        var used = {}, i, j;
        for (i = 0; i < comps.length; i++) {
            for (j = 1; j <= comps[i].numLayers; j++) {
                var s = comps[i].layer(j).source;
                if (s && s instanceof CompItem) { used[s.id] = true; }
            }
        }
        var best = null, bs = -1e9;
        for (i = 0; i < comps.length; i++) {
            var c = comps[i], sc = 0;
            if (!used[c.id]) { sc += 500; }
            if (MAIN_RX.test(c.name)) { sc += 1000; }
            if (SKIP_RX.test(c.name)) { sc -= 2000; }
            sc += Math.min(c.numLayers, 60) * 5 + Math.min(c.duration, 120) + (c.width * c.height) / 1e5;
            if (sc > bs) { bs = sc; best = c; }
        }
        return best;
    }
    function compInfo(c) {
        return c ? { id: c.id, name: c.name, w: c.width, h: c.height, dur: r2(c.duration), fps: r2(c.frameRate, 3), layers: c.numLayers } : null;
    }
    function compById(id) {
        id = parseInt(id, 10);
        try { if (app.project.itemByID) { var it = app.project.itemByID(id); if (it) { return it; } } } catch (e) {}
        for (var i = 1; i <= app.project.numItems; i++) { if (app.project.item(i).id === id) { return app.project.item(i); } }
        return null;
    }
    function targetComp(a) {
        if (a && a.compId) {
            var c = compById(a.compId);
            if (c && c instanceof CompItem) { return c; }
            throw new Error('COMP_GONE');
        }
        return U.comp();
    }
    function layerOf(a) {
        var c = compById(a.c);
        if (!c || !(c instanceof CompItem)) { throw new Error('COMP_GONE'); }
        if (a.l < 1 || a.l > c.numLayers) { throw new Error('LAYER_GONE'); }
        return c.layer(a.l);
    }
    // the comp and every precomp inside it (each once)
    function allComps(root) {
        var seen = {}, out = [];
        (function go(c, d) {
            if (seen[c.id] || d > 8) { return; }
            seen[c.id] = true; out.push(c);
            for (var i = 1; i <= c.numLayers; i++) {
                var s = c.layer(i).source;
                if (s && s instanceof CompItem) { go(s, d + 1); }
            }
        })(root, 0);
        return out;
    }
    function isText(L) { try { return L.property('ADBE Text Properties') !== null; } catch (e) { return false; } }
    function textProp(L) { return L.property('ADBE Text Properties').property('ADBE Text Document'); }
    function hasExpr(p) { try { return p.canSetExpression && p.expressionEnabled && p.expression !== ''; } catch (e) { return false; } }

    // every COLOR property of a layer (shape fills/strokes, effects, layer styles, text animators…)
    function walkColors(group, fn, budget) {
        for (var i = 1; i <= group.numProperties; i++) {
            if (budget.n-- <= 0) { return; }
            var p;
            try { p = group.property(i); } catch (e) { continue; }
            if (!p) { continue; }
            if (p.propertyType === PropertyType.PROPERTY) {
                try { if (p.propertyValueType === PropertyValueType.COLOR) { fn(p); } } catch (e2) {}
            } else {
                try { walkColors(p, fn, budget); } catch (e3) {}
            }
        }
    }

    /* ======================= LIBRARY ======================= */

    // import, find the comps + main comp, optionally render a thumbnail, then remove everything again
    P.inspect = function (a) {
        var prev = app.project.activeItem;
        var fol = importAep(a.path), info = null, list = [];
        try {
            var comps = compsIn(fol);
            if (!comps.length) { throw new Error('NO_COMP_IN_PROJECT'); }
            var main = pickMain(comps);
            if (a.main) { for (var i = 0; i < comps.length; i++) { if (comps[i].name === a.main) { main = comps[i]; break; } } }
            info = compInfo(main);
            comps.sort(function (x, y) { return (y === main) - (x === main) || y.numLayers - x.numLayers; });
            for (var k = 0; k < comps.length && k < 40; k++) { list.push(compInfo(comps[k])); }
            if (a.thumb) {
                var f = new File(a.thumb);
                if (f.exists) { f.remove(); }
                var t = main.workAreaStart + main.workAreaDuration * (a.at === undefined ? 0.45 : a.at);
                try {
                    main.saveFrameToPng(t, f);
                    U.waitForFile(f, 30000);
                    $.sleep(250);
                } catch (eT) {}
                info.thumb = f.exists;
            }
        } finally {
            try { fol.remove(); } catch (eR) {}
            try { if (prev && prev instanceof CompItem) { prev.openInViewer(); } } catch (eV) {}
        }
        return { main: info, comps: list, aeVersion: app.version };
    };

    P.importProject = function (a) {
        var active = U.compOrNull();
        var t = active ? active.time : 0;
        var fol = importAep(a.path);
        try { if (a.name) { fol.name = a.name; } } catch (e) {}
        try { fol.parentFolder = U.projectFolder(BIN); } catch (e2) {}
        var comps = compsIn(fol), main = null;
        if (!comps.length) { throw new Error('NO_COMP_IN_PROJECT'); }
        if (a.main) { for (var i = 0; i < comps.length; i++) { if (comps[i].name === a.main) { main = comps[i]; break; } } }
        if (!main) { main = pickMain(comps); }
        var placed = false;
        if (a.mode === 'add' && active) {
            var L = active.layers.add(main);
            L.startTime = t;
            if (a.fit && (main.width !== active.width || main.height !== active.height)) {
                var k = Math.min(active.width / main.width, active.height / main.height) * 100;
                U.setXY(U.tr(L).property('ADBE Scale'), k, k, k);
            }
            U.select(active, [L]);
            placed = true;
        } else {
            try { main.openInViewer(); } catch (e3) {}
        }
        return { comp: compInfo(main), placed: placed, comps: comps.length };
    };

    // read-only: the saved project + active comp (for "add current project")
    P.peekCurrent = function () {
        var f = app.project.file, c = U.compOrNull();
        return { path: f ? f.fsName : '', name: f ? decodeURI(f.name).replace(/\.aepx?$/i, '') : '', dirty: !!app.project.dirty, comp: c ? c.name : '' };
    };

    /* ======================= EDITOR ======================= */
    P.readScan = function (a) {
        var root = targetComp(a);
        var comps = allComps(root);
        var texts = [], colors = {}, media = {}, mediaList = [], controls = [];
        var budget = { n: 80000 };
        var addColor = function (c, kind) {
            var h = hex(c);
            if (!h) { return; }
            if (!colors[h]) { colors[h] = { hex: h, n: 0, kinds: {} }; }
            colors[h].n++; colors[h].kinds[kind] = true;
        };
        for (var ci = 0; ci < comps.length; ci++) {
            var C = comps[ci];
            for (var li = 1; li <= C.numLayers; li++) {
                var L = C.layer(li);
                if (isText(L)) {
                    var tp = textProp(L), td = null;
                    try { td = tp.valueAtTime(0, true); } catch (e0) { try { td = tp.value; } catch (e1) {} }
                    if (td && texts.length < 400) {
                        var row = { c: C.id, l: li, comp: C.name, layer: L.name, text: String(td.text), keyed: tp.numKeys, expr: hasExpr(tp), main: C === root };
                        try { row.font = td.font; row.size = r2(td.fontSize, 1); } catch (e2) {}
                        try { if (td.applyFill) { row.color = hex(td.fillColor); addColor(td.fillColor, 'text'); } } catch (e3) {}
                        try { if (td.applyStroke) { addColor(td.strokeColor, 'text'); } } catch (e4) {}
                        texts.push(row);
                    }
                }
                var src = L.source;
                if (src && !(src instanceof CompItem) && src.mainSource) {
                    var ms = src.mainSource;
                    if (ms instanceof SolidSource) { addColor(ms.color, 'solid'); }
                    else if (!media[src.id]) {
                        var isFile = ms instanceof FileSource, ph = (typeof PlaceholderSource !== 'undefined') && ms instanceof PlaceholderSource;
                        if (isFile || ph) {
                            media[src.id] = { id: src.id, name: src.name, w: src.width || 0, h: src.height || 0, still: !!ms.isStill, video: !!src.hasVideo, audio: !!src.hasAudio,
                                missing: !!src.footageMissing || ph, path: (isFile && ms.file) ? ms.file.fsName : '', uses: 0, dur: r2(src.duration || 0) };
                            mediaList.push(media[src.id]);
                        }
                    }
                    if (media[src.id]) { media[src.id].uses++; }
                }
                walkColors(L, function (p) {
                    if (p.numKeys > 0) { for (var k = 1; k <= p.numKeys && k <= 50; k++) { addColor(p.keyValue(k), 'prop'); } }
                    else { addColor(p.value, 'prop'); }
                }, budget);
                // expression controls
                var fx = null;
                try { fx = L.property('ADBE Effect Parade'); } catch (e5) {}
                if (fx && controls.length < 300) {
                    for (var ei = 1; ei <= fx.numProperties; ei++) {
                        var ef = fx.property(ei), type = CONTROL_MN[ef.matchName];
                        if (!type) { continue; }
                        var vp = ef.property(1), v = null;
                        try { v = vp.value; } catch (e6) {}
                        if (type === 'color') { v = hex(v); }
                        else if (v instanceof Array) { var vv = []; for (var q = 0; q < v.length; q++) { vv.push(r2(v[q], 2)); } v = vv; }
                        else if (typeof v === 'number') { v = r2(v, 3); }
                        controls.push({ c: C.id, l: li, e: ei, comp: C.name, layer: L.name, name: ef.name, type: type, v: v, keyed: vp.numKeys, main: C === root });
                    }
                }
            }
        }
        var cl = [];
        for (var h in colors) { if (colors.hasOwnProperty(h)) { var o = colors[h], ks = []; for (var kk in o.kinds) { if (o.kinds.hasOwnProperty(kk)) { ks.push(kk); } } cl.push({ hex: o.hex, n: o.n, kinds: ks.join(',') }); } }
        cl.sort(function (x, y) { return y.n - x.n; });
        return { comp: compInfo(root), comps: comps.length, texts: texts, colors: cl.slice(0, 60), media: mediaList, controls: controls, partial: budget.n <= 0 };
    };

    P.setText = function (a) {
        var L = layerOf(a);
        if (!isText(L)) { throw new Error('NO_TEXT_LAYER'); }
        var p = textProp(L);
        var edit = function (td) {
            if (a.text !== undefined) { td.text = String(a.text); }
            if (a.font) { td.font = a.font; }
            if (a.size) { td.fontSize = parseFloat(a.size); }
            if (a.color) { td.applyFill = true; td.fillColor = rgb(a.color); }
            return td;
        };
        if (p.numKeys > 0) {
            for (var k = 1; k <= p.numKeys; k++) { p.setValueAtKey(k, edit(p.keyValue(k))); }
        } else {
            var td;
            try { td = p.valueAtTime(0, true); } catch (e) { td = p.value; }
            p.setValue(edit(td));
        }
        var now = p.value;
        return { font: now.font, size: r2(now.fontSize, 1), keys: p.numKeys };
    };

    // replace one colour everywhere in the comp and its precomps
    P.recolor = function (a) {
        var root = targetComp(a), comps = allComps(root);
        var from = String(a.from).toLowerCase(), to = rgb(a.to), n = 0, budget = { n: 120000 };
        var match = function (c) { return hex(c) === from; };
        var doneSolids = {};
        for (var ci = 0; ci < comps.length; ci++) {
            var C = comps[ci];
            for (var li = 1; li <= C.numLayers; li++) {
                var L = C.layer(li);
                if (isText(L)) {
                    var tp = textProp(L);
                    var fix = function (td) {
                        var ch = false;
                        try { if (td.applyFill && match(td.fillColor)) { td.fillColor = to; ch = true; } } catch (e) {}
                        try { if (td.applyStroke && match(td.strokeColor)) { td.strokeColor = to; ch = true; } } catch (e2) {}
                        return ch;
                    };
                    try {
                        if (tp.numKeys > 0) { for (var k = 1; k <= tp.numKeys; k++) { var kd = tp.keyValue(k); if (fix(kd)) { tp.setValueAtKey(k, kd); n++; } } }
                        else { var d = tp.valueAtTime(0, true); if (fix(d)) { tp.setValue(d); n++; } }
                    } catch (e3) {}
                }
                var src = L.source;
                if (src && src.mainSource && src.mainSource instanceof SolidSource && !doneSolids[src.id]) {
                    doneSolids[src.id] = true;
                    if (match(src.mainSource.color)) { try { src.mainSource.color = to; n++; } catch (e4) {} }
                }
                walkColors(L, function (p) {
                    try {
                        if (p.numKeys > 0) {
                            for (var k2 = 1; k2 <= p.numKeys; k2++) { var kv = p.keyValue(k2); if (match(kv)) { p.setValueAtKey(k2, withAlpha(to, kv)); n++; } }
                        } else if (match(p.value)) { p.setValue(withAlpha(to, p.value)); n++; }
                    } catch (e5) {}
                }, budget);
            }
        }
        return { count: n };
    };

    P.replaceMedia = function (a) {
        var item = compById(a.itemId);
        if (!item || !(item instanceof FootageItem)) { throw new Error('ITEM_GONE'); }
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var ow = item.width, oh = item.height;
        item.replace(f);
        var n = 0;
        if (a.keepSize && ow && oh && item.width && item.height && (item.width !== ow || item.height !== oh)) {
            var k = Math.max(ow / item.width, oh / item.height);
            for (var i = 1; i <= app.project.numItems; i++) {
                var c = app.project.item(i);
                if (!(c instanceof CompItem)) { continue; }
                for (var j = 1; j <= c.numLayers; j++) {
                    var L = c.layer(j);
                    if (L.source !== item) { continue; }
                    var sp = U.tr(L).property('ADBE Scale');
                    try {
                        if (sp.numKeys > 0) { for (var q = 1; q <= sp.numKeys; q++) { var v = sp.keyValue(q); for (var z = 0; z < v.length; z++) { v[z] *= k; } sp.setValueAtKey(q, v); } }
                        else { var v2 = sp.value; for (var z2 = 0; z2 < v2.length; z2++) { v2[z2] *= k; } sp.setValue(v2); }
                        n++;
                    } catch (e) {}
                }
            }
        }
        return { name: item.name, w: item.width, h: item.height, rescaled: n };
    };

    P.setControl = function (a) {
        var L = layerOf(a);
        var ef = L.property('ADBE Effect Parade').property(a.e);
        if (!ef) { throw new Error('LAYER_GONE'); }
        var p = ef.property(1), v = a.v;
        if (a.type === 'color') { v = withAlpha(rgb(v), p.value); }
        else if (a.type === 'checkbox') { v = v ? 1 : 0; }
        else if (v instanceof Array) { for (var i = 0; i < v.length; i++) { v[i] = parseFloat(v[i]) || 0; } }
        else { v = parseFloat(v) || 0; }
        if (p.numKeys > 0) { p.setValueAtTime(L.containingComp.time, v); } else { p.setValue(v); }
        return { ok: true };
    };

    P.setComp = function (a) {
        var c = targetComp(a);
        if (a.duration) { c.duration = Math.max(0.1, parseFloat(a.duration)); }
        if (a.fps) { c.frameRate = U.clamp(parseFloat(a.fps), 1, 999); }
        return compInfo(c);
    };

    // read-only-ish: show a layer in its comp (no undo step)
    P.peekLayer = function (a) {
        var L = layerOf(a), c = L.containingComp;
        try { c.openInViewer(); } catch (e) {}
        U.select(c, [L]);
        return { comp: c.name };
    };


    /* ======================= SAVE COMP → LIBRARY ======================= */
    var SEQ_RX = /\.(png|jpe?g|tiff?|exr|dpx|tga|psd|bmp|cin|hdr)$/i;
    function saveTargets() {
        var out = [], sel = app.project.selection || [];
        for (var i = 0; i < sel.length; i++) { if (sel[i] instanceof CompItem) { out.push(sel[i]); } }
        if (!out.length) { var c = U.compOrNull(); if (c) { out.push(c); } }
        if (!out.length) { throw new Error('NO_COMP'); }
        return out;
    }
    // every footage file a set of comps depends on (precomps included)
    function deps(comps) {
        var seen = {}, files = [], byPath = {};
        var go = function (c, d) {
            if (seen[c.id] || d > 12) { return; }
            seen[c.id] = true;
            for (var i = 1; i <= c.numLayers; i++) {
                var s = c.layer(i).source;
                if (!s) { continue; }
                if (s instanceof CompItem) { go(s, d + 1); continue; }
                if (seen[s.id] || !(s instanceof FootageItem) || !(s.mainSource instanceof FileSource)) { continue; }
                seen[s.id] = true;
                var f = s.mainSource.file, seq = !!(f && !s.mainSource.isStill && SEQ_RX.test(f.name));
                var rec = { item: s, path: f ? f.fsName : '', missing: !f || !f.exists || !!s.footageMissing, seq: seq, size: 0, n: 0 };
                if (!rec.missing) {
                    if (seq) {
                        var ext = (/\.[^.]+$/.exec(f.name) || [''])[0].toLowerCase(), list = f.parent.getFiles();
                        for (var k = 0; k < list.length; k++) { if (list[k] instanceof File && list[k].name.toLowerCase().slice(-ext.length) === ext) { rec.size += list[k].length; rec.n++; } }
                    } else { rec.size = f.length; rec.n = 1; }
                }
                if (rec.path && byPath[rec.path]) { byPath[rec.path].items.push(s); continue; }
                rec.items = [s];
                if (rec.path) { byPath[rec.path] = rec; }
                files.push(rec);
            }
        };
        for (var j = 0; j < comps.length; j++) { go(comps[j], 0); }
        return files;
    }
    function safeName(n) { return String(n || 'Comp').replace(/[\\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '').slice(0, 80) || 'Comp'; }

    // read-only: what would be saved
    P.peekSaveTarget = function () {
        var comps = saveTargets(), files = deps(comps), size = 0, missing = 0, n = 0, names = [];
        for (var i = 0; i < files.length; i++) { size += files[i].size; n += files[i].n; if (files[i].missing) { missing++; } }
        for (var j = 0; j < comps.length; j++) { names.push(comps[j].name); }
        return { comps: names, main: compInfo(comps[0]), files: n, size: size, missing: missing, saved: !!app.project.file, dirty: !!app.project.dirty };
    };

    // a = { dir, name, collect, thumb, untitledDir }
    P.rawSaveComp = function (a) {
        var comps = saveTargets(), ids = [], i;
        for (i = 0; i < comps.length; i++) { ids.push(comps[i].id); }
        var orig = app.project.file, untitled = false;
        if (!orig) {
            var ud = new Folder(a.untitledDir); if (!ud.exists) { ud.create(); }
            orig = new File(ud.fsName + '/Untitled ' + new Date().getTime() + '.aep');
            app.project.save(orig); untitled = true;
        } else if (app.project.dirty) { app.project.save(); }
        // thumbnail from the live project (before anything changes)
        if (a.thumb) {
            try {
                var c0 = comps[0], tf = new File(a.thumb);
                if (tf.exists) { tf.remove(); }
                c0.saveFrameToPng(c0.workAreaStart + c0.workAreaDuration * 0.45, tf);
                U.waitForFile(tf, 30000); $.sleep(300);
            } catch (eT) {}
        }
        var root = new Folder(a.dir + '/files'); if (!root.exists) { root.create(); }
        var foot = new Folder(root.fsName + '/Footage');
        var aep = new File(root.fsName + '/' + safeName(a.name) + '.aep');
        var result = null, copied = 0, missing = [];
        try {
            app.project.reduceProject(comps);
            comps = [];
            for (i = 0; i < ids.length; i++) { var it = compById(ids[i]); if (it) { comps.push(it); } }
            if (a.collect) {
                var files = deps(comps), used = {};
                if (files.length && !foot.exists) { foot.create(); }
                for (var f = 0; f < files.length; f++) {
                    var r = files[f];
                    if (r.missing) { missing.push(r.path || r.item.name); continue; }
                    var src = new File(r.path);
                    if (r.seq) {
                        var sub = new Folder(foot.fsName + '/' + src.parent.name);
                        for (var q = 2; sub.exists && used[sub.fsName]; q++) { sub = new Folder(foot.fsName + '/' + src.parent.name + ' ' + q); }
                        sub.create(); used[sub.fsName] = true;
                        var ext = (/\.[^.]+$/.exec(src.name) || [''])[0].toLowerCase(), list = src.parent.getFiles();
                        for (var k = 0; k < list.length; k++) { if (list[k] instanceof File && list[k].name.toLowerCase().slice(-ext.length) === ext) { list[k].copy(sub.fsName + '/' + list[k].name); copied++; } }
                        for (var m = 0; m < r.items.length; m++) { try { r.items[m].replaceWithSequence(new File(sub.fsName + '/' + src.name), false); } catch (eS) {} }
                    } else {
                        var base = decodeURI(src.name), dest = new File(foot.fsName + '/' + base), n2 = 2;
                        while (dest.exists || used[dest.fsName]) { dest = new File(foot.fsName + '/' + base.replace(/(\.[^.]+)?$/, ' ' + n2++ + '$1')); }
                        used[dest.fsName] = true;
                        if (src.copy(dest.fsName)) { copied++; for (var m2 = 0; m2 < r.items.length; m2++) { try { r.items[m2].replace(dest); } catch (eR) {} } }
                        else { missing.push(r.path); }
                    }
                }
            }
            app.project.save(aep);
            var all = [];
            for (i = 1; i <= app.project.numItems; i++) { if (app.project.item(i) instanceof CompItem) { all.push(compInfo(app.project.item(i))); } }
            result = { aep: aep.fsName, main: compInfo(comps[0]), comps: all.slice(0, 40), copied: copied, missing: missing, untitled: untitled ? orig.fsName : '' };
        } finally {
            // always go back to the user's own project, exactly as it was saved
            try { app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES); } catch (eC) {}
            app.open(orig);
        }
        return result;
    };

    P._hex = hex; P._rgb = rgb; P._pickMain = pickMain;
    return P;
})();
