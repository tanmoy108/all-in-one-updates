/* All In One — Sound effects: import an audio file and place it in the comp (ExtendScript, ES3).
   Searching / downloading happens in the panel (Node). */
MKH.sfx = (function () {
    var U = MKH.util;
    var S = {};

    function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }

    function findItem(f) {
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            try { if (it instanceof FootageItem && it.file && it.file.fsName === f.fsName) { return it; } } catch (e) {}
        }
        return null;
    }

    function setVolume(L, db) {
        if (!db) { return; }
        try { L.property('ADBE Audio Group').property('ADBE Audio Levels').setValue([db, db]); } catch (e) {}
    }

    S.place = function (a) {
        var c = U.comp();
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var item = findItem(f);
        if (!item) {
            item = app.project.importFile(new ImportOptions(f));
            try { item.parentFolder = U.projectFolder('SFX'); } catch (e) {}
        }
        if (!item.hasAudio) { throw new Error('NO_AUDIO_IN_FILE'); }
        var times = [];
        var offset = num(a.offset, 0);
        if (a.at === 'layers') {
            var s = c.selectedLayers;
            for (var i = 0; i < s.length; i++) { times.push(s[i].inPoint + offset); }
            if (!times.length) { throw new Error('NO_LAYER'); }
        } else {
            times.push(c.time + offset);
        }
        var made = [];
        for (var j = 0; j < times.length; j++) {
            var L = c.layers.add(item);
            L.startTime = Math.max(-item.duration, times[j]);
            L.label = 14;
            setVolume(L, num(a.volume, 0));
            made.push(L);
        }
        // keep the new audio layers below the visual layers
        for (var k = 0; k < made.length; k++) { try { made[k].moveToEnd(); } catch (e2) {} }
        return { name: item.name, count: made.length };
    };

    return S;
})();
