/* All In One — Tools tab (ExtendScript, ES3)
   layers · arrange · shapes · rigs · looks · comp */
MKH.tools = (function () {
    var U = MKH.util;
    var T = {};
    var TAG = 'All In One';

    function isVisual(L) { return (L instanceof AVLayer) || (L instanceof TextLayer) || (L instanceof ShapeLayer); }
    function rnd(a, b) { return a + Math.random() * (b - a); }
    function shuffle(arr) {
        for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
        return arr;
    }
    function setPropVal(prop, v) {
        try { prop.setValue(v); return true; } catch (e) {}
        if (v instanceof Array && v.length >= 3) { try { prop.setValue(v.slice(0, v.length - 1)); return true; } catch (e2) {} }
        return false;
    }
    function fx(L, matchName, name) {
        var e = L.property('ADBE Effect Parade').addProperty(matchName);
        if (name) { e.name = name; }
        return e;
    }
    function slider(L, name, val) { var e = fx(L, 'ADBE Slider Control', name); e.property(1).setValue(val); return e; }
    function checkbox(L, name, val) { var e = fx(L, 'ADBE Checkbox Control', name); e.property(1).setValue(val ? 1 : 0); return e; }
    function colorCtl(L, name, rgb) { var e = fx(L, 'ADBE Color Control', name); setPropVal(e.property(1), [rgb[0], rgb[1], rgb[2], 1]); return e; }
    function q(s) { return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"'; }
    function uniqueName(c, base) {
        var name = base, n = 2, taken = {};
        for (var i = 1; i <= c.numLayers; i++) { taken[c.layer(i).name] = true; }
        while (taken[name]) { name = base + ' ' + n++; }
        return name;
    }
    // give every selected layer a unique name so expressions can find them
    function ensureUnique(c, layers) {
        var seen = {};
        for (var i = 0; i < layers.length; i++) {
            var nm = layers[i].name;
            if (seen[nm]) { layers[i].name = uniqueName(c, nm); }
            seen[layers[i].name] = true;
        }
    }
    // keep the selected set but put it in a new order, as one block below the topmost one's neighbour
    function restack(c, ordered) {
        var top = null;
        for (var i = 0; i < ordered.length; i++) { if (!top || ordered[i].index < top.index) { top = ordered[i]; } }
        var above = top.index > 1 ? c.layer(top.index - 1) : null;
        for (var j = ordered.length - 1; j >= 0; j--) {
            if (above) { ordered[j].moveAfter(above); } else { ordered[j].moveToBeginning(); }
        }
    }

    /* ======================= LAYERS ======================= */
    T.trimToBelow = function () {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (L.index >= c.numLayers) { continue; }
            var B = c.layer(L.index + 1);
            try {
                if (B.inPoint >= L.outPoint) { L.outPoint = B.outPoint; L.inPoint = B.inPoint; }
                else { L.inPoint = B.inPoint; L.outPoint = B.outPoint; }
                n++;
            } catch (e) {}
        }
        return { count: n };
    };

    T.randomIn = function (a) {
        var c = U.comp();
        var s = U.sel(c), max = Math.max(1, parseInt(a.frames, 10) || 10);
        for (var i = 0; i < s.length; i++) { s[i].startTime += Math.round(rnd(0, max)) * c.frameDuration; }
        return { count: s.length };
    };

    T.fade = function (a) {
        var c = U.comp();
        var s = U.sel(c), d = Math.max(1, parseInt(a.frames, 10) || 10) * c.frameDuration, n = 0, warn = [];
        for (var i = 0; i < s.length; i++) {
            var L = s[i], op = U.tr(L).property('ADBE Opacity');
            if (op.numKeys > 0) { warn.push(L.name + ': already has opacity keys'); continue; }
            var len = L.outPoint - L.inPoint;
            var both = a.mode !== 'in' && a.mode !== 'out';
            if (len < d * (both ? 2 : 1)) { warn.push(L.name + ': too short'); continue; }
            var v = op.value;
            if (a.mode !== 'out') { op.setValueAtTime(L.inPoint, 0); op.setValueAtTime(L.inPoint + d, v); }
            if (a.mode !== 'in') { op.setValueAtTime(L.outPoint - d, v); op.setValueAtTime(L.outPoint, 0); }
            n++;
        }
        return { count: n, warnings: warn };
    };

    T.randomOrder = function () {
        var c = U.comp();
        var s = U.sel(c, 2);
        restack(c, shuffle(s.slice(0)));
        return { count: s.length };
    };

    T.selectEvery = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2), n = Math.max(2, parseInt(a.n, 10) || 2), kept = 0;
        for (var i = 0; i < s.length; i++) {
            var on = (i % n) === 0;
            s[i].selected = on;
            if (on) { kept++; }
        }
        return { count: kept };
    };

    T.invertSelection = function () {
        var c = U.comp(), n = 0;
        for (var i = 1; i <= c.numLayers; i++) {
            var L = c.layer(i);
            if (L.locked) { continue; }
            L.selected = !L.selected;
            if (L.selected) { n++; }
        }
        return { count: n };
    };

    // nearest layer on top — pair with Quick ▸ Sequence ▸ Stagger for ripple animations
    T.reorderByDistance = function (a) {
        var c = U.comp();
        var s = U.sel(c, 2), t = c.time, target;
        if (a.from === 'first') { target = U.getPos(U.selSorted(c, 2)[0], t); }
        else { target = [c.width / 2, c.height / 2]; }
        var list = [];
        for (var i = 0; i < s.length; i++) {
            var p = U.getPos(s[i], t);
            list.push({ L: s[i], d: Math.sqrt(Math.pow(p[0] - target[0], 2) + Math.pow(p[1] - target[1], 2)) });
        }
        list.sort(function (x, y) { return a.far ? y.d - x.d : x.d - y.d; });
        var ordered = [];
        for (var j = 0; j < list.length; j++) { ordered.push(list[j].L); }
        restack(c, ordered);
        return { count: ordered.length };
    };

    /* ======================= ARRANGE ======================= */
    function moveCenterTo(L, x, y, t) {
        var par = L.parent;
        if (par) { L.parent = null; }
        var b = U.bounds(L, t);
        U.shiftPosition(L, x - (b.left + b.width / 2), y - (b.top + b.height / 2));
        if (par) { L.parent = par; }
    }

    T.grid = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2), t = c.time;
        var cols = Math.max(1, parseInt(a.cols, 10) || Math.ceil(Math.sqrt(s.length)));
        var gap = parseFloat(a.gap); if (isNaN(gap)) { gap = 40; }
        var cw = 0, ch = 0;
        for (var i = 0; i < s.length; i++) {
            if (!isVisual(s[i])) { continue; }
            var b = U.bounds(s[i], t);
            cw = Math.max(cw, b.width); ch = Math.max(ch, b.height);
        }
        var rows = Math.ceil(s.length / cols);
        var totalW = cols * cw + (cols - 1) * gap, totalH = rows * ch + (rows - 1) * gap;
        var x0 = (c.width - totalW) / 2 + cw / 2, y0 = (c.height - totalH) / 2 + ch / 2;
        for (var k = 0; k < s.length; k++) {
            if (!isVisual(s[k])) { continue; }
            moveCenterTo(s[k], x0 + (k % cols) * (cw + gap), y0 + Math.floor(k / cols) * (ch + gap), t);
        }
        return { count: s.length };
    };

    T.circle = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2), t = c.time;
        var r = parseFloat(a.radius) || Math.min(c.width, c.height) * 0.35;
        var start = (parseFloat(a.start) || -90) * Math.PI / 180;
        for (var i = 0; i < s.length; i++) {
            if (!isVisual(s[i])) { continue; }
            var ang = start + i * 2 * Math.PI / s.length;
            moveCenterTo(s[i], c.width / 2 + r * Math.cos(ang), c.height / 2 + r * Math.sin(ang), t);
            if (a.rotate) {
                var rz = U.tr(s[i]).property('ADBE Rotate Z');
                if (rz.numKeys === 0) { rz.setValue(ang * 180 / Math.PI + 90); }
            }
        }
        return { count: s.length };
    };

    T.randomPosition = function (a) {
        var c = U.comp();
        var s = U.sel(c), rx = parseFloat(a.x) || 0, ry = parseFloat(a.y) || 0;
        for (var i = 0; i < s.length; i++) { U.shiftPosition(s[i], rnd(-rx, rx), rnd(-ry, ry)); }
        return { count: s.length };
    };

    T.stepOffset = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2), dx = parseFloat(a.x) || 0, dy = parseFloat(a.y) || 0;
        for (var i = 1; i < s.length; i++) { U.shiftPosition(s[i], dx * i, dy * i); }
        return { count: s.length };
    };

    // Responsive row / column: layers stay lined up with a gap even when their text or size changes
    T.autoLayout = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2);
        ensureUnique(c, s);
        var ctl = c.layers.addNull();
        ctl.name = uniqueName(c, 'AIO Layout');
        ctl.label = 9;
        ctl.moveBefore(s[0]);
        U.setPosStatic(ctl, [c.width / 2, c.height / 2]);
        slider(ctl, 'Gap', parseFloat(a.gap) || 30);
        checkbox(ctl, 'Vertical', a.dir === 'column');
        var names = [];
        for (var i = 0; i < s.length; i++) { names.push(q(s[i].name)); }
        var expr = [
            '// ' + TAG + ' - auto layout',
            'var ctl = thisComp.layer(' + q(ctl.name) + ');',
            'var names = [' + names.join(',') + '];',
            'var gap = ctl.effect("Gap")(1);',
            'var vert = ctl.effect("Vertical")(1) > 0;',
            'function box(L) { var r = L.sourceRectAtTime(time, false); var s = L.transform.scale.value;',
            '  return { w: r.width * Math.abs(s[0]) / 100, h: r.height * Math.abs(s[1]) / 100, cx: r.left + r.width / 2, cy: r.top + r.height / 2, sx: s[0] / 100, sy: s[1] / 100 }; }',
            'var total = 0, start = 0, mine = null;',
            'for (var i = 0; i < names.length; i++) {',
            '  var b = box(thisComp.layer(names[i]));',
            '  var len = vert ? b.h : b.w;',
            '  if (names[i] == thisLayer.name) { start = total; mine = b; }',
            '  total += len + (i < names.length - 1 ? gap : 0);',
            '}',
            'var o = ctl.toComp(ctl.transform.anchorPoint);',
            'var me = mine ? mine : box(thisLayer);',
            'var c = (vert ? start + me.h / 2 : start + me.w / 2) - total / 2;',
            'var target = vert ? [o[0], o[1] + c] : [o[0] + c, o[1]];',
            'var ap = transform.anchorPoint;',
            'var x = target[0] - (me.cx - ap[0]) * me.sx, y = target[1] - (me.cy - ap[1]) * me.sy;',
            'value.length > 2 ? [x, y, value[2]] : [x, y]'
        ].join('\n');
        var n = 0;
        for (var j = 0; j < s.length; j++) {
            if (!isVisual(s[j]) || s[j].parent) { continue; }
            var pos = U.tr(s[j]).property('ADBE Position');
            if (pos.dimensionsSeparated) { pos.dimensionsSeparated = false; }
            pos.expression = expr;
            n++;
        }
        return { count: n, name: ctl.name };
    };

    /* ======================= SHAPES ======================= */
    function shapeLayers(c) {
        var s = U.sel(c), out = [];
        for (var i = 0; i < s.length; i++) { if (s[i] instanceof ShapeLayer) { out.push(s[i]); } }
        if (!out.length) { throw new Error('NO_SHAPE_LAYER'); }
        return out;
    }
    function contents(L) { return L.property('ADBE Root Vectors Group'); }

    function eachStroke(group, cb) {
        for (var i = 1; i <= group.numProperties; i++) {
            var p = group.property(i);
            if (!p) { continue; }
            if (p.matchName === 'ADBE Vector Graphic - Stroke' || p.matchName === 'ADBE Vector Graphic - G-Stroke') { cb(p); }
            else if (p.propertyType !== PropertyType.PROPERTY) { eachStroke(p, cb); }
        }
    }

    // cap: 1 butt, 2 round, 3 projecting · join follows (round cap → round join)
    T.strokeCap = function (a) {
        var c = U.comp();
        var s = shapeLayers(c), n = 0;
        var cap = a.cap === 'round' ? 2 : (a.cap === 'projecting' ? 3 : 1);
        for (var i = 0; i < s.length; i++) {
            eachStroke(contents(s[i]), function (st) {
                try { st.property('ADBE Vector Stroke Line Cap').setValue(cap); } catch (e) {}
                try { st.property('ADBE Vector Stroke Line Join').setValue(cap === 2 ? 2 : 1); } catch (e2) {}
                n++;
            });
        }
        if (!n) { throw new Error('NO_STROKE'); }
        return { count: n };
    };

    T.trimPaths = function (a) {
        var c = U.comp();
        var s = shapeLayers(c);
        for (var i = 0; i < s.length; i++) {
            var tr = contents(s[i]).addProperty('ADBE Vector Filter - Trim');
            if (a.animate) {
                var end = tr.property('ADBE Vector Trim End');
                var t0 = s[i].inPoint, dur = parseFloat(a.duration) || 1;
                end.setValueAtTime(t0, 0);
                end.setValueAtTime(t0 + dur, 100);
                for (var k = 1; k <= 2; k++) {
                    var ez = [new KeyframeEase(0, 75)];
                    end.setTemporalEaseAtKey(k, ez, ez);
                }
            }
        }
        return { count: s.length };
    };

    T.taper = function (a) {
        var c = U.comp();
        var s = shapeLayers(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            eachStroke(contents(s[i]), function (st) {
                var tp = st.property('ADBE Vector Stroke Taper');
                if (!tp) { return; }
                try { tp.property('ADBE Vector Taper Start Length').setValue(parseFloat(a.start) || 0); } catch (e) {}
                try { tp.property('ADBE Vector Taper End Length').setValue(parseFloat(a.end) || 0); } catch (e1) {}
                try { tp.property('ADBE Vector Taper Start Ease').setValue(parseFloat(a.ease) || 0); } catch (e2) {}
                try { tp.property('ADBE Vector Taper End Ease').setValue(parseFloat(a.ease) || 0); } catch (e3) {}
                n++;
            });
        }
        if (!n) { throw new Error('NO_TAPER'); }
        return { count: n };
    };

    T.vectorToShapes = function (a) {
        var c = U.comp();
        var s = U.sel(c), vec = [];
        for (var i = 0; i < s.length; i++) {
            var src = s[i].source;
            if (src && src.file && /\.(ai|eps|pdf|svg)$/i.test(src.file.name)) { vec.push(s[i]); }
        }
        if (!vec.length) { throw new Error('NO_VECTOR_LAYER'); }
        var id = app.findMenuCommandId('Create Shapes from Vector Layer');
        if (!id) { throw new Error('Create Shapes from Vector Layer command not found'); }
        U.select(c, vec);
        app.executeCommand(id);
        if (a.removeSource) { for (var j = 0; j < vec.length; j++) { try { vec[j].remove(); } catch (e) {} } }
        return { count: vec.length };
    };

    // each top-level group becomes its own layer (shared fills/strokes/modifiers are kept on every piece)
    T.explodeShapes = function () {
        var c = U.comp();
        var s = shapeLayers(c), made = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i], root = contents(L), groups = [];
            for (var g = 1; g <= root.numProperties; g++) { if (root.property(g).matchName === 'ADBE Vector Group') { groups.push(g); } }
            if (groups.length < 2) { continue; }
            for (var k = groups.length - 1; k >= 0; k--) {
                var gi = groups[k];
                var d = L.duplicate();
                var dr = contents(d);
                var gname = root.property(gi).name;
                for (var r = dr.numProperties; r >= 1; r--) {
                    if (dr.property(r).matchName === 'ADBE Vector Group' && r !== gi) { dr.property(r).remove(); }
                }
                d.name = L.name + ' - ' + gname;
                made++;
            }
            L.enabled = false;
            L.name = L.name + ' [original]';
        }
        if (!made) { throw new Error('NEED_GROUPS'); }
        return { count: made };
    };

    // generic copier for shape contents (groups are added, named groups are reused)
    function copyTree(src, dst) {
        for (var i = 1; i <= src.numProperties; i++) {
            var p = src.property(i);
            if (!p) { continue; }
            if (p.propertyType === PropertyType.PROPERTY) {
                var d = null;
                try { d = dst.property(p.matchName); } catch (e) {}
                if (!d) { continue; }
                try {
                    if (p.numKeys > 0) {
                        for (var k = 1; k <= p.numKeys; k++) { d.setValueAtTime(p.keyTime(k), p.keyValue(k)); }
                        for (var k2 = 1; k2 <= p.numKeys; k2++) {
                            try {
                                d.setInterpolationTypeAtKey(k2, p.keyInInterpolationType(k2), p.keyOutInterpolationType(k2));
                                d.setTemporalEaseAtKey(k2, p.keyInTemporalEase(k2), p.keyOutTemporalEase(k2));
                            } catch (e3) {}
                        }
                    } else if (p.propertyValueType !== PropertyValueType.NO_VALUE) {
                        d.setValue(p.value);
                    }
                    if (p.canSetExpression && p.expression) { d.expression = p.expression; }
                } catch (e2) {}
            } else {
                var g = null;
                if (dst.propertyType === PropertyType.INDEXED_GROUP) {
                    try { g = dst.addProperty(p.matchName); } catch (e4) { g = null; }
                    if (g) { try { g.name = p.name; } catch (e5) {} }
                } else {
                    try { g = dst.property(p.matchName); } catch (e6) { g = null; }
                }
                if (g) { copyTree(p, g); }
            }
        }
    }

    T.mergeShapes = function () {
        var c = U.comp();
        var s = shapeLayers(c), warn = [], t = c.time;
        if (s.length < 2) { throw new Error('NEED_2_SHAPES'); }
        s.sort(function (x, y) { return y.index - x.index; }); // bottom first → ends up underneath
        var top = s[s.length - 1];
        var M = c.layers.addShape();
        M.name = uniqueName(c, 'Merged Shapes');
        M.moveBefore(top);
        U.setXY(U.tr(M).property('ADBE Anchor Point'), 0, 0, 0);
        U.setPosStatic(M, [0, 0]);
        var root = contents(M);
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (L.parent || L.threeDLayer) { warn.push(L.name + ': parented/3D layers are merged without their parent transform'); }
            var g = root.addProperty('ADBE Vector Group');
            g.name = L.name;
            copyTree(contents(L), g.property('ADBE Vectors Group'));
            var lt = U.tr(L), gt = g.property('ADBE Vector Transform Group');
            var pos = U.getPos(L, t);
            try { setPropVal(gt.property('ADBE Vector Anchor'), lt.property('ADBE Anchor Point').valueAtTime(t, false).slice(0, 2)); } catch (e) {}
            try { setPropVal(gt.property('ADBE Vector Position'), [pos[0], pos[1]]); } catch (e1) {}
            try { setPropVal(gt.property('ADBE Vector Scale'), lt.property('ADBE Scale').valueAtTime(t, false).slice(0, 2)); } catch (e2) {}
            try { gt.property('ADBE Vector Rotation').setValue(lt.property('ADBE Rotate Z').valueAtTime(t, false)); } catch (e3) {}
            try { gt.property('ADBE Vector Group Opacity').setValue(lt.property('ADBE Opacity').valueAtTime(t, false)); } catch (e4) {}
            if (lt.property('ADBE Position').numKeys > 0 || lt.property('ADBE Scale').numKeys > 0) { warn.push(L.name + ': layer transform keys were not carried over'); }
            L.enabled = false;
        }
        return { count: s.length, warnings: warn };
    };

    function pruneEmpty(group) {
        var removed = 0;
        for (var i = group.numProperties; i >= 1; i--) {
            var p = group.property(i);
            if (!p || p.matchName !== 'ADBE Vector Group') { continue; }
            var inner = p.property('ADBE Vectors Group');
            removed += pruneEmpty(inner);
            if (inner.numProperties === 0) { p.remove(); removed++; }
        }
        return removed;
    }

    T.removeEmptyGroups = function () {
        var c = U.comp();
        var s = shapeLayers(c), n = 0;
        for (var i = 0; i < s.length; i++) { n += pruneEmpty(contents(s[i])); }
        return { count: n };
    };

    /* ======================= RIGS ======================= */
    function controller(c, name, build) {
        for (var i = 1; i <= c.numLayers; i++) { if (c.layer(i).name === name) { return c.layer(i); } }
        var N = c.layers.addNull();
        N.name = name;
        N.label = 2;
        N.enabled = false;
        build(N);
        return N;
    }
    function selectedProps(c) {
        var out = [], sp = c.selectedProperties;
        for (var i = 0; i < sp.length; i++) { if (sp[i].propertyType === PropertyType.PROPERTY && sp[i].canSetExpression) { out.push(sp[i]); } }
        if (!out.length) { throw new Error('NO_PROPS'); }
        return out;
    }

    // a ball dropping onto the last value: elasticity, gravity and how many bounces
    T.bounceBack = function (a) {
        var c = U.comp();
        var props = selectedProps(c);
        var ctl = controller(c, 'AIO Bounce Control', function (N) {
            slider(N, 'Elasticity', parseFloat(a.elasticity) || 70);
            slider(N, 'Gravity', parseFloat(a.gravity) || 5000);
            slider(N, 'Max Bounces', parseFloat(a.bounces) || 4);
        });
        var expr = [
            '// ' + TAG + ' - bounce back',
            'var ctl = thisComp.layer(' + q(ctl.name) + ');',
            'var e = Math.max(0, Math.min(1, ctl.effect("Elasticity")(1) / 100));',
            'var g = Math.max(1, ctl.effect("Gravity")(1));',
            'var nMax = Math.round(ctl.effect("Max Bounces")(1));',
            'var n = 0;',
            'if (numKeys > 1) { n = nearestKey(time).index; if (key(n).time > time) { n--; } }',
            'var out = value;',
            'if (n > 1) {',
            '  var t = time - key(n).time;',
            '  var v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);',
            '  var arr = (v instanceof Array);',
            '  var speed = arr ? length(v) : Math.abs(v);',
            '  if (speed > 0.001) {',
            '    var dir = arr ? div(v, speed) : (v > 0 ? 1 : -1);',
            '    var vb = speed * e, tc = 0, seg = 2 * vb / g, b = 1;',
            '    while (tc + seg < t && b < nMax) { tc += seg; vb *= e; seg = 2 * vb / g; b++; }',
            '    if (t < tc + seg) { var dt = t - tc, h = vb * dt - g * dt * dt / 2; out = arr ? sub(value, mul(dir, h)) : value - dir * h; }',
            '  }',
            '}',
            'out'
        ].join('\n');
        for (var i = 0; i < props.length; i++) { props[i].expression = expr; }
        return { count: props.length };
    };

    // random offset per layer, seedable, optional re-roll every N seconds
    T.randomizer = function (a) {
        var c = U.comp();
        var props = selectedProps(c), layers = [];
        for (var i = 0; i < props.length; i++) {
            var L = props[i].propertyGroup(props[i].propertyDepth);
            if (U.indexOf(layers, L) < 0) { layers.push(L); }
        }
        var ctl = controller(c, 'AIO Random Control', function (N) {
            slider(N, 'Amount', parseFloat(a.amount) || 50);
            slider(N, 'Seed', 1);
            slider(N, 'Change Every (s)', 0);
        });
        var expr = [
            '// ' + TAG + ' - randomizer',
            'var ctl = thisComp.layer(' + q(ctl.name) + ');',
            'var amt = ctl.effect("Amount")(1), every = ctl.effect("Change Every (s)")(1);',
            'var step = every > 0 ? Math.floor(time / every) : 0;',
            'seedRandom(ctl.effect("Seed")(1) * 1000 + index * 37 + step, true);',
            'if (value instanceof Array) { var d = []; for (var i = 0; i < value.length; i++) { d.push(random(-amt, amt)); } add(value, d); }',
            'else { value + random(-amt, amt); }'
        ].join('\n');
        for (var j = 0; j < props.length; j++) { props[j].expression = expr; }
        return { count: props.length, layers: layers.length };
    };

    T.loopPrecomp = function () {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!(L.source instanceof CompItem)) { continue; }
            if (!L.timeRemapEnabled) { L.timeRemapEnabled = true; }
            var tr = L.property('ADBE Time Remapping');
            while (tr.numKeys > 0) { tr.removeKey(1); }
            tr.expression = '// ' + TAG + ' - loop precomp\nvar d = thisLayer.source.duration;\nvar t = time - thisLayer.startTime;\nt - Math.floor(t / d) * d';
            try { L.outPoint = c.duration; } catch (e) {}
            n++;
        }
        if (!n) { throw new Error('NO_PRECOMP'); }
        return { count: n };
    };

    // layers react (scale / opacity / rotation) when the effector null comes close
    T.effector = function (a) {
        var c = U.comp();
        var s = U.sel(c);
        var name = uniqueName(c, 'AIO Effector');
        var E = c.layers.addNull();
        E.name = name;
        E.label = 1;
        U.setPosStatic(E, [c.width / 2, c.height / 2]);
        slider(E, 'Radius', parseFloat(a.radius) || 250);
        slider(E, 'Falloff', parseFloat(a.falloff) || 300);
        slider(E, 'Scale %', parseFloat(a.scale) || 150);
        slider(E, 'Opacity %', a.opacity === undefined ? 100 : parseFloat(a.opacity));
        slider(E, 'Rotation', parseFloat(a.rotation) || 0);
        checkbox(E, 'Invert', false);
        var head = [
            '// ' + TAG + ' - effector',
            'var E = thisComp.layer(' + q(name) + ');',
            'var p = thisLayer.hasParent ? thisLayer.parent.toComp(transform.position) : transform.position;',
            'var ep = E.toComp(E.transform.anchorPoint);',
            'var d = length([p[0], p[1]], [ep[0], ep[1]]);',
            'var r = E.effect("Radius")(1), f = Math.max(1, E.effect("Falloff")(1));',
            'var k = Math.max(0, Math.min(1, 1 - (d - r) / f));',
            'if (E.effect("Invert")(1) > 0) { k = 1 - k; }',
            'k = k * k * (3 - 2 * k);'
        ].join('\n');
        var n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!isVisual(L) || L === E) { continue; }
            var tr = U.tr(L);
            tr.property('ADBE Scale').expression = head + '\nvar m = 1 + (E.effect("Scale %")(1) / 100 - 1) * k;\nmul(value, m)';
            tr.property('ADBE Opacity').expression = head + '\nvalue * (1 + (E.effect("Opacity %")(1) / 100 - 1) * k)';
            tr.property('ADBE Rotate Z').expression = head + '\nvalue + E.effect("Rotation")(1) * k';
            n++;
        }
        E.moveToBeginning();
        return { count: n, name: name };
    };

    // a stroke that runs through the selected layers, following them as they move
    T.connect = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2);
        ensureUnique(c, s);
        var S = c.layers.addShape();
        S.name = uniqueName(c, 'AIO Connector');
        U.setXY(U.tr(S).property('ADBE Anchor Point'), 0, 0, 0);
        U.setPosStatic(S, [0, 0]);
        var root = contents(S);
        var g = root.addProperty('ADBE Vector Group');
        g.name = 'Line';
        var vg = g.property('ADBE Vectors Group');
        var path = vg.addProperty('ADBE Vector Shape - Group');
        var st = vg.addProperty('ADBE Vector Graphic - Stroke');
        var col = a.color || [1, 1, 1];
        setPropVal(st.property('ADBE Vector Stroke Color'), [col[0], col[1], col[2], 1]);
        st.property('ADBE Vector Stroke Width').setValue(parseFloat(a.width) || 4);
        try { st.property('ADBE Vector Stroke Line Cap').setValue(2); st.property('ADBE Vector Stroke Line Join').setValue(2); } catch (e) {}
        var names = [];
        for (var i = 0; i < s.length; i++) { names.push(q(s[i].name)); }
        path.property('ADBE Vector Shape').expression = [
            '// ' + TAG + ' - connector',
            'var names = [' + names.join(',') + '];',
            'var pts = [];',
            'for (var i = 0; i < names.length; i++) { var L = thisComp.layer(names[i]); var p = L.toComp(L.transform.anchorPoint); pts.push([p[0], p[1]]); }',
            'createPath(pts, [], [], ' + (a.closed ? 'true' : 'false') + ')'
        ].join('\n');
        S.moveAfter(s[s.length - 1]);
        return { count: s.length, name: S.name };
    };

    // palette: one null with colour controls; selected colour properties get linked to a slot
    T.paletteCreate = function (a) {
        var c = U.comp();
        var colors = a.colors || [];
        var P = null;
        for (var i = 1; i <= c.numLayers; i++) { if (c.layer(i).name === 'AIO Palette') { P = c.layer(i); } }
        if (!P) { P = c.layers.addNull(); P.name = 'AIO Palette'; P.label = 11; P.enabled = false; }
        var fxp = P.property('ADBE Effect Parade');
        for (var k = 0; k < colors.length; k++) {
            var nm = 'Color ' + (k + 1);
            var e = fxp.property(nm);
            if (!e) { e = colorCtl(P, nm, colors[k]); } else { setPropVal(e.property(1), [colors[k][0], colors[k][1], colors[k][2], 1]); }
        }
        return { name: P.name, count: colors.length };
    };

    T.paletteLink = function (a) {
        var c = U.comp();
        var sp = c.selectedProperties, n = 0, slot = parseInt(a.slot, 10) || 1;
        var P = null;
        for (var i = 1; i <= c.numLayers; i++) { if (c.layer(i).name === 'AIO Palette') { P = c.layer(i); } }
        if (!P) { throw new Error('NO_PALETTE'); }
        for (var j = 0; j < sp.length; j++) {
            var p = sp[j];
            if (p.propertyType === PropertyType.PROPERTY && p.propertyValueType === PropertyValueType.COLOR && p.canSetExpression) {
                p.expression = '// ' + TAG + ' - palette\nthisComp.layer("AIO Palette").effect("Color ' + slot + '")(1)';
                n++;
            }
        }
        if (!n) { throw new Error('NO_COLOR_PROPS'); }
        return { count: n };
    };

    /* ======================= LOOKS ======================= */
    function runMenu(name) {
        var id = app.findMenuCommandId(name);
        if (id) { app.executeCommand(id); return true; }
        return false;
    }
    function styleProp(L, mn) {
        var st = L.property('ADBE Layer Styles');
        if (!st) { return null; }
        var parts = mn.split('/');
        var grp = st.property(parts[0] + '/enabled');
        return grp ? grp.property(mn) : null;
    }
    function setStyle(L, mn, v) { try { var p = styleProp(L, mn); if (p) { setPropVal(p, v); } } catch (e) {} }

    // frosted glass: bevel + inner glow layer styles, soft drop shadow, see-through fill
    T.glassStyle = function () {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!isVisual(L)) { continue; }
            U.select(c, [L]);
            var okB = runMenu('Bevel and Emboss');
            var okG = runMenu('Inner Glow');
            if (okB) {
                setStyle(L, 'bevelEmboss/strengthRatio', 120);
                setStyle(L, 'bevelEmboss/blur', 12);
                setStyle(L, 'bevelEmboss/softness', 6);
                setStyle(L, 'bevelEmboss/highlightOpacity', 85);
                setStyle(L, 'bevelEmboss/shadowOpacity', 30);
            }
            if (okG) {
                setStyle(L, 'innerGlow/opacity', 45);
                setStyle(L, 'innerGlow/blur', 18);
                setStyle(L, 'innerGlow/color', [1, 1, 1, 1]);
            }
            var ds = fx(L, 'ADBE Drop Shadow', 'Glass Shadow');
            try { ds.property('ADBE Drop Shadow-0004').setValue(10); ds.property('ADBE Drop Shadow-0005').setValue(30); } catch (e) {}
            if (L instanceof ShapeLayer) {
                (function walk(g) {
                    for (var k = 1; k <= g.numProperties; k++) {
                        var p = g.property(k);
                        if (!p) { continue; }
                        if (p.matchName === 'ADBE Vector Graphic - Fill') { try { p.property('ADBE Vector Fill Opacity').setValue(25); } catch (e2) {} }
                        else if (p.propertyType !== PropertyType.PROPERTY) { walk(p); }
                    }
                })(contents(L));
            } else {
                U.tr(L).property('ADBE Opacity').setValue(60);
            }
            n++;
        }
        U.select(c, s);
        return { count: n };
    };

    // a rounded glass panel that blurs and bends whatever is below it
    T.liquidGlass = function (a) {
        var c = U.comp();
        var w = parseFloat(a.w) || Math.round(c.width * 0.5), h = parseFloat(a.h) || Math.round(c.height * 0.3);
        var round = a.shape === 'ellipse' ? 0 : (parseFloat(a.round) || Math.min(w, h) * 0.25);
        var name = uniqueName(c, 'Liquid Glass');
        var makeShape = function (nm) {
            var S = c.layers.addShape();
            S.name = nm;
            var g = contents(S).addProperty('ADBE Vector Group');
            var vg = g.property('ADBE Vectors Group');
            if (a.shape === 'ellipse') {
                var el = vg.addProperty('ADBE Vector Shape - Ellipse');
                el.property('ADBE Vector Ellipse Size').setValue([w, h]);
            } else {
                var rc = vg.addProperty('ADBE Vector Shape - Rect');
                rc.property('ADBE Vector Rect Size').setValue([w, h]);
                rc.property('ADBE Vector Rect Roundness').setValue(round);
            }
            return S;
        };
        // 1) adjustment layer that does the blur + refraction
        var adj = c.layers.addSolid([1, 1, 1], name + ' FX', c.width, c.height, c.pixelAspect, c.duration);
        adj.adjustmentLayer = true;
        var blur = fx(adj, 'ADBE Box Blur2', 'Glass Blur');
        try { blur.property(1).setValue(parseFloat(a.blur) || 18); } catch (e) {}
        var td = fx(adj, 'ADBE Turbulent Displace', 'Glass Refraction');
        try { td.property('Amount').setValue(parseFloat(a.distort) || 12); td.property('Size').setValue(160); } catch (e1) {}
        try { var ex = fx(adj, 'ADBE Exposure2', 'Glass Brightness'); ex.property('Exposure').setValue(0.25); } catch (e2) {}
        // 2) matte (same shape) right above the adjustment layer
        var matte = makeShape(name + ' Matte');
        matte.moveBefore(adj);
        var fillM = contents(matte).property(1).property('ADBE Vectors Group').addProperty('ADBE Vector Graphic - Fill');
        setPropVal(fillM.property('ADBE Vector Fill Color'), [1, 1, 1, 1]);
        adj.trackMatteType = TrackMatteType.ALPHA;
        // 3) visible glass on top: faint fill, bright rim, soft shadow
        var top = makeShape(name);
        top.moveBefore(matte);
        var vg2 = contents(top).property(1).property('ADBE Vectors Group');
        var fill = vg2.addProperty('ADBE Vector Graphic - Fill');
        setPropVal(fill.property('ADBE Vector Fill Color'), [1, 1, 1, 1]);
        fill.property('ADBE Vector Fill Opacity').setValue(8);
        var st = vg2.addProperty('ADBE Vector Graphic - Stroke');
        setPropVal(st.property('ADBE Vector Stroke Color'), [1, 1, 1, 1]);
        st.property('ADBE Vector Stroke Width').setValue(2);
        st.property('ADBE Vector Stroke Opacity').setValue(45);
        var ds = fx(top, 'ADBE Drop Shadow', 'Glass Shadow');
        try { ds.property('ADBE Drop Shadow-0004').setValue(16); ds.property('ADBE Drop Shadow-0005').setValue(40); } catch (e3) {}
        // controls live on the visible layer
        slider(top, 'Blur', parseFloat(a.blur) || 18);
        slider(top, 'Refraction', parseFloat(a.distort) || 12);
        try {
            blur.property(1).expression = 'thisComp.layer(' + q(name) + ').effect("Blur")(1)';
            td.property('Amount').expression = 'thisComp.layer(' + q(name) + ').effect("Refraction")(1)';
        } catch (e4) {}
        U.setPosStatic(top, [c.width / 2, c.height / 2]);
        matte.parent = top;
        U.select(c, [top]);
        return { name: name };
    };

    T.glitch = function (a) {
        var c = U.comp();
        var name = uniqueName(c, 'AIO Glitch');
        var G = c.layers.addSolid([1, 1, 1], name, c.width, c.height, c.pixelAspect, c.duration);
        G.adjustmentLayer = true;
        G.label = 14;
        slider(G, 'Amount', parseFloat(a.amount) || 50);
        slider(G, 'Speed', 12);
        var gate = 'var amt = effect("Amount")(1) / 100; seedRandom(Math.floor(time * effect("Speed")(1)), true); var on = random() < amt * 0.6;';
        var off = fx(G, 'ADBE Offset', 'Glitch Shift');
        off.property(1).expression = '// ' + TAG + ' - glitch\n' + gate + '\non ? value + [random(-1, 1) * thisComp.width * 0.08 * amt, 0] : value';
        var ww = fx(G, 'ADBE Wave Warp', 'Glitch Warp');
        try {
            ww.property(1).setValue(2); // square wave
            ww.property(2).expression = gate + '\non ? random(10, 60) * amt : 0';
            ww.property(3).setValue(40);
        } catch (e) {}
        var nz = fx(G, 'ADBE Noise', 'Glitch Noise');
        try { nz.property(1).expression = gate + '\non ? random(10, 40) * amt : 0'; } catch (e1) {}
        G.moveToBeginning();
        return { name: name };
    };

    T.vignette = function (a) {
        var c = U.comp();
        var name = uniqueName(c, 'AIO Vignette');
        var V = c.layers.addSolid([0, 0, 0], name, c.width, c.height, c.pixelAspect, c.duration);
        var m = V.property('ADBE Mask Parade').addProperty('ADBE Mask Atom');
        var sh = new Shape();
        var w = c.width, h = c.height, k = 0.5523;
        var cx = w / 2, cy = h / 2, rx = w * 0.62, ry = h * 0.62;
        sh.vertices = [[cx, cy - ry], [cx + rx, cy], [cx, cy + ry], [cx - rx, cy]];
        sh.inTangents = [[-rx * k, 0], [0, -ry * k], [rx * k, 0], [0, ry * k]];
        sh.outTangents = [[rx * k, 0], [0, ry * k], [-rx * k, 0], [0, -ry * k]];
        sh.closed = true;
        m.property('ADBE Mask Shape').setValue(sh);
        m.inverted = true;
        var f = Math.round(Math.min(w, h) * (parseFloat(a.feather) || 40) / 100);
        m.property('ADBE Mask Feather').setValue([f, f]);
        U.tr(V).property('ADBE Opacity').setValue(parseFloat(a.amount) || 60);
        V.moveToBeginning();
        return { name: name };
    };

    /* ======================= COMP ======================= */
    T.cameraRig = function () {
        var c = U.comp();
        var cam = c.layers.addCamera(uniqueName(c, 'Camera'), [c.width / 2, c.height / 2]);
        try { cam.autoOrient = AutoOrientType.NO_AUTO_ORIENT; } catch (e) {}
        var N = c.layers.addNull();
        N.name = uniqueName(c, 'Camera Controller');
        N.threeDLayer = true;
        N.label = 2;
        U.setPosStatic(N, [c.width / 2, c.height / 2]);
        cam.parent = N;
        N.moveBefore(cam);
        return { name: N.name };
    };

    T.extendComp = function (a) {
        var c = U.comp();
        var add = parseFloat(a.seconds) || 5, old = c.duration, n = 0;
        c.duration = old + add;
        if (a.layers !== false) {
            for (var i = 1; i <= c.numLayers; i++) {
                var L = c.layer(i);
                if (L.outPoint >= old - c.frameDuration / 2) { try { L.outPoint = c.duration; n++; } catch (e) {} }
            }
        }
        return { duration: c.duration, layers: n };
    };

    T.purge = function () {
        try { app.purge(PurgeTarget.ALL_CACHES); } catch (e) {}
        var disk = runMenu('All Memory & Disk Cache...') || runMenu('All Memory & Disk Cache');
        return { disk: disk };
    };

    // precompose and trim the new comp to the selected layers' time span
    T.precompTrim = function (a) {
        var c = U.comp();
        var s = U.selSorted(c);
        var inP = 1e9, outP = -1e9, idx = [];
        for (var i = 0; i < s.length; i++) { inP = Math.min(inP, s[i].inPoint); outP = Math.max(outP, s[i].outPoint); idx.push(s[i].index); }
        var nc = c.layers.precompose(idx, a.name || (s[0].name + ' Comp'), true);
        for (var j = 1; j <= nc.numLayers; j++) {
            var L = nc.layer(j);
            var lk = L.locked; L.locked = false;
            L.startTime -= inP;
            L.locked = lk;
        }
        nc.duration = Math.max(nc.frameDuration, outP - inP);
        var P = c.selectedLayers.length ? c.selectedLayers[0] : null;
        if (!P || P.source !== nc) {
            for (var k = 1; k <= c.numLayers; k++) { if (c.layer(k).source === nc) { P = c.layer(k); break; } }
        }
        if (P) { P.startTime = inP; P.inPoint = inP; P.outPoint = outP; }
        return { name: nc.name };
    };

    T.sourceToLayerName = function () {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            var src = s[i].source;
            if (!src || src.mainSource instanceof SolidSource) { continue; }
            try { src.name = s[i].name; n++; } catch (e) {}
        }
        return { count: n };
    };

    /* ======================= TEXT ======================= */
    T.scramble = function (a) {
        var c = U.comp();
        var s = U.textLayers(c);
        var dur = parseFloat(a.duration) || 1;
        var chars = String(a.chars || 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&*@').replace(/["\\\r\n]/g, '');
        var expr = [
            '// ' + TAG + ' - scramble',
            'var dur = ' + dur + ', speed = ' + (parseFloat(a.speed) || 20) + ';',
            'var chars = "' + chars + '";',
            'var txt = String(value);',
            'var n = txt.length;',
            'var shown = Math.floor(Math.max(0, Math.min(1, (time - inPoint) / dur)) * n);',
            'seedRandom(Math.floor(time * speed), true);',
            'var out = "";',
            'for (var i = 0; i < n; i++) {',
            '  var ch = txt.charAt(i);',
            '  if (i < shown || ch == " " || ch == "\\r" || ch == "\\n") { out += ch; }',
            '  else { out += chars.charAt(Math.floor(random(chars.length))); }',
            '}',
            'out'
        ].join('\n');
        for (var i = 0; i < s.length; i++) {
            s[i].property('ADBE Text Properties').property('ADBE Text Document').expression = expr;
        }
        return { count: s.length };
    };

    return T;
})();
