/* All In One — Quick Tools (ExtendScript, ES3) */
MKH.quick = (function () {
    var U = MKH.util;
    var Q = {};

    function placeAbove(c, layer, s) {
        if (s && s.length) {
            var top = s[0];
            for (var i = 1; i < s.length; i++) { if (s[i].index < top.index) { top = s[i]; } }
            if (top !== layer) {
                layer.moveBefore(top);
                layer.startTime = top.startTime;
                layer.inPoint = top.inPoint;
                layer.outPoint = top.outPoint;
            }
        }
    }

    /* ---------- create layers ---------- */
    Q.precompose = function (a) {
        var c = U.comp();
        var s = U.selSorted(c);
        var idx = [];
        for (var i = 0; i < s.length; i++) { idx.push(s[i].index); }
        var name = a.name || (s[0].name + ' Comp');
        var moveAll = (s.length > 1) ? true : (a.moveAll !== false);
        var nc = c.layers.precompose(idx, name, moveAll);
        return { name: nc.name };
    };

    function copyKeysOrValue(src, dst) {
        if (src.numKeys === 0) {
            try { dst.setValue(src.value); } catch (e) {}
            return;
        }
        for (var k = 1; k <= src.numKeys; k++) {
            var t = src.keyTime(k);
            dst.setValueAtTime(t, src.keyValue(k));
        }
        for (var j = 1; j <= src.numKeys; j++) {
            try {
                dst.setInterpolationTypeAtKey(j, src.keyInInterpolationType(j), src.keyOutInterpolationType(j));
                dst.setTemporalEaseAtKey(j, src.keyInTemporalEase(j), src.keyOutTemporalEase(j));
                if (src.isSpatial) {
                    dst.setSpatialTangentsAtKey(j, src.keyInSpatialTangent(j), src.keyOutSpatialTangent(j));
                }
            } catch (e2) {}
        }
    }

    Q.unprecompose = function (a) {
        var c = U.comp();
        var s = U.sel(c);
        var done = 0, warn = [];
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!(L.source instanceof CompItem)) { continue; }
            var src = L.source;
            if (L.timeRemapEnabled || L.stretch !== 100) { warn.push(L.name + ': time remap/stretch not carried over'); }
            if (L.property('ADBE Effect Parade').numProperties > 0) { warn.push(L.name + ': effects on the precomp layer were not copied'); }

            // a null carries the precomp layer's transform so nothing jumps
            var nul = c.layers.addNull(c.duration);
            nul.name = L.name + ' [transform]';
            nul.moveBefore(L);
            if (L.threeDLayer) { nul.threeDLayer = true; }
            nul.startTime = 0;
            nul.outPoint = L.outPoint;
            nul.inPoint = L.inPoint;
            var mns = ['ADBE Anchor Point', 'ADBE Position', 'ADBE Scale', 'ADBE Rotate Z'];
            if (L.threeDLayer) { mns = mns.concat(['ADBE Orientation', 'ADBE Rotate X', 'ADBE Rotate Y']); }
            var lt = U.tr(L), nt = U.tr(nul);
            if (lt.property('ADBE Position').dimensionsSeparated) {
                nt.property('ADBE Position').dimensionsSeparated = true;
                copyKeysOrValue(lt.property('ADBE Position_0'), nt.property('ADBE Position_0'));
                copyKeysOrValue(lt.property('ADBE Position_1'), nt.property('ADBE Position_1'));
                if (L.threeDLayer) { copyKeysOrValue(lt.property('ADBE Position_2'), nt.property('ADBE Position_2')); }
                mns.splice(1, 1);
            }
            for (var m = 0; m < mns.length; m++) {
                try { copyKeysOrValue(lt.property(mns[m]), nt.property(mns[m])); } catch (e) {}
            }
            var op = lt.property('ADBE Opacity');
            if (op.numKeys > 0 || op.value !== 100) { warn.push(L.name + ': layer opacity is not inherited through parenting'); }

            var map = {}, copies = [];
            for (var j = 1; j <= src.numLayers; j++) {
                var sl = src.layer(j);
                sl.copyToComp(c);
                var nl = c.layer(1);
                var wasLocked = nl.locked;
                nl.locked = false;
                nl.moveBefore(L);
                nl.startTime = nl.startTime + L.startTime;
                var inP = Math.max(nl.inPoint, L.inPoint), outP = Math.min(nl.outPoint, L.outPoint);
                if (outP > inP) {
                    try { nl.inPoint = inP; nl.outPoint = outP; } catch (e3) {}
                } else {
                    // never visible inside the precomp's range: keep it (may be a parent) but switch it off
                    nl.enabled = false;
                    try { if (nl.hasAudio) { nl.audioEnabled = false; } } catch (e5) {}
                }
                map[j] = nl;
                copies.push([sl, nl, wasLocked]);
            }
            for (var q = 0; q < copies.length; q++) {
                var orig = copies[q][0], copy = copies[q][1];
                var par = (orig.parent && map[orig.parent.index]) ? map[orig.parent.index] : nul;
                try { copy.setParentWithJump(par); } catch (e4) { copy.parent = par; }
                if (copies[q][2]) { copy.locked = true; }
            }
            if (a.keep) { L.enabled = false; L.audioEnabled = false; } else { L.remove(); }
            for (var w2 = 0; w2 < copies.length; w2++) {
                if (copies[w2][1].property('ADBE Effect Parade') && copies[w2][1].property('ADBE Effect Parade').numProperties > 0) {
                    warn.push('save before undoing this step (AE can crash when undoing copied layers that have effects)');
                    break;
                }
            }
            done++;
        }
        if (!done) { throw new Error('NO_PRECOMP'); }
        return { count: done, warnings: warn };
    };

    Q.addSolid = function (a) {
        var c = U.comp();
        var col = a.color || [0.1, 0.1, 0.12];
        var adj = !!a.adjustment;
        var name = a.name || (adj ? 'Adjustment Layer' : 'Solid');
        var prev = U.arr(c.selectedLayers);
        var L = c.layers.addSolid(col, name, c.width, c.height, c.pixelAspect, c.duration);
        if (adj) { L.adjustmentLayer = true; L.label = 5; }
        placeAbove(c, L, prev);
        return { name: L.name };
    };

    Q.addNull = function (a) {
        var c = U.comp();
        var s = c.selectedLayers, list = [];
        for (var i = 0; i < s.length; i++) { list.push(s[i]); }
        var top = null;
        for (var t0 = 0; t0 < list.length; t0++) { if (!top || list[t0].index < top.index) { top = list[t0]; } }
        var N = c.layers.addNull();
        N.name = a.name || 'Control';
        N.label = 2;
        if (list.length) {
            var sx = 0, sy = 0, is3d = false;
            for (var j = 0; j < list.length; j++) {
                var p = U.getPos(list[j], c.time);
                sx += p[0]; sy += p[1];
                if (list[j].threeDLayer) { is3d = true; }
            }
            if (is3d) { N.threeDLayer = true; }
            U.setPosStatic(N, [sx / list.length, sy / list.length]);
            N.moveBefore(top);
            if (a.parent) {
                for (var k = 0; k < list.length; k++) { if (!list[k].parent) { list[k].parent = N; } }
            }
        } else {
            U.setPosStatic(N, [c.width / 2, c.height / 2]);
        }
        return { name: N.name };
    };

    Q.addCamera = function () {
        var c = U.comp();
        var cam = c.layers.addCamera('Camera', [c.width / 2, c.height / 2]);
        return { name: cam.name };
    };

    Q.addText = function (a) {
        var c = U.comp();
        var prev = U.arr(c.selectedLayers);
        var L = c.layers.addText(a.text || 'Your Text');
        var r = L.sourceRectAtTime(c.time, false);
        U.setXY(U.tr(L).property('ADBE Anchor Point'), r.left + r.width / 2, r.top + r.height / 2);
        U.setPosStatic(L, [c.width / 2, c.height / 2]);
        placeAbove(c, L, prev);
        return { name: L.name };
    };

    /* ---------- rename / case ---------- */
    Q.rename = function (a) {
        var c = U.comp();
        var s = U.selSorted(c);
        var base = a.base || 'Layer';
        var n = parseInt(a.start, 10); if (isNaN(n)) { n = 1; }
        var pad = parseInt(a.pad, 10) || 2;
        for (var i = 0; i < s.length; i++) {
            s[i].name = (s.length === 1 && !a.number) ? base : (base + ' ' + U.pad(n + i, pad));
        }
        return { count: s.length };
    };

    function convertCase(t, mode) {
        if (mode === 'upper') { return t.toUpperCase(); }
        if (mode === 'lower') { return t.toLowerCase(); }
        if (mode === 'title') {
            return t.toLowerCase().replace(/(^|[\s\-\(\["'])([a-z])/g, function (m, p1, p2) { return p1 + p2.toUpperCase(); });
        }
        if (mode === 'sentence') {
            return t.toLowerCase().replace(/(^\s*|[\.\!\?]\s+)([a-z])/g, function (m, p1, p2) { return p1 + p2.toUpperCase(); });
        }
        return t;
    }

    Q.textCase = function (a) {
        var c = U.comp();
        var s = U.textLayers(c);
        for (var i = 0; i < s.length; i++) {
            var st = s[i].property('ADBE Text Properties').property('ADBE Text Document');
            if (st.numKeys > 0) {
                for (var k = 1; k <= st.numKeys; k++) {
                    var td = st.keyValue(k);
                    td.text = convertCase(td.text, a.mode);
                    st.setValueAtKey(k, td);
                }
            } else {
                var d = st.value;
                d.text = convertCase(d.text, a.mode);
                st.setValue(d);
            }
        }
        return { count: s.length };
    };

    /* ---------- split text into characters / words / lines ---------- */
    function copyDoc(src, text) {
        var d = src;
        d.text = text;
        try { d.justification = ParagraphJustification.LEFT_JUSTIFY; } catch (e) {}
        return d;
    }

    function measureRight(tmpProp, tmpLayer, baseDoc, str, time) {
        var d = copyDoc(baseDoc, str);
        tmpProp.setValue(d);
        var r = tmpLayer.sourceRectAtTime(time, false);
        return { left: r.left, right: r.left + r.width, top: r.top, height: r.height, width: r.width };
    }

    function tokenize(line, by) {
        var out = [];
        if (by === 'line') {
            if (U.trim(line).length) { out.push({ s: 0, t: line }); }
            return out;
        }
        if (by === 'word') {
            var re = /\S+/g, m;
            while ((m = re.exec(line)) !== null) { out.push({ s: m.index, t: m[0] }); }
            return out;
        }
        for (var i = 0; i < line.length; i++) {
            var ch = line.charAt(i);
            // keep Bangla vowel signs, hasanta conjuncts (ক্ষ) and joiners attached to their base letter
            var code = line.charCodeAt(i);
            var prev = out.length ? out[out.length - 1].t : '';
            var prevCode = prev ? prev.charCodeAt(prev.length - 1) : 0;
            var combining = (code >= 0x09BC && code <= 0x09D7) || code === 0x0981 || code === 0x0982 || code === 0x0983 || code === 0x200C || code === 0x200D;
            var joined = (prevCode === 0x09CD || prevCode === 0x200D) && !/\s/.test(ch);
            if (out.length && (combining || joined) && (out[out.length - 1].s + prev.length === i)) {
                out[out.length - 1].t += ch;
                continue;
            }
            if (/\s/.test(ch)) { continue; }
            out.push({ s: i, t: ch });
        }
        return out;
    }

    Q.splitText = function (a) {
        var c = U.comp();
        var by = a.by || 'char';
        var layers = U.textLayers(c);
        var made = 0, t = c.time;
        for (var li = 0; li < layers.length; li++) {
            var L = layers[li];
            var srcProp = L.property('ADBE Text Properties').property('ADBE Text Document');
            var doc = srcProp.valueAtTime(t, false);
            if (doc.boxText) { throw new Error('BOX_TEXT'); }
            var just = doc.justification;
            var leading = (doc.autoLeading || !doc.leading) ? doc.fontSize * 1.2 : doc.leading;
            var lines = String(doc.text).split(/\r\n|\r|\n/);

            // temp layer used only for measuring
            var tmp = L.duplicate();
            while (tmp.property('ADBE Text Properties').property('ADBE Text Animators').numProperties > 0) {
                tmp.property('ADBE Text Properties').property('ADBE Text Animators').property(1).remove();
            }
            var tmpProp = tmp.property('ADBE Text Properties').property('ADBE Text Document');
            if (tmpProp.numKeys > 0) { while (tmpProp.numKeys > 0) { tmpProp.removeKey(1); } }
            if (tmpProp.expression !== '') { tmpProp.expression = ''; }

            var created = [];
            for (var ln = 0; ln < lines.length; ln++) {
                var line = lines[ln];
                if (!U.trim(line).length) { continue; }
                // offset of this line caused by the original justification
                var lineOffset = 0;
                if (just !== ParagraphJustification.LEFT_JUSTIFY) {
                    var dj = doc; dj.text = line; dj.justification = just;
                    tmpProp.setValue(dj);
                    var rj = tmp.sourceRectAtTime(t, false);
                    var rl = measureRight(tmpProp, tmp, doc, line, t);
                    lineOffset = (rj.left + rj.width) - rl.right;
                }
                var toks = tokenize(line, by);
                for (var k = 0; k < toks.length; k++) {
                    var tok = toks[k];
                    var pre = measureRight(tmpProp, tmp, doc, line.substring(0, tok.s + tok.t.length), t);
                    var own = measureRight(tmpProp, tmp, doc, tok.t, t);
                    var penX = pre.right - own.right + lineOffset;
                    var penY = ln * leading;

                    var nl = L.duplicate();
                    var anim = nl.property('ADBE Text Properties').property('ADBE Text Animators');
                    while (anim.numProperties > 0) { anim.property(1).remove(); }
                    var np = nl.property('ADBE Text Properties').property('ADBE Text Document');
                    while (np.numKeys > 0) { np.removeKey(1); }
                    if (np.expression !== '') { np.expression = ''; }
                    np.setValue(copyDoc(doc, tok.t));
                    nl.name = tok.t;
                    while (nl.property('ADBE Effect Parade').numProperties > 0) { nl.property('ADBE Effect Parade').property(1).remove(); }
                    var ntr = U.tr(nl);
                    // reset this copy to identity, parent it to the original so it lands exactly on its glyph
                    var ap = ntr.property('ADBE Anchor Point'), ps = ntr.property('ADBE Position');
                    while (ap.numKeys > 0) { ap.removeKey(1); }
                    if (ps.dimensionsSeparated) { ps.dimensionsSeparated = false; }
                    while (ps.numKeys > 0) { ps.removeKey(1); }
                    var others = ['ADBE Scale', 'ADBE Rotate Z', 'ADBE Opacity'];
                    for (var o = 0; o < others.length; o++) {
                        var pr = ntr.property(others[o]);
                        while (pr.numKeys > 0) { pr.removeKey(1); }
                    }
                    var scv = ntr.property('ADBE Scale').value;
                    for (var sci = 0; sci < scv.length; sci++) { scv[sci] = 100; }
                    ntr.property('ADBE Scale').setValue(scv);
                    ntr.property('ADBE Rotate Z').setValue(0);
                    if (nl.threeDLayer) {
                        var r3 = ['ADBE Orientation', 'ADBE Rotate X', 'ADBE Rotate Y'];
                        for (var z = 0; z < 3; z++) {
                            var p3 = ntr.property(r3[z]);
                            while (p3.numKeys > 0) { p3.removeKey(1); }
                            p3.setValue(z ? 0 : [0, 0, 0]);
                        }
                    }
                    var r = nl.sourceRectAtTime(t, false);
                    var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
                    U.setXY(ap, cx, cy, 0);
                    nl.setParentWithJump(L);
                    U.setXY(ps, penX + cx, penY + cy, 0);
                    created.push(nl);
                }
            }
            tmp.remove();
            // un-parent (AE keeps every copy in place) and order them above the original
            for (var q = 0; q < created.length; q++) {
                created[q].parent = L.parent;
                created[q].moveBefore(L);
            }
            // keep the original hidden as a backup
            L.enabled = false;
            L.name = L.name + ' [original]';
            made += created.length;
        }
        return { count: made };
    };

    /* ---------- duplicate / time ---------- */
    Q.trueDuplicate = function () {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!(L.source instanceof CompItem)) { continue; }
            var nc = L.source.duplicate();
            nc.name = L.source.name + ' copy';
            var d = L.duplicate();
            d.replaceSource(nc, false);
            d.name = nc.name;
            n++;
        }
        if (!n) { throw new Error('NO_PRECOMP'); }
        return { count: n };
    };

    Q.splitAtPlayhead = function () {
        var c = U.comp();
        var s = U.sel(c), t = c.time, n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (t <= L.inPoint || t >= L.outPoint) { continue; }
            var d = L.duplicate();
            L.outPoint = t;
            d.inPoint = t;
            n++;
        }
        return { count: n };
    };

    Q.trim = function (a) {
        var c = U.comp();
        var s = U.sel(c), t = c.time;
        for (var i = 0; i < s.length; i++) {
            if (a.side === 'in' && t < s[i].outPoint) { s[i].inPoint = t; }
            if (a.side === 'out' && t > s[i].inPoint) { s[i].outPoint = t; }
        }
        return { count: s.length };
    };

    Q.sequence = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2);
        if (a.reverse) { s.reverse(); }
        var step = (parseFloat(a.frames) || 0) * c.frameDuration;
        var base = s[0].inPoint;
        var cursor = base;
        for (var i = 0; i < s.length; i++) {
            var target = a.mode === 'end' ? cursor : base + i * step;
            s[i].startTime += target - s[i].inPoint;
            if (a.mode === 'end') { cursor = s[i].outPoint + step; }
        }
        return { count: s.length };
    };

    Q.moveToPlayhead = function () {
        var c = U.comp();
        var s = U.sel(c);
        for (var i = 0; i < s.length; i++) { s[i].startTime += c.time - s[i].inPoint; }
        return { count: s.length };
    };

    /* ---------- transform helpers ---------- */
    Q.anchor = function (a) {
        var c = U.comp();
        var s = U.sel(c), skipped = 0, t = c.time;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!(L instanceof AVLayer) && !(L instanceof TextLayer) && !(L instanceof ShapeLayer)) { skipped++; continue; }
            var r = L.sourceRectAtTime(t, false);
            var ok = U.setAnchorKeep(L, r.left + r.width * a.x, r.top + r.height * a.y, t);
            if (!ok) { skipped++; }
        }
        return { count: s.length - skipped, skipped: skipped };
    };

    Q.align = function (a) {
        var c = U.comp();
        var s = U.sel(c), t = c.time, n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!(L instanceof AVLayer) && !(L instanceof TextLayer) && !(L instanceof ShapeLayer)) { continue; }
            var par = L.parent;
            if (par) { L.parent = null; }
            var b = U.bounds(L, t);
            var dx = 0, dy = 0;
            if (a.h === 'left') { dx = -b.left; }
            if (a.h === 'center') { dx = c.width / 2 - (b.left + b.width / 2); }
            if (a.h === 'right') { dx = c.width - b.right; }
            if (a.v === 'top') { dy = -b.top; }
            if (a.v === 'middle') { dy = c.height / 2 - (b.top + b.height / 2); }
            if (a.v === 'bottom') { dy = c.height - b.bottom; }
            U.shiftPosition(L, dx, dy);
            if (par) { L.parent = par; }
            n++;
        }
        return { count: n };
    };

    Q.fit = function (a) {
        var c = U.comp();
        var s = U.sel(c), t = c.time, n = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!(L instanceof AVLayer) && !(L instanceof TextLayer) && !(L instanceof ShapeLayer)) { continue; }
            var r = L.sourceRectAtTime(t, false);
            if (!r.width || !r.height) { continue; }
            var sx = c.width / r.width * 100, sy = c.height / r.height * 100;
            var k;
            if (a.mode === 'fill') { k = Math.max(sx, sy); }
            else if (a.mode === 'width') { k = sx; }
            else if (a.mode === 'height') { k = sy; }
            else { k = Math.min(sx, sy); }
            var par = L.parent;
            if (par) { L.parent = null; }
            var sc = U.tr(L).property('ADBE Scale');
            if (sc.numKeys === 0) {
                var cur = sc.value;
                var nv = [cur[0] < 0 ? -k : k, cur[1] < 0 ? -k : k];
                if (cur.length > 2) { nv.push(k); }
                sc.setValue(nv);
            }
            U.setAnchorKeep(L, r.left + r.width / 2, r.top + r.height / 2, t);
            U.setPosStatic(L, [c.width / 2, c.height / 2]);
            if (par) { L.parent = par; }
            n++;
        }
        return { count: n };
    };

    Q.flip = function (a) {
        var c = U.comp();
        var s = U.sel(c);
        for (var i = 0; i < s.length; i++) {
            var sc = U.tr(s[i]).property('ADBE Scale');
            var d = a.axis === 'v' ? 1 : 0;
            if (sc.numKeys > 0) {
                for (var k = 1; k <= sc.numKeys; k++) { var kv = sc.keyValue(k); kv[d] = -kv[d]; sc.setValueAtKey(k, kv); }
            } else {
                var v = sc.value; v[d] = -v[d]; sc.setValue(v);
            }
        }
        return { count: s.length };
    };

    /* ---------- effects / expressions ---------- */
    Q.toggleEffects = function (a) {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            var fx = s[i].property('ADBE Effect Parade');
            for (var k = 1; k <= fx.numProperties; k++) { fx.property(k).enabled = !!a.on; n++; }
        }
        return { count: n };
    };

    var EXPR = {
        bounce: function (p) {
            return '// All In One - bounce\n' +
                'var amp = ' + (p.amp || 0.06) + ', freq = ' + (p.freq || 2.5) + ', decay = ' + (p.decay || 6) + ';\n' +
                'var n = 0;\n' +
                'if (numKeys > 0) { n = nearestKey(time).index; if (key(n).time > time) { n--; } }\n' +
                'var t = (n > 0) ? time - key(n).time : 0;\n' +
                'if (n > 0 && n < numKeys + 1 && t < 3) {\n' +
                '  var v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n' +
                '  value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t);\n' +
                '} else { value; }';
        },
        wiggle: function (p) { return 'wiggle(' + (p.freq || 2) + ', ' + (p.amp || 25) + ')'; },
        loop: function () { return 'loopOut("cycle")'; },
        pingpong: function () { return 'loopOut("pingpong")'; },
        loopin: function () { return 'loopIn("cycle")'; },
        time: function (p) { return 'value + time * ' + (p.speed || 90); }
    };

    function selectedProps(c) {
        var out = [];
        var sp = c.selectedProperties;
        for (var i = 0; i < sp.length; i++) {
            if (sp[i].propertyType === PropertyType.PROPERTY) { out.push(sp[i]); }
        }
        return out;
    }

    Q.applyExpression = function (a) {
        var c = U.comp();
        var props = selectedProps(c);
        if (!props.length) { throw new Error('NO_PROPS'); }
        var gen = EXPR[a.type];
        var code = a.code || (gen ? gen(a.params || {}) : '');
        if (!code) { throw new Error('Unknown expression'); }
        var n = 0, errs = [];
        for (var i = 0; i < props.length; i++) {
            if (!props[i].canSetExpression) { continue; }
            props[i].expression = code;
            n++;
            try {
                props[i].valueAtTime(c.time, false);
                if (props[i].expressionError) { errs.push(props[i].name + ': ' + props[i].expressionError); }
            } catch (e) {}
        }
        if (!n) { throw new Error('NO_PROPS'); }
        return { count: n, errors: errs };
    };

    Q.removeExpressions = function () {
        var c = U.comp();
        var props = selectedProps(c), n = 0;
        var clear = function (p) { if (p.canSetExpression && p.expression !== '') { p.expression = ''; n++; } };
        if (props.length) {
            for (var i = 0; i < props.length; i++) { clear(props[i]); }
        } else {
            var s = U.sel(c);
            for (var j = 0; j < s.length; j++) { U.walk(s[j], clear); }
        }
        return { count: n };
    };

    /* ---------- project ---------- */
    var EXT = {
        video: 'mp4 mov avi mxf webm mkv m4v mpg mpeg wmv flv r3d braw mts m2ts 3gp',
        image: 'png jpg jpeg psd ai eps tif tiff gif bmp exr svg tga heic webp dpx hdr pdf',
        audio: 'wav mp3 aac m4a aif aiff ogg flac wma'
    };

    function kindOf(item) {
        if (item instanceof CompItem) { return 'comp'; }
        if (!(item instanceof FootageItem)) { return null; }
        var ms = item.mainSource;
        if (ms instanceof SolidSource) { return 'solid'; }
        if (ms instanceof PlaceholderSource) { return 'other'; }
        var f = ms.file;
        if (!f) { return 'other'; }
        var m = /\.([a-z0-9]+)$/i.exec(f.name);
        var ext = m ? ' ' + m[1].toLowerCase() + ' ' : '';
        if ((' ' + EXT.image + ' ').indexOf(ext) >= 0) { return ms.isStill ? 'image' : 'sequence'; }
        if ((' ' + EXT.video + ' ').indexOf(ext) >= 0) { return 'video'; }
        if ((' ' + EXT.audio + ' ').indexOf(ext) >= 0) { return 'audio'; }
        return 'other';
    }

    Q.organizeProject = function (a) {
        if (!app.project) { throw new Error('NO_PROJECT'); }
        var removed = 0;
        if (a.removeUnused) { removed = app.project.removeUnusedFootage() || 0; }
        var names = { comp: '01 Comps', video: '02 Video', image: '03 Images', sequence: '04 Image Sequences', audio: '05 Audio', solid: '06 Solids', other: '07 Other' };
        var ours = {};
        for (var k in names) { if (names.hasOwnProperty(k)) { ours[names[k]] = true; } }
        var root = app.project.rootFolder;
        var items = [];
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof FolderItem) { continue; }
            var parentName = it.parentFolder ? it.parentFolder.name : '';
            var atRoot = (it.parentFolder === root);
            var inOurs = (it.parentFolder && it.parentFolder.parentFolder === root && ours[parentName]);
            if (atRoot || inOurs || a.deep) { items.push(it); }
        }
        var moved = 0, folders = {};
        for (var j = 0; j < items.length; j++) {
            var kd = kindOf(items[j]);
            if (!kd) { continue; }
            if (!folders[kd]) { folders[kd] = U.projectFolder(names[kd]); }
            if (items[j].parentFolder !== folders[kd]) { items[j].parentFolder = folders[kd]; moved++; }
        }
        // drop empty folders left behind
        var emptied = 0;
        for (var r = app.project.numItems; r >= 1; r--) {
            var f = app.project.item(r);
            if (f instanceof FolderItem && f.numItems === 0 && (a.deep || ours[f.name])) { f.remove(); emptied++; }
        }
        return { moved: moved, removed: removed, emptied: emptied };
    };

    Q.labelColor = function (a) {
        var c = U.comp();
        var s = U.sel(c);
        for (var i = 0; i < s.length; i++) { s[i].label = a.label; }
        return { count: s.length };
    };

    return Q;
})();
