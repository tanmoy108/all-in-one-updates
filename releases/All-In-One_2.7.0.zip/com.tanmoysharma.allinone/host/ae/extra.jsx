/* All In One — extra tools (ExtendScript, ES3)
   crop comp · gradient lock · text highlight · replace layer source · silence cutter · SVG → shape layer */
MKH.ex = (function () {
    var U = MKH.util;
    var X = {};
    var TAG = '// All In One';

    function contents(L) { return L.property('ADBE Root Vectors Group'); }
    function fx(L, mn, name) { var e = L.property('ADBE Effect Parade').addProperty(mn); if (name) { e.name = name; } return e; }
    function uniqueName(c, base) {
        var taken = {}, n = 2, name = base;
        for (var i = 1; i <= c.numLayers; i++) { taken[c.layer(i).name] = true; }
        while (taken[name]) { name = base + ' ' + n++; }
        return name;
    }
    function q(s) { return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"'; }
    function isVisual(L) { return U.isVisual ? U.isVisual(L) : true; }
    function setKeys(prop, t0, t1, v0, v1, easeIn) {
        prop.setValueAtTime(t0, v0);
        prop.setValueAtTime(t1, v1);
        try {
            var dims = (v0 instanceof Array) ? v0.length : 1, eo = [], ei = [];
            for (var d = 0; d < dims; d++) { eo.push(new KeyframeEase(0, 75)); ei.push(new KeyframeEase(0, easeIn || 75)); }
            var k0 = prop.nearestKeyIndex(t0), k1 = prop.nearestKeyIndex(t1);
            prop.setTemporalEaseAtKey(k0, eo, eo);
            prop.setTemporalEaseAtKey(k1, ei, ei);
        } catch (e) {}
    }

    /* ---------- crop comp to the selected layers ---------- */
    X.cropComp = function (a) {
        var c = U.comp();
        var s = U.sel(c), t = c.time, pad = Math.max(0, parseFloat(a.pad) || 0);
        var L0 = 1e9, T0 = 1e9, R0 = -1e9, B0 = -1e9, n = 0;
        for (var i = 0; i < s.length; i++) {
            if (!isVisual(s[i])) { continue; }
            try {
                var b = U.bounds(s[i], t);
                if (!b.width || !b.height) { continue; }
                L0 = Math.min(L0, b.left); T0 = Math.min(T0, b.top); R0 = Math.max(R0, b.right); B0 = Math.max(B0, b.bottom); n++;
            } catch (e) {}
        }
        if (!n) { throw new Error('NO_LAYER'); }
        var x = Math.floor(L0 - pad), y = Math.floor(T0 - pad);
        var w = Math.ceil(R0 + pad) - x, h = Math.ceil(B0 + pad) - y;
        if (a.even !== false) { w += w % 2; h += h % 2; }
        w = U.clamp(w, 4, 30000); h = U.clamp(h, 4, 30000);
        var target = c;
        if (a.mode === 'new') {
            target = c.duplicate();
            target.name = c.name + ' (crop)';
        }
        target.width = w; target.height = h;
        for (var j = 1; j <= target.numLayers; j++) {
            var L = target.layer(j);
            if (L.parent) { continue; }
            try { U.shiftPosition(L, -x, -y); } catch (e2) {}
        }
        if (a.mode === 'new') { try { target.openInViewer(); } catch (e3) {} }
        return { w: w, h: h, name: target.name };
    };

    /* ---------- gradient that stays locked to the layer's bounds ---------- */
    X.gradientLock = function (a) {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        var c1 = a.c1 || [1, 0.25, 0.4], c2 = a.c2 || [0.35, 0.3, 1];
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!isVisual(L)) { continue; }
            var par = L.property('ADBE Effect Parade');
            for (var k = par.numProperties; k >= 1; k--) {
                if (/^AIO Gradient/.test(par.property(k).name)) { par.property(k).remove(); }
            }
            var ang = fx(L, 'ADBE Angle Control', 'AIO Gradient Angle');
            ang.property(1).setValue(parseFloat(a.angle) || 0);
            var r = fx(L, 'ADBE Ramp', 'AIO Gradient Lock');
            var radial = a.type === 'radial';
            r.property('ADBE Ramp-0005').setValue(radial ? 2 : 1);
            r.property('ADBE Ramp-0002').setValue(c1);
            r.property('ADBE Ramp-0004').setValue(c2);
            var head = TAG + ' - gradient lock\nvar r = sourceRectAtTime(time, false), cx = r.left + r.width / 2, cy = r.top + r.height / 2;\n';
            if (radial) {
                r.property('ADBE Ramp-0001').expression = head + '[cx, cy]';
                r.property('ADBE Ramp-0003').expression = head + '[cx + Math.max(r.width, r.height) / 2, cy]';
            } else {
                var body = 'var a = degreesToRadians(effect("AIO Gradient Angle")(1)), d = Math.abs(r.width / 2 * Math.cos(a)) + Math.abs(r.height / 2 * Math.sin(a));\n';
                r.property('ADBE Ramp-0001').expression = head + body + '[cx - Math.cos(a) * d, cy - Math.sin(a) * d]';
                r.property('ADBE Ramp-0003').expression = head + body + '[cx + Math.cos(a) * d, cy + Math.sin(a) * d]';
            }
            n++;
        }
        if (!n) { throw new Error('NO_LAYER'); }
        return { count: n };
    };

    /* ---------- animated highlight / marker / underline behind text ---------- */
    X.textHighlight = function (a) {
        var c = U.comp();
        var s = U.sel(c), made = [];
        var dur = Math.max(0.05, parseFloat(a.duration) || 0.5), pad = parseFloat(a.pad);
        if (isNaN(pad)) { pad = 12; }
        var style = a.style || 'box', dir = a.dir || 'left', col = a.color || [1, 0.85, 0.1];
        for (var i = 0; i < s.length; i++) {
            var T = s[i];
            if (!(T.property('ADBE Text Properties'))) { continue; }
            var S = c.layers.addShape();
            S.name = uniqueName(c, T.name + ' Highlight');
            S.moveAfter(T);
            S.startTime = T.startTime; S.inPoint = T.inPoint; S.outPoint = T.outPoint;
            S.parent = T;
            U.tr(S).property('ADBE Anchor Point').setValue([0, 0]);
            U.tr(S).property('ADBE Position').setValue([0, 0]);
            U.tr(S).property('ADBE Scale').setValue([100, 100]);
            var g = contents(S).addProperty('ADBE Vector Group');
            g.name = 'Highlight';
            var vg = g.property('ADBE Vectors Group');
            var rect = vg.addProperty('ADBE Vector Shape - Rect');
            var fill = vg.addProperty('ADBE Vector Graphic - Fill');
            fill.property('ADBE Vector Fill Color').setValue(col);
            var ref = 'var t = thisComp.layer(' + q(T.name) + '), r = t.sourceRectAtTime(time, false), p = ' + pad + ';\n';
            // height + vertical centre for each style
            var hy = style === 'underline' ? 'var h = Math.max(4, r.height * 0.12), y = r.top + r.height + h / 2 + p * 0.3;'
                : (style === 'marker' ? 'var h = r.height * 0.45 + p * 0.5, y = r.top + r.height - h / 2 + p * 0.25;'
                    : 'var h = r.height + p * 2, y = r.top + r.height / 2;');
            rect.property('ADBE Vector Rect Size').expression = TAG + ' - highlight\n' + ref + hy + '\n[r.width + p * 2, h]';
            rect.property('ADBE Vector Rect Roundness').setValue(style === 'underline' ? 2 : (parseFloat(a.round) || 8));
            var anchorX = dir === 'right' ? 'r.left + r.width + p' : (dir === 'center' ? 'r.left + r.width / 2' : 'r.left - p');
            var tg = g.property('ADBE Vector Transform Group');
            var pe = TAG + ' - highlight\n' + ref + hy + '\n[' + anchorX + ', y]';
            tg.property('ADBE Vector Anchor').expression = pe;
            tg.property('ADBE Vector Position').expression = pe;
            rect.property('ADBE Vector Rect Position').expression = TAG + ' - highlight\n' + ref + hy + '\n[r.left + r.width / 2, y]';
            var t0 = a.at === 'playhead' ? c.time : T.inPoint;
            setKeys(tg.property('ADBE Vector Scale'), t0, t0 + dur, [0, 100], [100, 100], 85);
            if (a.opacity) { tg.property('ADBE Vector Group Opacity').setValue(U.clamp(parseFloat(a.opacity), 1, 100)); }
            if (style === 'marker' && a.multiply !== false) { try { S.blendingMode = BlendingMode.MULTIPLY; } catch (e) {} }
            made.push(S);
        }
        if (!made.length) { throw new Error('NO_TEXT_LAYER'); }
        return { count: made.length };
    };

    /* ---------- selected still image layer (for remove-bg) ---------- */
    X.readSelImage = function () {
        var c = U.comp(), s = U.sel(c);
        for (var i = 0; i < s.length; i++) {
            var src = s[i].source;
            if (src instanceof FootageItem && src.mainSource instanceof FileSource && src.mainSource.isStill && src.file) {
                return { index: s[i].index, name: s[i].name, path: src.file.fsName, w: src.width, h: src.height };
            }
        }
        throw new Error('NO_IMAGE_LAYER');
    };
    // swap a layer's source for a new file, keeping its on-screen size
    X.replaceLayerSource = function (a) {
        var c = U.comp();
        var L = c.layer(a.index);
        if (!L || !L.source) { throw new Error('LAYER_GONE'); }
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var old = L.source, it = app.project.importFile(new ImportOptions(f));
        try { it.parentFolder = old.parentFolder; } catch (e) {}
        L.replaceSource(it, false);
        if (it.width && old.width && it.width !== old.width) {
            var k = old.width / it.width, sp = U.tr(L).property('ADBE Scale'), ap = U.tr(L).property('ADBE Anchor Point');
            try {
                if (sp.numKeys > 0) { for (var j = 1; j <= sp.numKeys; j++) { var v = sp.keyValue(j); v[0] *= k; v[1] *= k; sp.setValueAtKey(j, v); } }
                else { var v2 = sp.value; v2[0] *= k; v2[1] *= k; sp.setValue(v2); }
                if (ap.numKeys === 0) { var a0 = ap.value; a0[0] /= k; a0[1] /= k; ap.setValue(a0); }
            } catch (e2) {}
        }
        return { name: it.name };
    };

    /* ---------- silence cutter: keep only the given comp-time ranges of the layer ---------- */
    X.cutSilence = function (a) {
        var c = U.comp(), L = null, s = U.sel(c);
        for (var i = 0; i < s.length; i++) { if (s[i].hasAudio && s[i].source) { L = s[i]; break; } }
        if (!L) { throw new Error('NO_AUDIO_LAYER'); }
        var keep = a.keep || [];
        if (!keep.length) { throw new Error('NOTHING_TO_KEEP'); }
        var fr = c.frameDuration, snap = function (t) { return Math.round(t / fr) * fr; };
        var pieces = [], removed = 0, prevEnd = keep[0][0], in0 = L.inPoint, out0 = L.outPoint, first = true;
        for (var k = 0; k < keep.length; k++) {
            var st = snap(Math.max(in0, keep[k][0])), en = snap(Math.min(out0, keep[k][1]));
            if (en - st < fr) { continue; }
            var P = first ? L : L.duplicate();
            first = false;
            // order matters: never let in >= out while moving the ends
            if (en > P.inPoint) { P.outPoint = en; P.inPoint = st; } else { P.inPoint = st; P.outPoint = en; }
            if (a.close) {
                removed += Math.max(0, st - prevEnd);
                if (removed > 0) { P.startTime -= removed; }
            }
            prevEnd = en;
            pieces.push(P);
        }
        U.select(c, pieces);
        return { count: pieces.length, closed: a.close ? Math.round(removed * 100) / 100 : 0 };
    };

    /* ---------- SVG (already parsed by the panel) → shape layer ---------- */
    // a = { name, items: [{ paths: [{ v, i, o, closed }], fill, stroke, sw, cap, join, evenodd, opacity }], box: [x, y, w, h], size, anim, dur, at }
    X.svgToShape = function (a) {
        var c = U.comp();
        var S = c.layers.addShape();
        S.name = uniqueName(c, a.name || 'SVG');
        var box = a.box || [0, 0, 100, 100];
        var root = contents(S);
        var CAP = { butt: 1, round: 2, square: 3 }, JOIN = { miter: 1, round: 2, bevel: 3 };
        for (var i = 0; i < a.items.length; i++) {
            var it = a.items[i];
            var g = root.addProperty('ADBE Vector Group');
            g.name = it.name || ('Shape ' + (i + 1));
            var vg = g.property('ADBE Vectors Group');
            for (var p = 0; p < it.paths.length; p++) {
                var pd = it.paths[p];
                if (!pd.v || pd.v.length < 2) { continue; }
                var sh = new Shape();
                sh.vertices = pd.v; sh.inTangents = pd.i; sh.outTangents = pd.o; sh.closed = !!pd.closed;
                vg.addProperty('ADBE Vector Shape - Group').property('ADBE Vector Shape').setValue(sh);
            }
            if (it.fill) {
                var f = vg.addProperty('ADBE Vector Graphic - Fill');
                f.property('ADBE Vector Fill Color').setValue(it.fill);
                if (it.evenodd) { try { f.property('ADBE Vector Fill Rule').setValue(2); } catch (e) {} }
                if (it.fillOpacity !== undefined && it.fillOpacity < 1) { f.property('ADBE Vector Fill Opacity').setValue(it.fillOpacity * 100); }
            }
            if (it.stroke) {
                var st = vg.addProperty('ADBE Vector Graphic - Stroke');
                st.property('ADBE Vector Stroke Color').setValue(it.stroke);
                st.property('ADBE Vector Stroke Width').setValue(it.sw || 1);
                try { st.property('ADBE Vector Stroke Line Cap').setValue(CAP[it.cap] || 1); } catch (e2) {}
                try { st.property('ADBE Vector Stroke Line Join').setValue(JOIN[it.join] || 1); } catch (e3) {}
                if (it.strokeOpacity !== undefined && it.strokeOpacity < 1) { st.property('ADBE Vector Stroke Opacity').setValue(it.strokeOpacity * 100); }
            }
            if (it.opacity !== undefined && it.opacity < 1) { g.property('ADBE Vector Transform Group').property('ADBE Vector Group Opacity').setValue(it.opacity * 100); }
        }
        // centre + size
        var k = (parseFloat(a.size) || Math.min(c.width, c.height) * 0.3) / Math.max(box[2], box[3]) * 100;
        U.tr(S).property('ADBE Anchor Point').setValue([box[0] + box[2] / 2, box[1] + box[3] / 2]);
        U.tr(S).property('ADBE Position').setValue([c.width / 2, c.height / 2]);
        U.tr(S).property('ADBE Scale').setValue([k, k]);
        var t0 = a.at === 'start' ? 0 : c.time, d = Math.max(0.1, parseFloat(a.dur) || 0.6);
        S.startTime = 0;
        var tr = U.tr(S);
        if (a.anim === 'fade') { setKeys(tr.property('ADBE Opacity'), t0, t0 + d, 0, 100); }
        else if (a.anim === 'pop') {
            var sc = tr.property('ADBE Scale');
            sc.setValueAtTime(t0, [0, 0]); sc.setValueAtTime(t0 + d * 0.65, [k * 1.12, k * 1.12]); sc.setValueAtTime(t0 + d, [k, k]);
            try { for (var e = 1; e <= sc.numKeys; e++) { sc.setTemporalEaseAtKey(e, [new KeyframeEase(0, 60), new KeyframeEase(0, 60)]); } } catch (ex) {}
        } else if (a.anim === 'slide') {
            setKeys(tr.property('ADBE Position'), t0, t0 + d, [c.width / 2, c.height / 2 + c.height * 0.08], [c.width / 2, c.height / 2]);
            setKeys(tr.property('ADBE Opacity'), t0, t0 + d * 0.6, 0, 100);
        } else if (a.anim === 'draw') {
            var tp = root.addProperty('ADBE Vector Filter - Trim');
            setKeys(tp.property('ADBE Vector Trim End'), t0, t0 + d, 0, 100);
            // fills fade in after the line is drawn
            for (var gi = 1; gi <= root.numProperties; gi++) {
                var grp = root.property(gi);
                if (grp.matchName !== 'ADBE Vector Group') { continue; }
                var vv = grp.property('ADBE Vectors Group'), hasStroke = false, fl = null;
                for (var pi = 1; pi <= vv.numProperties; pi++) {
                    if (vv.property(pi).matchName === 'ADBE Vector Graphic - Stroke') { hasStroke = true; }
                    if (vv.property(pi).matchName === 'ADBE Vector Graphic - Fill') { fl = vv.property(pi); }
                }
                if (fl) {
                    if (!hasStroke) {
                        var ns = vv.addProperty('ADBE Vector Graphic - Stroke');
                        ns.property('ADBE Vector Stroke Color').setValue(fl.property('ADBE Vector Fill Color').value);
                        ns.property('ADBE Vector Stroke Width').setValue(Math.max(1, Math.max(box[2], box[3]) / 60));
                        setKeys(ns.property('ADBE Vector Stroke Opacity'), t0 + d, t0 + d * 1.3, 100, 0);
                    }
                    setKeys(fl.property('ADBE Vector Fill Opacity'), t0 + d * 0.7, t0 + d * 1.2, 0, fl.property('ADBE Vector Fill Opacity').value || 100);
                }
            }
        }
        U.select(c, [S]);
        return { name: S.name };
    };

    return X;
})();
