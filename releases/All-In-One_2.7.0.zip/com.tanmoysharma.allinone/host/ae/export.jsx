/* All In One — Export (render queue side) + Auto Podcast (ExtendScript, ES3)
   GIF / MP3 / fallback MP4 conversions happen in the panel with ffmpeg. */
MKH.exporter = (function () {
    var U = MKH.util;
    var X = {};

    X.getOutDir = function () {
        var base;
        if (app.project && app.project.file) { base = app.project.file.parent.fsName + '/All In One Exports'; }
        else { base = Folder.myDocuments.fsName + '/All In One/Exports'; }
        U.ensureFolder(base);
        return base;
    };

    X.getCompInfo = function () {
        var c = U.comp();
        return { name: c.name, width: c.width, height: c.height, fps: c.frameRate, duration: c.duration,
            workStart: c.workAreaStart, workDuration: c.workAreaDuration, hasAudio: c.hasAudio };
    };

    X.frame = function (a) {
        var c = U.comp();
        var f = new File(a.path);
        if (f.exists) { f.remove(); }
        c.saveFrameToPng(c.time, f);
        if (!U.waitForFile(f, 8000)) { throw new Error('CAPTURE_FAILED'); }
        return { path: f.fsName };
    };

    var TESTS = {
        lossless: [/^Lossless$/i, /^Lossless(?!.*Alpha)/i, /Lossless(?!.*Alpha)/i, /High Quality$/i],
        h264: [/H\.264/i],
        png: [/PNG/i],
        audio: [/WAV/i, /AIFF/i, /Audio Only/i]
    };

    function pickTemplate(list, kind) {
        var tests = TESTS[kind] || [];
        for (var t = 0; t < tests.length; t++) {
            for (var i = 0; i < list.length; i++) { if (tests[t].test(list[i])) { return list[i]; } }
        }
        return null;
    }

    X.listTemplates = function () {
        var c = U.comp();
        var item = app.project.renderQueue.items.add(c);
        var list = [];
        try { list = item.outputModule(1).templates; } finally { item.remove(); }
        return list;
    };

    // Renders the active comp with a matching output template. Other queued items are paused and restored.
    X.render = function (a) {
        var c = U.comp();
        var rq = app.project.renderQueue;
        var paused = [];
        for (var i = 1; i <= rq.numItems; i++) {
            var it = rq.item(i);
            if (it.status === RQItemStatus.QUEUED) { it.render = false; paused.push(it); }
        }
        var item = rq.items.add(c);
        try {
            if (a.range === 'work') { item.timeSpanStart = c.workAreaStart; item.timeSpanDuration = c.workAreaDuration; }
            else { item.timeSpanStart = 0; item.timeSpanDuration = c.duration; }
            var om = item.outputModule(1);
            var tpl = pickTemplate(om.templates, a.kind);
            if (tpl) { om.applyTemplate(tpl); }
            else {
                var fmt = { png: 'PNG Sequence', audio: 'WAV', lossless: 'QuickTime' }[a.kind];
                if (!fmt) { throw new Error('NO_TEMPLATE'); }
                try { om.setSettings({ 'Format': fmt }); } catch (e) { throw new Error('NO_TEMPLATE'); }
            }
            om.file = new File(a.path);
            rq.render();
            var out = om.file.fsName;
            return { path: out, template: tpl || '' };
        } finally {
            try { item.remove(); } catch (e2) {}
            for (var j = 0; j < paused.length; j++) { try { paused[j].render = true; } catch (e3) {} }
        }
    };

    return X;
})();

/* ---------- Auto Podcast: cut between camera layers by who is talking ---------- */
MKH.podcast = (function () {
    var U = MKH.util;
    var P = {};

    // loudness of one audio source over the work area, using AE's own "Convert Audio to Keyframes"
    function amplitude(c, src) {
        var id = app.findMenuCommandId('Convert Audio to Keyframes');
        if (!id) { throw new Error('NO_AUDIO_CMD'); }
        var states = [];
        for (var i = 1; i <= c.numLayers; i++) {
            var L = c.layer(i);
            if (L.hasAudio) { states.push([L, L.audioEnabled]); L.audioEnabled = (L === src); }
        }
        var before = c.numLayers;
        U.select(c, [src]);
        try { app.executeCommand(id); } finally {
            for (var s = 0; s < states.length; s++) { try { states[s][0].audioEnabled = states[s][1]; } catch (e) {} }
        }
        if (c.numLayers <= before) { throw new Error('NO_AUDIO_CMD'); }
        var amp = c.layer(1);
        var prop = amp.property('ADBE Effect Parade').property(3).property(1); // "Both Channels" › Slider
        var times = [], vals = [];
        for (var k = 1; k <= prop.numKeys; k++) { times.push(prop.keyTime(k)); vals.push(prop.keyValue(k)); }
        amp.remove();
        return { times: times, vals: vals };
    }

    function normalise(v) {
        var sorted = v.slice(0).sort(function (a, b) { return a - b; });
        var ref = sorted[Math.floor(sorted.length * 0.95)] || 1;
        var out = [];
        for (var i = 0; i < v.length; i++) { out.push(v[i] / (ref || 1)); }
        return out;
    }

    function smooth(v, w) {
        var out = [], acc = 0, q = [];
        for (var i = 0; i < v.length; i++) {
            q.push(v[i]); acc += v[i];
            if (q.length > w) { acc -= q.shift(); }
            out.push(acc / q.length);
        }
        return out;
    }

    // pure decision step, exposed for tests: returns [{f, who}] change points (who = -1 → wide shot)
    P.decide = function (series, opt) {
        var n = series[0].length, minHold = opt.minHold, thr = opt.threshold, wide = opt.wide, both = opt.both;
        var confirm = opt.confirm || Math.max(1, Math.round(minHold / 3));
        var cur = -2, since = 0, cand = -2, candSince = 0, changes = [];
        for (var f = 0; f < n; f++) {
            var best = 0, bestV = -1, second = -1;
            for (var i = 0; i < series.length; i++) {
                var v = series[i][f];
                if (v > bestV) { second = bestV; bestV = v; best = i; } else if (v > second) { second = v; }
            }
            var target = best;
            if (bestV < thr) { target = wide ? -1 : (cur < -1 ? best : cur); }
            else if (wide && both && second > bestV * 0.8) { target = -1; }
            if (cur === -2) { cur = target; cand = target; since = 0; changes.push({ f: 0, who: target }); continue; }
            if (target !== cand) { cand = target; candSince = f; }
            // a new speaker must hold the floor for a moment (no cuts on short "hmm"s) and shots last at least minHold
            if (cand !== cur && f - candSince >= confirm) {
                var at = Math.max(candSince, since + minHold);
                if (f >= at) { cur = cand; since = at; changes.push({ f: at, who: cand }); }
            }
        }
        return changes;
    };

    P.run = function (a) {
        var c = U.comp();
        var s = U.selSorted(c, 2);
        var vids = [], auds = [];
        for (var i = 0; i < s.length; i++) {
            if (s[i] instanceof AVLayer && s[i].hasVideo && !(s[i] instanceof TextLayer) && !(s[i] instanceof ShapeLayer)) { vids.push(s[i]); }
            else if (s[i].hasAudio) { auds.push(s[i]); }
        }
        var wideL = null;
        if (a.wide && vids.length >= 3) { wideL = vids.pop(); }        // bottom-most selected video = wide shot
        if (vids.length < 2) { throw new Error('NEED_2_CAMS'); }
        var sources = [];
        for (var v = 0; v < vids.length; v++) {
            if (auds.length === vids.length) { sources.push(auds[v]); }
            else if (vids[v].hasAudio) { sources.push(vids[v]); }
            else { throw new Error('CAM_NO_AUDIO'); }
        }
        for (var o = 0; o < vids.length; o++) {
            if (U.tr(vids[o]).property('ADBE Opacity').numKeys > 0) { throw new Error('HAS_OPACITY_KEYS'); }
        }
        var series = [], times = null, fps = c.frameRate;
        for (var k = 0; k < sources.length; k++) {
            var r = amplitude(c, sources[k]);
            if (!times || r.times.length < times.length) { times = r.times; }
            series.push(smooth(normalise(r.vals), Math.max(1, Math.round(fps * 0.25))));
        }
        if (!times || times.length < 2) { throw new Error('NO_AUDIO_DATA'); }
        for (var t = 0; t < series.length; t++) { series[t] = series[t].slice(0, times.length); }
        var changes = P.decide(series, {
            minHold: Math.max(1, Math.round((parseFloat(a.minShot) || 2) * fps)),
            threshold: (parseFloat(a.threshold) || 20) / 100,
            wide: !!wideL, both: a.both !== false
        });
        // opacity hold keys: active camera 100, others 0 (wide shot underneath stays visible)
        for (var cam = 0; cam < vids.length; cam++) {
            var op = U.tr(vids[cam]).property('ADBE Opacity');
            for (var ch = 0; ch < changes.length; ch++) {
                op.setValueAtTime(times[changes[ch].f], changes[ch].who === cam ? 100 : 0);
            }
            for (var kk = 1; kk <= op.numKeys; kk++) {
                op.setInterpolationTypeAtKey(kk, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);
            }
        }
        if (wideL) {
            for (var w = 0; w < vids.length; w++) { if (vids[w].index > wideL.index) { vids[w].moveBefore(wideL); } }
        }
        return { cuts: Math.max(0, changes.length - 1), cameras: vids.length, wide: !!wideL };
    };

    return P;
})();
