/* All In One — AI helpers (ExtendScript, ES3). The AI calls happen in the panel. */
MKH.ai = (function () {
    var U = MKH.util;
    var A = {};

    function layerType(L) {
        if (L instanceof TextLayer) { return 'text'; }
        if (L instanceof ShapeLayer) { return 'shape'; }
        if (L instanceof CameraLayer) { return 'camera'; }
        if (L instanceof LightLayer) { return 'light'; }
        if (L.nullLayer) { return 'null'; }
        if (L.adjustmentLayer) { return 'adjustment'; }
        if (L.source instanceof CompItem) { return 'precomp'; }
        if (L.source && L.source.mainSource instanceof SolidSource) { return 'solid'; }
        return 'footage';
    }

    function compact(v) {
        if (v instanceof Array) {
            var o = [];
            for (var i = 0; i < v.length; i++) { o.push(Math.round(v[i] * 100) / 100); }
            return o;
        }
        if (typeof v === 'number') { return Math.round(v * 1000) / 1000; }
        return null;
    }

    A.getContext = function () {
        var c = U.compOrNull();
        var o = { ae: app.version, comp: null, layers: [], properties: [] };
        if (!c) { return o; }
        o.comp = { name: c.name, width: c.width, height: c.height, fps: c.frameRate, duration: c.duration, time: c.time, numLayers: c.numLayers };
        var s = c.selectedLayers;
        for (var i = 0; i < s.length && i < 12; i++) {
            var L = s[i];
            var fx = [], ep = L.property('ADBE Effect Parade');
            if (ep) { for (var k = 1; k <= ep.numProperties && k <= 12; k++) { fx.push(ep.property(k).name); } }
            var info = { index: L.index, name: L.name, type: layerType(L), inPoint: L.inPoint, outPoint: L.outPoint, threeD: !!L.threeDLayer, parent: L.parent ? L.parent.name : null, effects: fx };
            if (L instanceof TextLayer) {
                try { info.text = String(L.property('ADBE Text Properties').property('ADBE Text Document').value.text).substring(0, 300); } catch (e) {}
            }
            o.layers.push(info);
        }
        var sp = c.selectedProperties;
        for (var j = 0; j < sp.length && o.properties.length < 12; j++) {
            var p = sp[j];
            if (p.propertyType !== PropertyType.PROPERTY) { continue; }
            var pi = { name: p.name, matchName: p.matchName, layer: '', numKeys: p.numKeys, expression: '', error: '' };
            try { pi.layer = p.propertyGroup(p.propertyDepth).name; } catch (e1) {}
            try { pi.value = compact(p.valueAtTime(c.time, false)); } catch (e2) {}
            if (p.canSetExpression) { pi.expression = p.expression; pi.error = p.expressionError; }
            o.properties.push(pi);
        }
        return o;
    };

    A.getSelectedExpression = function () {
        var c = U.comp();
        var sp = c.selectedProperties;
        for (var i = 0; i < sp.length; i++) {
            var p = sp[i];
            if (p.propertyType === PropertyType.PROPERTY && p.canSetExpression) {
                var layer = '';
                try { layer = p.propertyGroup(p.propertyDepth).name; } catch (e) {}
                return { name: p.name, matchName: p.matchName, layer: layer, expression: p.expression, error: p.expressionError };
            }
        }
        throw new Error('NO_PROPS');
    };

    A.getTexts = function () {
        var c = U.comp();
        var s = U.textLayers(c), out = [];
        for (var i = 0; i < s.length; i++) {
            out.push({ index: s[i].index, name: s[i].name, text: String(s[i].property('ADBE Text Properties').property('ADBE Text Document').value.text) });
        }
        return out;
    };

    A.setTexts = function (a) {
        var c = U.comp();
        var items = a.items || [], n = 0, jobs = [];
        // resolve layer objects first: duplicate() shifts the indices of everything below
        for (var j = 0; j < items.length; j++) {
            var ix = items[j].index;
            if (ix >= 1 && ix <= c.numLayers && c.layer(ix) instanceof TextLayer) { jobs.push([c.layer(ix), items[j].text]); }
        }
        for (var i = 0; i < jobs.length; i++) {
            var L = jobs[i][0];
            var prop = L.property('ADBE Text Properties').property('ADBE Text Document');
            if (a.duplicate) { L = L.duplicate(); prop = L.property('ADBE Text Properties').property('ADBE Text Document'); L.name = L.name + ' [' + (a.tag || 'tr') + ']'; }
            if (prop.numKeys > 0) {
                var kv = prop.keyValue(1); kv.text = jobs[i][1]; prop.setValueAtKey(1, kv);
            } else {
                var d = prop.value; d.text = jobs[i][1]; prop.setValue(d);
            }
            n++;
        }
        return { count: n };
    };

    A.captureFrame = function (a) {
        var c = U.comp();
        var f = new File(a.path);
        if (f.exists) { f.remove(); }
        c.saveFrameToPng(c.time, f);
        if (!U.waitForFile(f, 6000)) { throw new Error('CAPTURE_FAILED'); }
        $.sleep(200);
        return { path: f.fsName };
    };

    return A;
})();
