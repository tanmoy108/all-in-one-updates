/* All In One — Motion presets: keyframed In/Out animations + expression loops (ExtendScript, ES3)
   The preset shapes (tracks) live in the panel (js/modules/motion.js) so preview and result share one definition. */
MKH.motion = (function () {
    var U = MKH.util;
    var M = {};
    var TAG = '// AIO Motion';
    var FX = { blur: ['ADBE Gaussian Blur 2', 'AIO Blur'], dirblur: ['ADBE Motion Blur', 'AIO Motion Blur'] };
    var WIPE = 'AIO Wipe';

    function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }
    // footage, precomp, solid, null, text and shape layers — audio-only, camera and light layers are skipped
    function isVisual(L) { return U.isVisual(L); }

    function findFx(L, name) {
        var p = L.property('ADBE Effect Parade');
        for (var i = 1; i <= p.numProperties; i++) { if (p.property(i).name === name) { return p.property(i); } }
        return null;
    }
    function ensureFx(L, kind) {
        var spec = FX[kind];
        var e = findFx(L, spec[1]);
        if (!e) {
            e = L.property('ADBE Effect Parade').addProperty(spec[0]);
            e.name = spec[1];
        }
        return e;
    }

    /* ---------- value builders ---------- */
    // returns a list of { prop, base, make(v) } targets for one track
    function targets(L, tr, a) {
        var T = U.tr(L);
        var p = tr.p;
        var dist = num(a.dist, 200), str = num(a.strength, 1);
        if (p === 'opacity') {
            var op = T.property('ADBE Opacity');
            return [{ prop: op, make: function (base, v) { return base * v; } }];
        }
        if (p === 'scale') {
            var sc = T.property('ADBE Scale');
            return [{ prop: sc, make: function (base, v) {
                var mx = (v instanceof Array) ? v[0] : v, my = (v instanceof Array) ? v[1] : v;
                // strength pulls the multiplier toward 1
                mx = 1 + (mx - 1) * str; my = 1 + (my - 1) * str;
                var o = [base[0] * mx, base[1] * my];
                if (base.length > 2) { o.push(base[2] * ((v instanceof Array) ? 1 : (1 + (v - 1) * str))); }
                return o;
            } }];
        }
        if (p === 'rot') {
            var rot = T.property('ADBE Rotate Z');
            return [{ prop: rot, make: function (base, v) { return base + v * str; } }];
        }
        if (p === 'pos') {
            var pos = T.property('ADBE Position');
            var unit = tr.unit === 'w' ? L.containingComp.width : dist;
            if (pos.dimensionsSeparated) {
                return [
                    { prop: T.property('ADBE Position_0'), make: function (base, v) { return base + v[0] * unit; } },
                    { prop: T.property('ADBE Position_1'), make: function (base, v) { return base + v[1] * unit; } }
                ];
            }
            return [{ prop: pos, spatial: true, make: function (base, v) {
                var o = base.slice(0); o[0] += v[0] * unit; o[1] += v[1] * unit; return o;
            } }];
        }
        if (p === 'blur' || p === 'dirblur') {
            var e = ensureFx(L, p);
            if (p === 'dirblur') { try { e.property(1).setValue(tr.angle === undefined ? 90 : tr.angle); } catch (e1) {} }
            var target = (p === 'dirblur') ? e.property(2) : e.property(1);
            return [{ prop: target, absolute: true, make: function (base, v) { return v * str; } }];
        }
        if (p === 'wipe') {
            // a rectangle mask around the layer's content (text / shape layers are comp-sized, so a
            // Linear Wipe would sweep the whole frame); completion 100 = hidden, 0 = fully visible
            var m = wipeMask(L, a);
            var b = m.box, ang = tr.angle === undefined ? 270 : tr.angle;
            return [{ prop: m.path, absolute: true, make: function (base, v) {
                var u = 1 - U.clamp(v, 0, 100) / 100;
                var x0 = b[0], y0 = b[1], x1 = b[2], y1 = b[3];
                if (ang === 270) { x1 = x0 + (x1 - x0) * u; }
                else if (ang === 90) { x0 = x1 - (x1 - x0) * u; }
                else if (ang === 180) { y0 = y1 - (y1 - y0) * u; }
                else { y1 = y0 + (y1 - y0) * u; }
                var sh = new Shape();
                sh.vertices = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
                sh.closed = true;
                return sh;
            } }];
        }
        throw new Error('BAD_TRACK ' + p);
    }

    function wipeMask(L, a) {
        var masks = L.property('ADBE Mask Parade'), mk = null;
        for (var i = 1; i <= masks.numProperties; i++) { if (masks.property(i).name === WIPE) { mk = masks.property(i); } }
        var c = L.containingComp;
        var r = L.sourceRectAtTime(Math.max(0, Math.min(c.duration, a._rest || c.time)), U.isShape(L));
        var pad = Math.max(6, 0.06 * Math.max(r.width, r.height));
        var box = [r.left - pad, r.top - pad, r.left + r.width + pad, r.top + r.height + pad];
        if (!mk) {
            mk = masks.addProperty('ADBE Mask Atom');
            mk.name = WIPE;
            try { mk.property('ADBE Mask Feather').setValue([8, 8]); } catch (e) {}
        }
        return { path: mk.property('ADBE Mask Shape'), box: box };
    }

    function keyIndexAt(prop, t) {
        var k = prop.nearestKeyIndex(t);
        return (k > 0 && Math.abs(prop.keyTime(k) - t) < 1e-4) ? k : 0;
    }

    function easeArr(prop, k, speed, inf) {
        var n = prop.keyInTemporalEase(k).length, a = [];
        for (var i = 0; i < n; i++) { a.push(new KeyframeEase(speed, U.clamp(inf, 0.1, 100))); }
        return a;
    }

    // set keys for one track between t0 and t0+dur; reverse = OUT animation
    function track(L, tr, t0, dur, reverse, a) {
        var keys = tr.k;
        var fd = L.containingComp.frameDuration;
        a._rest = reverse ? t0 : t0 + dur;
        var tg = targets(L, tr, a);
        var easeO = num(a.ease && a.ease.o, 33), easeI = num(a.ease && a.ease.i, 33);
        var linear = a.ease && a.ease.linear;
        for (var g = 0; g < tg.length; g++) {
            var prop = tg[g].prop;
            if (!prop || !prop.canVaryOverTime) { continue; }
            var restT = reverse ? t0 : t0 + dur;
            // pre-expression value: a loop already on the property must not be baked into the keys
            var base = tg[g].absolute ? 0 : prop.valueAtTime(restT, true);
            var made = [], seen = {};
            for (var i = 0; i < keys.length; i++) {
                var f = keys[i][0], v = keys[i][1];
                var t = reverse ? t0 + (1 - f) * dur : t0 + f * dur;
                t = Math.round(t / fd) * fd;
                var val = tg[g].make(base, v);
                prop.setValueAtTime(t, val);
                var id = Math.round(t / fd);
                if (seen[id]) { seen[id].hint = keys[i][2] || ''; continue; }
                seen[id] = { t: t, hint: keys[i][2] || '' };
                made.push(seen[id]);
            }
            made.sort(function (x, y) { return x.t - y.t; });
            for (var m = 0; m < made.length; m++) {
                var ki = keyIndexAt(prop, made[m].t);
                if (!ki) { continue; }
                if (linear) {
                    prop.setInterpolationTypeAtKey(ki, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                } else if (made[m].hint === 'L') {
                    // impact keys (bounces) keep their speed: linear on both sides
                    prop.setInterpolationTypeAtKey(ki, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                } else {
                    var first = m === 0, last = m === made.length - 1;
                    var inInf = last ? (reverse ? easeO : easeI) : 40;
                    var outInf = first ? (reverse ? easeI : easeO) : 40;
                    prop.setInterpolationTypeAtKey(ki, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                    prop.setTemporalEaseAtKey(ki, easeArr(prop, ki, 0, inInf), easeArr(prop, ki, 0, outInf));
                }
                if (tg[g].spatial) {
                    try {
                        var zero = prop.value.length > 2 ? [0, 0, 0] : [0, 0];
                        prop.setSpatialTangentsAtKey(ki, zero, zero);
                    } catch (e) {}
                }
            }
        }
    }

    function frameSnap(c, t) { return Math.round(t / c.frameDuration) * c.frameDuration; }

    M.apply = function (a) {
        var c = U.comp();
        var layers = U.selSorted(c);
        var tracks = a.tracks || [];
        if (!tracks.length) { throw new Error('BAD_PRESET'); }
        var dur = U.clamp(num(a.dur, 0.6), c.frameDuration * 2, 60);
        var stag = Math.max(0, num(a.stagger, 0)) * c.frameDuration;
        var mode = a.mode || 'in';
        var n = 0, skipped = 0, warnings = [], outSkipped = 0;
        var todo = [];
        for (var q = 0; q < layers.length; q++) {
            if (!isVisual(layers[q]) || layers[q].locked) { skipped++; } else { todo.push(layers[q]); }
        }
        for (var i = 0; i < todo.length; i++) {
            var L = todo[i];
            // only the part of the layer that is inside the comp
            var inT = Math.max(L.inPoint, 0), outT = Math.min(L.outPoint, c.duration);
            var len = outT - inT;
            var d = dur;
            if (mode === 'both' && a.at !== 'playhead' && len < dur * 2) { d = Math.max(c.frameDuration * 2, len / 2.2); }
            var j, tin = null;
            if (mode === 'in' || mode === 'both') {
                tin = frameSnap(c, (a.at === 'playhead' ? c.time : inT) + i * stag);
                for (j = 0; j < tracks.length; j++) { track(L, tracks[j], tin, d, false, a); }
            }
            if (mode === 'out' || mode === 'both') {
                var tout;
                if (a.at === 'playhead' && mode === 'out') { tout = c.time + i * stag; }
                else { tout = outT - c.frameDuration - d - (todo.length - 1 - i) * stag; }
                tout = frameSnap(c, Math.max(inT, tout));
                // never start the OUT before the IN has finished
                if (tin !== null && tout < tin + d) { tout = frameSnap(c, tin + d); }
                if (tout + d <= outT + 1e-6 || tin === null) {
                    for (j = 0; j < tracks.length; j++) { track(L, tracks[j], tout, d, true, a); }
                } else { outSkipped++; }
            }
            n++;
        }
        if (outSkipped) { warnings.push(outSkipped + ' layer(s) too short for the OUT animation'); }
        if (!n) { throw new Error('NO_LAYER'); }
        if (skipped) { warnings.push(skipped + ' skipped (locked / camera / light / audio)'); }
        return { count: n, warnings: warnings };
    };

    /* ---------- loops (expressions, non-destructive) ---------- */
    function loopExpr(kind, sep, amt, f) {
        var head = TAG + ' - ' + kind + '\nvar t = time - inPoint, f = ' + f + ', a = ' + amt + ';\n';
        var TWO_PI = '2 * Math.PI';
        switch (kind) {
            case 'pulse': return head + 'var k = 1 + 0.08 * a * (0.5 - 0.5 * Math.cos(' + TWO_PI + ' * f * t));\nmul(value, k)';
            case 'heartbeat': return head + 'var p = 1 / f, u = t % p;\nvar k = 1 + 0.12 * a * (Math.exp(-Math.pow((u - 0.12) / 0.06, 2)) + 0.7 * Math.exp(-Math.pow((u - 0.34) / 0.06, 2)));\nmul(value, k)';
            case 'jelly': return head + 'var s = 0.06 * a * Math.sin(' + TWO_PI + ' * f * t);\nvar v = value;\nv[0] = v[0] * (1 + s); v[1] = v[1] * (1 - s);\nv';
            case 'float': return sep ? head + 'value + 18 * a * Math.sin(' + TWO_PI + ' * f * t)'
                : head + 'var v = value;\nv[1] = v[1] + 18 * a * Math.sin(' + TWO_PI + ' * f * t);\nv';
            case 'shake': return head + 'wiggle(10 * f, 10 * a)';
            case 'spin': return head + 'value + 360 * f * t';
            case 'swing': return head + 'value + 12 * a * Math.sin(' + TWO_PI + ' * f * t)';
            case 'blink': return head + 'var on = Math.sin(' + TWO_PI + ' * f * t) >= 0;\non ? value : value * 0.15';
        }
        throw new Error('BAD_PRESET');
    }

    M.loop = function (a) {
        var c = U.comp();
        var layers = U.selSorted(c);
        var kind = a.kind;
        var amt = Math.round(U.clamp(num(a.amount, 1), 0, 10) * 1000) / 1000;
        var f = Math.round(U.clamp(num(a.speed, 1), 0.05, 20) * 1000) / 1000;
        var n = 0, replaced = 0;
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            if (!isVisual(L) || L.locked) { continue; }
            var T = U.tr(L), list = [];
            if (kind === 'pulse' || kind === 'heartbeat' || kind === 'jelly') { list.push([T.property('ADBE Scale'), false]); }
            else if (kind === 'spin' || kind === 'swing') { list.push([T.property('ADBE Rotate Z'), false]); }
            else if (kind === 'blink') { list.push([T.property('ADBE Opacity'), false]); }
            else if (kind === 'float') {
                var pos = T.property('ADBE Position');
                list.push(pos.dimensionsSeparated ? [T.property('ADBE Position_1'), true] : [pos, false]);
            } else if (kind === 'shake') {
                var ps = T.property('ADBE Position');
                if (ps.dimensionsSeparated) { list.push([T.property('ADBE Position_0'), true]); list.push([T.property('ADBE Position_1'), true]); }
                else { list.push([ps, false]); }
            }
            for (var j = 0; j < list.length; j++) {
                var prop = list[j][0];
                if (prop.expression && prop.expression.indexOf(TAG) !== 0) { replaced++; }
                prop.expression = loopExpr(kind, list[j][1], amt, f);
            }
            n++;
        }
        if (!n) { throw new Error('NO_LAYER'); }
        return { count: n, warnings: replaced ? ['replaced ' + replaced + ' existing expression(s)'] : [] };
    };

    // remove AIO loops + AIO effects; optionally every key on the basic transform properties
    M.clear = function (a) {
        var c = U.comp();
        var layers = U.sel(c);
        var n = 0;
        var names = ['ADBE Opacity', 'ADBE Scale', 'ADBE Rotate Z', 'ADBE Position', 'ADBE Position_0', 'ADBE Position_1'];
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            if (!isVisual(L) || L.locked) { continue; }
            var T = U.tr(L);
            for (var j = 0; j < names.length; j++) {
                var p = T.property(names[j]);
                if (!p) { continue; }
                try { if (p.expression && p.expression.indexOf(TAG) === 0) { p.expression = ''; } } catch (e) {}
                if (a.keys) {
                    try { while (p.numKeys > 0) { p.removeKey(p.numKeys); } } catch (e1) {}
                }
            }
            for (var k in FX) {
                if (FX.hasOwnProperty(k)) { var fx = findFx(L, FX[k][1]); if (fx) { try { fx.remove(); } catch (e2) {} } }
            }
            var fxw = findFx(L, 'AIO Wipe');
            if (fxw) { try { fxw.remove(); } catch (e3) {} }
            try {
                var masks = L.property('ADBE Mask Parade');
                for (var mi = masks.numProperties; mi >= 1; mi--) { if (masks.property(mi).name === WIPE) { masks.property(mi).remove(); } }
            } catch (e4) {}
            n++;
        }
        return { count: n };
    };

    return M;
})();
