/* All In One — Copyright check + HDR → Rec.709 (ExtendScript, ES3)
   MKH.cr  : render the comp's audio for music recognition, list media sources, copyright markers
   MKH.hdr : find video files used in a comp/project and swap them for converted Rec.709 copies */
MKH.cr = (function () {
    var U = MKH.util;
    var C = {};
    var MARK = '⚠ © ';
    var AUDIO_TPL = [/AIFF/i, /WAV/i, /Audio Only/i];

    function allComps(root) {
        var seen = {}, out = [];
        (function go(c, d) {
            if (seen[c.id] || d > 8) { return; }
            seen[c.id] = true; out.push(c);
            for (var i = 1; i <= c.numLayers; i++) { var s = c.layer(i).source; if (s && s instanceof CompItem) { go(s, d + 1); } }
        })(root, 0);
        return out;
    }

    // render the active comp's audio (work area or whole comp) → { path, start, duration }
    C.renderCompAudio = function (a) {
        var c = U.comp();
        if (!c.hasAudio) { throw new Error('NO_AUDIO_IN_COMP'); }
        var rq = app.project.renderQueue, rqItem = null, paused = [];
        var start = a.range === 'comp' ? 0 : c.workAreaStart;
        var dur = a.range === 'comp' ? c.duration : c.workAreaDuration;
        try {
            for (var i = 1; i <= rq.numItems; i++) {
                var it = rq.item(i);
                if (it.status === RQItemStatus.QUEUED) { it.render = false; paused.push(it); }
            }
            rqItem = rq.items.add(c);
            try { rqItem.timeSpanStart = start; rqItem.timeSpanDuration = dur; } catch (eS) {}
            var om = rqItem.outputModule(1), tpl = null, list = om.templates;
            for (var t = 0; t < AUDIO_TPL.length && !tpl; t++) {
                for (var k = 0; k < list.length; k++) { if (AUDIO_TPL[t].test(list[k])) { tpl = list[k]; break; } }
            }
            if (tpl) { om.applyTemplate(tpl); }
            else { try { om.setSettings({ 'Format': 'WAV', 'Output Audio': true, 'Output Video': false }); } catch (e) { throw new Error('NO_TEMPLATE'); } }
            om.file = new File(a.out);
            rq.render();
            var want = new File(a.out), folder = want.parent, base = want.name.replace(/\.[^.]*$/, '');
            var hits = folder.getFiles(function (x) { return (x instanceof File) && x.name.indexOf(base) === 0; });
            if (!hits.length) { throw new Error('RENDER_FAILED'); }
            return { path: hits[0].fsName, start: start, duration: dur, comp: c.name };
        } finally {
            try { if (rqItem) { rqItem.remove(); } } catch (e2) {}
            for (var j = 0; j < paused.length; j++) { try { paused[j].render = true; } catch (e3) {} }
        }
    };

    // every file used in the active comp (and its precomps), with where it first appears
    C.readSources = function () {
        var root = U.comp(), comps = allComps(root), items = {}, list = [];
        for (var ci = 0; ci < comps.length; ci++) {
            var C2 = comps[ci];
            for (var li = 1; li <= C2.numLayers; li++) {
                var L = C2.layer(li), s = L.source;
                if (!s || !(s instanceof FootageItem) || !s.mainSource || !(s.mainSource instanceof FileSource)) { continue; }
                if (!items[s.id]) {
                    var f = s.mainSource.file;
                    items[s.id] = { id: s.id, name: s.name, path: f ? f.fsName : '', audio: !!s.hasAudio, video: !!s.hasVideo, still: !!s.mainSource.isStill,
                        uses: 0, comps: [], at: -1, muted: true };
                    list.push(items[s.id]);
                }
                var o = items[s.id];
                o.uses++;
                if (o.comps.length < 4 && ('|' + o.comps.join('|') + '|').indexOf('|' + C2.name + '|') < 0) { o.comps.push(C2.name); }
                if (C2 === root && (o.at < 0 || L.inPoint < o.at)) { o.at = Math.round(L.inPoint * 100) / 100; }
                try { if (L.hasAudio && L.audioEnabled) { o.muted = false; } } catch (e) {}
            }
        }
        return { comp: root.name, items: list };
    };

    function clear(c) {
        var mp = c.markerProperty, n = 0;
        for (var k = mp.numKeys; k >= 1; k--) {
            try { if (String(mp.keyValue(k).comment).indexOf(MARK) === 0) { mp.removeKey(k); n++; } } catch (e) {}
        }
        return n;
    }
    C.addMarkers = function (a) {
        var c = U.comp();
        clear(c);
        var hits = a.hits || [];
        for (var i = 0; i < hits.length; i++) {
            var mv = new MarkerValue(MARK + hits[i].label);
            try { mv.duration = Math.max(0, hits[i].d || 0); } catch (e) {}
            try { mv.label = 1; } catch (e2) {}
            c.markerProperty.setValueAtTime(hits[i].t, mv);
        }
        return { count: hits.length };
    };
    C.clearMarkers = function () { return { count: clear(U.comp()) }; };

    return C;
})();

MKH.hdr = (function () {
    var U = MKH.util;
    var H = {};

    function addItem(map, list, s) {
        if (!s || !(s instanceof FootageItem) || !s.mainSource || !(s.mainSource instanceof FileSource)) { return; }
        if (!s.hasVideo || s.mainSource.isStill || !s.mainSource.file) { return; }
        if (!map[s.id]) { map[s.id] = { id: s.id, name: s.name, path: s.mainSource.file.fsName, w: s.width, h: s.height, dur: Math.round(s.duration * 100) / 100, uses: 0 }; list.push(map[s.id]); }
        map[s.id].uses++;
    }

    // read-only: video files in the selected layers / active comp (+precomps) / whole project
    H.readTargets = function (a) {
        var map = {}, list = [], i, j;
        if (a.scope === 'project') {
            for (i = 1; i <= app.project.numItems; i++) { addItem(map, list, app.project.item(i)); }
            return { items: list };
        }
        var c = U.comp();
        if (a.scope === 'selected') {
            var s = c.selectedLayers;
            if (!s.length) { throw new Error('NO_LAYER'); }
            for (i = 0; i < s.length; i++) {
                var src = s[i].source;
                if (src instanceof CompItem) { for (j = 1; j <= src.numLayers; j++) { addItem(map, list, src.layer(j).source); } }
                else { addItem(map, list, src); }
            }
            return { items: list };
        }
        var seen = {};
        (function go(cc, d) {
            if (seen[cc.id] || d > 8) { return; }
            seen[cc.id] = true;
            for (var k = 1; k <= cc.numLayers; k++) {
                var sr = cc.layer(k).source;
                if (sr instanceof CompItem) { go(sr, d + 1); } else { addItem(map, list, sr); }
            }
        })(c, 0);
        return { items: list };
    };

    // point the footage item at the converted file (every layer that uses it follows)
    H.replace = function (a) {
        var it = null;
        for (var i = 1; i <= app.project.numItems; i++) { if (app.project.item(i).id === a.itemId) { it = app.project.item(i); break; } }
        if (!it || !(it instanceof FootageItem)) { throw new Error('ITEM_GONE'); }
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var oldName = it.name;
        it.replace(f);
        try { if (a.keepName) { it.name = oldName.replace(/\.[^.]+$/, '') + ' (709)'; } } catch (e) {}
        return { name: it.name, w: it.width, h: it.height };
    };

    return H;
})();
