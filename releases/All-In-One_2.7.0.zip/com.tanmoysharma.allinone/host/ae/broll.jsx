/* All In One — B-Roll import (ExtendScript, ES3). Downloads happen in the panel (Node). */
MKH.broll = (function () {
    var U = MKH.util;
    var B = {};

    B.getDownloadDir = function () {
        var base;
        if (app.project && app.project.file) { base = app.project.file.parent.fsName + '/All In One B-Roll'; }
        else { base = Folder.myDocuments.fsName + '/All In One/B-Roll'; }
        U.ensureFolder(base);
        return base;
    };

    B.importFile = function (a) {
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var io = new ImportOptions(f);
        var item = app.project.importFile(io);
        try { item.parentFolder = U.projectFolder(a.bin || 'B-Roll'); } catch (e) {}
        var placed = false;
        var c = U.compOrNull();
        if (a.addToComp && c) {
            var top = null, s = c.selectedLayers;
            for (var i = 0; i < s.length; i++) { if (!top || s[i].index < top.index) { top = s[i]; } }
            var L = c.layers.add(item);
            if (top) { L.moveBefore(top); }
            L.startTime = c.time;
            var dur = parseFloat(a.duration) || 3;
            if (item.mainSource && item.mainSource.isStill) {
                L.outPoint = Math.min(c.duration, c.time + dur);
            }
            var r = { width: 0, height: 0 };
            try { if (L.hasVideo) { r = L.sourceRectAtTime(c.time, false); } } catch (eR) {}
            if (r.width && r.height && a.fit !== 'none') {
                var sx = c.width / r.width * 100, sy = c.height / r.height * 100;
                var k = (a.fit === 'fit') ? Math.min(sx, sy) : Math.max(sx, sy);
                U.setXY(U.tr(L).property('ADBE Scale'), k, k, k);
            }
            placed = true;
        }
        return { name: item.name, placed: placed };
    };

    return B;
})();
