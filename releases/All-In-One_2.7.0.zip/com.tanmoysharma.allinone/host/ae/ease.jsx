/* All In One — EaseKit (ExtendScript, ES3)
   A cubic-bezier (x1,y1,x2,y2) like CSS is converted to AE speed/influence:
     out influence = x1,  out speed = avg * y1 / x1
     in  influence = 1-x2, in speed  = avg * (1-y2) / (1-x2)
   where avg = (v2 - v1) / (t2 - t1) for each dimension (path length for spatial props). */
MKH.ease = (function () {
    var U = MKH.util;
    var E = {};

    function keyedProps(c) {
        var out = [];
        var sp = c.selectedProperties;
        for (var i = 0; i < sp.length; i++) {
            var p = sp[i];
            if (p.propertyType === PropertyType.PROPERTY && p.numKeys > 0 && p.selectedKeys && p.selectedKeys.length) { out.push(p); }
        }
        if (!out.length) { throw new Error('NO_KEYS'); }
        return out;
    }

    function dist(a, b) {
        var s = 0;
        for (var i = 0; i < a.length; i++) { s += (b[i] - a[i]) * (b[i] - a[i]); }
        return Math.sqrt(s);
    }

    function isSpatial(p) {
        return p.propertyValueType === PropertyValueType.TwoD_SPATIAL || p.propertyValueType === PropertyValueType.ThreeD_SPATIAL;
    }

    function canEase(p) {
        var vt = p.propertyValueType;
        return !(vt === PropertyValueType.NO_VALUE || vt === PropertyValueType.CUSTOM_VALUE || vt === PropertyValueType.MARKER ||
                 vt === PropertyValueType.TEXT_DOCUMENT || vt === PropertyValueType.SHAPE || vt === PropertyValueType.LAYER_INDEX || vt === PropertyValueType.MASK_INDEX);
    }

    // per-dimension deltas between two keys, matched to the number of ease objects AE expects
    function deltas(p, a, b, n) {
        var v1 = p.keyValue(a), v2 = p.keyValue(b), out = [];
        if (!(v1 instanceof Array)) { out.push(v2 - v1); return out; }
        if (n === 1) { out.push(dist(v1, v2)); return out; }
        for (var d = 0; d < n; d++) { out.push((v2[d] || 0) - (v1[d] || 0)); }
        return out;
    }

    function sortNum(arr) { var c = arr.slice(0); c.sort(function (x, y) { return x - y; }); return c; }

    E.applyCurve = function (a) {
        var c = U.comp();
        var props = keyedProps(c);
        var x1 = U.clamp(+a.x1, 0.001, 1), y1 = +a.y1, x2 = U.clamp(+a.x2, 0, 0.999), y2 = +a.y2;
        var segs = 0;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (!canEase(p)) { continue; }
            var keys = sortNum(p.selectedKeys);
            var spatial = isSpatial(p);
            var inE = {}, outE = {}, touched = [];
            for (var j = 0; j < keys.length - 1; j++) {
                var ka = keys[j], kb = keys[j + 1];
                if (kb !== ka + 1) { continue; }
                var dt = p.keyTime(kb) - p.keyTime(ka);
                if (dt <= 0) { continue; }
                var n = p.keyOutTemporalEase(ka).length;
                var dv = deltas(p, ka, kb, n);
                var oArr = [], iArr = [];
                for (var d = 0; d < n; d++) {
                    var avg = dv[d] / dt;
                    var sOut = avg * y1 / x1;
                    var sIn = avg * (1 - y2) / (1 - x2);
                    if (spatial) { sOut = Math.max(0, sOut); sIn = Math.max(0, sIn); }
                    oArr.push(new KeyframeEase(sOut, U.clamp(x1 * 100, 0.1, 100)));
                    iArr.push(new KeyframeEase(sIn, U.clamp((1 - x2) * 100, 0.1, 100)));
                }
                outE[ka] = oArr; inE[kb] = iArr;
                if (U.indexOf(touched, ka) < 0) { touched.push(ka); }
                if (U.indexOf(touched, kb) < 0) { touched.push(kb); }
                segs++;
            }
            for (var t = 0; t < touched.length; t++) {
                var k = touched[t];
                var inT = inE[k] ? KeyframeInterpolationType.BEZIER : p.keyInInterpolationType(k);
                var outT = outE[k] ? KeyframeInterpolationType.BEZIER : p.keyOutInterpolationType(k);
                if (inT === KeyframeInterpolationType.HOLD && !inE[k]) { inT = KeyframeInterpolationType.LINEAR; }
                p.setInterpolationTypeAtKey(k, inT, outT);
                p.setTemporalEaseAtKey(k, inE[k] || p.keyInTemporalEase(k), outE[k] || p.keyOutTemporalEase(k));
                if (spatial) { try { p.setSpatialContinuousAtKey(k, true); } catch (e) {} }
            }
        }
        if (!segs) { throw new Error('NEED_2_KEYS'); }
        return { segments: segs };
    };

    // read the curve back from the first selected key pair
    E.readCurve = function () {
        var c = U.comp();
        var props = keyedProps(c);
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (!canEase(p)) { continue; }
            var keys = sortNum(p.selectedKeys);
            for (var j = 0; j < keys.length - 1; j++) {
                var ka = keys[j], kb = keys[j + 1];
                if (kb !== ka + 1) { continue; }
                var dt = p.keyTime(kb) - p.keyTime(ka);
                var oe = p.keyOutTemporalEase(ka), ie = p.keyInTemporalEase(kb);
                var dv = deltas(p, ka, kb, oe.length);
                // pick the dimension that actually moves the most
                var d = 0;
                for (var q = 1; q < dv.length; q++) { if (Math.abs(dv[q]) > Math.abs(dv[d])) { d = q; } }
                var avg = dv[d] / dt;
                var x1 = oe[d].influence / 100, x2 = 1 - ie[d].influence / 100;
                if (p.keyOutInterpolationType(ka) === KeyframeInterpolationType.LINEAR) { return { x1: 0, y1: 0, x2: 1, y2: 1 }; }
                if (Math.abs(avg) < 1e-9) { return { x1: x1, y1: 0, x2: x2, y2: 1 }; }
                return { x1: x1, y1: oe[d].speed * x1 / avg, x2: x2, y2: 1 - ie[d].speed * (1 - x2) / avg };
            }
        }
        throw new Error('NEED_2_KEYS');
    };

    function eachKey(c, fn) {
        var props = keyedProps(c), n = 0;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (!canEase(p)) { continue; }
            var ks = p.selectedKeys;
            for (var j = 0; j < ks.length; j++) { fn(p, ks[j]); n++; }
        }
        return n;
    }

    function flat(p, k, inf) {
        var n = p.keyInTemporalEase(k).length, arr = [];
        for (var i = 0; i < n; i++) { arr.push(new KeyframeEase(0, inf)); }
        return arr;
    }

    E.quick = function (a) {
        var c = U.comp();
        var B = KeyframeInterpolationType.BEZIER, L = KeyframeInterpolationType.LINEAR, H = KeyframeInterpolationType.HOLD;
        var inf = U.clamp(parseFloat(a.influence) || 33.333, 0.1, 100);
        var n = eachKey(c, function (p, k) {
            if (a.mode === 'linear') { p.setInterpolationTypeAtKey(k, L, L); return; }
            if (a.mode === 'hold') { p.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), H); return; }
            if (a.mode === 'easy') {
                p.setInterpolationTypeAtKey(k, B, B);
                p.setTemporalEaseAtKey(k, flat(p, k, inf), flat(p, k, inf));
                return;
            }
            if (a.mode === 'in') {
                p.setInterpolationTypeAtKey(k, B, p.keyOutInterpolationType(k) === H ? H : p.keyOutInterpolationType(k));
                p.setTemporalEaseAtKey(k, flat(p, k, inf), p.keyOutTemporalEase(k));
                return;
            }
            if (a.mode === 'out') {
                p.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), B);
                p.setTemporalEaseAtKey(k, p.keyInTemporalEase(k), flat(p, k, inf));
            }
        });
        return { count: n };
    };

    // nudge selected keys in time (frames)
    E.nudge = function (a) {
        var c = U.comp();
        var props = keyedProps(c), n = 0, dt = (parseFloat(a.frames) || 0) * c.frameDuration;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            var ks = sortNum(p.selectedKeys);
            if (dt > 0) { ks.reverse(); }
            for (var j = 0; j < ks.length; j++) {
                var k = ks[j];
                var t = p.keyTime(k), v = p.keyValue(k);
                var iT = p.keyInInterpolationType(k), oT = p.keyOutInterpolationType(k);
                var iE = null, oE = null, iS = null, oS = null;
                try { iE = p.keyInTemporalEase(k); oE = p.keyOutTemporalEase(k); } catch (e) {}
                if (p.isSpatial) { try { iS = p.keyInSpatialTangent(k); oS = p.keyOutSpatialTangent(k); } catch (e1) {} }
                p.removeKey(k);
                var nk = p.addKey(t + dt);
                p.setValueAtKey(nk, v);
                try {
                    p.setInterpolationTypeAtKey(nk, iT, oT);
                    if (iE && oE) { p.setTemporalEaseAtKey(nk, iE, oE); }
                    if (iS && oS) { p.setSpatialTangentsAtKey(nk, iS, oS); }
                } catch (e2) {}
                n++;
            }
        }
        return { count: n };
    };

    /* ---------- reverse / move / clone selected keys ---------- */
    function keyData(p, k) {
        var d = { t: p.keyTime(k), v: p.keyValue(k), it: p.keyInInterpolationType(k), ot: p.keyOutInterpolationType(k) };
        try { d.ie = p.keyInTemporalEase(k); d.oe = p.keyOutTemporalEase(k); } catch (e) {}
        if (p.isSpatial) { try { d.is = p.keyInSpatialTangent(k); d.os = p.keyOutSpatialTangent(k); } catch (e2) {} }
        return d;
    }

    // swap=true mirrors the key in time (in <-> out)
    function putKey(p, d, t, swap) {
        var k = p.addKey(t);
        p.setValueAtKey(k, d.v);
        try {
            p.setInterpolationTypeAtKey(k, swap ? d.ot : d.it, swap ? d.it : d.ot);
            if (d.ie && d.oe) { p.setTemporalEaseAtKey(k, swap ? d.oe : d.ie, swap ? d.ie : d.oe); }
            if (d.is && d.os) { p.setSpatialTangentsAtKey(k, swap ? d.os : d.is, swap ? d.is : d.os); }
        } catch (e) {}
    }

    function eachSelection(c, min, fn) {
        var props = keyedProps(c), n = 0;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            var ks = sortNum(p.selectedKeys);
            if (ks.length < min) { continue; }
            var data = [];
            for (var j = 0; j < ks.length; j++) { data.push(keyData(p, ks[j])); }
            fn(p, ks, data);
            n += ks.length;
        }
        if (!n) { throw new Error(min > 1 ? 'NEED_2_KEYS' : 'NO_KEYS'); }
        return n;
    }

    function removeAll(p, ks) { for (var r = ks.length - 1; r >= 0; r--) { p.removeKey(ks[r]); } }

    E.reverseKeys = function () {
        var c = U.comp();
        var n = eachSelection(c, 2, function (p, ks, data) {
            var t0 = data[0].t, t1 = data[data.length - 1].t;
            removeAll(p, ks);
            for (var i = 0; i < data.length; i++) { putKey(p, data[i], t0 + t1 - data[i].t, true); }
        });
        return { count: n };
    };

    // move (or copy) the selected keys so they start at the playhead; reverse=true plays them backwards
    E.keysToPlayhead = function (a) {
        var c = U.comp();
        var now = c.time;
        var n = eachSelection(c, 1, function (p, ks, data) {
            var t0 = data[0].t, t1 = data[data.length - 1].t;
            if (!a.clone) { removeAll(p, ks); }
            for (var i = 0; i < data.length; i++) {
                var nt = a.reverse ? now + (t1 - data[i].t) : now + (data[i].t - t0);
                putKey(p, data[i], nt, !!a.reverse);
            }
        });
        return { count: n };
    };

    return E;
})();
