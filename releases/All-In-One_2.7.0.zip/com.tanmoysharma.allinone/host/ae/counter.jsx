/* All In One — Number Counter (ExtendScript, ES3)
   Turns a text layer such as "২০১৯" or "$2,019+" into a counter that runs From → To.
   A keyed "AIO Counter" slider (0 → 100 %) drives a Source Text expression, so the
   speed can also be changed later in AE by moving the two keyframes. */
MKH.counter = (function () {
    var U = MKH.util;
    var C = {};
    var TAG = '// All In One - counter';
    var FX = 'AIO Counter';
    var BN0 = 0x09E6; // Bangla digit zero

    function isText(L) {
        try { return L.property('ADBE Text Properties') !== null && L.property('ADBE Text Properties').property('ADBE Text Document') !== null; }
        catch (e) { return false; }
    }

    function toAscii(s) {
        var o = '';
        for (var i = 0; i < s.length; i++) {
            var c = s.charCodeAt(i);
            if (c >= BN0 && c <= BN0 + 9) { o += String.fromCharCode(48 + c - BN0); }
            else if (c >= 0x0966 && c <= 0x096F) { o += String.fromCharCode(48 + c - 0x0966); }
            else if (c >= 0x0660 && c <= 0x0669) { o += String.fromCharCode(48 + c - 0x0660); }
            else if (c === 0x2212) { o += '-'; }
            else { o += s.charAt(i); }
        }
        return o;
    }

    function scriptOf(s) {
        for (var i = 0; i < s.length; i++) {
            var c = s.charCodeAt(i);
            if (c >= BN0 && c <= BN0 + 9) { return 'bn'; }
            if (c >= 0x0966 && c <= 0x096F) { return 'hi'; }
            if (c >= 0x0660 && c <= 0x0669) { return 'ar'; }
        }
        return 'en';
    }
    var DIGITS = { bn: '\u09E6\u09E7\u09E8\u09E9\u09EA\u09EB\u09EC\u09ED\u09EE\u09EF', hi: '\u0966\u0967\u0968\u0969\u096A\u096B\u096C\u096D\u096E\u096F', ar: '\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669' };
    // separator option -> { ch, grp: 0 none | 3 thousands | 2 Indian/BD lakh, dm: decimal mark }
    C._sepOf = function (sep, custom, detected) {
        var map = { none: ['', 0], comma: [',', 3], bd: [',', 2], dot: ['.', 3], space: [' ', 3], apos: ["'", 3], under: ['_', 3], custom: [String(custom || ''), 3], customBd: [String(custom || ''), 2] };
        var m = map[sep];
        if (!m) { m = detected === 2 ? [',', 2] : (detected === 1 ? [',', 3] : ['', 0]); }
        if (!m[0]) { m[1] = 0; }
        return { ch: m[0], grp: m[1], dm: m[0] === '.' ? ',' : '.' };
    };
    function hasBangla(s) {
        for (var i = 0; i < s.length; i++) { var c = s.charCodeAt(i); if (c >= BN0 && c <= BN0 + 9) { return true; } }
        return false;
    }

    // find the first number in a string -> {pre, num, suf, dec, sep, width, bn} or null
    C._parse = function (raw) {
        raw = String(raw === undefined || raw === null ? '' : raw);
        var s = toAscii(raw);
        var m = /-?[0-9]+(?:,[0-9]+)*(?:\.[0-9]+)?/.exec(s);
        if (!m) { return null; }
        var tok = m[0];
        var clean = tok.replace(/,/g, '');
        var n = parseFloat(clean);
        if (isNaN(n)) { return null; }
        var dot = clean.indexOf('.');
        var sep = 0;
        if (tok.indexOf(',') >= 0) {
            var groups = tok.replace(/^-/, '').split('.')[0].split(',');
            // 1,00,000 style (two-digit groups before the last three) = Bangladeshi / Indian
            sep = (groups.length > 2 && groups[groups.length - 2].length === 2) ? 2 : 1;
        }
        var intPart = clean.replace(/^-/, '').split('.')[0];
        return {
            pre: raw.substring(0, m.index),
            suf: raw.substring(m.index + tok.length),
            num: n,
            dec: dot >= 0 ? clean.length - dot - 1 : 0,
            sep: sep,
            width: intPart.length,
            zeros: intPart.length > 1 && intPart.charAt(0) === '0',
            bn: hasBangla(raw.substring(m.index, m.index + tok.length)),
            script: scriptOf(raw.substring(m.index, m.index + tok.length))
        };
    };

    // JS string literal, every non-ASCII char as \uXXXX (safe in any AE expression engine)
    function lit(s) {
        s = String(s);
        var o = '"', H = '0123456789abcdef';
        for (var i = 0; i < s.length; i++) {
            var c = s.charCodeAt(i), ch = s.charAt(i);
            if (ch === '"') { o += '\\"'; }
            else if (ch === '\\') { o += '\\\\'; }
            else if (c === 10) { o += '\\n'; }
            else if (c === 13) { o += '\\r'; }
            else if (c < 32 || c > 126) { o += '\\u' + H.charAt((c >> 12) & 15) + H.charAt((c >> 8) & 15) + H.charAt((c >> 4) & 15) + H.charAt(c & 15); }
            else { o += ch; }
        }
        return o + '"';
    }

    function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }

    var EASES = { linear: 0, out: 1, inout: 2, expo: 3, back: 4 };

    C._expr = function (o) {
        return [
            TAG,
            'var p = 1;',
            'try { p = effect(' + lit(FX) + ')(1) / 100; } catch (err) { p = 1; }',
            'p = Math.max(0, Math.min(1, p));',
            'var E = ' + o.ease + ';',
            'if (E == 1) { p = 1 - Math.pow(1 - p, 3); }',
            'else if (E == 2) { p = p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; }',
            'else if (E == 3) { p = p >= 1 ? 1 : 1 - Math.pow(2, -10 * p); }',
            'else if (E == 4) { var k = 1.70158; p = 1 + (k + 1) * Math.pow(p - 1, 3) + k * Math.pow(p - 1, 2); }',
            'var from = ' + o.from + ', to = ' + o.to + ', dec = ' + o.dec + ', grpN = ' + o.sp.grp + ', width = ' + (o.pad ? o.width : 0) + ';',
            'var sepc = ' + lit(o.sp.ch) + ', dmark = ' + lit(o.sp.dm) + ', digs = ' + lit(o.digs || '') + ';',
            'var pre = ' + lit(o.pre) + ', suf = ' + lit(o.suf) + ';',
            'var v = from + (to - from) * p;',
            'var neg = v < 0; if (neg) { v = -v; }',
            'var s = v.toFixed(dec);',
            'var ip = s, fp = "", d = s.indexOf(".");',
            'if (d >= 0) { ip = s.substring(0, d); fp = s.substring(d); }',
            'while (ip.length < width) { ip = "0" + ip; }',
            'function grp(t, n) { var r = ""; while (t.length > n) { r = sepc + t.substring(t.length - n) + r; t = t.substring(0, t.length - n); } return t + r; }',
            'if (grpN == 3) { ip = grp(ip, 3); }',
            'else if (grpN == 2 && ip.length > 3) { ip = grp(ip.substring(0, ip.length - 3), 2) + sepc + ip.substring(ip.length - 3); }',
            'if (fp) { fp = dmark + fp.substring(1); }',
            's = (neg && Number(s) != 0 ? "-" : "") + ip + fp;',
            'if (digs) { var o = ""; for (var i = 0; i < s.length; i++) { var c = s.charAt(i); o += (c >= "0" && c <= "9") ? digs.charAt(Number(c)) : c; } s = o; }',
            'pre + s + suf'
        ].join('\n');
    };

    function textProp(L) { return L.property('ADBE Text Properties').property('ADBE Text Document'); }

    function baseText(L) {
        var p = textProp(L);
        try { return String(p.valueAtTime(0, true).text); } catch (e) {}
        try { return String(p.value.text); } catch (e2) {}
        return '';
    }

    function removeFx(L) {
        var par = L.property('ADBE Effect Parade');
        for (var i = par.numProperties; i >= 1; i--) {
            if (par.property(i).name === FX) { par.property(i).remove(); }
        }
    }

    function clearExpr(L) {
        var p = textProp(L);
        try { if (p.expression && p.expression.indexOf(TAG) === 0) { p.expression = ''; } } catch (e) {}
    }

    C.apply = function (a) {
        var c = U.comp();
        var sel = c.selectedLayers, layers = [], created = false;
        for (var i = 0; i < sel.length; i++) { if (isText(sel[i])) { layers.push(sel[i]); } }
        var toTxt = U.trim(a.to === undefined || a.to === null ? '' : a.to);
        var toInfo = toTxt ? C._parse(toTxt) : null;
        if (toTxt && !toInfo) { throw new Error('BAD_NUMBER'); }

        if (!layers.length) {
            if (sel.length) { throw new Error('NO_TEXT_LAYER'); }
            if (!toInfo) { throw new Error('NO_COUNT_TO'); }
            var L0 = c.layers.addText(toTxt);
            L0.name = 'Counter ' + toTxt;
            layers.push(L0);
            created = true;
        }

        var dur = Math.max(0.05, num(a.duration, 2));
        var ease = EASES.hasOwnProperty(a.ease) ? EASES[a.ease] : 1;
        var from = num(toAscii(String(a.from === undefined ? '0' : a.from)).replace(/[,\s']/g, ''), 0);
        var warnings = [];

        for (var j = 0; j < layers.length; j++) {
            var L = layers[j];
            var info = C._parse(baseText(L));
            if (!info && !toInfo) { warnings.push(L.name + ': no number'); continue; }
            var base = info || { pre: '', suf: '', num: 0, dec: 0, sep: 0, width: 1, zeros: false, bn: false, script: 'en' };
            var to = toInfo ? toInfo.num : base.num;
            var dec = (a.decimals === '' || a.decimals === undefined || a.decimals === 'auto') ? Math.max(base.dec, toInfo ? toInfo.dec : 0) : Math.max(0, Math.min(6, Math.round(num(a.decimals, 0))));
            var sp = C._sepOf(a.sep, a.sepChar, toInfo && toInfo.sep ? toInfo.sep : base.sep);
            var script = (a.digits && a.digits !== 'auto') ? a.digits : (base.script && base.script !== 'en' ? base.script : (toInfo ? toInfo.script : 'en'));
            var digs = DIGITS[script] || '';
            var pre = (a.prefix !== undefined && a.prefix !== '') ? String(a.prefix) : base.pre;
            var suf = (a.suffix !== undefined && a.suffix !== '') ? String(a.suffix) : base.suf;
            var width = String(Math.floor(Math.abs(to))).length;
            if (base.zeros && !toInfo) { width = Math.max(width, base.width); }

            clearExpr(L);
            removeFx(L);
            var eff = L.property('ADBE Effect Parade').addProperty('ADBE Slider Control');
            eff.name = FX;
            var sl = eff.property(1);
            var t0 = a.at === 'playhead' ? c.time : L.inPoint;
            sl.setValueAtTime(t0, 0);
            sl.setValueAtTime(t0 + dur, 100);
            for (var k = 1; k <= sl.numKeys; k++) {
                sl.setInterpolationTypeAtKey(k, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
            }
            textProp(L).expression = C._expr({ ease: ease, from: from, to: to, dec: dec, sp: sp, digs: digs, pre: pre, suf: suf, width: width, pad: !!a.pad || (base.zeros && !toInfo) });
            try { if (textProp(L).expressionError) { warnings.push(L.name + ': ' + textProp(L).expressionError); } } catch (e3) {}
        }
        if (!created) { U.select(c, layers); }
        return { count: layers.length - warnings.length, created: created, warnings: warnings };
    };

    C.remove = function () {
        var c = U.comp();
        var s = U.sel(c), n = 0;
        for (var i = 0; i < s.length; i++) {
            if (!isText(s[i])) { continue; }
            clearExpr(s[i]); removeFx(s[i]); n++;
        }
        if (!n) { throw new Error('NO_TEXT_LAYER'); }
        return { count: n };
    };

    // read-only: what number does the selected text layer hold? (fills the panel's "To")
    C.readSelected = function () {
        var c = U.compOrNull();
        if (!c) { return null; }
        var s = c.selectedLayers;
        for (var i = 0; i < s.length; i++) {
            if (isText(s[i])) { var t = baseText(s[i]); var p = C._parse(t); return p ? { text: t, num: p.num, bn: p.bn } : { text: t }; }
        }
        return null;
    };

    return C;
})();
