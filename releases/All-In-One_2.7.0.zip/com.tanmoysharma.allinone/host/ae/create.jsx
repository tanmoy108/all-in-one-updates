/* All In One — Create: compositions, shapes with live controls, safe-zone guides (ExtendScript, ES3) */
MKH.create = (function () {
    var U = MKH.util;
    var K = {};
    var SAFE_TAG = 'AIO_SAFE';
    var SHAPE_TAG = 'AIO_SHAPE';

    function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }
    function rgb(a, d) { return (a instanceof Array && a.length >= 3) ? [a[0], a[1], a[2]] : d; }
    function setPropVal(prop, v) {
        try { prop.setValue(v); return true; } catch (e) {}
        if (v instanceof Array && v.length >= 3) { try { prop.setValue(v.slice(0, v.length - 1)); return true; } catch (e2) {} }
        return false;
    }
    function uniqueName(c, base) {
        var name = base, n = 2, taken = {};
        for (var i = 1; i <= c.numLayers; i++) { taken[c.layer(i).name] = true; }
        while (taken[name]) { name = base + ' ' + n++; }
        return name;
    }
    function parade(L) { return L.property('ADBE Effect Parade'); }
    function findFx(L, name) {
        var p = parade(L);
        for (var i = 1; i <= p.numProperties; i++) { if (p.property(i).name === name) { return p.property(i); } }
        return null;
    }
    function ensureFx(L, matchName, name) {
        var e = findFx(L, name);
        if (e) { return e; }
        e = parade(L).addProperty(matchName);
        e.name = name;
        return e;
    }
    function hex2(v) { var s = Math.round(U.clamp(v, 0, 1) * 255).toString(16); return s.length < 2 ? '0' + s : s; }

    /* ======================= compositions ======================= */
    function compInfo(c) {
        var b = c.bgColor;
        return {
            name: c.name, width: c.width, height: c.height, fps: Math.round(c.frameRate * 1000) / 1000,
            duration: Math.round(c.duration * 1000) / 1000, bg: '#' + hex2(b[0]) + hex2(b[1]) + hex2(b[2]), layers: c.numLayers
        };
    }

    K.readComp = function () { return compInfo(U.comp()); };

    K.newComp = function (a) {
        var w = Math.round(U.clamp(num(a.width, 1920), 4, 30000));
        var h = Math.round(U.clamp(num(a.height, 1080), 4, 30000));
        var fps = U.clamp(num(a.fps, 30), 1, 999);
        var dur = U.clamp(num(a.duration, 10), 1 / fps, 10800);
        var name = U.trim(a.name || '') || ('Comp ' + w + 'x' + h);
        var c = app.project.items.addComp(name, w, h, 1, dur, fps);
        c.bgColor = rgb(a.bg, [0, 0, 0]);
        // move the selected layers of the current comp into the new one? → no, keep it simple and safe
        try { c.openInViewer(); } catch (e) {}
        return compInfo(c);
    };

    function targetComps(scope) {
        var out = [];
        if (scope === 'project') {
            var sel = app.project.selection;
            for (var i = 0; i < sel.length; i++) { if (sel[i] instanceof CompItem) { out.push(sel[i]); } }
            if (!out.length) { throw new Error('NO_COMP_SELECTED'); }
            return out;
        }
        out.push(U.comp());
        return out;
    }

    function shiftLayer(L, dx, dy) {
        if (L.parent) { return; }
        var wasLocked = L.locked;
        if (wasLocked) { L.locked = false; }
        try { U.shiftPosition(L, dx, dy); } catch (e) {}
        // cameras and lights also carry a point of interest in the anchor slot
        if (L instanceof CameraLayer || L instanceof LightLayer) {
            try {
                var poi = U.tr(L).property('ADBE Anchor Point');
                if (poi && poi.numKeys === 0) {
                    var v = poi.value; v[0] += dx; v[1] += dy; poi.setValue(v);
                }
            } catch (e2) {}
        }
        if (wasLocked) { L.locked = true; }
    }

    K.editComp = function (a) {
        var comps = targetComps(a.scope);
        var warnings = [];
        for (var i = 0; i < comps.length; i++) {
            var c = comps[i];
            if (comps.length === 1 && a.name && U.trim(a.name) && U.trim(a.name) !== c.name) { c.name = U.trim(a.name); }
            var w = Math.round(U.clamp(num(a.width, c.width), 4, 30000));
            var h = Math.round(U.clamp(num(a.height, c.height), 4, 30000));
            if (w !== c.width || h !== c.height) {
                var dx = (w - c.width) / 2, dy = (h - c.height) / 2;
                c.width = w; c.height = h;
                if (a.keepCenter !== false) {
                    for (var j = 1; j <= c.numLayers; j++) { if (!isSafe(c.layer(j))) { shiftLayer(c.layer(j), dx, dy); } }
                }
                redrawSafe(c);
            }
            // only touch what really changed (the panel always sends every field)
            if (a.fps) {
                var fps = U.clamp(num(a.fps, c.frameRate), 1, 999);
                if (Math.abs(fps - c.frameRate) > 0.001) { c.frameRate = fps; }
            }
            if (a.duration) {
                var d = U.clamp(num(a.duration, c.duration), c.frameDuration, 10800);
                if (Math.abs(d - c.duration) > c.frameDuration / 2) {
                    var fullWork = Math.abs(c.workAreaStart) < 1e-6 && Math.abs(c.workAreaDuration - c.duration) < c.frameDuration;
                    if (d < c.duration) { warnings.push(c.name + ': made shorter'); }
                    c.duration = d;
                    if (fullWork) { try { c.workAreaStart = 0; c.workAreaDuration = c.duration; } catch (e) {} }
                }
            }
            if (a.bg) { c.bgColor = rgb(a.bg, c.bgColor); }
        }
        return { count: comps.length, info: comps.length === 1 ? compInfo(comps[0]) : null, warnings: warnings };
    };

    /* ======================= shapes ======================= */
    var LABEL = { rect: 'Rectangle', rounded: 'Rounded Rect', ellipse: 'Ellipse', triangle: 'Triangle', polygon: 'Polygon', star: 'Star', line: 'Line', arrow: 'Arrow' };

    function pathShape(verts, closed) {
        var s = new Shape();
        s.vertices = verts;
        s.closed = closed;
        return s;
    }

    function buildShape(vecs, a) {
        var t = a.type, w = Math.max(1, num(a.w, 400)), h = Math.max(1, num(a.h, 400)), r = Math.max(0, num(a.round, 0));
        var p;
        if (t === 'rect' || t === 'rounded') {
            p = vecs.addProperty('ADBE Vector Shape - Rect');
            p.property('ADBE Vector Rect Size').setValue([w, h]);
            p.property('ADBE Vector Rect Roundness').setValue(t === 'rounded' ? (r || Math.min(w, h) * 0.18) : 0);
        } else if (t === 'ellipse') {
            p = vecs.addProperty('ADBE Vector Shape - Ellipse');
            p.property('ADBE Vector Ellipse Size').setValue([w, h]);
        } else if (t === 'triangle' || t === 'polygon' || t === 'star') {
            p = vecs.addProperty('ADBE Vector Shape - Star');
            p.property('ADBE Vector Star Type').setValue(t === 'star' ? 1 : 2);
            var pts = t === 'triangle' ? 3 : Math.max(3, Math.round(num(a.points, t === 'star' ? 5 : 6)));
            p.property('ADBE Vector Star Points').setValue(pts);
            p.property('ADBE Vector Star Outer Radius').setValue(h / 2);
            if (t === 'star') { p.property('ADBE Vector Star Inner Radius').setValue(h / 2 * U.clamp(num(a.inner, 45), 5, 100) / 100); }
            try { p.property('ADBE Vector Star Outer Roundess').setValue(U.clamp(r, 0, 100)); } catch (e) {}
        } else if (t === 'line') {
            p = vecs.addProperty('ADBE Vector Shape - Group');
            p.property('ADBE Vector Shape').setValue(pathShape([[-w / 2, 0], [w / 2, 0]], false));
        } else if (t === 'arrow') {
            var th = h * 0.36, hl = Math.min(w * 0.45, h * 0.95);
            p = vecs.addProperty('ADBE Vector Shape - Group');
            p.property('ADBE Vector Shape').setValue(pathShape([
                [-w / 2, -th / 2], [w / 2 - hl, -th / 2], [w / 2 - hl, -h / 2], [w / 2, 0],
                [w / 2 - hl, h / 2], [w / 2 - hl, th / 2], [-w / 2, th / 2]
            ], true));
        } else {
            throw new Error('BAD_SHAPE');
        }
        return p;
    }

    K.shape = function (a) {
        var c = U.comp();
        var t = a.type || 'rect';
        var L = c.layers.addShape();
        L.name = uniqueName(c, LABEL[t] || 'Shape');
        L.comment = SHAPE_TAG;
        var g = L.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group');
        g.name = LABEL[t] || 'Shape';
        var vecs = g.property('ADBE Vectors Group');
        buildShape(vecs, a);
        var sw = Math.max(0, num(a.sw, 0));
        if (t === 'line' && sw <= 0) { sw = 12; }
        if (sw > 0) {
            var st = vecs.addProperty('ADBE Vector Graphic - Stroke');
            setPropVal(st.property('ADBE Vector Stroke Color'), rgb(a.stroke, [1, 1, 1]));
            st.property('ADBE Vector Stroke Width').setValue(sw);
            if (t === 'line') { try { st.property('ADBE Vector Stroke Line Cap').setValue(2); } catch (e) {} }
            try { st.property('ADBE Vector Stroke Line Join').setValue(2); } catch (e1) {}
        }
        if (t !== 'line' && a.fillOn !== false) {
            var f = vecs.addProperty('ADBE Vector Graphic - Fill');
            setPropVal(f.property('ADBE Vector Fill Color'), rgb(a.fill, [1, 1, 1]));
        }
        // the new shape layer is created at the comp centre with anchor [0,0]
        try { if (c.selectedLayers.length) { U.deselectAll(c); } } catch (e2) {}
        L.selected = true;
        if (a.live) {
            var w0 = Math.max(1, num(a.w, 400)), h0 = Math.max(1, num(a.h, 400));
            linkControls(L, a, { w: w0, h: t === 'line' ? 0 : h0, line: t === 'line' });
        }
        return { name: L.name, live: !!a.live };
    };

    /* ---------- live controls: Effect Controls drive the shape ---------- */
    function walkVec(group, cb) {
        for (var i = 1; i <= group.numProperties; i++) {
            var p = group.property(i);
            cb(p);
            if (p.propertyType === PropertyType.INDEXED_GROUP || p.propertyType === PropertyType.NAMED_GROUP) { walkVec(p, cb); }
        }
    }

    function collect(L) {
        var o = { rect: [], ellipse: [], star: [], fill: [], stroke: [], groups: [] };
        var root = L.property('ADBE Root Vectors Group');
        for (var i = 1; i <= root.numProperties; i++) { if (root.property(i).matchName === 'ADBE Vector Group') { o.groups.push(root.property(i)); } }
        walkVec(root, function (p) {
            var m = p.matchName;
            if (m === 'ADBE Vector Shape - Rect') { o.rect.push(p); }
            else if (m === 'ADBE Vector Shape - Ellipse') { o.ellipse.push(p); }
            else if (m === 'ADBE Vector Shape - Star') { o.star.push(p); }
            else if (m === 'ADBE Vector Graphic - Fill') { o.fill.push(p); }
            else if (m === 'ADBE Vector Graphic - Stroke') { o.stroke.push(p); }
        });
        return o;
    }

    function ctl(L, mn, name, val) {
        var existed = !!findFx(L, name);
        var e = ensureFx(L, mn, name);
        if (!existed && val !== undefined) { setPropVal(e.property(1), val); }
        return e;
    }
    function ex(name, tail) { return 'try { ' + (tail || 'effect("' + name + '")(1)') + ' } catch (err) { value }'; }

    function linkControls(L, a, base) {
        var o = collect(L);
        var c = L.containingComp;
        var linked = !!findFx(L, 'Width');
        var r = L.sourceRectAtTime(c.time, true);
        var single = (o.rect.length + o.ellipse.length + o.star.length) === 1;
        var W0 = Math.max(1, r.width), H0 = Math.max(1, r.height);
        if (base && base.w) { W0 = base.w; H0 = base.h || H0; }
        if (single && o.rect.length) { var rs = o.rect[0].property('ADBE Vector Rect Size').value; W0 = rs[0]; H0 = rs[1]; }
        if (single && o.ellipse.length) { var es = o.ellipse[0].property('ADBE Vector Ellipse Size').value; W0 = es[0]; H0 = es[1]; }
        if (single && o.star.length) { H0 = o.star[0].property('ADBE Vector Star Outer Radius').value * 2; W0 = H0; }
        W0 = Math.round(W0 * 100) / 100; H0 = Math.round(H0 * 100) / 100;
        var isLine = !!(base && base.line);

        ctl(L, 'ADBE Slider Control', 'Width', W0);
        if (!isLine) { ctl(L, 'ADBE Slider Control', 'Height', H0); }
        var sizeExpr = ex('', '[effect("Width")(1), effect("Height")(1)]');
        if (linked) {
            // already linked: keep the existing size wiring (re-linking would reset the size)
        } else if (single && o.rect.length) {
            o.rect[0].property('ADBE Vector Rect Size').expression = sizeExpr;
            ctl(L, 'ADBE Slider Control', 'Roundness', o.rect[0].property('ADBE Vector Rect Roundness').value);
            o.rect[0].property('ADBE Vector Rect Roundness').expression = ex('Roundness');
        } else if (single && o.ellipse.length) {
            o.ellipse[0].property('ADBE Vector Ellipse Size').expression = sizeExpr;
        } else if (single && o.star.length) {
            var s = o.star[0];
            s.property('ADBE Vector Star Outer Radius').expression = ex('', 'effect("Height")(1) / 2');
            ctl(L, 'ADBE Slider Control', 'Points', s.property('ADBE Vector Star Points').value);
            s.property('ADBE Vector Star Points').expression = ex('', 'Math.max(3, Math.round(effect("Points")(1)))');
            var r0 = 0;
            try { r0 = s.property('ADBE Vector Star Outer Roundess').value; } catch (e0) {}
            ctl(L, 'ADBE Slider Control', 'Roundness', r0);
            try { s.property('ADBE Vector Star Outer Roundess').expression = ex('Roundness'); } catch (e) {}
            if (s.property('ADBE Vector Star Type').value === 1) {
                var ir = s.property('ADBE Vector Star Inner Radius').value, or0 = s.property('ADBE Vector Star Outer Radius').value || 1;
                ctl(L, 'ADBE Slider Control', 'Inner %', Math.round(ir / or0 * 100));
                s.property('ADBE Vector Star Inner Radius').expression = ex('', 'effect("Height")(1) / 2 * effect("Inner %")(1) / 100');
            }
            // non-square polygons: stretch the group horizontally (only when the star sits inside a group)
            var grp = s.parentProperty ? s.parentProperty.parentProperty : null;
            if (grp && grp.matchName === 'ADBE Vector Group') {
                var gs = grp.property('ADBE Vector Transform Group').property('ADBE Vector Scale');
                gs.expression = ex('', 'var h = Math.max(1, effect("Height")(1)); [100 * effect("Width")(1) / h, 100]');
            }
        } else {
            // paths or several shapes: scale every top-level group
            for (var gi = 0; gi < o.groups.length; gi++) {
                var sc = o.groups[gi].property('ADBE Vector Transform Group').property('ADBE Vector Scale');
                sc.expression = ex('', 'var v = value; [v[0] * effect("Width")(1) / ' + W0 + ', ' +
                    (isLine ? 'v[1]' : 'v[1] * effect("Height")(1) / ' + H0) + ']');
            }
        }
        if (o.fill.length) {
            ctl(L, 'ADBE Color Control', 'Fill Color', o.fill[0].property('ADBE Vector Fill Color').value);
            for (var f = 0; f < o.fill.length; f++) { o.fill[f].property('ADBE Vector Fill Color').expression = ex('Fill Color'); }
        }
        if (o.stroke.length) {
            ctl(L, 'ADBE Color Control', 'Stroke Color', o.stroke[0].property('ADBE Vector Stroke Color').value);
            ctl(L, 'ADBE Slider Control', 'Stroke Width', o.stroke[0].property('ADBE Vector Stroke Width').value);
            for (var k = 0; k < o.stroke.length; k++) {
                o.stroke[k].property('ADBE Vector Stroke Color').expression = ex('Stroke Color');
                o.stroke[k].property('ADBE Vector Stroke Width').expression = ex('Stroke Width');
            }
        }
        return true;
    }

    // apply panel values to the selected shape layers (controls if present, otherwise the shape itself)
    K.editShape = function (a) {
        var c = U.comp();
        var s = U.sel(c), n = 0, skipped = 0;
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (!(L instanceof ShapeLayer)) { skipped++; continue; }
            if (a.live) { linkControls(L, a); }
            var live = !!findFx(L, 'Width');
            var o = collect(L);
            var w = num(a.w, 0), h = num(a.h, 0);
            if (a.doSize && w > 0 && h > 0) {
                if (live) {
                    findFx(L, 'Width').property(1).setValue(w);
                    var hf = findFx(L, 'Height');
                    if (hf) { hf.property(1).setValue(h); }
                } else {
                    for (var r = 0; r < o.rect.length; r++) { o.rect[r].property('ADBE Vector Rect Size').setValue([w, h]); }
                    for (var e = 0; e < o.ellipse.length; e++) { o.ellipse[e].property('ADBE Vector Ellipse Size').setValue([w, h]); }
                    for (var st = 0; st < o.star.length; st++) {
                        var sp = o.star[st], oldR = sp.property('ADBE Vector Star Outer Radius').value || 1;
                        sp.property('ADBE Vector Star Outer Radius').setValue(h / 2);
                        if (sp.property('ADBE Vector Star Type').value === 1) {
                            var ip = sp.property('ADBE Vector Star Inner Radius');
                            ip.setValue(ip.value * (h / 2) / oldR);
                        }
                    }
                }
            }
            if (a.doRound) {
                var rd = Math.max(0, num(a.round, 0));
                if (live && findFx(L, 'Roundness')) { findFx(L, 'Roundness').property(1).setValue(rd); }
                else {
                    for (var rr = 0; rr < o.rect.length; rr++) { o.rect[rr].property('ADBE Vector Rect Roundness').setValue(rd); }
                    for (var sr = 0; sr < o.star.length; sr++) { try { o.star[sr].property('ADBE Vector Star Outer Roundess').setValue(U.clamp(rd, 0, 100)); } catch (e1) {} }
                }
                if (a.points && o.star.length) {
                    if (live && findFx(L, 'Points')) { findFx(L, 'Points').property(1).setValue(num(a.points, 5)); }
                    else { for (var sq = 0; sq < o.star.length; sq++) { o.star[sq].property('ADBE Vector Star Points').setValue(Math.max(3, Math.round(num(a.points, 5)))); } }
                }
            }
            if (a.doFill && a.fill) {
                if (live && findFx(L, 'Fill Color')) { setPropVal(findFx(L, 'Fill Color').property(1), rgb(a.fill)); }
                else { for (var f = 0; f < o.fill.length; f++) { setPropVal(o.fill[f].property('ADBE Vector Fill Color'), rgb(a.fill)); } }
            }
            if (a.doStroke) {
                var sw = Math.max(0, num(a.sw, 0));
                if (!o.stroke.length && sw > 0 && o.groups.length) {
                    var vg = o.groups[0].property('ADBE Vectors Group');
                    var ns = vg.addProperty('ADBE Vector Graphic - Stroke');
                    // a stroke added after the fill would render underneath it: move it above the first fill
                    for (var fi = 1; fi <= vg.numProperties; fi++) {
                        if (vg.property(fi).matchName === 'ADBE Vector Graphic - Fill') { try { ns.moveTo(fi); } catch (e2) {} break; }
                    }
                    o = collect(L);
                }
                if (live && findFx(L, 'Stroke Width')) {
                    findFx(L, 'Stroke Width').property(1).setValue(sw);
                    if (a.stroke) { setPropVal(findFx(L, 'Stroke Color').property(1), rgb(a.stroke)); }
                } else {
                    for (var k = 0; k < o.stroke.length; k++) {
                        o.stroke[k].property('ADBE Vector Stroke Width').setValue(sw);
                        if (a.stroke) { setPropVal(o.stroke[k].property('ADBE Vector Stroke Color'), rgb(a.stroke)); }
                    }
                }
            }
            n++;
        }
        if (!n) { throw new Error('NO_SHAPE_LAYER'); }
        return { count: n, skipped: skipped };
    };

    /* ======================= safe-zone guides ======================= */
    // covered margins as fractions of the frame (measured on 1080 x 1920 for vertical formats)
    var ZONES = {
        ig_reels: { name: 'Instagram Reels', t: 0.14, b: 0.35, l: 0.06, r: 0.06, extra: [[0.79, 0.60, 1, 1]] },
        fb_reels: { name: 'Facebook Reels', t: 0.14, b: 0.35, l: 0.06, r: 0.06, extra: [[0.79, 0.60, 1, 1]] },
        stories: { name: 'IG / FB Stories', t: 0.14, b: 0.20, l: 0.06, r: 0.06 },
        tiktok: { name: 'TikTok', t: 240 / 1920, b: 660 / 1920, l: 120 / 1080, r: 120 / 1080, extra: [[900 / 1080, 840 / 1920, 1, 1]] },
        yt_shorts: { name: 'YouTube Shorts', t: 288 / 1920, b: 672 / 1920, l: 48 / 1080, r: 192 / 1080 },
        all_vertical: { name: 'All vertical (Reels + TikTok + Shorts)', t: 288 / 1920, b: 672 / 1920, l: 120 / 1080, r: 192 / 1080, extra: [[0.79, 0.60, 1, 1]] },
        tv: { name: 'Title / Action safe', tv: true },
        ig_grid: { name: 'Instagram grid crop 3:4', crop: 3 / 4 },
        ig_feed: { name: 'Instagram feed crop 4:5', crop: 4 / 5 },
        square: { name: 'Square crop 1:1', crop: 1 }
    };

    function addRect(vecs, x0, y0, x1, y1) {
        var p = vecs.addProperty('ADBE Vector Shape - Rect');
        p.property('ADBE Vector Rect Size').setValue([Math.max(0.5, x1 - x0), Math.max(0.5, y1 - y0)]);
        p.property('ADBE Vector Rect Position').setValue([(x0 + x1) / 2, (y0 + y1) / 2]);
        return p;
    }
    function addLine(vecs, x0, y0, x1, y1) {
        var p = vecs.addProperty('ADBE Vector Shape - Group');
        p.property('ADBE Vector Shape').setValue(pathShape([[x0, y0], [x1, y1]], false));
        return p;
    }
    function group(L, name) {
        var g = L.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group');
        g.name = name;
        return g;
    }
    function paint(g, fillCol, strokeCol, sw, opacity) {
        var v = g.property('ADBE Vectors Group');
        if (strokeCol) {
            var st = v.addProperty('ADBE Vector Graphic - Stroke');
            setPropVal(st.property('ADBE Vector Stroke Color'), strokeCol);
            st.property('ADBE Vector Stroke Width').setValue(sw);
        }
        if (fillCol) {
            var f = v.addProperty('ADBE Vector Graphic - Fill');
            setPropVal(f.property('ADBE Vector Fill Color'), fillCol);
        }
        g.property('ADBE Vector Transform Group').property('ADBE Vector Group Opacity').setValue(opacity);
    }

    // exposed for tests: the covered rectangles + safe box for a zone on a W x H frame
    K.zoneRects = function (id, W, H) {
        var z = ZONES[id];
        if (!z) { throw new Error('BAD_ZONE'); }
        var covered = [], boxes = [];
        if (z.tv) {
            boxes.push([W * 0.035, H * 0.035, W * 0.965, H * 0.965, 'Action safe 93%']);
            boxes.push([W * 0.05, H * 0.05, W * 0.95, H * 0.95, 'Title safe 90%']);
            return { covered: covered, boxes: boxes, name: z.name };
        }
        if (z.crop) {
            var cw = W, ch = W / z.crop;
            if (ch > H) { ch = H; cw = H * z.crop; }
            var x0 = (W - cw) / 2, y0 = (H - ch) / 2;
            if (y0 > 0.5) { covered.push([0, 0, W, y0]); covered.push([0, y0 + ch, W, H]); }
            if (x0 > 0.5) { covered.push([0, y0, x0, y0 + ch]); covered.push([x0 + cw, y0, W, y0 + ch]); }
            boxes.push([x0, y0, x0 + cw, y0 + ch, 'Visible']);
            return { covered: covered, boxes: boxes, name: z.name };
        }
        var T = H * z.t, B = H * (1 - z.b), Lx = W * z.l, R = W * (1 - z.r);
        covered.push([0, 0, W, T]);
        covered.push([0, B, W, H]);
        covered.push([0, T, Lx, B]);
        covered.push([R, T, W, B]);
        if (z.extra) {
            for (var i = 0; i < z.extra.length; i++) {
                var e = z.extra[i];
                var ex0 = Math.max(W * e[0], Lx), ey0 = Math.max(H * e[1], T), ex1 = Math.min(W * e[2], R), ey1 = Math.min(H * e[3], B);
                if (ex1 - ex0 > 0.5 && ey1 - ey0 > 0.5) { covered.push([ex0, ey0, ex1, ey1]); }
            }
        }
        boxes.push([Lx, T, R, B, 'Safe']);
        return { covered: covered, boxes: boxes, name: z.name };
    };

    K.safeZone = function (a) { return drawSafe(U.comp(), a); };

    function drawSafe(c, a) {
        var W = c.width, H = c.height;
        var z = K.zoneRects(a.zone || 'ig_reels', W, H);
        var k = Math.max(W, H) / 1920;
        var L = c.layers.addShape();
        L.name = uniqueName(c, 'AIO Safe - ' + z.name);
        // remember the settings so the guide can be redrawn when the comp is resized
        L.comment = SAFE_TAG + '|' + (a.zone || 'ig_reels') + '|' + (a.thirds ? 1 : 0) + '|' + (a.center ? 1 : 0) + '|' + num(a.opacity, 35);
        L.label = 1;
        U.setXY(U.tr(L).property('ADBE Position'), 0, 0);
        var i;
        if (z.covered.length) {
            var gc = group(L, 'Covered by app UI');
            var vc = gc.property('ADBE Vectors Group');
            for (i = 0; i < z.covered.length; i++) { addRect(vc, z.covered[i][0], z.covered[i][1], z.covered[i][2], z.covered[i][3]); }
            paint(gc, [1, 0.22, 0.3], null, 0, U.clamp(num(a.opacity, 35), 5, 100));
        }
        var cols = [[0.25, 1, 0.55], [1, 0.82, 0.2]];
        for (i = 0; i < z.boxes.length; i++) {
            var b = z.boxes[i];
            var gb = group(L, b[4]);
            addRect(gb.property('ADBE Vectors Group'), b[0], b[1], b[2], b[3]);
            paint(gb, null, cols[i % 2], Math.max(2, 4 * k), 100);
        }
        if (a.thirds) {
            var gt = group(L, 'Rule of thirds');
            var vt = gt.property('ADBE Vectors Group');
            addLine(vt, W / 3, 0, W / 3, H); addLine(vt, W * 2 / 3, 0, W * 2 / 3, H);
            addLine(vt, 0, H / 3, W, H / 3); addLine(vt, 0, H * 2 / 3, W, H * 2 / 3);
            paint(gt, null, [1, 1, 1], Math.max(1, 2 * k), 45);
        }
        if (a.center) {
            var gx = group(L, 'Centre');
            var vx = gx.property('ADBE Vectors Group'), s = 40 * k;
            addLine(vx, W / 2 - s, H / 2, W / 2 + s, H / 2); addLine(vx, W / 2, H / 2 - s, W / 2, H / 2 + s);
            paint(gx, null, [1, 1, 1], Math.max(1, 2 * k), 80);
        }
        L.startTime = 0;
        try { L.inPoint = 0; L.outPoint = c.duration; } catch (e) {}
        L.guideLayer = true;
        L.selected = false;
        L.locked = true;
        return { name: L.name, zone: z.name };
    }

    function isSafe(L) { return String(L.comment).indexOf(SAFE_TAG) === 0; }

    function redrawSafe(c) {
        var list = [];
        for (var i = c.numLayers; i >= 1; i--) {
            var L = c.layer(i);
            if (!isSafe(L)) { continue; }
            var p = String(L.comment).split('|');
            list.push({ zone: p[1] || 'ig_reels', thirds: p[2] === '1', center: p[3] === '1', opacity: num(p[4], 35) });
            L.locked = false;
            L.remove();
        }
        for (var j = 0; j < list.length; j++) { drawSafe(c, list[j]); }
    }

    K.removeSafeZones = function () {
        var c = U.comp();
        var n = 0;
        for (var i = c.numLayers; i >= 1; i--) {
            var L = c.layer(i);
            if (isSafe(L)) { L.locked = false; L.remove(); n++; }
        }
        return { count: n };
    };

    return K;
})();
