/* All In One — Captions (ExtendScript, ES3) */
MKH.captions = (function () {
    var U = MKH.util;
    var C = {};
    var TAG = 'AIO_CAPTION', OLD_TAG = 'MK_CAPTION';

    function r3(v) { return Math.round(v * 1000) / 1000; }
    // start times are rounded DOWN so `time >= start` is already true on the first frame
    function fl3(v) { return Math.floor(v * 1000 + 1e-6) / 1000; }

    function textDoc(L) { return L.property('ADBE Text Properties').property('ADBE Text Document'); }

    function setPropVal(prop, v) {
        try { prop.setValue(v); return true; } catch (e) {}
        if (v instanceof Array && v.length >= 3) { try { prop.setValue(v.slice(0, v.length - 1)); return true; } catch (e2) {} }
        return false;
    }

    function vec(prop, k) {
        var v = prop.value;
        if (!(v instanceof Array)) { return k; }
        var o = [];
        for (var i = 0; i < v.length; i++) { o.push(i < 2 ? k : 100); }
        return o;
    }

    function easeKeys(prop, from, to) {
        for (var k = from; k <= to; k++) {
            try {
                var n = prop.keyInTemporalEase(k).length, a = [];
                for (var i = 0; i < n; i++) { a.push(new KeyframeEase(0, 60)); }
                prop.setTemporalEaseAtKey(k, a, a);
            } catch (e) {}
        }
    }

    C.getSourceInfo = function () {
        var c = U.comp();
        var s = U.sel(c);
        for (var i = 0; i < s.length; i++) {
            var L = s[i];
            if (L.source && L.source.file && L.hasAudio) {
                return {
                    path: L.source.file.fsName, name: L.name, startTime: L.startTime, stretch: L.stretch,
                    inPoint: L.inPoint, outPoint: L.outPoint, duration: L.source.duration, compDuration: c.duration
                };
            }
        }
        throw new Error('NO_AUDIO_LAYER');
    };

    function animate(L, kind, t0) {
        var tr = U.tr(L);
        if (kind === 'pop') {
            var s = tr.property('ADBE Scale');
            s.setValueAtTime(t0, vec(s, 72));
            s.setValueAtTime(t0 + 0.08, vec(s, 108));
            s.setValueAtTime(t0 + 0.16, vec(s, 100));
            easeKeys(s, 1, 3);
        } else if (kind === 'bounce') {
            var b = tr.property('ADBE Scale');
            b.setValueAtTime(t0, vec(b, 0));
            b.setValueAtTime(t0 + 0.1, vec(b, 115));
            b.setValueAtTime(t0 + 0.18, vec(b, 94));
            b.setValueAtTime(t0 + 0.26, vec(b, 100));
            easeKeys(b, 1, 4);
        } else if (kind === 'fade') {
            var o = tr.property('ADBE Opacity');
            o.setValueAtTime(t0, 0);
            o.setValueAtTime(t0 + 0.12, 100);
        } else if (kind === 'slide') {
            var p = tr.property('ADBE Position');
            var v = p.value;
            var v0 = v.slice(0); v0[1] += 36;
            p.setValueAtTime(t0, v0);
            p.setValueAtTime(t0 + 0.18, v);
            easeKeys(p, 1, 2);
            var op = tr.property('ADBE Opacity');
            op.setValueAtTime(t0, 0);
            op.setValueAtTime(t0 + 0.12, 100);
        }
    }

    function highlight(L, words, st) {
        if (!words || !words.length) { return; }
        var anim = L.property('ADBE Text Properties').property('ADBE Text Animators').addProperty('ADBE Text Animator');
        anim.name = 'AIO Highlight';
        var props = anim.property('ADBE Text Animator Properties');
        var col = st.hlColor || [1, 0.85, 0.1];
        setPropVal(props.addProperty('ADBE Text Fill Color'), [col[0], col[1], col[2], 1]);
        var hs = parseFloat(st.hlScale) || 100;
        if (hs !== 100) {
            setPropVal(props.addProperty('ADBE Text Scale 3D'), [hs, hs, 100]);
            try {
                var more = L.property('ADBE Text Properties').property('ADBE Text More Options');
                more.property('ADBE Text Anchor Point Option').setValue(2);
                setPropVal(more.property('ADBE Text Anchor Point Align'), [0, -50]);
            } catch (e) {}
        }
        var sel = anim.property('ADBE Text Selectors').addProperty('ADBE Text Expressible Selector');
        try { sel.property('ADBE Text Range Type2').setValue(3); } catch (e2) {}
        var arr = [];
        for (var i = 0; i < words.length; i++) {
            arr.push('[' + fl3(words[i][0]) + ',' + r3(words[i][1]) + ']');
        }
        var cond = (st.hlMode === 'progressive') ? 'time >= w[i][0]' : 'time >= w[i][0] && time < w[i][1]';
        sel.property('ADBE Text Expressible Amount').expression =
            '// All In One - word highlight\nvar w = [' + arr.join(',') + '];\nvar i = textIndex - 1, k = 0;\n' +
            'if (i < w.length && ' + cond + ') { k = 100; }\n[k, k, k]';
    }

    function styleDoc(prop, st, txt) {
        var d = prop.value;
        if (txt !== undefined) { d.text = txt; }
        d.fontSize = parseFloat(st.size) || 72;
        d.applyFill = true;
        d.fillColor = st.fill || [1, 1, 1];
        if (st.font) { try { d.font = st.font; } catch (e) {} }
        var sw = parseFloat(st.stroke) || 0;
        d.applyStroke = sw > 0;
        if (sw > 0) {
            d.strokeColor = st.strokeColor || [0, 0, 0];
            d.strokeWidth = sw;
            try { d.strokeOverFill = false; } catch (e1) {}
        }
        try { d.justification = ParagraphJustification.CENTER_JUSTIFY; } catch (e2) {}
        if (st.tracking) { try { d.tracking = parseFloat(st.tracking); } catch (e3) {} }
        prop.setValue(d);
    }

    // AE silently falls back to another font when the PostScript name is unknown
    function fontCheck(prop, st, warnings) {
        if (!st.font) { return; }
        try {
            var got = prop.value.font;
            if (got && got !== st.font && !warnings.fontWarned) {
                warnings.push('FONT_MISSING:' + st.font + '>' + got);
                warnings.fontWarned = true;
            }
        } catch (e) {}
    }

    function snap(c, t) { return Math.round(t / c.frameDuration) * c.frameDuration; }

    // sort, snap to frames and make sure no two captions are on screen at once
    function cleanTimes(c, caps) {
        var out = [];
        for (var i = 0; i < caps.length; i++) {
            var cp = caps[i];
            if (!cp || !U.trim(String(cp.text || '').replace(/\r/g, ' '))) { continue; }
            if (cp.start >= c.duration - c.frameDuration / 2) { continue; }
            out.push({ text: String(cp.text), words: cp.words || [], s: snap(c, Math.max(0, cp.start)), e: snap(c, Math.min(c.duration, cp.end)) });
        }
        out.sort(function (a, b) { return a.s - b.s; });
        for (var j = 0; j < out.length; j++) {
            var nx = out[j + 1];
            if (nx && out[j].e > nx.s) { out[j].e = nx.s; }
            if (out[j].e - out[j].s < c.frameDuration) { out[j].e = out[j].s + c.frameDuration; if (nx && nx.s < out[j].e) { nx.s = out[j].e; } }
        }
        return out;
    }

    function isCaption(L) { return L.comment === TAG || L.comment === OLD_TAG; }
    function removeCaptions(c) {
        var n = 0;
        for (var i = c.numLayers; i >= 1; i--) {
            var L = c.layer(i);
            if (isCaption(L)) { if (L.locked) { L.locked = false; } L.remove(); n++; }
        }
        return n;
    }

    // how many caption layers (this or older versions) are already in the comp
    C.listExisting = function () {
        var c = U.comp(), n = 0;
        for (var i = 1; i <= c.numLayers; i++) { if (isCaption(c.layer(i))) { n++; } }
        return { count: n };
    };

    C.create = function (a) {
        var c = U.comp();
        if (a.replace) { removeCaptions(c); }
        var st = a.style || {};
        var caps = cleanTimes(c, a.captions || []);
        var size = parseFloat(st.size) || 72;
        var y = c.height * U.clamp((parseFloat(st.yPct) || 80) / 100, 0, 1);
        var made = 0, startNum = a.startNum || 1, warnings = [];
        for (var i = 0; i < caps.length; i++) {
            var cap = caps[i];
            var t0 = cap.s, t1 = cap.e;
            if (t1 - t0 < c.frameDuration * 0.5 || t0 >= c.duration) { continue; }
            var txt = st.upper ? cap.text.toUpperCase() : cap.text;
            var L = c.layers.addText(txt);
            var prop = textDoc(L);
            styleDoc(prop, st);
            if (i === 0) { fontCheck(prop, st, warnings); }
            L.name = 'CAP ' + U.pad(startNum + i, 3);
            L.comment = TAG;
            L.label = 11;
            // set the time range explicitly: start at 0, then out, then in (never out < in)
            L.startTime = 0;
            L.outPoint = t1;
            L.inPoint = t0;
            var r = L.sourceRectAtTime(t0, false);
            U.setXY(U.tr(L).property('ADBE Anchor Point'), r.left + r.width / 2, r.top + r.height / 2);
            U.setPosStatic(L, [c.width / 2, y]);
            if (st.anim && st.anim !== 'none') { animate(L, st.anim, t0); }
            if (st.highlight && cap.words && cap.words.length) { highlight(L, cap.words, st); }
            if (st.shadow) { shadow(L, size); }
            made++;
        }
        var res = { count: made };
        if (warnings.length) { res.warnings = warnings; }
        return res;
    };

    function shadow(L, size) {
        try {
            var ds = L.property('ADBE Effect Parade').addProperty('ADBE Drop Shadow');
            ds.property('ADBE Drop Shadow-0004').setValue(Math.max(4, size * 0.06));
            ds.property('ADBE Drop Shadow-0005').setValue(Math.max(6, size * 0.12));
        } catch (e) {}
    }


    // all captions on ONE text layer: Source Text keys + expressions for centring, animation and highlight
    C.createSingle = function (a) {
        var c = U.comp();
        var st = a.style || {};
        var caps = cleanTimes(c, a.captions || []);
        if (!caps.length) { throw new Error('NO_CAPTIONS'); }
        if (a.replace) { removeCaptions(c); }
        var size = parseFloat(st.size) || 72;
        var y = c.height * U.clamp((parseFloat(st.yPct) || 80) / 100, 0, 1);
        var warnings = [];
        var L = c.layers.addText(' ');
        var prop = textDoc(L);
        styleDoc(prop, st);
        fontCheck(prop, st, warnings);
        L.name = 'AIO Captions';
        L.comment = TAG;
        L.label = 11;
        var starts = [], words = [];
        for (var i = 0; i < caps.length; i++) {
            var cap = caps[i];
            var txt = st.upper ? cap.text.toUpperCase() : cap.text;
            var d = prop.value; d.text = txt;
            prop.setValueAtTime(cap.s, d);
            var nx = caps[i + 1];
            if (!nx || nx.s > cap.e + 1e-4) { var blank = prop.value; blank.text = ' '; prop.setValueAtTime(cap.e, blank); }
            starts.push(fl3(cap.s));
            var wl = [];
            for (var w = 0; w < cap.words.length; w++) { wl.push('[' + fl3(cap.words[w][0]) + ',' + r3(cap.words[w][1]) + ']'); }
            words.push('[' + wl.join(',') + ']');
        }
        L.startTime = 0;
        L.outPoint = Math.min(c.duration, caps[caps.length - 1].e + c.frameDuration);
        L.inPoint = caps[0].s;
        var T = U.tr(L);
        var find = 'var S = [' + starts.join(',') + '];\nvar lo = 0, hi = S.length - 1, i = -1;\n' +
            'while (lo <= hi) { var m = Math.floor((lo + hi) / 2); if (S[m] <= time) { i = m; lo = m + 1; } else { hi = m - 1; } }\n' +
            'var dt = i < 0 ? 0 : time - S[i];\n';
        // centre each caption once (hold keys) — a per-frame expression would wobble as highlighted words grow
        var ap = T.property('ADBE Anchor Point');
        for (var a2 = 0; a2 < caps.length; a2++) {
            var rr = L.sourceRectAtTime(caps[a2].s + c.frameDuration / 4, false);
            var av = ap.value;
            av[0] = rr.left + rr.width / 2; av[1] = rr.top + rr.height / 2;
            ap.setValueAtTime(caps[a2].s, av);
        }
        for (var hk = 1; hk <= ap.numKeys; hk++) { ap.setInterpolationTypeAtKey(hk, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD); }
        U.setPosStatic(L, [c.width / 2, y]);
        var anim = st.anim || 'none';
        if (anim === 'pop') {
            T.property('ADBE Scale').expression = '// All In One - caption pop\n' + find + 'var k = dt < 0.08 ? ease(dt, 0, 0.08, 72, 108) : ease(dt, 0.08, 0.16, 108, 100);\nmul(value, k / 100)';
        } else if (anim === 'bounce') {
            T.property('ADBE Scale').expression = '// All In One - caption bounce\n' + find +
                'var k = dt < 0.1 ? ease(dt, 0, 0.1, 0, 115) : (dt < 0.18 ? ease(dt, 0.1, 0.18, 115, 94) : ease(dt, 0.18, 0.26, 94, 100));\nmul(value, k / 100)';
        } else if (anim === 'fade') {
            T.property('ADBE Opacity').expression = '// All In One - caption fade\n' + find + 'value * ease(dt, 0, 0.12, 0, 1)';
        } else if (anim === 'slide') {
            T.property('ADBE Opacity').expression = '// All In One - caption slide\n' + find + 'value * ease(dt, 0, 0.12, 0, 1)';
            T.property('ADBE Position').expression = '// All In One - caption slide\n' + find + 'var v = value; v[1] = v[1] + ease(dt, 0, 0.18, 36, 0);\nv';
        }
        if (st.highlight) {
            var an = L.property('ADBE Text Properties').property('ADBE Text Animators').addProperty('ADBE Text Animator');
            an.name = 'AIO Highlight';
            var props = an.property('ADBE Text Animator Properties');
            var col = st.hlColor || [1, 0.85, 0.1];
            setPropVal(props.addProperty('ADBE Text Fill Color'), [col[0], col[1], col[2], 1]);
            var hs = parseFloat(st.hlScale) || 100;
            if (hs !== 100) {
                setPropVal(props.addProperty('ADBE Text Scale 3D'), [hs, hs, 100]);
                // grow whole words around their baseline centre, like the per-layer mode
                try {
                    var more = L.property('ADBE Text Properties').property('ADBE Text More Options');
                    more.property('ADBE Text Anchor Point Option').setValue(2);
                    setPropVal(more.property('ADBE Text Anchor Point Align'), [0, -50]);
                } catch (e5) {}
            }
            var sel = an.property('ADBE Text Selectors').addProperty('ADBE Text Expressible Selector');
            try { sel.property('ADBE Text Range Type2').setValue(3); } catch (e2) {}
            var cond = (st.hlMode === 'progressive') ? 'time >= w[j][0]' : 'time >= w[j][0] && time < w[j][1]';
            sel.property('ADBE Text Expressible Amount').expression = '// All In One - word highlight\n' + find +
                'var W = [' + words.join(',') + '];\nvar k = 0;\nif (i >= 0) { var w = W[i], j = textIndex - 1; if (j < w.length && ' + cond + ') { k = 100; } }\n[k, k, k]';
        }
        if (st.shadow) { shadow(L, size); }
        var res = { count: caps.length, single: true };
        if (warnings.length) { res.warnings = warnings; }
        return res;
    };

    /* ---------- audio for transcription, rendered by After Effects itself (no ffmpeg needed) ---------- */
    function findFootage(f) {
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            try { if (it instanceof FootageItem && it.file && it.file.fsName === f.fsName) { return it; } } catch (e) {}
        }
        return null;
    }
    var AUDIO_TPL = [/AIFF/i, /WAV/i, /Audio Only/i];

    // a.path = media file, a.out = output path without extension → { path, duration }
    C.renderAudio = function (a) {
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var item = findFootage(f), imported = false;
        if (!item) { item = app.project.importFile(new ImportOptions(f)); imported = true; }
        var tmp = null, rqItem = null, paused = [];
        var rq = app.project.renderQueue;
        try {
            if (!item.hasAudio) { throw new Error('NO_AUDIO_IN_FILE'); }
            var dur = item.duration;
            tmp = app.project.items.addComp('AIO caption audio', 64, 64, 1, Math.max(dur, 0.1), 25);
            var L = tmp.layers.add(item);
            L.startTime = 0;
            for (var i = 1; i <= rq.numItems; i++) {
                var it = rq.item(i);
                if (it.status === RQItemStatus.QUEUED) { it.render = false; paused.push(it); }
            }
            rqItem = rq.items.add(tmp);
            var om = rqItem.outputModule(1), tpl = null, list = om.templates;
            for (var t = 0; t < AUDIO_TPL.length && !tpl; t++) {
                for (var k = 0; k < list.length; k++) { if (AUDIO_TPL[t].test(list[k])) { tpl = list[k]; break; } }
            }
            if (tpl) { om.applyTemplate(tpl); }
            else { try { om.setSettings({ 'Format': 'WAV' }); } catch (e) { throw new Error('NO_TEMPLATE'); } }
            om.file = new File(a.out);
            rq.render();
            // AE adds the extension itself: find the file it wrote
            var want = new File(a.out), folder = want.parent, base = want.name.replace(/\.[^.]*$/, '');
            var hits = folder.getFiles(function (x) { return (x instanceof File) && x.name.indexOf(base) === 0; });
            if (!hits.length) { throw new Error('RENDER_FAILED'); }
            return { path: hits[0].fsName, duration: dur, template: tpl || 'WAV' };
        } finally {
            try { if (rqItem) { rqItem.remove(); } } catch (e2) {}
            for (var j = 0; j < paused.length; j++) { try { paused[j].render = true; } catch (e3) {} }
            try { if (tmp) { tmp.remove(); } } catch (e4) {}
            try { if (imported) { item.remove(); } } catch (e5) {}
        }
    };

    C.removeAll = function () { return { count: removeCaptions(U.comp()) }; };

    return C;
})();
