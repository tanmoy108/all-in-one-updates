/* All In One — Text Animation (ExtendScript, ES3)
   1) .ffx preset library: apply + generate frame previews
   2) Text Builder: an original animator rig driven by an Expression Selector */
MKH.text = (function () {
    var U = MKH.util;
    var T = {};

    function textDoc(L) { return L.property('ADBE Text Properties').property('ADBE Text Document'); }

    function newTextLayer(c, str) {
        var L = c.layers.addText(str || 'Your Text');
        var d = textDoc(L).value;
        try { d.justification = ParagraphJustification.CENTER_JUSTIFY; } catch (e) {}
        textDoc(L).setValue(d);
        var r = L.sourceRectAtTime(c.time, false);
        U.setXY(U.tr(L).property('ADBE Anchor Point'), r.left + r.width / 2, r.top + r.height / 2);
        U.setPosStatic(L, [c.width / 2, c.height / 2]);
        return L;
    }

    /* ---------- .ffx presets ---------- */
    /* ---------- IN / OUT split of an applied preset ---------- */
    function walkPaths(group, path, cb) {
        for (var i = 1; i <= group.numProperties; i++) {
            var p = group.property(i);
            if (!p) { continue; }
            var pp = path + '/' + i;
            if (p.propertyType === PropertyType.PROPERTY) { cb(p, pp); } else { walkPaths(p, pp, cb); }
        }
    }

    function r3(t) { return String(Math.round(t * 1000)); }

    // key times per property path, taken before the preset is applied
    function keySnapshot(L) {
        var snap = {};
        walkPaths(L, '', function (p, path) {
            try {
                if (p.numKeys > 0) {
                    var ts = {};
                    for (var k = 1; k <= p.numKeys; k++) { ts[r3(p.keyTime(k))] = true; }
                    snap[path] = ts;
                }
            } catch (e) {}
        });
        return snap;
    }

    // keyframes the preset added: [{p, t}]
    function addedKeys(L, snap) {
        var out = [];
        walkPaths(L, '', function (p, path) {
            try {
                if (!(p.numKeys > 0)) { return; }
                var old = snap[path] || {};
                for (var k = 1; k <= p.numKeys; k++) {
                    var t = p.keyTime(k);
                    if (!old[r3(t)]) { out.push({ p: p, t: t }); }
                }
            } catch (e) {}
        });
        return out;
    }

    // Find the "hold" between an IN cluster and an OUT cluster of key times.
    // Returns the split time, or null when the preset has a single animation.
    T.splitTime = function (times) {
        var u = [], seen = {};
        for (var i = 0; i < times.length; i++) { var k = r3(times[i]); if (!seen[k]) { seen[k] = true; u.push(times[i]); } }
        u.sort(function (a, b) { return a - b; });
        if (u.length < 4) { return null; }
        var best = -1, gap = 0;
        for (var j = 0; j < u.length - 1; j++) { if (u[j + 1] - u[j] > gap) { gap = u[j + 1] - u[j]; best = j; } }
        var left = u.slice(0, best + 1), right = u.slice(best + 1);
        if (left.length < 2 || right.length < 2) { return null; }
        var span = Math.max(left[left.length - 1] - left[0], right[right.length - 1] - right[0]);
        if (gap < 0.5 || gap < 0.75 * span) { return null; }
        return (u[best] + u[best + 1]) / 2;
    };

    // move one key to a new time keeping value, interpolation, eases and tangents
    function moveKey(p, k, t) {
        var v = p.keyValue(k), iT = p.keyInInterpolationType(k), oT = p.keyOutInterpolationType(k);
        var iE = null, oE = null, iS = null, oS = null;
        try { iE = p.keyInTemporalEase(k); oE = p.keyOutTemporalEase(k); } catch (e) {}
        if (p.isSpatial) { try { iS = p.keyInSpatialTangent(k); oS = p.keyOutSpatialTangent(k); } catch (e1) {} }
        p.removeKey(k);
        var nk = p.addKey(t);
        p.setValueAtKey(nk, v);
        try {
            p.setInterpolationTypeAtKey(nk, iT, oT);
            if (iE && oE) { p.setTemporalEaseAtKey(nk, iE, oE); }
            if (iS && oS) { p.setSpatialTangentsAtKey(nk, iS, oS); }
        } catch (e2) {}
    }

    // group added keys by property, newest-first friendly
    function byProp(keys, test) {
        var groups = [];
        for (var i = 0; i < keys.length; i++) {
            if (!test(keys[i].t)) { continue; }
            var g = null;
            for (var j = 0; j < groups.length; j++) { if (groups[j].p === keys[i].p) { g = groups[j]; break; } }
            if (!g) { g = { p: keys[i].p, ts: [] }; groups.push(g); }
            g.ts.push(keys[i].t);
        }
        return groups;
    }

    function keepPart(c, L, keys, part) {
        var times = [];
        for (var i = 0; i < keys.length; i++) { times.push(keys[i].t); }
        var split = T.splitTime(times);
        if (split === null) { return 'single'; }
        var lastIn = -1e9, firstOut = 1e9, lastOut = -1e9;
        for (var q = 0; q < times.length; q++) {
            if (times[q] < split) { lastIn = Math.max(lastIn, times[q]); }
            else { firstOut = Math.min(firstOut, times[q]); lastOut = Math.max(lastOut, times[q]); }
        }
        // 1) drop the part we don't want
        if (part === 'in' || part === 'out') {
            var drop = byProp(keys, part === 'in' ? function (t) { return t > split; } : function (t) { return t < split; });
            for (var d = 0; d < drop.length; d++) {
                var ts = drop[d].ts.sort(function (a, b) { return b - a; });
                for (var r = 0; r < ts.length; r++) { drop[d].p.removeKey(drop[d].p.nearestKeyIndex(ts[r])); }
            }
        }
        // 2) slide the OUT animation so it finishes on the layer's last frame
        if (part === 'out' || part === 'both') {
            var dt = (L.outPoint - c.frameDuration) - lastOut;
            var okToMove = part === 'out' ? true : (firstOut + dt > lastIn + c.frameDuration);
            if (Math.abs(dt) > c.frameDuration / 2 && okToMove) {
                var mv = byProp(keys, function (t) { return t > split; });
                for (var m = 0; m < mv.length; m++) {
                    var mts = mv[m].ts.sort(function (a, b) { return dt > 0 ? b - a : a - b; });
                    for (var n = 0; n < mts.length; n++) {
                        moveKey(mv[m].p, mv[m].p.nearestKeyIndex(mts[n]), mts[n] + dt);
                    }
                }
            }
        }
        return 'split';
    }

    /* ---------- .ffx presets ---------- */
    T.applyFFX = function (a) {
        var c = U.comp();
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var part = a.part || 'both';
        var targets = [];
        var s = c.selectedLayers;
        for (var i = 0; i < s.length; i++) { targets.push(s[i]); }
        var created = false;
        if (!targets.length) { targets.push(newTextLayer(c, a.text)); created = true; }
        var keepTime = c.time, single = false;
        for (var j = 0; j < targets.length; j++) {
            var L = targets[j];
            U.select(c, [L]);
            if (a.at === 'start') { c.time = L.inPoint; }
            var snap = (part !== 'raw') ? keySnapshot(L) : null;
            L.applyPreset(f);
            c.time = keepTime;
            if (snap) {
                var res = keepPart(c, L, addedKeys(L, snap), part);
                if (res === 'single') { single = true; }
            }
        }
        U.select(c, targets);
        return { count: targets.length, created: created, single: single };
    };

    function maxKeyTime(group) {
        var m = 0;
        U.walk(group, function (p) {
            try { if (p.numKeys > 0) { var t = p.keyTime(p.numKeys); if (t > m) { m = t; } } } catch (e) {}
        });
        return m;
    }

    // Renders a handful of PNG frames of the preset on sample text (no render queue needed)
    T.genPreview = function (a) {
        var f = new File(a.path);
        if (!f.exists) { throw new Error('FILE_MISSING'); }
        var outDir = U.ensureFolder(a.outDir);
        var w = a.w || 400, h = a.h || 225, frames = a.frames || 10;
        var prev = U.compOrNull();
        // transparent background: the panel card supplies the dark backdrop
        var c = app.project.items.addComp('AIO_preview_tmp', w, h, 1, 4, 30);
        var names = [], dur = 1;
        try {
            var L = c.layers.addText(a.text || 'Motion');
            var td = textDoc(L).value;
            td.fontSize = a.size || 64;
            td.applyFill = true;
            td.fillColor = [1, 1, 1];
            td.applyStroke = false;
            try { td.justification = ParagraphJustification.CENTER_JUSTIFY; } catch (e) {}
            if (a.font) { try { td.font = a.font; } catch (e1) {} }
            textDoc(L).setValue(td);
            var r = L.sourceRectAtTime(0, false);
            U.setXY(U.tr(L).property('ADBE Anchor Point'), r.left + r.width / 2, r.top + r.height / 2);
            U.setPosStatic(L, [w / 2, h / 2]);
            try { c.openInViewer(); } catch (e2) {}
            c.time = 0;
            U.select(c, [L]);
            L.applyPreset(f);
            var end = maxKeyTime(L);
            dur = U.clamp(end + 0.4, 1, 4);
            for (var i = 0; i < frames; i++) {
                var t = (frames === 1) ? dur : i * dur / (frames - 1);
                var pf = new File(outDir.fsName + '/f' + U.pad(i, 2) + '.png');
                if (pf.exists) { pf.remove(); }
                c.saveFrameToPng(t, pf);
                U.waitForFile(pf, 4000);
                names.push(pf.name);
            }
        } finally {
            $.sleep(150);
            try { c.remove(); } catch (e5) {}
            if (prev) { try { prev.openInViewer(); } catch (e4) {} }
        }
        return { frames: names, duration: dur };
    };

    /* ---------- Text Builder ---------- */
    var BASED = { chars: 1, charsNoSpace: 2, words: 3, lines: 4 };
    var GROUP = { chars: 1, charsNoSpace: 1, words: 2, lines: 3 };

    function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }

    // The selector expression. Amount 100 = animator values fully applied (the "from" state), 0 = text at rest.
    function word(v, d) { return String(v || d).replace(/[^a-zA-Z]/g, ''); }

    function builderExpression(p, mode) {
        var lines = [
            '// All In One - Text Builder (' + mode + ')',
            'var d = ' + num(p.delay, 0.04) + ';',
            'var dur = ' + Math.max(0.01, num(p.duration, 0.6)) + ';',
            'var ease = "' + word(p.easing, 'smooth') + '";',
            'var freq = ' + num(p.freq, 2) + ', decay = ' + num(p.decay, 6) + ';',
            'var order = "' + word(p.order, 'forward') + '";',
            'var off = ' + num(p.offset, 0) + ';',
            'var n = textTotal, i = textIndex - 1;',
            'if (order == "reverse") { i = n - 1 - i; }',
            'else if (order == "center") { i = Math.abs(i - (n - 1) / 2); }',
            'else if (order == "edges") { i = (n - 1) / 2 - Math.abs(i - (n - 1) / 2); }',
            'else if (order == "random") { seedRandom(textIndex, true); i = Math.floor(random(0, n)); }',
            'var span = dur + Math.max(0, n - 1) * d;'
        ];
        if (mode === 'in') {
            lines.push('var t = time - (inPoint + off) - i * d;');
            lines.push('var k = 0;');
            lines.push('if (t <= 0) { k = 100; }');
            lines.push('else if (ease == "elastic") { k = 100 * Math.exp(-decay * t) * Math.cos(2 * Math.PI * freq * t); }');
            lines.push('else {');
            lines.push('  var x = Math.min(1, t / dur), e;');
            lines.push('  if (ease == "linear") { e = x; }');
            lines.push('  else if (ease == "back") { var s = 1.70158 * ' + num(p.overshoot, 1) + '; var y = x - 1; e = 1 + (s + 1) * y * y * y + s * y * y; }');
            lines.push('  else if (ease == "bounce") { var b = x; if (b < 1 / 2.75) { e = 7.5625 * b * b; } else if (b < 2 / 2.75) { b -= 1.5 / 2.75; e = 7.5625 * b * b + 0.75; } else if (b < 2.5 / 2.75) { b -= 2.25 / 2.75; e = 7.5625 * b * b + 0.9375; } else { b -= 2.625 / 2.75; e = 7.5625 * b * b + 0.984375; } }');
            lines.push('  else { e = 1 - Math.pow(1 - x, 4); }');
            lines.push('  k = 100 * (1 - e);');
            lines.push('}');
        } else {
            lines.push('var t = time - (outPoint - off - span) - i * d;');
            lines.push('var x = Math.max(0, Math.min(1, t / dur)), e;');
            lines.push('if (ease == "linear") { e = x; }');
            lines.push('else if (ease == "back") { var s = 1.70158 * ' + num(p.overshoot, 1) + '; e = x * x * ((s + 1) * x - s); }');
            lines.push('else { e = x * x * x * x; }');
            lines.push('var k = 100 * e;');
        }
        lines.push('[k, k, k]');
        return lines.join('\n');
    }

    function setPropVal(prop, v) {
        try { prop.setValue(v); return true; } catch (e) {}
        if (v instanceof Array && v.length === 3) { try { prop.setValue([v[0], v[1]]); return true; } catch (e2) {} }
        return false;
    }

    function removeMK(L, tag) {
        var anim = L.property('ADBE Text Properties').property('ADBE Text Animators');
        for (var i = anim.numProperties; i >= 1; i--) {
            if (anim.property(i).name.indexOf(tag) === 0) { anim.property(i).remove(); }
        }
    }

    function addAnimator(L, p, mode) {
        var anim = L.property('ADBE Text Properties').property('ADBE Text Animators');
        var g = anim.addProperty('ADBE Text Animator');
        g.name = 'AIO ' + (p.name || 'Builder') + ' ' + (mode === 'in' ? 'In' : 'Out');
        var props = g.property('ADBE Text Animator Properties');
        var dist = num(p.distance, 0), dx = 0, dy = 0;
        var dir = p.direction || 'none';
        // "up" = text travels upward into place, so it starts below
        if (dir === 'up') { dy = dist; } else if (dir === 'down') { dy = -dist; }
        else if (dir === 'left') { dx = dist; } else if (dir === 'right') { dx = -dist; }
        if (mode === 'out') { dx = -dx; dy = -dy; }
        if (dx || dy) { setPropVal(props.addProperty('ADBE Text Position 3D'), [dx, dy, 0]); }
        var sc = num(p.scale, 100);
        if (sc !== 100) { setPropVal(props.addProperty('ADBE Text Scale 3D'), [sc, sc, 100]); }
        var rot = num(p.rotation, 0);
        if (rot) { props.addProperty('ADBE Text Rotation').setValue(mode === 'out' ? -rot : rot); }
        var op = num(p.opacity, 100);
        if (op !== 100) { props.addProperty('ADBE Text Opacity').setValue(op); }
        var bl = num(p.blur, 0);
        if (bl) { setPropVal(props.addProperty('ADBE Text Blur'), [bl, bl]); }
        var tr = num(p.tracking, 0);
        if (tr) { props.addProperty('ADBE Text Tracking Amount').setValue(tr); }
        var sk = num(p.skew, 0);
        if (sk) { props.addProperty('ADBE Text Skew').setValue(sk); }

        var sels = g.property('ADBE Text Selectors');
        for (var i = sels.numProperties; i >= 1; i--) { sels.property(i).remove(); }
        var ex = sels.addProperty('ADBE Text Expressible Selector');
        ex.name = 'AIO Selector';
        try { ex.property('ADBE Text Range Type2').setValue(BASED[p.based] || 1); } catch (e) {}
        ex.property('ADBE Text Expressible Amount').expression = builderExpression(p, mode);
        return g;
    }

    function setGrouping(L, based) {
        try {
            var more = L.property('ADBE Text Properties').property('ADBE Text More Options');
            more.property('ADBE Text Anchor Point Option').setValue(GROUP[based] || 1);
            setPropVal(more.property('ADBE Text Anchor Point Align'), [0, -50]);
        } catch (e) {}
    }

    T.applyBuilder = function (a) {
        var c = U.comp();
        var p = a.preset || {};
        var targets = [];
        var s = c.selectedLayers;
        for (var i = 0; i < s.length; i++) { if (s[i] instanceof TextLayer) { targets.push(s[i]); } }
        var created = false;
        if (!targets.length) {
            if (s.length) { throw new Error('NO_TEXT_LAYER'); }
            targets.push(newTextLayer(c, a.text));
            created = true;
        }
        var mode = p.mode || 'in';
        for (var j = 0; j < targets.length; j++) {
            var L = targets[j];
            if (a.replace !== false) { removeMK(L, 'AIO '); removeMK(L, 'MK '); }
            setGrouping(L, p.based);
            if (p.motionBlur) { L.motionBlur = true; c.motionBlur = true; }
            if (mode === 'in' || mode === 'both') { addAnimator(L, p, 'in'); }
            if (mode === 'out' || mode === 'both') { addAnimator(L, p.out || p, 'out'); }
        }
        U.select(c, targets);
        return { count: targets.length, created: created };
    };

    T.removeBuilder = function () {
        var c = U.comp();
        var s = U.textLayers(c);
        for (var i = 0; i < s.length; i++) { removeMK(s[i], 'AIO '); removeMK(s[i], 'MK '); }
        return { count: s.length };
    };

    // exposes the generated expression so the panel/tests can inspect it
    T.getExpression = function (a) { return builderExpression(a.preset || {}, a.mode || 'in'); };

    return T;
})();
