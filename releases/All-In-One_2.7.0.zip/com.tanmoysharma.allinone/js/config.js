/* All In One — build-time settings. Fill the links to turn on the Community buttons/popup. */
window.MK = window.MK || {};
window.MK.config = {
    links: {
        whatsappCommunity: '',   // e.g. https://chat.whatsapp.com/xxxxxxxx
        whatsappChannel: '',     // e.g. https://whatsapp.com/channel/xxxxxxxx
        facebook: ''             // e.g. https://www.facebook.com/tanmoysharma
    },
    bootTimeoutMs: 30000,
    // auto update: the panel reads this file and installs newer versions it lists
    updateManifest: 'https://raw.githubusercontent.com/tanmoy108/all-in-one-updates/main/latest.json'
};
