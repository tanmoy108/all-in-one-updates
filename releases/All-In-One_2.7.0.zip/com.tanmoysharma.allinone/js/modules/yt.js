/* All In One — Media ▸ YouTube downloader (yt-dlp + ffmpeg, runs in the panel's Node)
   MP4 or MP3, optional part (start → end), then optional import into AE. */
(function (w) {
    'use strict';
    var MK = w.MK;
    var BN = '০১২৩৪৫৬৭৮৯';
    var st = { info: null, infoUrl: '', proc: null, cancelled: false, last: '' };

    /* ---------- time helpers ---------- */
    function ascii(s) { return String(s || '').replace(/[০-৯]/g, function (d) { return String(BN.indexOf(d)); }).replace(/[：]/g, ':').trim(); }
    // "83", "1:23", "01:02:03", "1:23.5" -> seconds, NaN if invalid, '' -> null
    function parseTime(s) {
        s = ascii(s);
        if (!s) { return null; }
        if (!/^\d+(:\d{1,2}){0,2}(\.\d+)?$/.test(s)) { return NaN; }
        var p = s.split(':'), t = 0;
        for (var i = 0; i < p.length; i++) { t = t * 60 + parseFloat(p[i]); }
        return t;
    }
    function fmtTime(t) {
        t = Math.max(0, Math.round(t || 0));
        var h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
        var pad = function (n) { return (n < 10 ? '0' : '') + n; };
        return h ? h + ':' + pad(m) + ':' + pad(s) : m + ':' + pad(s);
    }
    function tag(t) { return fmtTime(t).replace(/:/g, '.'); }

    /* ---------- yt-dlp binary ---------- */
    var Y = {
        exe: function () { return MK.isWin ? 'yt-dlp.exe' : 'yt-dlp'; },
        path: function () { return MK.paths.join(MK.paths.data, 'bin', Y.exe()); },
        url: function () {
            return 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/' + (MK.isWin ? 'yt-dlp.exe' : 'yt-dlp_macos');
        },
        ok: function () { return MK.fs.exists(Y.path()); },
        status: function () {
            MK.$('#ytStatus').textContent = 'yt-dlp: ' + (Y.ok() ? '✓' : MK.t('yt.notYet')) + ' · ffmpeg: ' + (MK.ffmpeg && MK.ffmpeg.find() ? '✓' : MK.t('yt.notYet'));
        },
        download: function () {
            var bar = MK.$('#ytProgress'), fs = MK.require('fs');
            var dest = Y.path(), tmp = dest + '.part';
            MK.fs.mkdirp(MK.require('path').dirname(dest));
            MK.progress(bar, 0, MK.t('yt.getTool', { p: 0 }));
            return MK.http.download(Y.url(), tmp, function (f) { MK.progress(bar, f, MK.t('yt.getTool', { p: Math.round(f * 100) })); })
                .then(function () {
                    if (fs.statSync(tmp).size < 500000) { throw new Error('yt-dlp download failed'); }
                    try { fs.unlinkSync(dest); } catch (e) {}
                    fs.renameSync(tmp, dest);
                    if (!MK.isWin) {
                        fs.chmodSync(dest, 493);
                        try { MK.require('child_process').execFileSync('/usr/bin/xattr', ['-d', 'com.apple.quarantine', dest]); } catch (e2) {}
                    }
                    Y.status();
                });
        },
        ensure: function () { return Y.ok() ? Promise.resolve() : Y.download(); }
    };

    function ensureFF() {
        if (MK.ffmpeg.find()) { return Promise.resolve(MK.ffmpeg.find()); }
        return MK.modal({ title: 'ffmpeg', html: '<p>' + MK.esc(MK.t('yt.needFF')) + '</p>', okText: MK.t('x.ffDownload') }).then(function (r) {
            if (!r) { throw new Error(MK.t('yt.needFF')); }
            return MK.ffmpeg.download(null, MK.$('#ytProgress')).then(function () {
                var p = MK.ffmpeg.find();
                if (!p) { throw new Error(MK.t('x.ffNeeded')); }
                Y.status();
                return p;
            });
        });
    }

    /* ---------- process runner ---------- */
    function spawn(args, onLine) {
        var cp = MK.require('child_process');
        var env = Object.assign({}, (typeof process !== 'undefined' && process.env) ? process.env : MK.require('process').env, { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' });
        var p = cp.spawn(Y.path(), args, { windowsHide: true, env: env });
        st.proc = p;
        var out = '', err = '', bufO = '', bufE = '';
        var feed = function (chunk, which) {
            var s = chunk.toString('utf8');
            if (which === 'o') { out += s; bufO += s; } else { err = (err + s).slice(-6000); bufE += s; }
            var buf = which === 'o' ? bufO : bufE;
            var lines = buf.split(/\r\n|\r|\n/);
            var rest = lines.pop();
            if (which === 'o') { bufO = rest; } else { bufE = rest; }
            if (onLine) { lines.forEach(function (l) { if (l) { onLine(l, which); } }); }
        };
        var promise = new Promise(function (resolve, reject) {
            p.stdout.on('data', function (d) { feed(d, 'o'); });
            p.stderr.on('data', function (d) { feed(d, 'e'); });
            p.on('error', reject);
            p.on('close', function (code) {
                st.proc = null;
                if (onLine) { if (bufO) { onLine(bufO, 'o'); } if (bufE) { onLine(bufE, 'e'); } }
                if (st.cancelled) { return reject(new Error(MK.t('yt.cancelled'))); }
                if (code === 0) { return resolve(out); }
                var e = err.split(/\r?\n/).filter(function (l) { return /ERROR/.test(l); }).pop() || err.split(/\r?\n/).filter(Boolean).pop() || ('exit ' + code);
                reject(new Error(friendly(e)));
            });
        });
        return promise;
    }
    function friendly(e) {
        e = String(e).replace(/^ERROR:\s*/, '').replace(/^\[\w+\]\s*[\w-]+:\s*/, '');
        if (/Sign in to confirm|age/i.test(e)) { return MK.t('yt.e.age') + ' (' + e + ')'; }
        if (/Private video|unavailable/i.test(e)) { return MK.t('yt.e.unavail'); }
        if (/HTTP Error 403|Requested format is not available|nsig|Signature/i.test(e)) { return MK.t('yt.e.update') + ' (' + e + ')'; }
        if (/getaddrinfo|Unable to download webpage|timed out/i.test(e)) { return MK.t('yt.e.net'); }
        return 'yt-dlp: ' + e;
    }
    function killTree() {
        var p = st.proc;
        if (!p) { return; }
        st.cancelled = true;
        try {
            if (MK.isWin) { MK.require('child_process').execFile('taskkill', ['/pid', String(p.pid), '/T', '/F'], { windowsHide: true }, function () {}); }
            else { p.kill('SIGTERM'); }
        } catch (e) {}
    }

    /* ---------- UI helpers ---------- */
    function val(id) { return MK.$('#' + id).value; }
    function fmt() { return MK.segValue(MK.$('#ytFmt'), 'data-v') || 'mp4'; }
    function outDir() { return MK.settings.ytDir || MK.paths.join(MK.paths.data, 'YouTube'); }
    function save() {
        MK.settings.yt = { fmt: fmt(), q: val('ytQuality'), kb: val('ytKbps'), exact: MK.$('#ytExact').checked, imp: MK.$('#ytImport').checked, add: MK.$('#ytAdd').checked, h264: MK.$('#ytH264').checked };
        MK.saveSettings();
    }
    function showFmt() {
        var f = fmt();
        MK.$('#ytQualityRow').classList.toggle('hidden', f !== 'mp4');
        MK.$('#ytKbpsRow').classList.toggle('hidden', f !== 'mp3');
        MK.$('#ytH264Lbl').classList.toggle('hidden', f !== 'mp4');
        MK.$('#ytGo span').textContent = MK.t(f === 'mp3' ? 'yt.goMp3' : 'yt.goMp4');
    }
    function partOn() { return MK.$('#ytPart').checked; }
    function showPart() {
        MK.$('#ytPartBox').classList.toggle('hidden', !partOn());
        syncRanges();
    }
    function duration() { return st.info && st.info.duration ? st.info.duration : 0; }
    function syncRanges() {
        var d = duration(), a = MK.$('#ytRangeA'), b = MK.$('#ytRangeB');
        [a, b].forEach(function (r) { r.disabled = !d; r.max = d || 100; });
        var s = parseTime(val('ytStart')), e = parseTime(val('ytEnd'));
        if (d) { a.value = isFinite(s) && s !== null ? s : 0; b.value = isFinite(e) && e !== null ? e : d; }
        var len = (isFinite(e) && e !== null ? e : d) - (isFinite(s) && s !== null ? s : 0);
        MK.$('#ytPartLen').textContent = len > 0 && (d || (e !== null && isFinite(e))) ? MK.t('yt.partLen', { t: fmtTime(len) }) : '';
    }
    function videoId(url) {
        var m = /(?:v=|youtu\.be\/|shorts\/|embed\/|live\/)([\w-]{11})/.exec(url || '');
        return m ? m[1] : '';
    }

    /* ---------- info ---------- */
    function fetchInfo(btn) {
        var url = val('ytUrl').trim();
        if (!/^https?:\/\//i.test(url)) { MK.toast(MK.t('yt.badUrl'), 'warn'); return Promise.resolve(); }
        return MK.busy(btn, function () {
            return Y.ensure().then(function () {
                MK.progress(MK.$('#ytProgress'), null, MK.t('yt.reading'));
                st.cancelled = false;
                return spawn(['-J', '--no-playlist', '--no-warnings', '--encoding', 'utf-8', url]);
            }).then(function (out) {
                MK.progressHide(MK.$('#ytProgress'));
                var j = JSON.parse(out);
                st.info = { id: j.id, title: j.title || '', duration: j.duration || 0, uploader: j.uploader || j.channel || '', thumb: j.thumbnail || '', live: !!j.is_live };
                st.infoUrl = url;
                renderInfo();
                syncRanges();
            }, function (e) { MK.progressHide(MK.$('#ytProgress')); throw e; });
        });
    }
    function renderInfo() {
        var box = MK.$('#ytInfo'), i = st.info;
        if (!i) { box.classList.add('hidden'); return; }
        box.classList.remove('hidden');
        MK.$('#ytThumb').style.backgroundImage = i.thumb ? 'url("' + i.thumb.replace(/"/g, '%22') + '")' : '';
        MK.$('#ytThumb').dataset.dur = i.duration ? fmtTime(i.duration) : '';
        MK.$('#ytTitle').textContent = i.title;
        MK.$('#ytMeta').textContent = i.uploader;
    }

    /* ---------- download ---------- */
    function buildArgs(o) {
        var a = ['--no-playlist', '--newline', '--progress', '--no-warnings', '--encoding', 'utf-8', '--windows-filenames', '--no-mtime', '--force-overwrites',
            '--ffmpeg-location', o.ff, '-o', o.tpl, '--print', 'after_move:filepath',
            '--progress-template', 'download:AIOP %(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s'];
        if (o.fmt === 'mp3') {
            a.push('-f', 'ba/b', '-x', '--audio-format', 'mp3', '--audio-quality', (o.kbps || 320) + 'K');
        } else {
            a.push('-f', formatSel(o),
                '--merge-output-format', 'mp4', '--remux-video', 'mp4');
        }
        if (o.part) { a.push('--download-sections', '*' + o.start + '-' + o.end); }
        a.push(o.url);
        return a;
    }

    function formatSel(o) {
        if (o.fmt === 'mp3') { return 'ba/b'; }
        var H = o.height || 1080;
        return 'bv*[height<=' + H + '][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=' + H + ']+ba/b[height<=' + H + ']/bv*+ba/b';
    }
    function safeName(t) {
        return String(t || 'video').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 70).replace(/[. ]+$/, '') || 'video';
    }

    // frame-accurate part: ask yt-dlp for the stream URLs, then ffmpeg seeks + re-encodes only that range
    function exactCut(o, bar, dir, suffix) {
        var path = MK.require('path');
        MK.progress(bar, null, MK.t('yt.reading'));
        return spawn(['-j', '--no-playlist', '--no-warnings', '--encoding', 'utf-8', '-f', formatSel(o), o.url]).then(function (out) {
            var j = JSON.parse(out);
            var fmts = (j.requested_formats && j.requested_formats.length) ? j.requested_formats : [j];
            var len = o.end - o.start;
            var file = path.join(dir, safeName(j.title) + ' [' + j.id + ']' + suffix + (o.fmt === 'mp3' ? '.mp3' : '.mp4'));
            var args = ['-y', '-hide_banner', '-nostdin'];
            var vIn = -1, aIn = -1;
            fmts.forEach(function (f, i) {
                var h = f.http_headers || j.http_headers || {};
                var hs = Object.keys(h).map(function (k) { return k + ': ' + h[k] + '\r\n'; }).join('');
                if (hs) { args.push('-headers', hs); }
                args.push('-ss', String(o.start), '-i', f.url);
                var hasV = f.vcodec && f.vcodec !== 'none', hasA = f.acodec && f.acodec !== 'none';
                if (fmts.length === 1) { hasV = hasV !== false; hasA = true; }
                if (hasV && vIn < 0) { vIn = i; }
                if (hasA && aIn < 0) { aIn = i; }
            });
            args.push('-t', String(len));
            if (o.fmt === 'mp3') {
                args.push('-map', (aIn < 0 ? 0 : aIn) + ':a:0', '-vn', '-c:a', 'libmp3lame', '-b:a', (o.kbps || 320) + 'k');
            } else {
                args.push('-map', (vIn < 0 ? 0 : vIn) + ':v:0', '-map', (aIn < 0 ? 0 : aIn) + ':a:0?',
                    '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-preset', 'veryfast', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart');
            }
            args.push(file);
            MK.progress(bar, 0, MK.t('yt.cutting', { p: 0 }));
            return runFF(args, len, function (f) { MK.progress(bar, f, MK.t('yt.cutting', { p: Math.round(f * 100) })); }).then(function () { return file; });
        });
    }
    function runFF(args, dur, onP) {
        return new Promise(function (resolve, reject) {
            var p = MK.require('child_process').spawn(MK.ffmpeg.find(), args, { windowsHide: true });
            st.proc = p;
            var tail = '';
            p.stderr.on('data', function (d) {
                var s = d.toString(); tail = (tail + s).slice(-1500);
                var m = /time=(\d+):(\d+):([\d.]+)/.exec(s);
                if (m && dur) { onP(Math.min(1, ((+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3])) / dur)); }
            });
            p.on('error', reject);
            p.on('close', function (code) {
                st.proc = null;
                if (st.cancelled) { return reject(new Error(MK.t('yt.cancelled'))); }
                if (code === 0) { resolve(); } else { reject(new Error('ffmpeg: ' + tail.split(/\r?\n/).filter(Boolean).slice(-2).join(' '))); }
            });
        });
    }

    function probeCodec(file) {
        return new Promise(function (resolve) {
            var p = MK.require('child_process').spawn(MK.ffmpeg.find(), ['-hide_banner', '-i', file], { windowsHide: true });
            var err = '';
            p.stderr.on('data', function (d) { err += d.toString(); });
            p.on('error', function () { resolve({}); });
            p.on('close', function () {
                var v = /Video:\s*(\w+)/.exec(err), d = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec(err);
                resolve({ video: v ? v[1] : '', dur: d ? (+d[1]) * 3600 + (+d[2]) * 60 + parseFloat(d[3]) : 0 });
            });
        });
    }

    // YouTube 4K and some videos are VP9/AV1 — AE can't import those, so convert to H.264
    function makeAEReady(file, bar) {
        return probeCodec(file).then(function (c) {
            if (!c.video || /^h264$/i.test(c.video)) { return file; }
            var fs = MK.require('fs');
            var tmp = file.replace(/\.mp4$/i, '') + '.h264.tmp.mp4';
            MK.progress(bar, 0, MK.t('yt.converting', { p: 0 }));
            return MK.ffmpeg.run(['-y', '-i', file, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-preset', 'veryfast', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', tmp],
                c.dur, function (f) { MK.progress(bar, f, MK.t('yt.converting', { p: Math.round(f * 100) })); })
                .then(function () { fs.unlinkSync(file); fs.renameSync(tmp, file); return file; });
        });
    }

    function findOutput(dir, id, since) {
        var fs = MK.require('fs'), path = MK.require('path'), best = '', bt = 0;
        MK.fs.list(dir).forEach(function (f) {
            if (id && f.indexOf('[' + id + ']') < 0) { return; }
            if (/\.(part|ytdl|tmp)$|\.f\d+\./i.test(f)) { return; }
            var full = path.join(dir, f), t = 0;
            try { t = fs.statSync(full).mtimeMs; } catch (e) { return; }
            if (t >= since - 2000 && t > bt) { bt = t; best = full; }
        });
        return best;
    }

    function download(btn) {
        var url = val('ytUrl').trim();
        if (!/^https?:\/\//i.test(url)) { MK.toast(MK.t('yt.badUrl'), 'warn'); return; }
        var o = { url: url, fmt: fmt(), height: +val('ytQuality') || 1080, kbps: +val('ytKbps') || 320, part: partOn(), exact: MK.$('#ytExact').checked };
        if (o.part) {
            var s = parseTime(val('ytStart')), e = parseTime(val('ytEnd'));
            if (s === null) { s = 0; }
            if (e === null && duration()) { e = duration(); }
            if (!isFinite(s) || !isFinite(e) || e === null) { MK.toast(MK.t('yt.badTime'), 'warn'); return; }
            if (duration()) { e = Math.min(e, duration()); }
            if (e <= s) { MK.toast(MK.t('yt.badRange'), 'warn'); return; }
            o.start = s; o.end = e;
        }
        save();
        var bar = MK.$('#ytProgress'), started = Date.now(), dir = outDir();
        var id = (st.info && st.infoUrl === url && st.info.id) || videoId(url);
        var suffix = o.part ? ' (' + tag(o.start) + '-' + tag(o.end) + ')' : '';
        var path = MK.require('path');
        MK.fs.mkdirp(dir);
        o.tpl = path.join(dir, '%(title).70B [%(id)s]' + suffix + '.%(ext)s');
        MK.$('#ytCancel').classList.remove('hidden');
        st.cancelled = false;
        var printed = '', phase = 0, lastPct = -1;
        return MK.busy(btn, function () {
            return Y.ensure().then(ensureFF).then(function (ff) {
                o.ff = ff;
                if (o.part && o.exact) { return exactCut(o, bar, dir, suffix).then(function (f) { printed = f; }); }
                MK.progress(bar, null, MK.t('yt.starting'));
                return spawn(buildArgs(o), function (line, which) {
                    var m = /^AIOP\s+([\d.]+)%\|([^|]*)\|(.*)$/.exec(line.trim());
                    if (m) {
                        var pct = parseFloat(m[1]);
                        if (pct < lastPct - 30) { phase++; }
                        lastPct = pct;
                        var what = o.fmt === 'mp4' ? MK.t(phase ? 'yt.audio' : 'yt.video') : MK.t('yt.audio');
                        MK.progress(bar, pct / 100, what + ' ' + Math.round(pct) + '% · ' + m[2].trim() + ' · ' + m[3].trim());
                        return;
                    }
                    var t = /time=(\d+):(\d+):([\d.]+)/.exec(line);
                    if (t && o.part) {
                        var sec = (+t[1]) * 3600 + (+t[2]) * 60 + parseFloat(t[3]);
                        var f = Math.min(1, sec / (o.end - o.start));
                        MK.progress(bar, f, MK.t('yt.cutting', { p: Math.round(f * 100) }));
                        return;
                    }
                    if (/^\[(ExtractAudio|Merger|VideoConvertor|FixupM3u8)\]/.test(line)) { MK.progress(bar, null, MK.t('yt.finishing')); return; }
                    if (which === 'o' && /\.(mp4|mp3|m4a|webm|mkv)$/i.test(line.trim())) { printed = line.trim(); }
                });
            }).then(function () {
                var file = printed && MK.fs.exists(printed) ? printed : findOutput(dir, id, started);
                if (!file) { throw new Error(MK.t('yt.noFile')); }
                if (o.fmt === 'mp4' && MK.$('#ytH264').checked) { return makeAEReady(file, bar); }
                return file;
            }).then(function (file) {
                st.last = file;
                MK.$('#ytLastName').textContent = path.basename(file);
                MK.$('#ytLast').classList.remove('hidden');
                MK.progress(bar, 1, MK.t('yt.done'));
                if (MK.$('#ytImport').checked) {
                    return MK.host('broll.importFile', { path: file, addToComp: MK.$('#ytAdd').checked, fit: 'fit', bin: 'YouTube', duration: 3 })
                        .then(function (r) { MK.toast(MK.t(r && r.placed ? 'yt.okPlaced' : 'yt.okImported')); });
                }
                MK.toast(MK.t('yt.okSaved'));
            });
        }).then(function () {
            MK.$('#ytCancel').classList.add('hidden');
            setTimeout(function () { MK.progressHide(bar); }, 2500);
        });
    }

    MK.initYT = function () {
        var s = MK.settings.yt || {};
        MK.$$('#ytFmt button').forEach(function (b) { b.classList.toggle('active', b.dataset.v === (s.fmt || 'mp4')); });
        if (s.q) { MK.$('#ytQuality').value = s.q; }
        if (s.kb) { MK.$('#ytKbps').value = s.kb; }
        if (s.exact !== undefined) { MK.$('#ytExact').checked = s.exact; }
        if (s.imp !== undefined) { MK.$('#ytImport').checked = s.imp; }
        if (s.add !== undefined) { MK.$('#ytAdd').checked = s.add; }
        if (s.h264 !== undefined) { MK.$('#ytH264').checked = s.h264; }
        MK.seg(MK.$('#ytFmt'), function () { showFmt(); save(); });
        ['ytQuality', 'ytKbps', 'ytExact', 'ytImport', 'ytAdd', 'ytH264'].forEach(function (id) { MK.$('#' + id).addEventListener('change', save); });
        MK.$('#ytPart').addEventListener('change', showPart);
        MK.$('#ytStart').addEventListener('input', syncRanges);
        MK.$('#ytEnd').addEventListener('input', syncRanges);
        MK.$('#ytRangeA').addEventListener('input', function () {
            var b = +MK.$('#ytRangeB').value; if (+this.value > b) { this.value = b; }
            MK.$('#ytStart').value = fmtTime(+this.value); syncRanges();
        });
        MK.$('#ytRangeB').addEventListener('input', function () {
            var a = +MK.$('#ytRangeA').value; if (+this.value < a) { this.value = a; }
            MK.$('#ytEnd').value = fmtTime(+this.value); syncRanges();
        });
        MK.$('#ytPaste').onclick = function () {
            var p = (navigator.clipboard && navigator.clipboard.readText) ? navigator.clipboard.readText() : Promise.reject();
            p.catch(function () {
                try { return MK.require('child_process').execSync(MK.isWin ? 'powershell -NoProfile -Command Get-Clipboard' : 'pbpaste', { encoding: 'utf8', windowsHide: true, timeout: 4000 }); } catch (e) { return ''; }
            }).then(function (t) {
                t = String(t || '').trim();
                if (t) { MK.$('#ytUrl').value = t; MK.$('#ytUrl').dispatchEvent(new Event('change')); }
            });
        };
        MK.$('#ytUrl').addEventListener('change', function () {
            if (this.value.trim() !== st.infoUrl) { st.info = null; renderInfo(); syncRanges(); }
            if (/^https?:\/\//i.test(this.value.trim())) { fetchInfo(MK.$('#ytInfoBtn')); }
        });
        MK.$('#ytInfoBtn').onclick = function () { fetchInfo(this); };
        MK.$('#ytGo').onclick = function () { download(this); };
        MK.$('#ytCancel').onclick = killTree;
        MK.$('#ytCheck').onclick = function () {
            var u = val('ytUrl').trim(), id = (st.info && st.info.id) || videoId(u);
            var t = Math.floor(parseTime(val('ytStart')) || 0);
            if (id) { MK.openURL('https://www.youtube.com/watch?v=' + id + (t ? '&t=' + t + 's' : '')); } else if (u) { MK.openURL(u); }
        };
        MK.$('#ytFolder').onclick = function () { MK.fs.mkdirp(outDir()); MK.host('app.openFolder', { path: outDir() }).catch(MK.fail); };
        MK.$('#ytPickDir').onclick = function () {
            MK.host('app.chooseFolder', { title: MK.t('yt.saveTo') }).then(function (p) {
                if (!p) { return; }
                MK.settings.ytDir = p; MK.saveSettings(); MK.$('#ytDir').textContent = p;
            }).catch(MK.fail);
        };
        MK.$('#ytDir').textContent = outDir();
        MK.$('#ytUpdate').onclick = function () {
            var b = this;
            MK.busy(b, function () { return Y.download().then(function () { MK.progressHide(MK.$('#ytProgress')); MK.toast(MK.t('yt.updated')); }); });
        };
        MK.$('#ytLastImport').onclick = function () {
            if (st.last) { MK.run(this, 'broll.importFile', { path: st.last, addToComp: true, fit: 'fit', bin: 'YouTube', duration: 3 }, MK.t('yt.okPlaced')); }
        };
        showFmt(); showPart();
        MK.onLang = MK.onLang || [];
        MK.onLang.push(function () { showFmt(); syncRanges(); Y.status(); });
        MK.$$('#mediaSub button').forEach(function (b) { b.addEventListener('click', function () { if (b.dataset.sub === 'yt') { Y.status(); } }); });
    };

    MK._yt = { parseTime: parseTime, fmtTime: fmtTime, buildArgs: buildArgs, videoId: videoId, Y: Y, exactCut: exactCut, safeName: safeName, st: st };
})(window);
