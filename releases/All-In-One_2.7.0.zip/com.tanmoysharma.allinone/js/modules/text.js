/* All In One — Text Animation: Builder (original rig) + .ffx preset library */
(function (w) {
    'use strict';
    var MK = w.MK;

    /* ======================= BUILDER ======================= */
    var BASE = { mode: 'in', based: 'chars', direction: 'none', distance: 0, scale: 100, rotation: 0, opacity: 100, blur: 0,
        delay: 0.04, duration: 0.6, easing: 'smooth', order: 'forward', overshoot: 1, freq: 2, decay: 6 };

    function P(o) { var r = {}; for (var k in BASE) { r[k] = BASE[k]; } for (var j in o) { r[j] = o[j]; } return r; }

    var BUILT_IN = [
        P({ name: 'Rise', direction: 'up', distance: 70, opacity: 0, delay: 0.035, duration: 0.6 }),
        P({ name: 'Drop', direction: 'down', distance: 90, opacity: 0, easing: 'back', delay: 0.04, duration: 0.55 }),
        P({ name: 'Slide Left', direction: 'left', distance: 120, opacity: 0, delay: 0.03, duration: 0.5 }),
        P({ name: 'Slide Right', direction: 'right', distance: 120, opacity: 0, delay: 0.03, duration: 0.5 }),
        P({ name: 'Pop', scale: 0, easing: 'elastic', delay: 0.04, freq: 2.2, decay: 7 }),
        P({ name: 'Spin Pop', scale: 0, rotation: -90, easing: 'back', overshoot: 1.6, delay: 0.035, duration: 0.55 }),
        P({ name: 'Blur In', scale: 125, opacity: 0, blur: 30, delay: 0.025, duration: 0.7 }),
        P({ name: 'Typewriter', opacity: 0, easing: 'linear', delay: 0.06, duration: 0.01 }),
        P({ name: 'Word Rise', based: 'words', direction: 'up', distance: 60, opacity: 0, easing: 'back', delay: 0.09, duration: 0.55 }),
        P({ name: 'Line Slide', based: 'lines', direction: 'left', distance: 220, opacity: 0, delay: 0.15, duration: 0.7 }),
        P({ name: 'Elastic Drop', direction: 'down', distance: 160, easing: 'elastic', delay: 0.045, freq: 1.8, decay: 5.5 }),
        P({ name: 'Flicker', opacity: 0, easing: 'linear', order: 'random', delay: 0.025, duration: 0.05 }),
        P({ name: 'Center Out', scale: 0, easing: 'back', order: 'center', delay: 0.05, duration: 0.5 }),
        P({ name: 'Bounce In', direction: 'down', distance: 120, easing: 'bounce', delay: 0.04, duration: 0.8 }),
        P({ name: 'Zoom Words', based: 'words', scale: 300, opacity: 0, blur: 20, delay: 0.08, duration: 0.5 }),
        P({ name: 'Fade Out Up', mode: 'out', direction: 'up', distance: 50, opacity: 0, delay: 0.03, duration: 0.45 })
    ];

    var FIELDS = ['mode', 'based', 'direction', 'distance', 'scale', 'rotation', 'opacity', 'blur', 'delay', 'duration', 'easing', 'order', 'overshoot', 'freq', 'decay'];
    var NUMERIC = { distance: 1, scale: 1, rotation: 1, opacity: 1, blur: 1, delay: 1, duration: 1, overshoot: 1, freq: 1, decay: 1 };
    var current = P({ name: 'Rise', direction: 'up', distance: 70, opacity: 0 });

    function userPresets() { return MK.hasNode ? MK.fs.readJSON(MK.paths.builder, []) : []; }
    function saveUserPresets(l) { if (MK.hasNode) { MK.fs.writeJSON(MK.paths.builder, l); } }

    function readForm() {
        FIELDS.forEach(function (f) {
            var el = MK.$('#tb-' + f);
            current[f] = NUMERIC[f] ? (parseFloat(el.value) || 0) : el.value;
        });
        if (!current.duration) { current.duration = 0.01; }
        return current;
    }
    function writeForm(p) {
        FIELDS.forEach(function (f) { var el = MK.$('#tb-' + f); if (el && p[f] !== undefined) { el.value = p[f]; } });
        showEaseOpts();
    }
    function showEaseOpts() {
        var e = MK.$('#tb-easing').value;
        MK.$$('#sub-builder .ease-opt').forEach(function (l) { l.classList.toggle('show', l.dataset.for === e); });
    }

    /* --- same maths as the AE expression, for the live HTML preview --- */
    function pseudoRand(i, n) { var x = Math.sin((i + 1) * 12.9898) * 43758.5453; return Math.floor((x - Math.floor(x)) * n); }

    function unitIndex(p, i, n) {
        if (p.order === 'reverse') { return n - 1 - i; }
        if (p.order === 'center') { return Math.abs(i - (n - 1) / 2); }
        if (p.order === 'edges') { return (n - 1) / 2 - Math.abs(i - (n - 1) / 2); }
        if (p.order === 'random') { return pseudoRand(i, n); }
        return i;
    }

    function easeOut(p, x) {
        if (p.easing === 'linear') { return x; }
        if (p.easing === 'back') { var s = 1.70158 * p.overshoot, y = x - 1; return 1 + (s + 1) * y * y * y + s * y * y; }
        if (p.easing === 'bounce') {
            var b = x;
            if (b < 1 / 2.75) { return 7.5625 * b * b; }
            if (b < 2 / 2.75) { b -= 1.5 / 2.75; return 7.5625 * b * b + 0.75; }
            if (b < 2.5 / 2.75) { b -= 2.25 / 2.75; return 7.5625 * b * b + 0.9375; }
            b -= 2.625 / 2.75; return 7.5625 * b * b + 0.984375;
        }
        return 1 - Math.pow(1 - x, 4);
    }

    MK.builderAmount = function (p, mode, i, n, time, inP, outP) {
        var idx = unitIndex(p, i, n), d = p.delay, dur = Math.max(0.01, p.duration);
        var span = dur + Math.max(0, n - 1) * d;
        if (mode === 'in') {
            var t = time - inP - idx * d;
            if (t <= 0) { return 100; }
            if (p.easing === 'elastic') { return 100 * Math.exp(-p.decay * t) * Math.cos(2 * Math.PI * p.freq * t); }
            return 100 * (1 - easeOut(p, Math.min(1, t / dur)));
        }
        var to = time - (outP - span) - idx * d;
        var x = Math.max(0, Math.min(1, to / dur));
        if (p.easing === 'linear') { return 100 * x; }
        if (p.easing === 'back') { var s = 1.70158 * p.overshoot; return 100 * x * x * ((s + 1) * x - s); }
        return 100 * x * x * x * x;
    };

    function splitUnits(text, based) {
        var units = [];
        if (based === 'words') {
            text.split(/(\s+)/).forEach(function (s) { if (s) { units.push({ t: s, space: /^\s+$/.test(s) }); } });
        } else if (based === 'lines') {
            text.split(/(\n)/).forEach(function (s) { if (s) { units.push({ t: s, space: s === '\n' }); } });
        } else {
            Array.from(text).forEach(function (ch) { units.push({ t: ch, space: /\s/.test(ch) }); });
        }
        return units;
    }

    function buildSpans(el, text, p) {
        el.innerHTML = '';
        var units = splitUnits(text, p.based);
        var spans = [], idx = 0;
        units.forEach(function (u) {
            if (u.t === '\n') { el.appendChild(document.createElement('br')); return; }
            var s = document.createElement('span');
            s.textContent = u.t;
            el.appendChild(s);
            var counts = !(u.space && (p.based === 'words' || p.based === 'charsNoSpace'));
            if (counts) { spans.push({ el: s, i: idx++ }); } else { spans.push({ el: s, i: -1 }); }
        });
        return { spans: spans, n: idx };
    }

    function styleSpan(s, p, k, scale) {
        var a = k / 100, dx = 0, dy = 0, dist = p.distance * scale;
        var dir = p.direction;
        if (dir === 'up') { dy = dist; } else if (dir === 'down') { dy = -dist; } else if (dir === 'left') { dx = dist; } else if (dir === 'right') { dx = -dist; }
        if (p._out) { dx = -dx; dy = -dy; }
        var sc = 1 + (p.scale / 100 - 1) * a;
        var rot = (p._out ? -p.rotation : p.rotation) * a;
        var op = Math.max(0, Math.min(1, 1 + (p.opacity / 100 - 1) * a));
        var bl = Math.max(0, p.blur * a * scale * 0.5);
        s.style.transform = 'translate(' + (dx * a).toFixed(2) + 'px,' + (dy * a).toFixed(2) + 'px) rotate(' + rot.toFixed(2) + 'deg) scale(' + Math.max(0, sc).toFixed(3) + ')';
        s.style.opacity = op.toFixed(3);
        s.style.filter = bl > 0.05 ? 'blur(' + bl.toFixed(1) + 'px)' : '';
    }

    // a looping preview player bound to one element
    function Player(el, getText, getP, scale) {
        this.el = el; this.getText = getText; this.getP = getP; this.scale = scale; this.t0 = 0; this.on = false; this.built = null;
    }
    Player.prototype.rebuild = function () { var p = this.getP(); this.built = buildSpans(this.el, this.getText(), p); this.t0 = performance.now(); };
    Player.prototype.frame = function (now) {
        if (!this.built) { this.rebuild(); }
        var p = this.getP(), n = Math.max(1, this.built.n);
        var span = Math.max(0.01, p.duration) + (n - 1) * p.delay;
        var inP = 0.25;
        var hasIn = p.mode !== 'out', hasOut = p.mode !== 'in';
        var settle = p.easing === 'elastic' ? Math.min(1.6, 5 / Math.max(0.5, p.decay)) : 0;
        var outP = inP + (hasIn ? span + settle : 0) + 0.8 + (hasOut ? span : 0);
        var total = hasOut ? outP + 0.5 : inP + span + settle + 1.0;
        var t = ((now - this.t0) / 1000) % total;
        var self = this, pOut = Object.assign({}, p, { _out: true });
        this.built.spans.forEach(function (s) {
            if (s.i < 0) { return; }
            var k = 0, po = p;
            if (hasIn) { k = MK.builderAmount(p, 'in', s.i, n, t, inP, outP); }
            if (hasOut) {
                var ko = MK.builderAmount(p, 'out', s.i, n, t, inP, outP);
                if (ko > 0.001) { k = ko; po = pOut; }
            }
            styleSpan(s.el, po, k, self.scale);
        });
    };

    var mainPlayer = null, hoverPlayers = [];
    function loop(now) {
        if (MK.tabs.current === 'text') {
            if (mainPlayer) { mainPlayer.frame(now); }
            hoverPlayers.forEach(function (hp) { if (hp.on) { hp.frame(now); } });
        }
        w.requestAnimationFrame(loop);
    }

    function renderPresetStrip() {
        var box = MK.$('#tbPresets');
        box.innerHTML = '';
        hoverPlayers = [];
        var list = BUILT_IN.map(function (p) { return { p: p, user: false }; })
            .concat(userPresets().map(function (p, i) { return { p: P(p), user: true, idx: i }; }));
        list.forEach(function (it) {
            var card = document.createElement('div');
            card.className = 'pcard' + (it.p.name === current.name ? ' active' : '');
            card.innerHTML = '<div class="mini-stage"></div><span class="pname">' + (it.user ? '★ ' : '') + MK.esc(it.p.name) + '</span>' + (it.user ? '<span class="del" title="Delete">✕</span>' : '');
            var stage = card.querySelector('.mini-stage');
            var hp = new Player(stage, function () { return 'Text'; }, function () { return it.p; }, 0.18);
            hp.rebuild();
            hp.built.spans.forEach(function (s) { s.el.style.transform = ''; });
            card.addEventListener('mouseenter', function () { hp.rebuild(); hp.on = true; });
            card.addEventListener('mouseleave', function () { hp.on = false; hp.rebuild(); });
            card.addEventListener('click', function (e) {
                if (e.target.classList.contains('del')) {
                    var l = userPresets(); l.splice(it.idx, 1); saveUserPresets(l); renderPresetStrip(); return;
                }
                current = P(it.p);
                writeForm(current);
                MK.$$('#tbPresets .pcard').forEach(function (c) { c.classList.remove('active'); });
                card.classList.add('active');
                mainPlayer.rebuild();
            });
            hoverPlayers.push(hp);
            box.appendChild(card);
        });
    }

    /* ======================= LIBRARY ======================= */
    var lib = { items: [], at: 'start' };

    function hash(s) { var h = 5381; for (var i = 0; i < s.length; i++) { h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; } return h.toString(36); }

    function previewDir(item) { return MK.paths.join(MK.paths.previews, hash(item.path)); }

    function previewFrames(item) {
        var dir = previewDir(item);
        return MK.fs.list(dir).filter(function (f) { return /^f\d+\.png$/i.test(f); }).sort().map(function (f) { return MK.paths.join(dir, f); });
    }

    function sidecar(item) {
        var base = item.path.replace(/\.ffx$/i, '');
        var exts = ['.gif', '.png', '.jpg', '.webp', '.mp4'];
        for (var i = 0; i < exts.length; i++) { if (MK.fs.exists(base + exts[i])) { return base + exts[i]; } }
        return '';
    }

    function scan() {
        lib.items = [];
        if (!MK.hasNode) { return; }
        MK.fs.mkdirp(MK.paths.presets);
        var roots = [{ dir: MK.paths.bundledPresets, label: 'All In One' }, { dir: MK.paths.presets, label: 'My presets' }];
        (MK.settings.presetFolders || []).forEach(function (d) { roots.push({ dir: d, label: d.split(/[\\/]/).pop() }); });
        roots.forEach(function (r) {
            if (!r.dir || !MK.fs.isDir(r.dir)) { return; }
            var walk = function (dir, cat, depth) {
                MK.fs.list(dir).forEach(function (f) {
                    var full = MK.paths.join(dir, f);
                    if (MK.fs.isDir(full) && depth < 2) { walk(full, f, depth + 1); }
                    else if (/\.ffx$/i.test(f)) { lib.items.push({ path: full, name: f.replace(/\.ffx$/i, '').replace(/^\d+[_\-\s]+/, ''), cat: cat }); }
                });
            };
            walk(r.dir, r.label, 0);
        });
        lib.items.sort(function (a, b) { return a.cat === b.cat ? a.name.localeCompare(b.name) : a.cat.localeCompare(b.cat); });
        var cats = {};
        lib.items.forEach(function (i) { cats[i.cat] = 1; });
        var sel = MK.$('#libCat'), keep = sel.value;
        sel.innerHTML = '<option value="">All</option>' + Object.keys(cats).map(function (c) { return '<option>' + MK.esc(c) + '</option>'; }).join('');
        sel.value = keep && cats[keep] ? keep : '';
    }

    function favs() { MK.settings.favs = MK.settings.favs || []; return MK.settings.favs; }

    function renderLib() {
        var grid = MK.$('#libGrid');
        grid.innerHTML = '';
        var q = MK.$('#libSearch').value.trim().toLowerCase(), cat = MK.$('#libCat').value, favOnly = MK.$('#libFavOnly').checked;
        var shown = lib.items.filter(function (it) {
            return (!q || it.name.toLowerCase().indexOf(q) >= 0) && (!cat || it.cat === cat) && (!favOnly || favs().indexOf(it.path) >= 0);
        });
        MK.$('#libEmpty').classList.toggle('hidden', lib.items.length > 0);
        shown.forEach(function (it) {
            var card = document.createElement('div');
            card.className = 'lcard';
            var frames = previewFrames(it), side = frames.length ? '' : sidecar(it);
            var isFav = favs().indexOf(it.path) >= 0;
            card.innerHTML = '<div class="thumb">' + (frames.length || side ? '' : MK.esc(it.name.slice(0, 18))) + '</div>' +
                '<div class="meta"><span title="' + MK.esc(it.name) + '">' + MK.esc(it.name) + '</span><b class="fav' + (isFav ? ' on' : '') + '">★</b></div>' +
                '<div class="state">✓</div>';
            var thumb = card.querySelector('.thumb');
            if (frames.length) {
                thumb.style.backgroundImage = 'url("' + MK.fs.fileUrl(frames[frames.length - 1]) + '")';
                var timer = null, fi = 0;
                card.addEventListener('mouseenter', function () {
                    frames.forEach(function (f) { var im = new Image(); im.src = MK.fs.fileUrl(f); });
                    timer = setInterval(function () { thumb.style.backgroundImage = 'url("' + MK.fs.fileUrl(frames[fi++ % frames.length]) + '")'; }, 90);
                });
                card.addEventListener('mouseleave', function () { clearInterval(timer); fi = 0; thumb.style.backgroundImage = 'url("' + MK.fs.fileUrl(frames[frames.length - 1]) + '")'; });
            } else if (side && /\.mp4$/i.test(side)) {
                thumb.innerHTML = '<video src="' + MK.fs.fileUrl(side) + '" muted loop playsinline style="width:100%;height:100%;object-fit:cover"></video>';
                var v = thumb.querySelector('video');
                card.addEventListener('mouseenter', function () { try { v.play(); } catch (e) {} });
                card.addEventListener('mouseleave', function () { v.pause(); });
            } else if (side) {
                thumb.style.backgroundImage = 'url("' + MK.fs.fileUrl(side) + '")';
            }
            card.querySelector('.fav').addEventListener('click', function (e) {
                e.stopPropagation();
                var f = favs(), i = f.indexOf(it.path);
                if (i >= 0) { f.splice(i, 1); } else { f.push(it.path); }
                MK.saveSettings();
                this.classList.toggle('on');
            });
            card.addEventListener('click', function () {
                askPart(it).then(function (part) {
                    if (!part) { return; }
                    card.classList.add('loading');
                    return MK.host('text.applyFFX', { path: it.path, at: lib.at, part: part, text: MK.$('#tbSample').value })
                        .then(function (r) {
                            card.classList.remove('loading'); card.classList.add('done');
                            setTimeout(function () { card.classList.remove('done'); }, 900);
                            if (r.single && part !== 'both') { MK.toast(MK.t('t.single'), 'warn'); return; }
                            MK.toast(r.created ? MK.t('ok.newLayer') : MK.t('ok.applied', { n: r.count }));
                        }, function (e) { card.classList.remove('loading'); MK.fail(e); });
                });
            });
            grid.appendChild(card);
        });
    }

    // IN / OUT / IN+OUT: ask every time unless the user picked a fixed mode
    function askPart(it) {
        var sel = MK.$('#libPart');
        if (sel.value !== 'ask') { return Promise.resolve(sel.value); }
        return MK.choose({
            title: MK.t('t.part.title'),
            sub: it.name,
            options: [
                { value: 'in', label: 'IN', small: MK.t('t.part.inSub') },
                { value: 'out', label: 'OUT', small: MK.t('t.part.outSub') },
                { value: 'both', label: 'IN + OUT', small: MK.t('t.part.bothSub') }
            ],
            remember: MK.t('t.part.remember')
        }).then(function (r) {
            if (!r) { return null; }
            if (r.remember) { sel.value = r.value; MK.settings.libPart = r.value; MK.saveSettings(); }
            return r.value;
        });
    }

    function makePreviews(btn) {
        var todo = lib.items.filter(function (it) { return !previewFrames(it).length && !sidecar(it); });
        if (!todo.length) { MK.toast(MK.t('t.allHavePreviews')); return; }
        var bar = MK.$('#libProgress');
        return MK.busy(btn, function () {
            var i = 0;
            var step = function () {
                if (i >= todo.length) { MK.progressHide(bar); MK.toast(MK.t('t.previewDone')); renderLib(); return; }
                MK.progress(bar, i / todo.length, MK.t('t.previewing', { i: i + 1, n: todo.length }));
                var it = todo[i++];
                return MK.host('text.genPreview', { path: it.path, outDir: previewDir(it), text: 'Motion', frames: 10, w: 400, h: 225 })
                    .catch(function (e) {
                        console.warn('preview failed', it.path, e);
                        previewFrames(it).forEach(function (f) { try { MK.require('fs').unlinkSync(f); } catch (e2) {} });
                    })
                    .then(function () { return MK.sleep(30); })
                    .then(step);
            };
            return step();
        });
    }

    function addFfx(btn) {
        return MK.busy(btn, function () {
            return MK.host('app.chooseFiles', { title: 'Choose .ffx presets', filter: 'Animation presets:*.ffx', ext: 'ffx' }).then(function (files) {
                if (!files || !files.length) { return; }
                var fs = MK.require('fs'), path = MK.require('path');
                MK.fs.mkdirp(MK.paths.presets);
                files.forEach(function (f) { fs.copyFileSync(f, path.join(MK.paths.presets, path.basename(f))); });
                scan(); renderLib();
                MK.toast(MK.t('t.added', { n: files.length }));
            });
        });
    }

    /* ======================= INIT ======================= */
    MK.initText = function () {
        MK.seg(MK.$('#textSeg'), function (b) {
            MK.$$('#tab-text .sub').forEach(function (s) { s.classList.toggle('active', s.id === 'sub-' + b.dataset.sub); });
            if (b.dataset.sub === 'library') { scan(); renderLib(); }
        });

        writeForm(current);
        mainPlayer = new Player(MK.$('#tbPreview'), function () { return MK.$('#tbSample').value || 'All In One'; }, function () { return current; }, 0.4);
        FIELDS.forEach(function (f) {
            var el = MK.$('#tb-' + f);
            el.addEventListener('input', function () { readForm(); showEaseOpts(); mainPlayer.rebuild(); });
            el.addEventListener('change', function () { readForm(); showEaseOpts(); mainPlayer.rebuild(); });
        });
        MK.$('#tbSample').addEventListener('input', function () { mainPlayer.rebuild(); });
        MK.$('#tbReplay').onclick = function () { mainPlayer.rebuild(); };
        renderPresetStrip();

        MK.$('#tbApply').onclick = function () {
            var p = readForm();
            MK.run(this, 'text.applyBuilder', { preset: p, text: MK.$('#tbSample').value }, function (r) {
                return r.created ? MK.t('ok.newLayer') : MK.t('ok.applied', { n: r.count });
            });
        };
        MK.$('#tbRemove').onclick = function () { MK.run(this, 'text.removeBuilder', {}); };
        MK.$('#tbSave').onclick = function () {
            MK.prompt(MK.t('t.presetName'), MK.t('q.name'), current.name + ' 2').then(function (name) {
                if (!name) { return; }
                var p = readForm(), copy = {};
                for (var k in p) { if (k.charAt(0) !== '_') { copy[k] = p[k]; } }
                copy.name = name;
                var l = userPresets(); l.push(copy); saveUserPresets(l);
                current.name = name;
                renderPresetStrip();
                MK.toast(MK.t('ok.saved'));
            });
        };

        // library
        MK.seg(MK.$('#libAt'), function (b) { lib.at = b.dataset.at; });
        MK.$('#libSearch').addEventListener('input', renderLib);
        MK.$('#libCat').addEventListener('change', renderLib);
        MK.$('#libFavOnly').addEventListener('change', renderLib);
        MK.$('#libRefresh').onclick = function () { scan(); renderLib(); };
        MK.$('#libAdd').onclick = function () { addFfx(this); };
        MK.$('#libFolder').onclick = function () { MK.fs.mkdirp(MK.paths.presets); MK.host('app.openFolder', { path: MK.paths.presets }).catch(MK.fail); };
        MK.$('#libPreviews').onclick = function () { makePreviews(this); };
        MK.$('#libPart').value = MK.settings.libPart || 'ask';
        MK.$('#libPart').addEventListener('change', function () { MK.settings.libPart = this.value; MK.saveSettings(); });

        w.requestAnimationFrame(loop);
    };
})(window);
