/* All In One — Media ▸ Icons: Iconify search (200k+ free icons) + any .svg file → editable shape layer */
(function (w) {
    'use strict';
    var MK = w.MK;
    var API = 'https://api.iconify.design';
    var SETS = [['', 'All'], ['material-symbols', 'Material Symbols'], ['ph', 'Phosphor'], ['tabler', 'Tabler'], ['lucide', 'Lucide'], ['solar', 'Solar'],
        ['fluent', 'Fluent'], ['mdi', 'Material Design'], ['heroicons', 'Heroicons'], ['iconamoon', 'IconaMoon'], ['simple-icons', 'Brands (mono)'], ['logos', 'Brand logos (colour)'], ['fluent-emoji-flat', 'Emoji (colour)']];
    var COLOR_SETS = /^(logos|fluent-emoji-flat|flat-color-icons|noto|twemoji|skill-icons|devicon)$/;
    var STYLE = {
        outline: function (id) { return /(outline|linear|-line\b|regular|light|thin)/.test(id) || /^(tabler|lucide|iconamoon):/.test(id) && !/fill|filled|bold/.test(id); },
        fill: function (id) { return /(fill|solid|bold|filled)/.test(id) || /^mdi:/.test(id) && !/outline/.test(id); },
        duotone: function (id) { return /(duotone|twotone|bulk)/.test(id); },
        color: function (id) { return COLOR_SETS.test(id.split(':')[0]); }
    };
    var EN = {
        'ic.tab': 'Icons', 'ic.search': 'Search icons (rocket, phone, cart…)', 'ic.all': 'All', 'ic.outline': 'Outline', 'ic.fill': 'Fill', 'ic.duotone': 'Duotone', 'ic.colorful': 'Colour',
        'ic.color': 'Colour', 'ic.keep': 'Keep original colours', 'ic.size': 'Size (px)', 'ic.anim': 'Animation', 'ic.none': 'None', 'ic.fade': 'Fade in', 'ic.pop': 'Scale pop',
        'ic.slide': 'Slide up', 'ic.draw': 'Draw on', 'ic.dur': 'Duration (s)', 'ic.svgFile': 'Import .svg file…', 'ic.more': 'Load more',
        'ic.hint': 'Click an icon: it becomes a real shape layer (every path, fill and stroke editable), animated at the playhead. “Import .svg file” works for Figma / Illustrator exports too. Icons from Iconify (free, open licences).',
        'ic.empty': 'No icons found. Try another word or set.', 'ic.ok': '“{n}” added as a shape layer', 'ic.loading': 'Searching…', 'ic.found': '{n} icons',
        'err.NOT_SVG': 'That is not an SVG file.', 'err.SVG_EMPTY': 'No drawable shapes in that SVG.'
    };
    var BN = {
        'ic.tab': 'আইকন', 'ic.search': 'আইকন খুঁজুন (rocket, phone, cart…)', 'ic.all': 'সব', 'ic.outline': 'আউটলাইন', 'ic.fill': 'ভরাট', 'ic.duotone': 'ডুয়োটোন', 'ic.colorful': 'রঙিন',
        'ic.color': 'রং', 'ic.keep': 'আসল রং রাখুন', 'ic.size': 'সাইজ (px)', 'ic.anim': 'অ্যানিমেশন', 'ic.none': 'নেই', 'ic.fade': 'ফেড ইন', 'ic.pop': 'পপ (বড় হয়ে আসা)',
        'ic.slide': 'নিচ থেকে ওঠা', 'ic.draw': 'আঁকা হয়ে আসা', 'ic.dur': 'সময় (সে.)', 'ic.svgFile': '.svg ফাইল ইমপোর্ট…', 'ic.more': 'আরও দেখুন',
        'ic.hint': 'আইকনে ক্লিক করলে সেটা আসল শেপ লেয়ার হয়ে প্লেহেডে অ্যানিমেশনসহ বসে। প্রতিটা পাথ, ফিল আর স্ট্রোক এডিট করা যায়। "SVG ফাইল ইমপোর্ট" Figma / Illustrator-এর export-এও কাজ করে। আইকনগুলো Iconify-র (ফ্রি, ওপেন লাইসেন্স)।',
        'ic.empty': 'কোনো আইকন পাওয়া যায়নি। অন্য শব্দ বা সেট দিয়ে চেষ্টা করুন।', 'ic.ok': '"{n}" শেপ লেয়ার হিসেবে যোগ হয়েছে', 'ic.loading': 'খোঁজা হচ্ছে…', 'ic.found': '{n}টি আইকন',
        'err.NOT_SVG': 'এটা SVG ফাইল নয়।', 'err.SVG_EMPTY': 'ওই SVG-তে আঁকার মতো কোনো শেপ নেই।'
    };
    MK.regStrings(EN, BN);

    var st = { q: '', icons: [], shown: 0, page: 0, busy: false };
    function val(id) { return MK.$('#' + id).value; }
    function opts() {
        return { color: MK.hexToRgb01(val('icColor')), keep: MK.$('#icKeep').checked, size: parseFloat(val('icSize')) || 300, anim: val('icAnim'), dur: parseFloat(val('icDur')) || 0.6 };
    }
    function save() {
        MK.settings.icons = { set: val('icSet'), style: MK.segValue(MK.$('#icStyle'), 'data-v'), color: val('icColor'), keep: MK.$('#icKeep').checked, size: val('icSize'), anim: val('icAnim'), dur: val('icDur') };
        MK.saveSettings();
    }

    function place(name, svgText, keepDefault, btn) {
        var o = opts(), parsed;
        try { parsed = MK.svg.parse(svgText, { color: o.color, keepColors: keepDefault || o.keep }); } catch (e) { MK.fail(e); return; }
        return MK.run(btn, 'ex.svgToShape', { name: name, items: parsed.items, box: parsed.box, size: o.size, anim: o.anim === 'none' ? '' : o.anim, dur: o.dur, at: 'playhead' },
            function () { return MK.t('ic.ok', { n: name }); });
    }

    function search(more) {
        var q = val('icQuery').trim();
        if (!q) { return Promise.resolve(); }
        var grid = MK.$('#icGrid');
        if (!more) { st.icons = []; st.shown = 0; grid.innerHTML = '<div class="empty">' + MK.esc(MK.t('ic.loading')) + '</div>'; }
        var set = val('icSet'), style = MK.segValue(MK.$('#icStyle'), 'data-v') || '';
        var url = API + '/search?query=' + encodeURIComponent(q) + '&limit=999' + (set ? '&prefixes=' + set : '');
        var p = more ? Promise.resolve(st.icons) : MK.http.get(url).then(function (r) {
            var list = (r && r.icons) || [];
            if (style && STYLE[style]) { list = list.filter(STYLE[style]); }
            st.icons = list; return list;
        });
        return p.then(function (list) {
            if (!more) { grid.innerHTML = ''; }
            MK.$('#icCount').textContent = list.length ? MK.t('ic.found', { n: list.length }) : '';
            if (!list.length) { grid.innerHTML = '<div class="empty">' + MK.esc(MK.t('ic.empty')) + '</div>'; MK.$('#icMore').classList.add('hidden'); return; }
            var next = list.slice(st.shown, st.shown + 60);
            st.shown += next.length;
            next.forEach(function (id) {
                var parts = id.split(':'), b = document.createElement('button');
                b.className = 'ic-cell'; b.title = id;
                var colorful = COLOR_SETS.test(parts[0]);
                b.innerHTML = '<img loading="lazy" alt="">';
                b.querySelector('img').src = API + '/' + parts[0] + '/' + parts[1] + '.svg' + (colorful ? '' : '?color=%23e8e8ee');
                b.onclick = function () {
                    MK.busy(b, function () {
                        return MK.http.get(API + '/' + parts[0] + '/' + parts[1] + '.svg').then(function (svg) { return place(parts[1], String(svg), colorful, null); });
                    });
                };
                grid.appendChild(b);
            });
            MK.$('#icMore').classList.toggle('hidden', st.shown >= list.length);
        }).catch(function (e) { grid.innerHTML = ''; MK.fail(e); });
    }

    function svgFile(btn) {
        return MK.host('app.chooseFile', { title: 'SVG', filter: 'SVG:*.svg' }).then(function (p) {
            if (!p) { return; }
            var txt = MK.fs.readText(p), name = MK.require('path').basename(p).replace(/\.svg$/i, '');
            return place(name, txt, true, btn);
        }).catch(MK.fail);
    }

    MK.initIcons = function () {
        var sel = MK.$('#icSet');
        SETS.forEach(function (s) { var o = document.createElement('option'); o.value = s[0]; o.textContent = s[0] ? s[1] : MK.t('ic.all'); sel.appendChild(o); });
        var s = MK.settings.icons || {};
        if (s.set !== undefined) { sel.value = s.set; }
        if (s.style !== undefined) { MK.$$('#icStyle button').forEach(function (b) { b.classList.toggle('active', b.dataset.v === s.style); }); }
        ['color', 'size', 'anim', 'dur'].forEach(function (k) { if (s[k] !== undefined) { MK.$('#ic' + k.charAt(0).toUpperCase() + k.slice(1)).value = s[k]; } });
        if (s.keep !== undefined) { MK.$('#icKeep').checked = s.keep; }
        ['icSet', 'icColor', 'icKeep', 'icSize', 'icAnim', 'icDur'].forEach(function (id) { MK.$('#' + id).addEventListener('change', save); });
        MK.seg(MK.$('#icStyle'), function () { save(); search(false); });
        sel.addEventListener('change', function () { search(false); });
        MK.$('#icGo').onclick = function () { search(false); };
        MK.$('#icQuery').addEventListener('keydown', function (e) { if (e.key === 'Enter') { search(false); } });
        MK.$('#icMore').onclick = function () { search(true); };
        MK.$('#icSvg').onclick = function () { svgFile(this); };
        MK.$$('#icTags button').forEach(function (b) { b.onclick = function () { MK.$('#icQuery').value = b.textContent; search(false); }; });
    };

    MK._icons = { STYLE: STYLE, place: place };
})(window);
