/* All In One — auto update.
   Reads a small JSON file from GitHub, and when a newer version is listed it downloads the zip,
   checks its SHA-256, backs up the current install, copies the new files in place and reloads the panel. */
(function (w) {
    'use strict';
    var MK = w.MK;

    var EN = {
        'up.title': 'Updates', 'up.auto': 'Check for updates when the panel opens', 'up.check': 'Check now',
        'up.rollback': 'Go back to previous version', 'up.checking': 'Checking for updates…',
        'up.latest': 'You have the latest version (v{v}).', 'up.found': 'New version v{v} is available',
        'up.btn': 'Update v{v}', 'up.install': 'Update now', 'up.later': 'Later',
        'up.dl': 'Downloading update… {p}%', 'up.unpack': 'Installing…', 'up.bad': 'Update file is damaged (checksum mismatch). Try again.',
        'up.done': 'Updated to v{v}. Reloading…', 'up.restart': 'Updated to v{v}. Please restart After Effects once to finish.',
        'up.noWrite': 'Cannot write to the plugin folder: {p}', 'up.noBackup': 'No previous version saved yet.',
        'up.rolled': 'Restored v{v}. Reloading…', 'up.offline': 'Could not reach the update server.',
        'up.whatsNew': 'What’s new', 'up.current': 'Installed: v{v}'
    };
    var BN = {
        'up.title': 'আপডেট', 'up.auto': 'প্যানেল খুললেই আপডেট চেক করবে', 'up.check': 'এখনই চেক করুন',
        'up.rollback': 'আগের ভার্সনে ফিরে যান', 'up.checking': 'আপডেট চেক হচ্ছে…',
        'up.latest': 'আপনার কাছে সর্বশেষ ভার্সন আছে (v{v})।', 'up.found': 'নতুন ভার্সন v{v} এসেছে',
        'up.btn': 'আপডেট v{v}', 'up.install': 'এখনই আপডেট', 'up.later': 'পরে',
        'up.dl': 'আপডেট ডাউনলোড হচ্ছে… {p}%', 'up.unpack': 'ইনস্টল হচ্ছে…', 'up.bad': 'আপডেট ফাইল নষ্ট (checksum মেলেনি)। আবার চেষ্টা করুন।',
        'up.done': 'v{v} তে আপডেট হয়েছে। রিলোড হচ্ছে…', 'up.restart': 'v{v} তে আপডেট হয়েছে। শেষ করতে After Effects একবার রিস্টার্ট দিন।',
        'up.noWrite': 'প্লাগিন ফোল্ডারে লেখা যাচ্ছে না: {p}', 'up.noBackup': 'আগের কোনো ভার্সন সেভ করা নেই।',
        'up.rolled': 'v{v} ফেরত আনা হয়েছে। রিলোড হচ্ছে…', 'up.offline': 'আপডেট সার্ভারে পৌঁছানো যায়নি।',
        'up.whatsNew': 'নতুন কী আছে', 'up.current': 'ইনস্টল করা: v{v}'
    };
    if (MK.regStrings) { MK.regStrings(EN, BN); }

    var U = { latest: null };
    var cfg = function () { return (MK.settings.update = MK.settings.update || { auto: true }); };

    // "2.10.0" > "2.9.3"
    U.cmp = function (a, b) {
        var x = String(a || '0').split('.'), y = String(b || '0').split('.');
        for (var i = 0; i < Math.max(x.length, y.length); i++) {
            var d = (parseInt(x[i], 10) || 0) - (parseInt(y[i], 10) || 0);
            if (d) { return d > 0 ? 1 : -1; }
        }
        return 0;
    };

    function manifestUrl() {
        var u = (MK.config && MK.config.updateManifest) || '';
        return u ? u + (u.indexOf('?') < 0 ? '?' : '&') + 't=' + Date.now() : '';
    }

    function notesOf(info) {
        var n = info && info.notes;
        if (!n) { return ''; }
        if (typeof n === 'string') { return n; }
        return n[MK.lang()] || n.en || n.bn || '';
    }

    U.check = function (manual) {
        var url = manifestUrl();
        if (!url || !MK.hasNode) { return Promise.resolve(null); }
        if (manual) { MK.toast(MK.t('up.checking')); }
        return MK.http.get(url).then(function (info) {
            if (typeof info === 'string') { info = JSON.parse(info); }
            cfg().lastCheck = Date.now();
            MK.saveSettings();
            if (info && info.version && info.zip && U.cmp(info.version, MK.version) > 0 && (manual || cfg().skip !== info.version)) {
                U.latest = info;
                showBadge(info);
                if (manual) { U.prompt(); } else { MK.toast(MK.t('up.found', { v: info.version })); }
            } else {
                U.latest = null;
                hideBadge();
                if (manual) { MK.toast(MK.t('up.latest', { v: MK.version })); }
            }
            return info;
        }, function (e) {
            console.warn('update check failed', e);
            if (manual) { MK.toast(MK.t('up.offline'), 'err'); }
            return null;
        });
    };

    function showBadge(info) {
        var b = MK.$('#updBtn');
        if (!b) { return; }
        b.textContent = '⬆ ' + MK.t('up.btn', { v: info.version });
        b.classList.remove('hidden');
    }
    function hideBadge() { var b = MK.$('#updBtn'); if (b) { b.classList.add('hidden'); } }

    U.prompt = function () {
        var info = U.latest;
        if (!info) { return U.check(true); }
        var notes = notesOf(info);
        return MK.modal({
            title: MK.t('up.found', { v: info.version }),
            html: '<p class="hint">' + MK.esc(MK.t('up.current', { v: MK.version })) + (info.date ? ' · ' + MK.esc(info.date) : '') + '</p>' +
                  (notes ? '<div class="group-title">' + MK.esc(MK.t('up.whatsNew')) + '</div><div class="hint" style="white-space:pre-wrap">' + MK.esc(notes) + '</div>' : '') +
                  '',
            okText: MK.t('up.install')
        }).then(function (r) { if (r) { return U.install(info); } });
    };

    /* ---------- file helpers (Node) ---------- */
    function walk(dir, base, out) {
        var fs = MK.require('fs'), path = MK.require('path');
        out = out || [];
        fs.readdirSync(dir).forEach(function (f) {
            var full = path.join(dir, f), rel = base ? base + '/' + f : f;
            if (fs.statSync(full).isDirectory()) { walk(full, rel, out); } else { out.push(rel); }
        });
        return out;
    }
    function copyTree(src, dst) {
        var fs = MK.require('fs'), path = MK.require('path');
        walk(src, '').forEach(function (rel) {
            var to = path.join(dst, rel);
            MK.fs.mkdirp(path.dirname(to));
            fs.copyFileSync(path.join(src, rel), to);
        });
    }
    function rmTree(p) {
        var fs = MK.require('fs'), path = MK.require('path');
        if (!fs.existsSync(p)) { return; }
        if (fs.statSync(p).isDirectory()) {
            fs.readdirSync(p).forEach(function (f) { rmTree(path.join(p, f)); });
            fs.rmdirSync(p);
        } else { fs.unlinkSync(p); }
    }
    function readText(p) { try { return MK.require('fs').readFileSync(p, 'utf8'); } catch (e) { return ''; } }
    function findRoot(dir) {
        var fs = MK.require('fs'), path = MK.require('path');
        if (fs.existsSync(path.join(dir, 'CSXS', 'manifest.xml'))) { return dir; }
        var subs = fs.readdirSync(dir);
        for (var i = 0; i < subs.length; i++) {
            var s = path.join(dir, subs[i]);
            if (fs.statSync(s).isDirectory()) { var r = findRoot(s); if (r) { return r; } }
        }
        return '';
    }
    function unzip(zip, out) {
        var cp = MK.require('child_process');
        if (MK.isWin) {
            cp.execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
                "Expand-Archive -LiteralPath '" + zip.replace(/'/g, "''") + "' -DestinationPath '" + out.replace(/'/g, "''") + "' -Force"], { windowsHide: true, timeout: 300000 });
        } else {
            cp.execFileSync('/usr/bin/unzip', ['-o', '-q', zip, '-d', out], { timeout: 300000 });
        }
    }
    function backupDir() { return MK.paths.join(MK.paths.data, 'Backups'); }

    // put the files of `newRoot` into the plugin folder; returns true when AE must restart
    function apply(newRoot) {
        var fs = MK.require('fs'), path = MK.require('path');
        var ext = MK.extRoot;
        var needRestart = readText(path.join(ext, 'CSXS', 'manifest.xml')) !== readText(path.join(newRoot, 'CSXS', 'manifest.xml')) ||
                          readText(path.join(ext, 'host', 'index.jsx')) !== readText(path.join(newRoot, 'host', 'index.jsx'));
        var keep = {};
        walk(newRoot, '').forEach(function (rel) { keep[rel] = 1; });
        copyTree(newRoot, ext);
        // remove files the new version no longer has (old modules etc.)
        walk(ext, '').forEach(function (rel) {
            if (!keep[rel] && !/^META-INF\//.test(rel)) { try { fs.unlinkSync(path.join(ext, rel)); } catch (e) {} }
        });
        return needRestart;
    }

    U.install = function (info) {
        var bar = MK.$('#updSetProgress');
        var fs = MK.require('fs'), path = MK.require('path'), crypto = MK.require('crypto');
        var ext = MK.extRoot;
        try {
            var probe = path.join(ext, '.write-test');
            fs.writeFileSync(probe, '1'); fs.unlinkSync(probe);
        } catch (e) { MK.toast(MK.t('up.noWrite', { p: ext }), 'err'); return Promise.resolve(); }

        var tmp = MK.paths.join(MK.paths.temp, 'update-' + info.version);
        rmTree(tmp);
        MK.fs.mkdirp(tmp);
        var zip = path.join(tmp, 'update.zip');
        var last = -1;
        var prog = function (f) {
            var pc = Math.round(f * 100);
            MK.progress(bar, f, MK.t('up.dl', { p: pc }));
            if (pc - last >= 10 || pc === 100) { last = pc; MK.toast(MK.t('up.dl', { p: pc })); }
        };
        prog(0);
        return MK.http.download(info.zip, zip, prog).then(function () {
            if (info.sha256) {
                var h = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
                if (h.toLowerCase() !== String(info.sha256).toLowerCase()) { throw new Error(MK.t('up.bad')); }
            }
            MK.progress(bar, null, MK.t('up.unpack'));
            MK.toast(MK.t('up.unpack'));
            var out = path.join(tmp, 'x');
            MK.fs.mkdirp(out);
            unzip(zip, out);
            var root = findRoot(out);
            if (!root) { throw new Error('manifest.xml not found in update'); }
            // back up the current version first (keep the last two)
            var bdir = path.join(backupDir(), 'v' + MK.version);
            rmTree(bdir);
            copyTree(ext, bdir);
            try {
                var olds = fs.readdirSync(backupDir()).filter(function (d) { return /^v\d/.test(d); })
                    .sort(function (a, b) { return U.cmp(a.slice(1), b.slice(1)); });
                while (olds.length > 2) { rmTree(path.join(backupDir(), olds.shift())); }
            } catch (e) {}
            var restart = apply(root);
            rmTree(tmp);
            MK.progressHide(bar);
            finish(restart, 'up.restart', 'up.done', info.version);
        }).catch(function (e) { MK.progressHide(bar); MK.fail(e); });
    };

    function finish(restart, kRestart, kDone, v) {
        MK.saveSettings();
        if (restart) {
            MK.modal({ title: MK.t('up.title'), html: '<p>' + MK.esc(MK.t(kRestart, { v: v })) + '</p>' });
        } else {
            MK.toast(MK.t(kDone, { v: v }));
            setTimeout(function () { location.reload(); }, 1200);
        }
    }

    U.rollback = function () {
        var fs = MK.require('fs'), path = MK.require('path');
        var dirs = [];
        try { dirs = fs.readdirSync(backupDir()).filter(function (d) { return /^v\d/.test(d) && U.cmp(d.slice(1), MK.version) !== 0; }); } catch (e) {}
        if (!dirs.length) { MK.toast(MK.t('up.noBackup')); return; }
        dirs.sort(function (a, b) { return U.cmp(b.slice(1), a.slice(1)); });
        var v = dirs[0].slice(1);
        MK.modal({ title: MK.t('up.rollback'), html: '<p>v' + MK.esc(MK.version) + ' → v' + MK.esc(v) + '</p>', okText: MK.t('ui.ok') }).then(function (r) {
            if (!r) { return; }
            try {
                var restart = apply(path.join(backupDir(), dirs[0]));
                cfg().skip = MK.version; // don't nag about the version we just left
                finish(restart, 'up.restart', 'up.rolled', v);
            } catch (e) { MK.fail(e); }
        });
    };

    MK.initUpdate = function () {
        var b = MK.$('#updBtn');
        if (b) { b.onclick = function () { U.prompt(); }; }
        var chk = MK.$('#updAuto');
        if (chk) {
            chk.checked = cfg().auto !== false;
            chk.onchange = function () { cfg().auto = chk.checked; MK.saveSettings(); };
        }
        if (MK.$('#updCheck')) { MK.$('#updCheck').onclick = function () { U.check(true); }; }
        if (MK.$('#updRollback')) { MK.$('#updRollback').onclick = U.rollback; }
        if (cfg().auto !== false) { setTimeout(function () { U.check(false); }, 4000); }
    };
    MK.update = U;
})(window);
