/* All In One — SVG → AE shape data (paths as vertices + relative tangents)
   MK.svg.parse(text, { color: [r,g,b] | null, keepColors: bool }) → { items, box } */
(function (w) {
    'use strict';
    var MK = w.MK;
    var NAMED = { black: '#000000', white: '#ffffff', red: '#ff0000', green: '#008000', blue: '#0000ff', yellow: '#ffff00', gray: '#808080', grey: '#808080', orange: '#ffa500', purple: '#800080' };

    /* ---------- colours ---------- */
    function color(v, cur) {
        if (!v) { return undefined; }
        v = String(v).trim().toLowerCase();
        if (v === 'none' || v === 'transparent') { return null; }
        if (v === 'currentcolor') { return cur || [0, 0, 0]; }
        if (/^url\(/.test(v)) { return cur || [0.5, 0.5, 0.5]; }
        if (NAMED[v]) { v = NAMED[v]; }
        var m = /^#([0-9a-f]{3,8})$/.exec(v);
        if (m) {
            var h = m[1];
            if (h.length === 3 || h.length === 4) { h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2); }
            return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255];
        }
        m = /^rgba?\(([^)]+)\)/.exec(v);
        if (m) {
            var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(function (x, i) { return /%$/.test(x) ? parseFloat(x) / 100 : (i < 3 ? parseFloat(x) / 255 : parseFloat(x)); });
            return [p[0] || 0, p[1] || 0, p[2] || 0];
        }
        return cur || [0, 0, 0];
    }

    /* ---------- matrices [a b c d e f] ---------- */
    function mul(m, n) { return [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3], m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]]; }
    function ap(m, p) { return [m[0] * p[0] + m[2] * p[1] + m[4], m[1] * p[0] + m[3] * p[1] + m[5]]; }
    function parseTransform(s) {
        var m = [1, 0, 0, 1, 0, 0], re = /(\w+)\s*\(([^)]*)\)/g, r;
        while ((r = re.exec(s || ''))) {
            var a = r[2].split(/[\s,]+/).filter(Boolean).map(parseFloat), t;
            switch (r[1]) {
            case 'matrix': t = a.slice(0, 6); break;
            case 'translate': t = [1, 0, 0, 1, a[0] || 0, a[1] || 0]; break;
            case 'scale': t = [a[0], 0, 0, a.length > 1 ? a[1] : a[0], 0, 0]; break;
            case 'rotate':
                var rad = (a[0] || 0) * Math.PI / 180, cs = Math.cos(rad), sn = Math.sin(rad);
                t = [cs, sn, -sn, cs, 0, 0];
                if (a.length > 2) { t = mul(mul([1, 0, 0, 1, a[1], a[2]], t), [1, 0, 0, 1, -a[1], -a[2]]); }
                break;
            case 'skewX': t = [1, 0, Math.tan(a[0] * Math.PI / 180), 1, 0, 0]; break;
            case 'skewY': t = [1, Math.tan(a[0] * Math.PI / 180), 0, 1, 0, 0]; break;
            default: t = [1, 0, 0, 1, 0, 0];
            }
            m = mul(m, t);
        }
        return m;
    }

    /* ---------- path data → subpaths of cubic segments ---------- */
    function tokens(d) {
        var out = [], re = /([MmLlHhVvCcSsQqTtAaZz])|(-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)/g, r;
        while ((r = re.exec(d))) { out.push(r[1] ? r[1] : parseFloat(r[2])); }
        return out;
    }
    // SVG arc → cubic beziers (endpoint parameterisation, F.6 of the SVG spec)
    function arcToCubics(x1, y1, rx, ry, phi, fa, fs, x2, y2) {
        if (rx === 0 || ry === 0) { return [[x1, y1, x2, y2, x2, y2]]; }
        rx = Math.abs(rx); ry = Math.abs(ry);
        var p = phi * Math.PI / 180, cp = Math.cos(p), sp = Math.sin(p);
        var dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
        var x1p = cp * dx + sp * dy, y1p = -sp * dx + cp * dy;
        var lam = x1p * x1p / (rx * rx) + y1p * y1p / (ry * ry);
        if (lam > 1) { var sl = Math.sqrt(lam); rx *= sl; ry *= sl; }
        var num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p, den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
        var co = Math.sqrt(Math.max(0, num / den)) * (fa === fs ? -1 : 1);
        var cxp = co * rx * y1p / ry, cyp = -co * ry * x1p / rx;
        var cx = cp * cxp - sp * cyp + (x1 + x2) / 2, cy = sp * cxp + cp * cyp + (y1 + y2) / 2;
        var ang = function (ux, uy, vx, vy) { var a = Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy); return a; };
        var t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
        var dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
        if (!fs && dt > 0) { dt -= 2 * Math.PI; } else if (fs && dt < 0) { dt += 2 * Math.PI; }
        var n = Math.max(1, Math.ceil(Math.abs(dt) / (Math.PI / 2))), step = dt / n, out = [];
        var k = 4 / 3 * Math.tan(step / 4);
        var pt = function (t) { var c = Math.cos(t), s = Math.sin(t); return [cx + rx * c * cp - ry * s * sp, cy + rx * c * sp + ry * s * cp]; };
        var dv = function (t) { var c = Math.cos(t), s = Math.sin(t); return [-rx * s * cp - ry * c * sp, -rx * s * sp + ry * c * cp]; };
        for (var i = 0; i < n; i++) {
            var a0 = t1 + i * step, a1 = a0 + step, P0 = pt(a0), P1 = pt(a1), D0 = dv(a0), D1 = dv(a1);
            out.push([P0[0] + k * D0[0], P0[1] + k * D0[1], P1[0] - k * D1[0], P1[1] - k * D1[1], P1[0], P1[1]]);
        }
        if (out.length) { out[out.length - 1][4] = x2; out[out.length - 1][5] = y2; }
        return out;
    }
    function pathSubs(d) {
        var t = tokens(d), i = 0, cmd = '', subs = [], cur = null, x = 0, y = 0, sx = 0, sy = 0, lc = null, lq = null;
        var num = function () { return t[i++]; };
        var isNum = function () { return typeof t[i] === 'number'; };
        var start = function (nx, ny) { cur = { start: [nx, ny], segs: [], closed: false }; subs.push(cur); x = sx = nx; y = sy = ny; };
        var cubic = function (a, b, c, e, f, g) { if (!cur) { start(x, y); } cur.segs.push([a, b, c, e, f, g]); x = f; y = g; };
        while (i < t.length) {
            if (!isNum()) { cmd = t[i++]; }
            else if (!cmd) { i++; continue; }
            var rel = cmd === cmd.toLowerCase() && cmd !== 'z' ? 1 : 0, C = cmd.toUpperCase();
            var ox = rel ? x : 0, oy = rel ? y : 0, nlc = null, nlq = null;
            if (C === 'Z') { if (cur) { cur.closed = true; x = sx; y = sy; cur = null; } lc = lq = null; continue; }
            if (!isNum()) { continue; }
            if (C === 'M') { var mx = num() + ox, my = num() + oy; start(mx, my); cmd = rel ? 'l' : 'L'; }
            else if (C === 'L') { var lx = num() + ox, ly = num() + oy; cubic(x, y, lx, ly, lx, ly); }
            else if (C === 'H') { var hx = num() + ox; cubic(x, y, hx, y, hx, y); }
            else if (C === 'V') { var vy = num() + oy; cubic(x, y, x, vy, x, vy); }
            else if (C === 'C') { var c1x = num() + ox, c1y = num() + oy, c2x = num() + ox, c2y = num() + oy, ex = num() + ox, ey = num() + oy; cubic(c1x, c1y, c2x, c2y, ex, ey); nlc = [c2x, c2y]; }
            else if (C === 'S') {
                var r1x = lc ? 2 * x - lc[0] : x, r1y = lc ? 2 * y - lc[1] : y;
                var s2x = num() + ox, s2y = num() + oy, sex = num() + ox, sey = num() + oy;
                cubic(r1x, r1y, s2x, s2y, sex, sey); nlc = [s2x, s2y];
            } else if (C === 'Q' || C === 'T') {
                var qx, qy;
                if (C === 'Q') { qx = num() + ox; qy = num() + oy; } else { qx = lq ? 2 * x - lq[0] : x; qy = lq ? 2 * y - lq[1] : y; }
                var qex = num() + ox, qey = num() + oy;
                cubic(x + 2 / 3 * (qx - x), y + 2 / 3 * (qy - y), qex + 2 / 3 * (qx - qex), qey + 2 / 3 * (qy - qey), qex, qey);
                nlq = [qx, qy];
            } else if (C === 'A') {
                var arx = num(), ary = num(), rot = num(), fa = num(), fs = num(), aex = num() + ox, aey = num() + oy;
                arcToCubics(x, y, arx, ary, rot, fa ? 1 : 0, fs ? 1 : 0, aex, aey).forEach(function (s) { cubic(s[0], s[1], s[2], s[3], s[4], s[5]); });
            } else { i++; }
            lc = nlc; lq = nlq;
        }
        return subs;
    }

    // shapes → path data
    function rectD(x, y, wd, h, rx, ry) {
        if (rx === undefined && ry !== undefined) { rx = ry; }
        if (ry === undefined && rx !== undefined) { ry = rx; }
        rx = Math.min(rx || 0, wd / 2); ry = Math.min(ry || 0, h / 2);
        if (!rx || !ry) { return 'M' + x + ' ' + y + 'H' + (x + wd) + 'V' + (y + h) + 'H' + x + 'Z'; }
        return 'M' + (x + rx) + ' ' + y + 'H' + (x + wd - rx) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + (x + wd) + ' ' + (y + ry) + 'V' + (y + h - ry) +
            'A' + rx + ' ' + ry + ' 0 0 1 ' + (x + wd - rx) + ' ' + (y + h) + 'H' + (x + rx) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + x + ' ' + (y + h - ry) +
            'V' + (y + ry) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + (x + rx) + ' ' + y + 'Z';
    }
    function ellipseD(cx, cy, rx, ry) {
        return 'M' + (cx - rx) + ' ' + cy + 'A' + rx + ' ' + ry + ' 0 1 0 ' + (cx + rx) + ' ' + cy + 'A' + rx + ' ' + ry + ' 0 1 0 ' + (cx - rx) + ' ' + cy + 'Z';
    }

    // subpath (absolute cubics) + matrix → AE path {v, i, o, closed}
    function toAE(sub, m) {
        var P = function (x, y) { return ap(m, [x, y]); };
        var v = [P(sub.start[0], sub.start[1])], ins = [[0, 0]], outs = [[0, 0]];
        sub.segs.forEach(function (s) {
            var last = v[v.length - 1], c1 = P(s[0], s[1]), c2 = P(s[2], s[3]), e = P(s[4], s[5]);
            outs[outs.length - 1] = [c1[0] - last[0], c1[1] - last[1]];
            v.push(e); ins.push([c2[0] - e[0], c2[1] - e[1]]); outs.push([0, 0]);
        });
        var closed = sub.closed;
        if (v.length > 1) {
            var a = v[0], b = v[v.length - 1];
            if (Math.abs(a[0] - b[0]) < 1e-3 && Math.abs(a[1] - b[1]) < 1e-3) { ins[0] = ins[ins.length - 1]; v.pop(); ins.pop(); outs.pop(); closed = closed || true; }
        }
        var r = function (n) { return Math.round(n * 1000) / 1000; };
        var rr = function (p) { return [r(p[0]), r(p[1])]; };
        return { v: v.map(rr), i: ins.map(rr), o: outs.map(rr), closed: !!closed };
    }

    function styleOf(el, parent) {
        var st = Object.assign({}, parent);
        var css = {};
        (el.getAttribute('style') || '').split(';').forEach(function (kv) { var p = kv.split(':'); if (p.length === 2) { css[p[0].trim()] = p[1].trim(); } });
        var get = function (k) { return css[k] !== undefined ? css[k] : el.getAttribute(k); };
        ['fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'fill-rule', 'opacity', 'fill-opacity', 'stroke-opacity', 'color', 'display', 'visibility'].forEach(function (k) {
            var v = get(k);
            if (v !== null && v !== undefined && v !== '' && v !== 'inherit') { st[k] = k === 'opacity' ? (parseFloat(v) * (parent.opacity === undefined ? 1 : parent.opacity)) : v; }
        });
        return st;
    }

    function parse(text, opts) {
        opts = opts || {};
        var doc = new w.DOMParser().parseFromString(String(text), 'image/svg+xml');
        var svg = doc.getElementsByTagName('svg')[0];
        if (!svg) { throw new Error('NOT_SVG'); }
        var vb = (svg.getAttribute('viewBox') || '').split(/[\s,]+/).map(parseFloat);
        var box = vb.length === 4 && !isNaN(vb[2]) ? vb : [0, 0, parseFloat(svg.getAttribute('width')) || 100, parseFloat(svg.getAttribute('height')) || 100];
        var items = [], defs = {};
        var forced = opts.color || null, keep = opts.keepColors;
        // collect <defs> by id for <use>
        Array.prototype.forEach.call(doc.querySelectorAll('[id]'), function (e) { defs[e.getAttribute('id')] = e; });

        var walk = function (el, m, st, depth) {
            if (depth > 20) { return; }
            var tag = (el.localName || el.nodeName || '').toLowerCase();
            if (/^(defs|clippath|mask|lineargradient|radialgradient|pattern|symbol|style|title|desc|metadata|filter|marker|text)$/.test(tag) && depth > 0) { return; }
            var mm = el.getAttribute && el.getAttribute('transform') ? mul(m, parseTransform(el.getAttribute('transform'))) : m;
            var s = depth === 0 ? styleOf(el, { fill: '#000000', opacity: 1 }) : styleOf(el, st);
            if (s.display === 'none' || s.visibility === 'hidden') { return; }
            var d = null, num = function (k) { return parseFloat(el.getAttribute(k)) || 0; };
            if (tag === 'path') { d = el.getAttribute('d'); }
            else if (tag === 'rect') { d = rectD(num('x'), num('y'), num('width'), num('height'), el.hasAttribute('rx') ? num('rx') : undefined, el.hasAttribute('ry') ? num('ry') : undefined); }
            else if (tag === 'circle') { d = ellipseD(num('cx'), num('cy'), num('r'), num('r')); }
            else if (tag === 'ellipse') { d = ellipseD(num('cx'), num('cy'), num('rx'), num('ry')); }
            else if (tag === 'line') { d = 'M' + num('x1') + ' ' + num('y1') + 'L' + num('x2') + ' ' + num('y2'); }
            else if (tag === 'polyline' || tag === 'polygon') {
                var pts = (el.getAttribute('points') || '').trim().split(/[\s,]+/).map(parseFloat);
                if (pts.length >= 4) { d = 'M' + pts.slice(0, 2).join(' ') + 'L' + pts.slice(2).join(' ') + (tag === 'polygon' ? 'Z' : ''); }
            } else if (tag === 'use') {
                var ref = (el.getAttribute('href') || el.getAttribute('xlink:href') || '').replace(/^#/, '');
                if (defs[ref]) { walk(defs[ref], mul(mm, [1, 0, 0, 1, num('x'), num('y')]), s, depth + 1); }
                return;
            }
            if (d) {
                var cur = color(s.color) || forced || [0, 0, 0];
                var fill = color(s.fill, cur), stroke = color(s.stroke, cur);
                if (fill === undefined) { fill = cur; }
                if (!keep && forced) { if (fill) { fill = forced; } if (stroke) { stroke = forced; } }
                if (fill || stroke) {
                    var paths = pathSubs(d).map(function (sub) { return toAE(sub, mm); }).filter(function (p) { return p.v.length > 1; });
                    if (paths.length) {
                        var sc = Math.sqrt(Math.abs(mm[0] * mm[3] - mm[1] * mm[2])) || 1;
                        items.push({
                            name: el.getAttribute('id') || tag, paths: paths, fill: fill || null, stroke: stroke || null,
                            sw: (parseFloat(s['stroke-width']) || 1) * sc, cap: s['stroke-linecap'] || 'butt', join: s['stroke-linejoin'] || 'miter',
                            evenodd: s['fill-rule'] === 'evenodd', opacity: s.opacity === undefined ? 1 : s.opacity,
                            fillOpacity: s['fill-opacity'] !== undefined ? parseFloat(s['fill-opacity']) : 1, strokeOpacity: s['stroke-opacity'] !== undefined ? parseFloat(s['stroke-opacity']) : 1
                        });
                    }
                }
            }
            var kids = el.children || [];
            for (var k = 0; k < kids.length; k++) { walk(kids[k], mm, s, depth + 1); }
        };
        walk(svg, [1, 0, 0, 1, 0, 0], {}, 0);
        if (!items.length) { throw new Error('SVG_EMPTY'); }
        // AE draws the first group on top: reverse so SVG paint order is kept
        items.reverse();
        return { items: items, box: box };
    }

    MK.svg = { parse: parse, color: color, _pathSubs: pathSubs, _arc: arcToCubics };
})(window);
