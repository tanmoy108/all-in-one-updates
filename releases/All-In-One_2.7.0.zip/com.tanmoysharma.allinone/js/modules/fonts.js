/* All In One — font picker: searchable list of installed fonts, rendered in their own typeface.
   AE 2024+ gives the list (app.fonts); older versions fall back to reading the system font folders with Node. */
(function (w) {
    'use strict';
    var MK = w.MK;

    var BANGLA = /bangla|bengali|siliguri|solaiman|kalpurush|nikosh|siyam|rupali|adorsho|mukti|vrinda|shonar|galada|atma|\bmina\b|baloo ?da|tiro|anek|ekushey|bensen|charukola|lohit|akaash|mitra|sutonny|kohinoor bangla|noto (sans|serif) bengali/i;
    var cache = null, loading = null;

    function weightOf(style) {
        var s = String(style || '').toLowerCase().replace(/[\s-]/g, '');
        if (/thin|hairline/.test(s)) { return 100; }
        if (/extralight|ultralight/.test(s)) { return 200; }
        if (/semilight|light/.test(s)) { return 300; }
        if (/medium/.test(s)) { return 500; }
        if (/semibold|demibold/.test(s)) { return 600; }
        if (/extrabold|ultrabold/.test(s)) { return 800; }
        if (/black|heavy/.test(s)) { return 900; }
        if (/bold/.test(s)) { return 700; }
        return 400;
    }

    /* ---------- reading font files (fallback for AE < 24) ---------- */
    function readNames(file) {
        var fs = MK.require('fs'), Buffer = MK.require('buffer').Buffer;
        var out = [];
        var fd = fs.openSync(file, 'r');
        var rd = function (len, pos) { var b = Buffer.alloc(len); fs.readSync(fd, b, 0, len, pos); return b; };
        try {
            var head = rd(12, 0), offs = [0];
            if (head.toString('latin1', 0, 4) === 'ttcf') {
                var n = Math.min(64, head.readUInt32BE(8)), ob = rd(4 * n, 12);
                offs = [];
                for (var i = 0; i < n; i++) { offs.push(ob.readUInt32BE(4 * i)); }
            }
            offs.forEach(function (off) {
                var h = rd(12, off), nt = h.readUInt16BE(4);
                if (nt > 200) { return; }
                var dir = rd(16 * nt, off + 12), nameOff = -1, nameLen = 0, os2 = -1;
                for (var t = 0; t < nt; t++) {
                    var tag = dir.toString('latin1', t * 16, t * 16 + 4);
                    if (tag === 'name') { nameOff = dir.readUInt32BE(t * 16 + 8); nameLen = dir.readUInt32BE(t * 16 + 12); }
                    if (tag === 'OS/2') { os2 = dir.readUInt32BE(t * 16 + 8); }
                }
                if (nameOff < 0 || nameLen > 2000000) { return; }
                var nb = rd(nameLen, nameOff), count = nb.readUInt16BE(2), sOff = nb.readUInt16BE(4);
                var best = {};
                for (var r = 0; r < count; r++) {
                    var b = 6 + r * 12;
                    if (b + 12 > nb.length) { break; }
                    var pid = nb.readUInt16BE(b), lid = nb.readUInt16BE(b + 4), nid = nb.readUInt16BE(b + 6);
                    var len = nb.readUInt16BE(b + 8), so = nb.readUInt16BE(b + 10);
                    if ([1, 2, 4, 6, 16, 17].indexOf(nid) < 0) { continue; }
                    var score = pid === 3 && (lid === 0x409) ? 3 : (pid === 3 ? 2 : (pid === 1 && lid === 0 ? 1 : 0));
                    if (!score || (best[nid] && best[nid].s >= score)) { continue; }
                    var raw = nb.slice(sOff + so, sOff + so + len), str = '';
                    if (pid === 3 || pid === 0) { for (var k = 0; k + 1 < raw.length; k += 2) { str += String.fromCharCode(raw.readUInt16BE(k)); } }
                    else { str = raw.toString('latin1'); }
                    best[nid] = { s: score, v: str };
                }
                var g = function (id) { return best[id] ? best[id].v : ''; };
                var ps = g(6), family = g(16) || g(1), style = g(17) || g(2) || 'Regular';
                if (!ps || !family) { return; }
                var bangla = false;
                if (os2 > 0) { try { bangla = ((rd(4, os2 + 42).readUInt32BE(0) >>> 16) & 1) === 1; } catch (e) {} }
                out.push({ ps: ps, family: family, style: style, name: family + ' ' + style, bangla: bangla });
            });
        } finally { fs.closeSync(fd); }
        return out;
    }

    function fontDirs() {
        var path = MK.require('path'), home = MK.paths.home, env = MK.require('process').env || {};
        if (MK.isWin) {
            return [path.join(env.WINDIR || 'C:\\Windows', 'Fonts'), path.join(env.LOCALAPPDATA || path.join(home, 'AppData', 'Local'), 'Microsoft', 'Windows', 'Fonts'),
                path.join(env.APPDATA || path.join(home, 'AppData', 'Roaming'), 'Adobe', 'CoreSync', 'plugins', 'livetype', 'r')];
        }
        return ['/Library/Fonts', '/System/Library/Fonts', '/System/Library/Fonts/Supplemental', path.join(home, 'Library', 'Fonts'),
            path.join(home, 'Library', 'Application Support', 'Adobe', 'CoreSync', 'plugins', 'livetype', '.r')];
    }

    function scanSystem() {
        var out = [], seen = {};
        fontDirs().forEach(function (d) {
            (function walk(dir, depth) {
                MK.fs.list(dir).forEach(function (n) {
                    var p = MK.paths.join(dir, n);
                    if (/\.(ttf|otf|ttc|otc)$/i.test(n) || (/livetype/.test(dir) && /^\d+$|\.\w+$/.test(n) && !MK.fs.isDir(p))) {
                        try { readNames(p).forEach(function (f) { if (!seen[f.ps]) { seen[f.ps] = true; out.push(f); } }); } catch (e) {}
                    } else if (depth > 0 && MK.fs.isDir(p)) { walk(p, depth - 1); }
                });
            })(d, 2);
        });
        return out;
    }

    MK.fonts = {
        list: function () {
            if (cache) { return Promise.resolve(cache); }
            if (loading) { return loading; }
            loading = MK.host('app.listFonts', {}).catch(function () { return []; }).then(function (list) {
                var out = (list || []).map(function (f) {
                    var family = f[2] || String(f[1]).replace(/\s+\S+$/, ''), style = f[3] || '';
                    return { ps: f[0], family: family, style: style, name: f[1] };
                });
                if (!out.length && MK.hasNode) { out = scanSystem(); }
                out.forEach(function (f) { f.bangla = f.bangla || BANGLA.test(f.name) || BANGLA.test(f.ps); f.key = (f.name + ' ' + f.ps).toLowerCase(); });
                out.sort(function (a, b) { return a.name.localeCompare(b.name); });
                cache = out;
                loading = null;
                return out;
            });
            return loading;
        },
        weightOf: weightOf,
        css: function (f) {
            if (!f) { return ''; }
            return 'font-family:"' + String(f.family).replace(/"/g, '') + '", "' + String(f.ps).replace(/"/g, '') + '";font-weight:' + weightOf(f.style) + ';font-style:' + (/italic|oblique/i.test(f.style) ? 'italic' : 'normal');
        },
        find: function (ps) { return cache ? cache.filter(function (f) { return f.ps === ps; })[0] : null; },

        // modal picker → Promise<font|null>
        pick: function (current) {
            return new Promise(function (resolve) {
                var ov = document.createElement('div');
                ov.className = 'choice-overlay font-overlay';
                ov.innerHTML = '<div class="choice-box font-box"><div class="choice-title">' + MK.esc(MK.t('font.title')) + '</div>' +
                    '<input type="search" class="font-search" placeholder="' + MK.esc(MK.t('font.search')) + '">' +
                    '<div class="seg mini font-filter"><button data-f="all" class="active">' + MK.esc(MK.t('font.all')) + '</button><button data-f="bn">বাংলা</button><button data-f="recent">' + MK.esc(MK.t('font.recent')) + '</button></div>' +
                    '<div class="font-list"><div class="empty">' + MK.esc(MK.t('font.loading')) + '</div></div>' +
                    '<div class="row between"><span class="hint font-count"></span><button class="btn sm choice-cancel">' + MK.esc(MK.t('ui.cancel')) + '</button></div></div>';
                document.body.appendChild(ov);
                MK.lockScroll(true);
                setTimeout(function () { ov.classList.add('show'); }, 10);
                var input = ov.querySelector('.font-search'), listEl = ov.querySelector('.font-list'), filter = 'all', all = [];
                var close = function (val) {
                    MK.lockScroll(false);
                    ov.classList.remove('show');
                    setTimeout(function () { if (ov.parentNode) { ov.parentNode.removeChild(ov); } }, 160);
                    if (val) {
                        var rec = (MK.settings.fontRecent || []).filter(function (p) { return p !== val.ps; });
                        rec.unshift(val.ps);
                        MK.settings.fontRecent = rec.slice(0, 12);
                        MK.saveSettings();
                    }
                    resolve(val || null);
                };
                var draw = function () {
                    var q = input.value.trim().toLowerCase(), rec = MK.settings.fontRecent || [];
                    var words = q.split(/\s+/).filter(Boolean);
                    var src = all;
                    if (filter === 'bn') { src = all.filter(function (f) { return f.bangla; }); }
                    if (filter === 'recent') { src = rec.map(function (p) { return all.filter(function (f) { return f.ps === p; })[0]; }).filter(Boolean); }
                    var hits = src.filter(function (f) { return words.every(function (wd) { return f.key.indexOf(wd) >= 0; }); });
                    ov.querySelector('.font-count').textContent = hits.length + ' / ' + all.length;
                    var sample = filter === 'bn' ? 'আমার সোনার বাংলা' : '';
                    listEl.innerHTML = hits.length ? '' : '<div class="empty">' + MK.esc(MK.t('font.none')) + '</div>';
                    var frag = document.createDocumentFragment();
                    hits.slice(0, 250).forEach(function (f) {
                        var b = document.createElement('button');
                        b.className = 'font-row' + (f.ps === current ? ' active' : '');
                        b.innerHTML = '<span class="fr-sample" style=\'' + MK.fonts.css(f).replace(/'/g, '') + '\'></span><small></small>';
                        b.querySelector('.fr-sample').textContent = sample ? sample + '  ·  ' + f.name : f.name;
                        b.querySelector('small').textContent = f.ps + (f.bangla ? '  ·  বাংলা' : '');
                        b.onclick = function () { close(f); };
                        frag.appendChild(b);
                    });
                    listEl.appendChild(frag);
                };
                input.addEventListener('input', draw);
                MK.seg(ov.querySelector('.font-filter'), function (b) { filter = b.dataset.f; draw(); });
                ov.querySelector('.choice-cancel').onclick = function () { close(null); };
                ov.addEventListener('click', function (e) { if (e.target === ov) { close(null); } });
                ov.addEventListener('keydown', function (e) { if (e.key === 'Escape') { close(null); } });
                setTimeout(function () { input.focus(); }, 30);
                MK.fonts.list().then(function (list) {
                    all = list;
                    if (!all.length) { listEl.innerHTML = '<div class="empty">' + MK.esc(MK.t('font.noList')) + '</div>'; return; }
                    draw();
                    var act = listEl.querySelector('.active');
                    if (act && act.scrollIntoView) { act.scrollIntoView({ block: 'center' }); }
                });
            });
        }
    };

    MK._fonts = { readNames: readNames, weightOf: weightOf, BANGLA: BANGLA };
})(window);
