/* All In One — AI assistant (Gemini / Groq) */
(function (w) {
    'use strict';
    var MK = w.MK;

    var history = [];
    var mode = 'chat';

    var SYSTEM = [
        'You are the AI assistant inside "All In One", an Adobe After Effects panel made by Tanmoy Sharma.',
        'You are a senior motion designer and After Effects expression engineer.',
        'Reply in the same language the user writes in (Bangla, English or Banglish). Be concise and practical; use short steps.',
        'When you give an expression, put the complete expression in ONE ```javascript code block that works in the AE JavaScript expression engine.',
        'Never wrap expressions in functions that are not called; the last line must evaluate to the property value.',
        'If AE context JSON is provided, use it (layer names, property value dimensions, errors).'
    ].join(' ');

    function provider() { return MK.$('#aiProvider').value; }
    function model() { return MK.$('#aiModel').value; }
    function key(p) {
        var k = MK.settings.keys[p];
        if (!k) { throw new Error(MK.t('err.noKey', { name: p === 'groq' ? 'Groq' : 'Gemini' })); }
        return k;
    }

    /* ---------- providers ---------- */
    // messages: [{role:'user'|'assistant', text, image?:{mime,data}}]
    function complete(messages, opts) {
        opts = opts || {};
        var p = provider(), m = model();
        if (!m) { return Promise.reject(new Error(MK.t('a.noModel'))); }
        if (p === 'gemini') {
            var body = {
                systemInstruction: { parts: [{ text: opts.system || SYSTEM }] },
                contents: messages.map(function (x) {
                    var parts = [{ text: x.text }];
                    if (x.image) { parts.push({ inline_data: { mime_type: x.image.mime, data: x.image.data } }); }
                    return { role: x.role === 'assistant' ? 'model' : 'user', parts: parts };
                }),
                generationConfig: { temperature: opts.temperature === undefined ? 0.6 : opts.temperature }
            };
            if (opts.json) { body.generationConfig.responseMimeType = 'application/json'; }
            return MK.http.postJSON('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(m) + ':generateContent', body, { 'x-goog-api-key': key('gemini') }, 180000)
                .then(function (r) {
                    var c = r.candidates && r.candidates[0];
                    var txt = c && c.content && c.content.parts ? c.content.parts.map(function (pt) { return pt.text || ''; }).join('') : '';
                    if (!txt && r.promptFeedback && r.promptFeedback.blockReason) { throw new Error('Blocked: ' + r.promptFeedback.blockReason); }
                    return txt;
                });
        }
        var msgs = [{ role: 'system', content: opts.system || SYSTEM }].concat(messages.map(function (x) {
            if (x.image) {
                return { role: x.role, content: [{ type: 'text', text: x.text }, { type: 'image_url', image_url: { url: 'data:' + x.image.mime + ';base64,' + x.image.data } }] };
            }
            return { role: x.role, content: x.text };
        }));
        var gb = { model: m, messages: msgs, temperature: opts.temperature === undefined ? 0.6 : opts.temperature };
        if (opts.json) { gb.response_format = { type: 'json_object' }; }
        return MK.http.postJSON('https://api.groq.com/openai/v1/chat/completions', gb, { Authorization: 'Bearer ' + key('groq') }, 180000)
            .then(function (r) { return (r.choices && r.choices[0] && r.choices[0].message && r.choices[0].message.content) || ''; });
    }

    function loadModels(btn) {
        var p = provider();
        return MK.busy(btn, function () {
            var req = p === 'gemini'
                ? MK.http.get('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { 'x-goog-api-key': key('gemini') }).then(function (r) {
                    return (r.models || []).filter(function (x) {
                        return (x.supportedGenerationMethods || []).indexOf('generateContent') >= 0 && /gemini/i.test(x.name) && !/embed|tts|image|live|audio|robotics|omni/i.test(x.name);
                    }).map(function (x) { return x.name.replace(/^models\//, ''); });
                })
                : MK.http.get('https://api.groq.com/openai/v1/models', { Authorization: 'Bearer ' + key('groq') }).then(function (r) {
                    return (r.data || []).map(function (x) { return x.id; }).filter(function (id) { return !/whisper|tts|guard|playai|orpheus|distil|prompt/i.test(id); });
                });
            return req.then(function (list) {
                list.sort();
                MK.settings.ai[p + 'Models'] = list;
                MK.saveSettings();
                fillModels();
                MK.toast(MK.t('a.models', { n: list.length }));
            });
        });
    }

    function fillModels() {
        var p = provider(), sel = MK.$('#aiModel');
        var list = (MK.settings.ai[p + 'Models'] || []).slice(0);
        var cur = MK.settings.ai[p + 'Model'];
        if (p === 'gemini' && list.indexOf('gemini-flash-latest') < 0) { list.unshift('gemini-flash-latest'); }
        if (!cur && list.length) {
            var pref = [/gpt-oss-120b/, /llama-3\.3-70b/, /llama-4/, /flash-latest/, /flash/];
            for (var i = 0; i < pref.length && !cur; i++) { for (var j = 0; j < list.length; j++) { if (pref[i].test(list[j])) { cur = list[j]; break; } } }
            cur = cur || list[0];
        }
        if (cur && list.indexOf(cur) < 0) { list.unshift(cur); }
        sel.innerHTML = list.length ? list.map(function (m) { return '<option>' + MK.esc(m) + '</option>'; }).join('') : '<option value="">— ↻ —</option>';
        if (cur) { sel.value = cur; }
    }

    /* ---------- rendering ---------- */
    function md(src) {
        var blocks = [];
        var s = String(src).replace(/```([\w-]*)\n?([\s\S]*?)```/g, function (m, lang, code) {
            blocks.push({ lang: lang, code: code.replace(/\s+$/, '') });
            return '\u0000' + (blocks.length - 1) + '\u0000';
        });
        s = MK.esc(s)
            .replace(/`([^`\n]+)`/g, '<code>$1</code>')
            .replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
            .replace(/^#{1,4}\s*(.+)$/gm, '<b>$1</b>');
        var lines = s.split('\n'), html = '', list = null;
        lines.forEach(function (ln) {
            var ul = /^\s*[-*•]\s+(.*)/.exec(ln), ol = /^\s*\d+[.)]\s+(.*)/.exec(ln);
            if (ul || ol) {
                var tag = ul ? 'ul' : 'ol';
                if (list !== tag) { if (list) { html += '</' + list + '>'; } html += '<' + tag + '>'; list = tag; }
                html += '<li>' + (ul || ol)[1] + '</li>';
                return;
            }
            if (list) { html += '</' + list + '>'; list = null; }
            if (ln.trim()) { html += '<p>' + ln + '</p>'; }
        });
        if (list) { html += '</' + list + '>'; }
        html = html.replace(/<p>\u0000(\d+)\u0000<\/p>|\u0000(\d+)\u0000/g, function (m, a, b) {
            var i = +(a || b);
            return '<pre data-code="' + i + '"><code>' + MK.esc(blocks[i].code) + '</code></pre>';
        });
        return { html: html, blocks: blocks };
    }

    function add(role, text, extra) {
        var log = MK.$('#aiLog');
        var el = document.createElement('div');
        el.className = 'msg ' + role;
        if (role === 'bot') {
            var out = md(text), blocks = out.blocks;
            el.innerHTML = out.html;
            MK.$$('pre[data-code]', el).forEach(function (pre) {
                var code = blocks[+pre.dataset.code].code;
                var bar = document.createElement('div');
                bar.className = 'code-actions';
                var copy = document.createElement('button');
                copy.className = 'btn sm'; copy.textContent = MK.t('ui.copy');
                copy.onclick = function () { MK.copy(code); MK.toast(MK.t('ok.copied')); };
                var apply = document.createElement('button');
                apply.className = 'btn sm primary'; apply.textContent = MK.t('a.applyExpr');
                apply.onclick = function () {
                    MK.run(apply, 'quick.applyExpression', { code: code }, function (r) {
                        return r.errors && r.errors.length ? MK.t('a.exprErr', { e: r.errors[0] }) : MK.t('a.exprApplied', { n: r.count });
                    });
                };
                bar.appendChild(apply); bar.appendChild(copy);
                pre.parentNode.insertBefore(bar, pre.nextSibling);
            });
        } else {
            el.textContent = text;
        }
        if (extra) { el.appendChild(extra); }
        log.appendChild(el);
        log.scrollTop = log.scrollHeight;
        return el;
    }

    function thinking() {
        var el = add('sys', '');
        el.innerHTML = MK.esc(MK.t('a.thinking')) + '<span class="typing"></span>';
        return el;
    }

    function context() {
        if (!MK.$('#aiCtx').checked) { return Promise.resolve(''); }
        return MK.host('ai.getContext', {}).then(function (c) { return '\n\n[AE context]\n' + JSON.stringify(c); }, function () { return ''; });
    }

    /* ---------- modes ---------- */
    var handlers = {
        chat: function (text) {
            return context().then(function (ctx) {
                history.push({ role: 'user', text: text + ctx });
                return complete(history.slice(-16)).then(function (ans) {
                    history[history.length - 1].text = text; // keep history light
                    history.push({ role: 'assistant', text: ans });
                    add('bot', ans);
                });
            });
        },
        expr: function (text) {
            return context().then(function (ctx) {
                var prompt = 'Write an After Effects expression for this request:\n' + text +
                    '\nIf AE context shows the selected property, match its value dimensions. Give one ```javascript block, then 1-3 short lines on how to tweak it.' + ctx;
                return complete([{ role: 'user', text: prompt }], { temperature: 0.3 }).then(function (a) { add('bot', a); });
            });
        },
        fix: function (text) {
            return MK.host('ai.getSelectedExpression', {}).then(function (sel) {
                if (!sel.expression) { throw new Error(MK.t('a.needSel')); }
                var prompt = 'Fix this After Effects expression.\nProperty: ' + sel.name + ' (' + sel.matchName + ') on layer "' + sel.layer + '"\n' +
                    'AE error: ' + (sel.error || '(none reported)') + '\n' + (text ? 'User note: ' + text + '\n' : '') +
                    'Expression:\n```javascript\n' + sel.expression + '\n```\nReturn the corrected full expression in one ```javascript block and one line explaining the bug.';
                return complete([{ role: 'user', text: prompt }], { temperature: 0.2 }).then(function (a) { add('bot', a); });
            });
        },
        translate: function (text) {
            var target = MK.$('#aiTarget').value;
            return MK.host('ai.getTexts', {}).then(function (items) {
                add('sys', MK.t('a.gotText', { n: items.length }));
                var prompt = 'Translate each string to ' + target + ' for on-screen video text. Keep line breaks (\\r), keep it short and natural, keep emojis/numbers.' +
                    (text ? ' Extra instruction: ' + text : '') +
                    '\nReturn ONLY a JSON object {"items": [..translated strings in the same order..]}.\n' + JSON.stringify(items.map(function (i) { return i.text; }));
                return complete([{ role: 'user', text: prompt }], { temperature: 0.2, json: true }).then(function (a) {
                    var arr;
                    try { arr = JSON.parse(a.replace(/^```(json)?|```$/g, '').trim()).items; } catch (e) { arr = null; }
                    if (!arr || !arr.length) { add('bot', a); return; }
                    var view = document.createElement('div');
                    view.innerHTML = '<ol>' + arr.map(function (s) { return '<li>' + MK.esc(String(s).replace(/\r/g, ' / ')) + '</li>'; }).join('') + '</ol>';
                    var b = document.createElement('button');
                    b.className = 'btn sm primary'; b.textContent = MK.t('a.applyText');
                    b.onclick = function () {
                        MK.run(b, 'ai.setTexts', { items: items.map(function (it, i) { return { index: it.index, text: String(arr[i] === undefined ? it.text : arr[i]) }; }), duplicate: MK.$('#aiDup').checked, tag: target });
                    };
                    view.appendChild(b);
                    var el = add('bot', '**' + target + '**');
                    el.appendChild(view);
                });
            });
        },
        hooks: function (text) {
            var kind = MK.$('#aiHookKind').value, plat = MK.$('#aiPlatform').value, lang = MK.$('#aiOutLang').value;
            var ask = {
                hooks: 'Write 10 scroll-stopping opening hook lines (max 12 words each)',
                ideas: 'Give 8 short-form video ideas, each with a one-line concept, a hook and a suggested After Effects visual style',
                script: 'Write a 30-45 second video script with on-screen text lines and simple shot / motion notes',
                titles: 'Write 10 punchy video titles plus 5 caption/description lines with relevant hashtags'
            }[kind];
            var prompt = ask + ' for ' + plat + ' about: "' + text + '". Write in ' + lang + '. Format as a numbered list.';
            return complete([{ role: 'user', text: prompt }], { temperature: 0.9 }).then(function (a) { add('bot', a); });
        },
        review: function (text) {
            var path = MK.paths.join(MK.paths.temp, 'review_' + Date.now() + '.png');
            MK.fs.mkdirp(MK.paths.temp);
            add('sys', MK.t('a.capturing'));
            return MK.host('ai.captureFrame', { path: path }).then(function (r) {
                var data = MK.require('fs').readFileSync(r.path).toString('base64');
                try { MK.require('fs').unlinkSync(r.path); } catch (e) {}
                var prompt = 'Review this After Effects frame like a senior motion designer: composition, hierarchy, typography, colour/contrast, readability on phones, safe areas. ' +
                    'Give the 5 most useful concrete fixes (with AE how-to). ' + (text ? 'Context from the user: ' + text : '');
                return complete([{ role: 'user', text: prompt, image: { mime: 'image/png', data: data } }], { temperature: 0.4 }).then(function (a) { add('bot', a); });
            });
        }
    };

    function send() {
        var inp = MK.$('#aiInput');
        var text = inp.value.trim();
        if (!text && (mode === 'chat' || mode === 'expr' || mode === 'hooks')) { inp.focus(); return; }
        if (text) { add('user', text); }
        inp.value = '';
        var t = thinking();
        MK.busy(MK.$('#aiSend'), function () {
            return handlers[mode](text).catch(function (e) { add('err', MK.errText(e)); throw e; });
        }).then(function () { t.remove(); });
    }

    MK.initAI = function () {
        MK.$('#aiProvider').value = MK.settings.ai.provider || 'gemini';
        fillModels();
        MK.$('#aiProvider').addEventListener('change', function () { MK.settings.ai.provider = this.value; MK.saveSettings(); fillModels(); });
        MK.$('#aiModel').addEventListener('change', function () { MK.settings.ai[provider() + 'Model'] = this.value; MK.saveSettings(); });
        MK.$('#aiLoadModels').onclick = function () { loadModels(this); };
        MK.seg(MK.$('#aiModes'), function (b) {
            mode = b.dataset.mode;
            MK.$$('#tab-ai .ai-opts').forEach(function (o) { o.classList.toggle('show', o.dataset.for === mode); });
            MK.$('#aiCtxWrap').classList.toggle('hidden', !(mode === 'chat' || mode === 'expr'));
            var hint = MK.t('a.hint.' + mode);
            if (hint !== 'a.hint.' + mode) { add('sys', hint); }
        });
        MK.$('#aiSend').onclick = send;
        MK.$('#aiInput').addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } });
        MK.$('#aiClear').onclick = function () {
            history = [];
            MK.$('#aiLog').innerHTML = '';
            add('sys', MK.t('a.hint.' + mode) !== 'a.hint.' + mode ? MK.t('a.hint.' + mode) : '');
        };
    };

    MK._ai = { md: md, add: add };
})(window);
