/* All In One — Tools tab: layers, arrange, shapes, rigs, looks, comp, export (ffmpeg), auto podcast */
(function (w) {
    'use strict';
    var MK = w.MK;

    function num(id, d) { var v = parseFloat(MK.$(id).value); return isNaN(v) ? d : v; }
    function palette() {
        return MK.$$('#xPalette input').map(function (i) { return MK.hexToRgb01(i.value); });
    }

    var actions = {
        trimToBelow: function (b) { return MK.run(b, 'tools.trimToBelow', {}); },
        randomOrder: function (b) { return MK.run(b, 'tools.randomOrder', {}); },
        invertSelection: function (b) { return MK.run(b, 'tools.invertSelection', {}); },
        randomIn: function (b) { return MK.run(b, 'tools.randomIn', { frames: num('#xFrames', 10) }); },
        fadeBoth: function (b) { return MK.run(b, 'tools.fade', { frames: num('#xFrames', 10), mode: 'both' }); },
        fadeIn: function (b) { return MK.run(b, 'tools.fade', { frames: num('#xFrames', 10), mode: 'in' }); },
        fadeOut: function (b) { return MK.run(b, 'tools.fade', { frames: num('#xFrames', 10), mode: 'out' }); },
        selectEvery: function (b) { return MK.run(b, 'tools.selectEvery', { n: num('#xEvery', 2) }); },
        reorderCenter: function (b) { return MK.run(b, 'tools.reorderByDistance', { from: 'center' }); },
        reorderFirst: function (b) { return MK.run(b, 'tools.reorderByDistance', { from: 'first' }); },

        grid: function (b) { return MK.run(b, 'tools.grid', { cols: num('#xCols', 3), gap: num('#xGap', 40) }); },
        layoutRow: function (b) { return MK.run(b, 'tools.autoLayout', { dir: 'row', gap: num('#xGap', 40) }, function (r) { return MK.t('x.layoutDone', { name: r.name }); }); },
        layoutCol: function (b) { return MK.run(b, 'tools.autoLayout', { dir: 'column', gap: num('#xGap', 40) }, function (r) { return MK.t('x.layoutDone', { name: r.name }); }); },
        circle: function (b) { return MK.run(b, 'tools.circle', { radius: num('#xRadius', 350), rotate: MK.$('#xFace').checked }); },
        randomPosition: function (b) { return MK.run(b, 'tools.randomPosition', { x: num('#xDX', 100), y: num('#xDY', 100) }); },
        stepOffset: function (b) { return MK.run(b, 'tools.stepOffset', { x: num('#xDX', 100), y: num('#xDY', 100) }); },

        capButt: function (b) { return MK.run(b, 'tools.strokeCap', { cap: 'butt' }); },
        capRound: function (b) { return MK.run(b, 'tools.strokeCap', { cap: 'round' }); },
        capSquare: function (b) { return MK.run(b, 'tools.strokeCap', { cap: 'projecting' }); },
        trimPaths: function (b) { return MK.run(b, 'tools.trimPaths', { animate: MK.$('#xTrimAnim').checked, duration: 1 }); },
        vectorToShapes: function (b) { return MK.run(b, 'tools.vectorToShapes', {}); },
        explodeShapes: function (b) { return MK.run(b, 'tools.explodeShapes', {}); },
        mergeShapes: function (b) { return MK.run(b, 'tools.mergeShapes', {}); },
        removeEmptyGroups: function (b) { return MK.run(b, 'tools.removeEmptyGroups', {}); },
        taper: function (b) { return MK.run(b, 'tools.taper', { start: num('#xTaperS', 30), end: num('#xTaperE', 30), ease: num('#xTaperEase', 50) }); },

        bounceBack: function (b) { return MK.run(b, 'tools.bounceBack', {}, function (r) { return MK.t('x.rigDone', { n: r.count, name: 'AIO Bounce Control' }); }); },
        randomizer: function (b) { return MK.run(b, 'tools.randomizer', { amount: 50 }, function (r) { return MK.t('x.rigDone', { n: r.count, name: 'AIO Random Control' }); }); },
        loopPrecomp: function (b) { return MK.run(b, 'tools.loopPrecomp', {}); },
        effector: function (b) { return MK.run(b, 'tools.effector', {}, function (r) { return MK.t('x.rigDone', { n: r.count, name: r.name }); }); },
        connect: function (b) { return MK.run(b, 'tools.connect', {}, function (r) { return MK.t('x.rigDone', { n: r.count, name: r.name }); }); },
        cameraRig: function (b) { return MK.run(b, 'tools.cameraRig', {}, function (r) { return MK.t('x.made', { name: r.name }); }); },
        paletteCreate: function (b) {
            MK.settings.palette = MK.$$('#xPalette input').map(function (i) { return i.value; });
            MK.saveSettings();
            return MK.run(b, 'tools.paletteCreate', { colors: palette() }, function (r) { return MK.t('x.made', { name: r.name }); });
        },
        paletteLink: function (b) { return MK.run(b, 'tools.paletteLink', { slot: +MK.$('#xSlot').value }); },

        glassStyle: function (b) { return MK.run(b, 'tools.glassStyle', {}); },
        liquidGlass: function (b) { return MK.run(b, 'tools.liquidGlass', { shape: 'rect' }, function (r) { return MK.t('x.made', { name: r.name }); }); },
        glitch: function (b) { return MK.run(b, 'tools.glitch', { amount: 50 }, function (r) { return MK.t('x.made', { name: r.name }); }); },
        vignette: function (b) { return MK.run(b, 'tools.vignette', { amount: 60, feather: 40 }, function (r) { return MK.t('x.made', { name: r.name }); }); },

        precompTrim: function (b) { return MK.run(b, 'tools.precompTrim', {}, function (r) { return MK.t('ok.precomp', { name: r.name }); }); },
        sourceName: function (b) { return MK.run(b, 'tools.sourceToLayerName', {}); },
        purge: function (b) { return MK.run(b, 'tools.purge', {}, function () { return MK.t('x.purged'); }); },
        extendComp: function (b) { return MK.run(b, 'tools.extendComp', { seconds: num('#xSeconds', 5) }, function (r) { return MK.t('x.extended', { s: r.duration.toFixed(2) }); }); },

        podcast: function (b) {
            return MK.run(b, 'podcast.run', { minShot: num('#xMinShot', 2), threshold: num('#xThr', 20), wide: MK.$('#xWide').checked },
                function (r) { return MK.t('x.podcastDone', { n: r.cuts, c: r.cameras }); });
        }
    };

    /* ======================= ffmpeg ======================= */
    var FF = {
        exe: function () { return MK.isWin ? 'ffmpeg.exe' : 'ffmpeg'; },
        local: function () { return MK.paths.join(MK.paths.data, 'ffmpeg', FF.exe()); },
        find: function () {
            if (!MK.hasNode) { return ''; }
            var list = [];
            if (MK.settings.ffmpeg) { list.push(MK.settings.ffmpeg); }
            list.push(FF.local());
            if (MK.isWin) { list.push('C:\\ffmpeg\\bin\\ffmpeg.exe', 'C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe'); }
            else { list.push('/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/usr/bin/ffmpeg'); }
            for (var i = 0; i < list.length; i++) { if (list[i] && MK.fs.exists(list[i])) { return list[i]; } }
            try {
                var out = MK.require('child_process').execSync(MK.isWin ? 'where ffmpeg' : 'command -v ffmpeg', { encoding: 'utf8', timeout: 4000, windowsHide: true });
                var first = String(out).split(/\r?\n/)[0].trim();
                if (first && MK.fs.exists(first)) { return first; }
            } catch (e) {}
            return '';
        },
        status: function () {
            var p = FF.find();
            MK.$('#xFfStatus').textContent = 'ffmpeg: ' + (p ? '✓ ' + p : MK.t('x.ffMissing'));
            return p;
        },
        run: function (args, durSec, onProgress) {
            return new Promise(function (resolve, reject) {
                var bin = FF.find();
                if (!bin) { return reject(new Error(MK.t('x.ffNeeded'))); }
                var cp = MK.require('child_process');
                var p = cp.spawn(bin, args, { windowsHide: true });
                var tail = '';
                p.stderr.on('data', function (d) {
                    var s = d.toString();
                    tail = (tail + s).slice(-1500);
                    var m = /time=(\d+):(\d+):([\d.]+)/.exec(s);
                    if (m && onProgress && durSec) { onProgress(Math.min(1, ((+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3])) / durSec)); }
                });
                p.on('error', reject);
                p.on('close', function (code) { if (code === 0) { resolve(); } else { reject(new Error('ffmpeg: ' + tail.split(/\r?\n/).filter(Boolean).slice(-2).join(' '))); } });
            });
        },
        // media duration in seconds (ffmpeg -i prints it to stderr and exits with an error)
        probe: function (file) {
            return new Promise(function (resolve, reject) {
                var bin = FF.find();
                if (!bin) { return reject(new Error(MK.t('x.ffNeeded'))); }
                var p = MK.require('child_process').spawn(bin, ['-hide_banner', '-i', file], { windowsHide: true });
                var err = '';
                p.stderr.on('data', function (d) { err += d.toString(); });
                p.on('error', reject);
                p.on('close', function () {
                    var m = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec(err);
                    resolve(m ? (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]) : 0);
                });
            });
        },
        download: function (btn, barEl) {
            var bar = barEl || MK.$('#xProgress');
            return MK.busy(btn, function () {
                var path = MK.require('path'), fs = MK.require('fs'), cp = MK.require('child_process');
                var url = MK.isWin ? 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip'
                                   : 'https://evermeet.cx/ffmpeg/getrelease/zip';
                var tmp = MK.paths.join(MK.paths.temp, 'ffmpeg-dl');
                MK.fs.mkdirp(tmp);
                var zip = MK.paths.join(tmp, 'ffmpeg.zip');
                MK.progress(bar, 0, MK.t('x.ffDownloading', { p: 0 }));
                return MK.http.download(url, zip, function (f) { MK.progress(bar, f, MK.t('x.ffDownloading', { p: Math.round(f * 100) })); })
                    .then(function () {
                        MK.progress(bar, null, MK.t('x.ffUnpacking'));
                        var out = MK.paths.join(tmp, 'x');
                        MK.fs.mkdirp(out);
                        if (MK.isWin) {
                            cp.execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
                                "Expand-Archive -LiteralPath '" + zip.replace(/'/g, "''") + "' -DestinationPath '" + out.replace(/'/g, "''") + "' -Force"], { windowsHide: true, timeout: 600000 });
                        } else {
                            cp.execFileSync('/usr/bin/unzip', ['-o', zip, '-d', out], { timeout: 600000 });
                        }
                        var found = '';
                        (function walk(d) {
                            MK.fs.list(d).forEach(function (f) {
                                var full = path.join(d, f);
                                if (found) { return; }
                                if (MK.fs.isDir(full)) { walk(full); } else if (f === FF.exe()) { found = full; }
                            });
                        })(out);
                        if (!found) { throw new Error('ffmpeg not found in the download'); }
                        MK.fs.mkdirp(path.dirname(FF.local()));
                        fs.copyFileSync(found, FF.local());
                        if (!MK.isWin) { fs.chmodSync(FF.local(), 493); }
                        MK.settings.ffmpeg = FF.local();
                        MK.saveSettings();
                        MK.progressHide(bar);
                        FF.status();
                        MK.toast(MK.t('x.ffReady'));
                    });
            }).then(function () { MK.progressHide(bar); });
        }
    };
    MK.ffmpeg = FF;

    /* ======================= export ======================= */
    var lastDir = '';
    function stamp() {
        var d = new Date(), p = function (n) { return (n < 10 ? '0' : '') + n; };
        return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
    }
    function safe(s) { return String(s).replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, '_').slice(0, 60) || 'comp'; }
    function fmt() { return MK.segValue(MK.$('#xFmt'), 'data-f') || 'gif'; }
    function showFmt() {
        var f = fmt();
        MK.$$('#tab-tools .xf').forEach(function (el) { el.classList.toggle('show', el.dataset.for === f); });
    }
    function rm(p) { try { if (p && MK.fs.exists(p)) { MK.require('fs').unlinkSync(p); } } catch (e) {} }

    function doExport(btn) {
        var bar = MK.$('#xProgress');
        var f = fmt(), range = MK.$('#xRange').value;
        return MK.busy(btn, function () {
            var info, dir, base;
            return MK.host('exporter.getCompInfo', {}).then(function (i) {
                info = i;
                return MK.host('exporter.getOutDir', {});
            }).then(function (d) {
                dir = d; lastDir = d;
                base = safe(info.name) + '_' + stamp();
                var dur = range === 'work' ? info.workDuration : info.duration;
                var tmp = MK.paths.join(MK.paths.temp, base + '_tmp');
                var render = function (kind, path) {
                    if (!MK.hasNode) { throw new Error(MK.t('x.needNode')); }
                    MK.fs.mkdirp(MK.paths.temp);
                    MK.progress(bar, null, MK.t('x.rendering'));
                    return MK.host('exporter.render', { kind: kind, path: path, range: range });
                };
                if (f === 'png' && MK.$('#xPngMode').value === 'frame') {
                    return MK.host('exporter.frame', { path: MK.paths.join(dir, base + '.png') }).then(function (r) { return r.path; });
                }
                if (f === 'png') {
                    var seqDir = MK.paths.join(dir, base);
                    if (MK.hasNode) { MK.fs.mkdirp(seqDir); }
                    return render('png', MK.paths.join(seqDir, base + '_[#####].png')).then(function () { return seqDir; });
                }
                if (f === 'mp4') {
                    return render('h264', MK.paths.join(dir, base + '.mp4')).then(function (r) { return r.path; }, function (e) {
                        if (!/NO_TEMPLATE/.test(e.message)) { throw e; }
                        if (!FF.find()) { throw new Error(MK.t('x.ffNeeded')); }
                        return render('lossless', tmp).then(function (r) {
                            MK.progress(bar, 0, MK.t('x.converting'));
                            var out = MK.paths.join(dir, base + '.mp4');
                            return FF.run(['-y', '-i', r.path, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-preset', 'medium', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out], dur,
                                function (p) { MK.progress(bar, p, MK.t('x.converting')); }).then(function () { rm(r.path); return out; });
                        });
                    });
                }
                if (!FF.find()) { throw new Error(MK.t('x.ffNeeded')); }
                if (f === 'mp3') {
                    return render('audio', tmp).then(function (r) {
                        var out = MK.paths.join(dir, base + '.mp3');
                        MK.progress(bar, 0, MK.t('x.converting'));
                        return FF.run(['-y', '-i', r.path, '-codec:a', 'libmp3lame', '-q:a', '2', out], dur, function (p) { MK.progress(bar, p, MK.t('x.converting')); })
                            .then(function () { rm(r.path); return out; });
                    });
                }
                // GIF: lossless render → palette-optimised GIF
                return render('lossless', tmp).then(function (r) {
                    var out = MK.paths.join(dir, base + '.gif');
                    var fps = Math.max(1, Math.min(60, num('#xFps', 15))), wd = Math.max(64, num('#xWidth', 720));
                    MK.progress(bar, 0, MK.t('x.converting'));
                    var vf = 'fps=' + fps + ',scale=' + Math.round(wd) + ':-2:flags=lanczos,split[s0][s1];[s0]palettegen=stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=4';
                    return FF.run(['-y', '-i', r.path, '-vf', vf, '-loop', MK.$('#xLoop').checked ? '0' : '-1', out], dur,
                        function (p) { MK.progress(bar, p, MK.t('x.converting')); }).then(function () { rm(r.path); return out; });
                });
            }).then(function (path) {
                MK.progressHide(bar);
                MK.toast(MK.t('x.exported', { path: String(path).split(/[\\/]/).pop() }));
            });
        }).then(function () { MK.progressHide(bar); });
    }

    /* ======================= init ======================= */
    MK.initTools = function () {
        MK.$$('#tab-tools [data-x]').forEach(function (btn) {
            btn.addEventListener('click', function () { var fn = actions[btn.dataset.x]; if (fn) { fn(btn); } });
        });
        // palette swatches (remembered)
        var cols = MK.settings.palette || ['#ff2d55', '#ffb03b', '#2fbf71', '#2d9cff', '#ffffff'];
        MK.$('#xPalette').innerHTML = cols.map(function (c) { return '<input type="color" value="' + MK.esc(c) + '">'; }).join('');
        // export
        MK.seg(MK.$('#xFmt'), showFmt);
        showFmt();
        MK.$('#xExport').onclick = function () { doExport(this); };
        MK.$('#xOpenOut').onclick = function () {
            (lastDir ? Promise.resolve(lastDir) : MK.host('exporter.getOutDir', {})).then(function (d) { return MK.host('app.openFolder', { path: d }); }).catch(MK.fail);
        };
        MK.$('#xFfDownload').onclick = function () { FF.download(this); };
        MK.$('#xFfPick').onclick = function () {
            MK.host('app.chooseFile', { title: 'Choose ffmpeg', filter: MK.isWin ? 'ffmpeg:ffmpeg.exe' : '' }).then(function (p) {
                if (!p) { return; }
                MK.settings.ffmpeg = p; MK.saveSettings(); FF.status();
            }).catch(MK.fail);
        };
        MK.tabs.onShow.tools = function () { FF.status(); };

        // Ease tab: key tools
        MK.$$('[data-ek]').forEach(function (b) {
            b.onclick = function () {
                var k = b.dataset.ek;
                if (k === 'reverse') { MK.run(b, 'ease.reverseKeys', {}); return; }
                MK.run(b, 'ease.keysToPlayhead', { clone: k !== 'move', reverse: k === 'cloneRev' });
            };
        });
        // Text tab: scramble
        MK.$('#tbScramble').onclick = function () { MK.run(this, 'tools.scramble', { duration: num('#tbScrDur', 1) }); };
    };
})(window);
