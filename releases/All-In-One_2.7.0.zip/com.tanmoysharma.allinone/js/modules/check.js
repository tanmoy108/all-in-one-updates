/* All In One — Tools ▸ Copyright check (music recognition + source audit) and HDR → Rec.709 */
(function (w) {
    'use strict';
    var MK = w.MK;

    function esc(s) { return MK.esc(String(s === undefined || s === null ? '' : s)); }
    function key(k) { return ((MK.settings.keys || {})[k] || '').trim(); }
    function tc(t) {
        t = Math.max(0, t);
        var m = Math.floor(t / 60), s = Math.floor(t % 60);
        return m + ':' + (s < 10 ? '0' : '') + s;
    }
    function norm(s) { return String(s || '').toLowerCase().replace(/\(.*?\)|\[.*?\]|feat\..*$|ft\..*$/g, '').replace(/[^a-z0-9ঀ-৿]+/g, ' ').trim(); }

    /* ======================= COPYRIGHT ======================= */
    var CR = { stop: false };

    // where a file came from → risk
    function classify(it) {
        var p = String(it.path || '').replace(/\\/g, '/'), n = (it.name + ' ' + p).toLowerCase();
        if (/\/all in one\/youtube\//i.test(p) || /\[[\w-]{11}\]/.test(it.name) || /y2mate|savefrom|ssyoutube|snaptik|ytmp3|tiktok|instagram|facebook|fbdown|4kdownload/.test(n)) {
            return { risk: 'high', why: MK.t('cr.src.yt') };
        }
        if (/official (music )?video|official audio|lyrics?|lyrical|\bremix\b|\bslowed\b|\breverb\b|\bft\.|\bfeat\./.test(n)) {
            return { risk: 'high', why: MK.t('cr.src.song') };
        }
        if (/\/all in one\/b-roll\/|all in one b-roll|pixabay|pexels|unsplash/i.test(n)) { return { risk: 'ok', why: MK.t('cr.src.stock') }; }
        if (/\/all in one\/sfx\//i.test(p) || /freesound/.test(n)) { return { risk: 'low', why: MK.t('cr.src.sfx') }; }
        if (/envato|videohive|audiojungle|motionarray|artlist|epidemic|musicbed|storyblocks/.test(n)) { return { risk: 'lic', why: MK.t('cr.src.lic') }; }
        if (it.audio && !it.video && /\.(mp3|m4a|wav|aac|flac|ogg|aiff?)$/i.test(p)) { return { risk: 'check', why: MK.t('cr.src.music') }; }
        return { risk: 'ok', why: MK.t('cr.src.own') };
    }

    // RMS of a 16-bit mono WAV buffer (header 44 bytes)
    function rms(buf) {
        var n = (buf.length - 44) >> 1, acc = 0;
        if (n <= 0) { return 0; }
        for (var i = 0; i < n; i++) { var v = buf.readInt16LE(44 + i * 2) / 32768; acc += v * v; }
        return Math.sqrt(acc / n);
    }

    function audd(wav) {
        return MK.http.multipart('https://api.audd.io/', [['api_token', key('audd')], ['return', 'spotify,apple_music']],
            { field: 'file', name: 'sample.wav', type: 'audio/wav', buffer: wav }, 60000).then(function (r) {
            if (r && r.status === 'error') {
                var e = new Error('AudD: ' + ((r.error && r.error.error_message) || 'error'));
                e.fatal = r.error && /token|limit|exceed|subscription|payment|90[0-9]/i.test(String(r.error.error_code) + ' ' + r.error.error_message);
                throw e;
            }
            var x = r && r.result;
            if (!x) { return null; }
            return { title: x.title, artist: x.artist, album: x.album, label: x.label, date: x.release_date, link: x.song_link || (x.spotify && x.spotify.external_urls && x.spotify.external_urls.spotify) || '' };
        });
    }

    function acr(wav) {
        var crypto = MK.require('crypto');
        var host = key('acrHost').replace(/^https?:\/\//, '').replace(/\/.*$/, ''), ak = key('acrKey'), sk = key('acrSecret');
        var ts = String(Math.floor(Date.now() / 1000));
        var sig = crypto.createHmac('sha1', sk).update(['POST', '/v1/identify', ak, 'audio', '1', ts].join('\n')).digest('base64');
        return MK.http.multipart('https://' + host + '/v1/identify',
            [['access_key', ak], ['sample_bytes', String(wav.length)], ['timestamp', ts], ['signature', sig], ['data_type', 'audio'], ['signature_version', '1']],
            { field: 'sample', name: 'sample.wav', type: 'audio/wav', buffer: wav }, 60000).then(function (r) {
            var st = (r && r.status) || {};
            if (st.code === 1001) { return null; }
            if (st.code !== 0) { var e = new Error('ACRCloud: ' + (st.msg || 'error') + ' (' + st.code + ')'); e.fatal = st.code >= 3000; throw e; }
            var m = r.metadata && r.metadata.music && r.metadata.music[0];
            if (!m) { return null; }
            var em = m.external_metadata || {}, link = '';
            if (em.spotify && em.spotify.track && em.spotify.track.id) { link = 'https://open.spotify.com/track/' + em.spotify.track.id; }
            else if (em.youtube && em.youtube.vid) { link = 'https://www.youtube.com/watch?v=' + em.youtube.vid; }
            return { title: m.title, artist: (m.artists || []).map(function (x) { return x.name; }).join(', '), album: m.album && m.album.name, label: m.label, date: m.release_date, score: m.score, link: link };
        });
    }

    function engine() { return MK.$('#crEngine').value; }
    function hasKey(e) { return e === 'acr' ? !!(key('acrHost') && key('acrKey') && key('acrSecret')) : !!key('audd'); }

    // merge neighbouring samples of the same song
    function merge(found, step, len) {
        var out = [];
        found.forEach(function (f) {
            var k = norm(f.m.title) + '|' + norm(f.m.artist), last = out[out.length - 1];
            if (last && last.k === k && f.t - last.lastT <= step * 1.6) { last.end = f.t + len; last.lastT = f.t; last.n++; return; }
            out.push({ k: k, start: f.t, end: f.t + len, lastT: f.t, n: 1, m: f.m });
        });
        return out;
    }

    function musicScan(bar) {
        var e = engine(), path = MK.require('path'), fs = MK.require('fs');
        var step = +MK.$('#crDensity').value || 20, len = 10;
        MK.fs.mkdirp(MK.paths.temp);
        var out = path.join(MK.paths.temp, 'aio-copyright-' + Date.now());
        MK.progress(bar, null, MK.t('cr.rendering'));
        return MK.host('cr.renderCompAudio', { out: out, range: MK.segValue(MK.$('#crRange'), 'data-v') || 'work' }, { timeout: 1800000 }).then(function (r) {
            var info = MK._pcm.info(r.path), times = [];
            var cleanup = function () { try { fs.closeSync(info.fd); } catch (e1) {} try { fs.unlinkSync(r.path); } catch (e2) {} };
            for (var t = 0; t + 4 <= info.duration; t += step) { times.push(t); }
            if (!times.length && info.duration > 1) { times.push(0); }
            var found = [], asked = 0, silent = 0, i = 0, errors = [];
            var next = function () {
                if (CR.stop) { return Promise.resolve(); }
                if (i >= times.length) { return Promise.resolve(); }
                var t0 = times[i++];
                var wav = MK._pcm.chunk(info, t0, Math.min(info.duration, t0 + len));
                MK.progress(bar, i / times.length, MK.t('cr.listening', { i: i, n: times.length, t: tc(r.start + t0) }));
                if (rms(wav) < 0.003) { silent++; return next(); }
                asked++;
                return (e === 'acr' ? acr(wav) : audd(wav)).then(function (m) {
                    if (m && m.title) { found.push({ t: r.start + t0, m: m }); }
                    return next();
                }, function (err) {
                    errors.push(err.message);
                    if (err.fatal || errors.length >= 3) { throw err; }
                    return next();
                });
            };
            return next().then(function () { cleanup(); return { hits: merge(found, step, len), asked: asked, silent: silent, total: times.length, errors: errors, start: r.start, dur: r.duration }; },
                function (err) { cleanup(); throw err; });
        });
    }

    function renderResult(res, src) {
        var box = MK.$('#crResult'), html = '';
        var high = src.filter(function (s) { return s.c.risk === 'high'; }), check = src.filter(function (s) { return s.c.risk === 'check' || s.c.risk === 'lic'; });
        var level = res && res.hits.length ? 'bad' : (high.length ? 'bad' : (check.length || !res ? 'warn' : 'good'));
        var head;
        if (res && res.hits.length) { head = MK.t('cr.v.songs', { n: res.hits.length }); }
        else if (high.length) { head = MK.t('cr.v.risky', { n: high.length }); }
        else if (!res) { head = MK.t('cr.v.noScan'); }
        else { head = MK.t('cr.v.clean', { n: res.asked }); }
        html += '<div class="cr-verdict ' + level + '">' + esc(head) + '</div>';
        if (res) {
            if (res.hits.length) {
                html += '<div class="cr-h">' + esc(MK.t('cr.songs')) + '</div>';
                res.hits.forEach(function (h, i) {
                    html += '<div class="cr-hit"><span class="cr-time">' + tc(h.start) + '–' + tc(h.end) + '</span><div class="cr-song"><b>' + esc(h.m.title) + '</b><small>' + esc(h.m.artist) +
                        (h.m.album ? ' · ' + esc(h.m.album) : '') + (h.m.label ? ' · ' + esc(h.m.label) : '') + (h.m.date ? ' · ' + esc(String(h.m.date).slice(0, 4)) : '') + '</small></div>' +
                        '<button class="btn sm icon" data-seek="' + h.start + '" title="' + esc(MK.t('cr.goTo')) + '">▶</button>' +
                        (h.m.link ? '<button class="btn sm icon" data-link="' + i + '" title="' + esc(MK.t('cr.open')) + '">↗</button>' : '') + '</div>';
                });
            }
            html += '<p class="hint">' + esc(MK.t('cr.stats', { a: res.asked, s: res.silent, e: res.errors.length })) + '</p>';
        }
        var shown = src.filter(function (s) { return s.c.risk !== 'ok'; });
        if (shown.length) {
            html += '<div class="cr-h">' + esc(MK.t('cr.sources')) + '</div>';
            shown.forEach(function (s) {
                html += '<div class="cr-src ' + s.c.risk + '"><span class="cr-dot"></span><div class="cr-song"><b>' + esc(s.name) + '</b><small>' + esc(s.c.why) +
                    (s.at >= 0 ? ' · ' + tc(s.at) : '') + (s.muted && s.audio ? ' · ' + esc(MK.t('cr.muted')) : '') + '</small></div>' +
                    (s.at >= 0 ? '<button class="btn sm icon" data-seek="' + s.at + '">▶</button>' : '') + '</div>';
            });
        }
        var okN = src.length - shown.length;
        if (okN) { html += '<p class="hint">' + esc(MK.t('cr.okFiles', { n: okN })) + '</p>'; }
        html += '<p class="hint">' + esc(MK.t('cr.disclaimer')) + '</p>';
        box.innerHTML = html;
        box.classList.remove('hidden');
        MK.$$('[data-seek]', box).forEach(function (b) { b.onclick = function () { MK.host('app.seek', { time: +b.dataset.seek }).catch(MK.fail); }; });
        MK.$$('[data-link]', box).forEach(function (b) { b.onclick = function () { MK.openURL(res.hits[+b.dataset.link].m.link); }; });
    }

    function runCheck(btn) {
        var bar = MK.$('#crProgress');
        CR.stop = false;
        MK.$('#crStop').classList.remove('hidden');
        MK.busy(btn, function () {
            var src = [];
            return MK.host('cr.readSources', {}).then(function (r) {
                src = r.items.map(function (it) { it.c = classify(it); return it; });
                if (!MK.$('#crMusic').checked) { return null; }
                if (!hasKey(engine())) { MK.toast(MK.t('cr.needKey'), 'warn'); return null; }
                return musicScan(bar).catch(function (e) {
                    if (e && e.message === 'NO_AUDIO_IN_COMP') { MK.toast(MK.errText(e), 'warn'); return { hits: [], asked: 0, silent: 0, errors: [] }; }
                    throw e;
                });
            }).then(function (res) {
                MK.progressHide(bar);
                renderResult(res, src);
                if (res && res.hits.length && MK.$('#crMarkers').checked) {
                    return MK.host('cr.addMarkers', { hits: res.hits.map(function (h) { return { t: h.start, d: h.end - h.start, label: h.m.title + ' — ' + h.m.artist }; }) })
                        .then(function (m) { MK.toast(MK.t('cr.markers', { n: m.count })); });
                }
            }, function (e) { MK.progressHide(bar); throw e; });
        }).then(function () { MK.$('#crStop').classList.add('hidden'); });
    }

    function keyHint() {
        var e = engine(), ok = hasKey(e);
        MK.$('#crKeyHint').textContent = ok ? MK.t(e === 'acr' ? 'cr.keyAcrOk' : 'cr.keyAuddOk') : MK.t('cr.noKey');
        MK.$('#crKeyHint').classList.toggle('warn', !ok);
    }

    /* ======================= HDR → Rec.709 ======================= */
    var HDR = { items: [], stop: false };
    function probe(file) {
        return new Promise(function (resolve) {
            var p = MK.require('child_process').spawn(MK.ffmpeg.find(), ['-hide_banner', '-i', file], { windowsHide: true });
            var err = '';
            p.stderr.on('data', function (d) { err += d.toString(); });
            p.on('error', function () { resolve({ kind: '?' }); });
            p.on('close', function () {
                var line = (/Stream #[^\n]*Video:[^\n]*/.exec(err) || [''])[0];
                var d = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec(err);
                var col = (/\b(?:yuv|p0|gbr|rgb|nv)\w*\(([^)]*)\)/.exec(line) || ['', ''])[1];
                var bits10 = /p10|p12|p16|10le|12le/.test(line);
                var kind = 'sdr';
                if (/arib-std-b67/.test(col)) { kind = 'hlg'; }
                else if (/smpte2084/.test(col)) { kind = 'pq'; }
                else if (/bt2020/.test(col)) { kind = 'wide'; }
                else if (!col && bits10 && /hevc/.test(line)) { kind = 'maybe'; }
                resolve({ kind: kind, dur: d ? (+d[1]) * 3600 + (+d[2]) * 60 + parseFloat(d[3]) : 0, line: line.replace(/^\s*Stream #\S+\s*/, '').slice(0, 160), audio: /Audio:/.test(err) });
            });
        });
    }
    var BADGE = { hlg: 'HDR · HLG', pq: 'HDR10 · PQ', wide: 'Rec.2020', maybe: 'HDR?', sdr: 'SDR · 709', '?': '?' };

    function hdrOpts() {
        return { tm: MK.$('#hdrStyle').value, bright: parseFloat(MK.$('#hdrBright').value) || 0, fmt: MK.$('#hdrFmt').value };
    }
    function hdrArgs(src, out, kind, o, cfr) {
        var tin = kind === 'pq' ? 'smpte2084' : (kind === 'wide' ? 'bt709' : 'arib-std-b67');
        var npl = Math.round(100 / Math.pow(2, o.bright));
        var pix = o.fmt === 'prores' ? 'yuv422p10le' : 'yuv420p';
        var vf = kind === 'wide'
            ? 'zscale=min=bt2020nc:pin=bt2020:m=bt709:p=bt709:t=bt709:r=tv,format=' + pix
            : 'zscale=tin=' + tin + ':min=bt2020nc:pin=bt2020:rin=tv:t=linear:npl=' + npl + ',format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=' + o.tm + ':desat=0,zscale=t=bt709:m=bt709:r=tv,format=' + pix;
        var a = ['-y', '-hide_banner', '-i', src, '-map', '0:v:0', '-map', '0:a?', '-vf', vf];
        if (cfr) { a.push('-fps_mode', 'cfr'); }
        if (o.fmt === 'prores') { a.push('-c:v', 'prores_ks', '-profile:v', '3', '-vendor', 'apl0', '-c:a', 'pcm_s16le'); }
        else { a.push('-c:v', 'libx264', '-crf', '16', '-preset', 'medium', '-c:a', 'aac', '-b:a', '320k', '-movflags', '+faststart'); }
        a.push('-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', out);
        return a;
    }
    function outPath(src, o) {
        var path = MK.require('path');
        var dir = MK.$('#hdrNext').checked ? path.dirname(src) : MK.paths.join(MK.paths.data, 'HDR to 709');
        MK.fs.mkdirp(dir);
        return path.join(dir, path.basename(src).replace(/\.[^.]+$/, '') + '_709' + (o.fmt === 'prores' ? '.mov' : '.mp4'));
    }
    function renderHdr() {
        var box = MK.$('#hdrList');
        box.innerHTML = '';
        HDR.items.forEach(function (it) {
            var row = document.createElement('div');
            row.className = 'hdr-row ' + (it.p ? it.p.kind : '');
            row.innerHTML = '<span class="hdr-badge"></span><div class="cr-song"><b></b><small></small></div><span class="hdr-st"></span>';
            row.querySelector('.hdr-badge').textContent = it.p ? BADGE[it.p.kind] : '…';
            row.querySelector('b').textContent = it.name;
            row.querySelector('small').textContent = (it.w ? it.w + '×' + it.h + ' · ' : '') + (it.dur ? it.dur + 's · ' : '') + MK.t('pj.uses', { n: it.uses });
            row.querySelector('.hdr-st').textContent = it.st || '';
            row.title = it.p ? it.p.line : '';
            it.row = row;
            box.appendChild(row);
        });
        box.classList.toggle('hidden', !HDR.items.length);
    }
    function scanHdr() {
        if (!MK.ffmpeg.find()) { return Promise.reject(new Error(MK.t('x.ffNeeded'))); }
        var scope = MK.segValue(MK.$('#hdrScope'), 'data-v') || 'comp';
        return MK.host('hdr.readTargets', { scope: scope }).then(function (r) {
            HDR.items = r.items;
            renderHdr();
            return r.items.reduce(function (p, it) {
                return p.then(function () { return probe(it.path).then(function (pr) { it.p = pr; }); });
            }, Promise.resolve()).then(function () {
                renderHdr();
                var n = HDR.items.filter(function (it) { return /hlg|pq|wide/.test(it.p.kind); }).length;
                MK.$('#hdrSum').textContent = HDR.items.length ? MK.t('hdr.found', { n: n, all: HDR.items.length }) : MK.t('hdr.none');
                return n;
            });
        });
    }
    function ensureFF() {
        if (MK.ffmpeg.find()) { return Promise.resolve(); }
        return MK.modal({ title: 'ffmpeg', html: '<p>' + esc(MK.t('hdr.needFF')) + '</p>', okText: MK.t('x.ffDownload') }).then(function (r) {
            if (!r) { throw new Error(MK.t('x.ffNeeded')); }
            return MK.ffmpeg.download(null, MK.$('#hdrProgress'));
        });
    }
    function convertAll(btn) {
        var bar = MK.$('#hdrProgress'), o = hdrOpts();
        HDR.stop = false;
        MK.busy(btn, function () {
            return ensureFF().then(scanHdr).then(function () {
                var todo = HDR.items.filter(function (it) { return /hlg|pq|wide/.test(it.p.kind) || (it.p.kind === 'maybe' && MK.$('#hdrMaybe').checked); });
                if (!todo.length) { MK.toast(MK.t('hdr.nothing'), 'warn'); return; }
                var done = 0, fails = [];
                return todo.reduce(function (p, it, idx) {
                    return p.then(function () {
                        if (HDR.stop) { return; }
                        var out = outPath(it.path, o), label = (idx + 1) + '/' + todo.length + ' ' + it.name;
                        it.st = '…'; it.row.querySelector('.hdr-st').textContent = '…';
                        var kind = it.p.kind === 'maybe' ? 'hlg' : it.p.kind;
                        var conv = MK.fs.exists(out) && MK.$('#hdrReuse').checked ? Promise.resolve()
                            : MK.ffmpeg.run(hdrArgs(it.path, out, kind, o, true), it.p.dur || it.dur, function (f) { MK.progress(bar, f, label + ' · ' + Math.round(f * 100) + '%'); })
                                .catch(function (e) {
                                    if (/fps_mode|Unrecognized option/i.test(e.message)) { return MK.ffmpeg.run(hdrArgs(it.path, out, kind, o, false), it.p.dur || it.dur, function (f) { MK.progress(bar, f, label + ' · ' + Math.round(f * 100) + '%'); }); }
                                    if (/zscale|No such filter/i.test(e.message)) { throw new Error(MK.t('hdr.noZscale')); }
                                    throw e;
                                });
                        return conv.then(function () { return MK.host('hdr.replace', { itemId: it.id, path: out, keepName: true }); }).then(function () {
                            done++; it.st = '✓ 709'; it.row.querySelector('.hdr-st').textContent = it.st; it.row.className = 'hdr-row done';
                        }, function (e) { fails.push(it.name + ': ' + MK.errText(e)); it.st = '✕'; it.row.querySelector('.hdr-st').textContent = '✕'; });
                    });
                }, Promise.resolve()).then(function () {
                    MK.progressHide(bar);
                    if (fails.length) { MK.toast(MK.t('hdr.someFail', { n: done, f: fails.join(' · ') }), 'warn'); } else { MK.toast(MK.t('hdr.ok', { n: done })); }
                });
            }, function (e) { MK.progressHide(bar); throw e; });
        });
    }

    MK.initCheck = function () {
        var s = MK.settings.check || {};
        if (s.engine) { MK.$('#crEngine').value = s.engine; }
        if (s.density) { MK.$('#crDensity').value = s.density; }
        ['hdrStyle', 'hdrFmt'].forEach(function (id) { if (s[id]) { MK.$('#' + id).value = s[id]; } });
        var save = function () {
            MK.settings.check = { engine: MK.$('#crEngine').value, density: MK.$('#crDensity').value, hdrStyle: MK.$('#hdrStyle').value, hdrFmt: MK.$('#hdrFmt').value };
            MK.saveSettings();
        };
        ['crEngine', 'crDensity', 'hdrStyle', 'hdrFmt'].forEach(function (id) { MK.$('#' + id).addEventListener('change', save); });
        MK.$('#crEngine').addEventListener('change', keyHint);
        MK.seg(MK.$('#crRange'));
        MK.seg(MK.$('#hdrScope'));
        MK.$('#crGo').onclick = function () { runCheck(this); };
        MK.$('#crStop').onclick = function () { CR.stop = true; };
        MK.$('#crClear').onclick = function () { MK.run(this, 'cr.clearMarkers', {}); };
        MK.$('#crKeys').onclick = function () { MK.showTab('settings'); };
        MK.$('#hdrBright').addEventListener('input', function () { MK.$('#hdrBrightV').textContent = (this.value > 0 ? '+' : '') + this.value; });
        MK.$('#hdrScan').onclick = function () { var b = this; MK.busy(b, function () { return ensureFF().then(scanHdr); }); };
        MK.$('#hdrGo').onclick = function () { convertAll(this); };
        keyHint();
        MK.onLang = MK.onLang || [];
        MK.onLang.push(keyHint);
        MK.$$('[data-key]').forEach(function (i) { i.addEventListener('change', keyHint); });
    };

    MK._check = { classify: classify, merge: merge, musicScan: musicScan, rms: rms, hdrArgs: hdrArgs, probe: probe, audd: audd, acr: acr, renderResult: renderResult, HDR: HDR, renderHdr: renderHdr };
})(window);
