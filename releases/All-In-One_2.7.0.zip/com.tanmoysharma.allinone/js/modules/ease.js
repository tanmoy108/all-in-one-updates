/* All In One — EaseKit: cubic-bezier editor → AE keyframe ease */
(function (w) {
    'use strict';
    var MK = w.MK;

    var BUILT_IN = [
        ['Easy Ease', [0.33, 0, 0.67, 1]], ['Sine', [0.37, 0, 0.63, 1]], ['Cubic', [0.65, 0, 0.35, 1]],
        ['Quint', [0.83, 0, 0.17, 1]], ['Expo', [0.87, 0, 0.13, 1]], ['Snap', [0.9, 0, 0.1, 1]],
        ['Out Cubic', [0.33, 1, 0.68, 1]], ['Out Expo', [0.16, 1, 0.3, 1]], ['In Cubic', [0.32, 0, 0.67, 0]],
        ['In Expo', [0.7, 0, 0.84, 0]], ['Back Out', [0.34, 1.56, 0.64, 1]], ['Back In', [0.36, 0, 0.66, -0.56]],
        ['Back In-Out', [0.68, -0.6, 0.32, 1.6]], ['Linear', [0, 0, 1, 1]]
    ];

    var curve = [0.33, 0, 0.67, 1];
    var cv, ctx, drag = -1;
    var Y_MIN = -0.6, Y_MAX = 1.6, PAD = 34;

    function custom() { return MK.hasNode ? MK.fs.readJSON(MK.paths.ease, []) : []; }
    function saveCustom(list) { if (MK.hasNode) { MK.fs.writeJSON(MK.paths.ease, list); } }

    function toPx(x, y) {
        var W = cv.width - PAD * 2, H = cv.height - PAD * 2;
        return [PAD + x * W, PAD + (Y_MAX - y) / (Y_MAX - Y_MIN) * H];
    }
    function fromPx(px, py) {
        var W = cv.width - PAD * 2, H = cv.height - PAD * 2;
        return [(px - PAD) / W, Y_MAX - (py - PAD) / H * (Y_MAX - Y_MIN)];
    }

    // y for a given x on the bezier (bisection on t)
    MK.bezierY = function (c, x) {
        var bx = function (t) { var u = 1 - t; return 3 * u * u * t * c[0] + 3 * u * t * t * c[2] + t * t * t; };
        var by = function (t) { var u = 1 - t; return 3 * u * u * t * c[1] + 3 * u * t * t * c[3] + t * t * t; };
        var lo = 0, hi = 1, t = x;
        for (var i = 0; i < 40; i++) { t = (lo + hi) / 2; if (bx(t) < x) { lo = t; } else { hi = t; } }
        return by(t);
    };

    function draw() {
        var W = cv.width, H = cv.height;
        ctx.clearRect(0, 0, W, H);
        var p0 = toPx(0, 0), p3 = toPx(1, 1);
        // grid
        ctx.strokeStyle = '#26262c'; ctx.lineWidth = 1;
        for (var g = 0; g <= 10; g++) {
            var gx = toPx(g / 10, 0)[0];
            ctx.beginPath(); ctx.moveTo(gx, PAD); ctx.lineTo(gx, H - PAD); ctx.stroke();
        }
        [0, 0.5, 1].forEach(function (v) {
            var gy = toPx(0, v)[1];
            ctx.strokeStyle = v === 0.5 ? '#26262c' : '#3a3a42';
            ctx.beginPath(); ctx.moveTo(PAD, gy); ctx.lineTo(W - PAD, gy); ctx.stroke();
        });
        // diagonal
        ctx.setLineDash([6, 6]); ctx.strokeStyle = '#3a3a42';
        ctx.beginPath(); ctx.moveTo(p0[0], p0[1]); ctx.lineTo(p3[0], p3[1]); ctx.stroke();
        ctx.setLineDash([]);
        var h1 = toPx(curve[0], curve[1]), h2 = toPx(curve[2], curve[3]);
        // handles
        ctx.strokeStyle = '#8a8a96'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(p0[0], p0[1]); ctx.lineTo(h1[0], h1[1]); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(p3[0], p3[1]); ctx.lineTo(h2[0], h2[1]); ctx.stroke();
        // curve
        ctx.strokeStyle = '#ff2d4a'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(p0[0], p0[1]);
        ctx.bezierCurveTo(h1[0], h1[1], h2[0], h2[1], p3[0], p3[1]);
        ctx.stroke();
        // points
        [[p0, '#666'], [p3, '#666']].forEach(function (q) { ctx.fillStyle = q[1]; ctx.beginPath(); ctx.arc(q[0][0], q[0][1], 6, 0, Math.PI * 2); ctx.fill(); });
        [h1, h2].forEach(function (q, i) {
            ctx.fillStyle = drag === i ? '#fff' : '#ff2d4a';
            ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(q[0], q[1], 11, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        });
        MK.$('#easeText').value = curve.map(function (v) { return +v.toFixed(3); }).join(', ');
    }

    function setCurve(c) {
        curve = [Math.min(1, Math.max(0, +c[0])), +c[1], Math.min(1, Math.max(0, +c[2])), +c[3]];
        draw();
    }
    MK.setEaseCurve = setCurve;

    function pointer(e) {
        var r = cv.getBoundingClientRect();
        return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height];
    }

    function renderPresets() {
        var box = MK.$('#easePresets');
        box.innerHTML = '';
        var add = function (name, c, removable, idx) {
            var b = document.createElement('button');
            b.className = 'chip';
            b.textContent = name;
            b.title = c.join(', ');
            b.onclick = function () { MK.$$('#easePresets .chip').forEach(function (x) { x.classList.remove('active'); }); b.classList.add('active'); setCurve(c); };
            if (removable) {
                b.oncontextmenu = function (ev) {
                    ev.preventDefault();
                    var list = custom(); list.splice(idx, 1); saveCustom(list); renderPresets();
                };
                b.title += '  (right-click to delete)';
            }
            box.appendChild(b);
        };
        BUILT_IN.forEach(function (p) { add(p[0], p[1]); });
        custom().forEach(function (p, i) { add('★ ' + p.name, p.curve, true, i); });
    }

    var dotStart = 0;
    function animateDot(ts) {
        if (MK.tabs.current === 'ease') {
            if (!dotStart) { dotStart = ts; }
            var period = 1800;
            var ph = ((ts - dotStart) % period) / period;
            var x = ph < 0.7 ? ph / 0.7 : 1;
            var y = MK.bezierY(curve, x);
            var track = MK.$('.ease-dot-track');
            MK.$('#easeDot').style.left = ((Math.max(-0.15, Math.min(1.15, y)) + 0.15) / 1.3 * track.clientWidth) + 'px';
        }
        w.requestAnimationFrame(animateDot);
    }

    MK.initEase = function () {
        cv = MK.$('#easeCanvas');
        ctx = cv.getContext('2d');
        var move = function (e) {
            if (drag < 0) { return; }
            var v = fromPx.apply(null, pointer(e));
            var x = Math.min(1, Math.max(0, v[0])), y = Math.min(Y_MAX, Math.max(Y_MIN, v[1]));
            if (e.shiftKey) { y = drag === 0 ? 0 : 1; }
            if (drag === 0) { curve[0] = x; curve[1] = y; } else { curve[2] = x; curve[3] = y; }
            draw();
        };
        cv.addEventListener('pointerdown', function (e) {
            var p = pointer(e);
            var h = [toPx(curve[0], curve[1]), toPx(curve[2], curve[3])];
            var d0 = Math.hypot(p[0] - h[0][0], p[1] - h[0][1]), d1 = Math.hypot(p[0] - h[1][0], p[1] - h[1][1]);
            drag = d0 < d1 ? 0 : 1;
            cv.setPointerCapture(e.pointerId);
            move(e);
        });
        cv.addEventListener('pointermove', move);
        cv.addEventListener('pointerup', function () { drag = -1; draw(); });

        MK.$('#easeText').addEventListener('change', function () {
            var n = this.value.replace(/cubic-bezier|\(|\)/g, '').split(/[\s,]+/).filter(Boolean).map(parseFloat);
            if (n.length === 4 && n.every(function (v) { return !isNaN(v); })) { setCurve(n); } else { draw(); }
        });
        MK.$('#easeCopy').onclick = function () {
            var s = 'cubic-bezier(' + MK.$('#easeText').value + ')';
            MK.copy(s);
            MK.toast(MK.t('ok.copied'));
        };
        MK.$('#easeApply').onclick = function () {
            MK.run(this, 'ease.applyCurve', { x1: curve[0], y1: curve[1], x2: curve[2], y2: curve[3] }, function (r) { return MK.t('e.applied', { n: r.segments }); });
        };
        MK.$('#easeRead').onclick = function () {
            var b = this;
            MK.busy(b, function () {
                return MK.host('ease.readCurve', {}).then(function (c) { setCurve([c.x1, c.y1, c.x2, c.y2]); MK.toast(MK.t('ok.done')); });
            });
        };
        MK.$('#easeSave').onclick = function () {
            MK.prompt(MK.t('e.presetName'), MK.t('q.name'), 'My ease').then(function (name) {
                if (!name) { return; }
                var list = custom(); list.push({ name: name, curve: curve.slice(0) }); saveCustom(list); renderPresets();
                MK.toast(MK.t('ok.saved'));
            });
        };
        var inf = MK.$('#easeInfluence');
        inf.oninput = function () { MK.$('#easeInfluenceVal').textContent = inf.value + '%'; };
        MK.$$('[data-eq]').forEach(function (b) {
            b.onclick = function () { MK.run(b, 'ease.quick', { mode: b.dataset.eq, influence: +inf.value }); };
        });
        MK.$$('[data-nudge]').forEach(function (b) {
            b.onclick = function () { MK.run(b, 'ease.nudge', { frames: +b.dataset.nudge }); };
        });
        renderPresets();
        draw();
        w.requestAnimationFrame(animateDot);
    };
})(window);
