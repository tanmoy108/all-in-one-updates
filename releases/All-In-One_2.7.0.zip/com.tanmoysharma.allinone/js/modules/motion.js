/* All In One — Motion tab: 25 In/Out animation presets + 8 loops, with hover previews.
   One definition (tracks) drives both the CSS preview and the keyframes After Effects gets. */
(function (w) {
    'use strict';
    var MK = w.MK;

    // keys: [fraction 0..1, value, hint]  — the last key is always the resting state.
    // opacity: multiplier · scale: multiplier or [x,y] · pos: offset in "distance" units ([x,y]) · rot: degrees
    // blur / dirblur: pixels · wipe: transition completion %
    var PRESETS = [
        { id: 'fade', name: 'Fade', t: [{ p: 'opacity', k: [[0, 0], [1, 1]] }] },
        { id: 'pop', name: 'Pop', t: [{ p: 'scale', k: [[0, 0], [0.6, 1.12], [1, 1]] }, { p: 'opacity', k: [[0, 0], [0.3, 1]] }] },
        { id: 'scaleUp', name: 'Scale Up', t: [{ p: 'scale', k: [[0, 0.6], [1, 1]] }, { p: 'opacity', k: [[0, 0], [0.6, 1]] }] },
        { id: 'zoomIn', name: 'Zoom In', t: [{ p: 'scale', k: [[0, 1.6], [1, 1]] }, { p: 'opacity', k: [[0, 0], [0.5, 1]] }] },
        { id: 'slideUp', name: 'Slide Up', t: [{ p: 'pos', k: [[0, [0, 1]], [1, [0, 0]]] }, { p: 'opacity', k: [[0, 0], [0.5, 1]] }] },
        { id: 'slideDown', name: 'Slide Down', t: [{ p: 'pos', k: [[0, [0, -1]], [1, [0, 0]]] }, { p: 'opacity', k: [[0, 0], [0.5, 1]] }] },
        { id: 'slideLeft', name: 'Slide Left', t: [{ p: 'pos', k: [[0, [1, 0]], [1, [0, 0]]] }, { p: 'opacity', k: [[0, 0], [0.5, 1]] }] },
        { id: 'slideRight', name: 'Slide Right', t: [{ p: 'pos', k: [[0, [-1, 0]], [1, [0, 0]]] }, { p: 'opacity', k: [[0, 0], [0.5, 1]] }] },
        { id: 'blurIn', name: 'Blur In', t: [{ p: 'blur', k: [[0, 60], [1, 0]] }, { p: 'opacity', k: [[0, 0], [0.6, 1]] }] },
        { id: 'zoomBlur', name: 'Zoom Blur', t: [{ p: 'scale', k: [[0, 1.35], [1, 1]] }, { p: 'blur', k: [[0, 50], [1, 0]] }, { p: 'opacity', k: [[0, 0], [0.5, 1]] }] },
        { id: 'softRise', name: 'Soft Rise', t: [{ p: 'pos', k: [[0, [0, 0.6]], [1, [0, 0]]] }, { p: 'blur', k: [[0, 30], [1, 0]] }, { p: 'opacity', k: [[0, 0], [0.6, 1]] }] },
        { id: 'jumpIn', name: 'Jump In', t: [{ p: 'pos', k: [[0, [0, 0.5]], [1, [0, 0]]] }, { p: 'scale', k: [[0, 0.5], [0.6, 1.08], [1, 1]] }, { p: 'opacity', k: [[0, 0], [0.3, 1]] }] },
        { id: 'rotateIn', name: 'Rotate In', t: [{ p: 'rot', k: [[0, -90], [1, 0]] }, { p: 'scale', k: [[0, 0.3], [1, 1]] }, { p: 'opacity', k: [[0, 0], [0.4, 1]] }] },
        { id: 'spinIn', name: 'Spin In', t: [{ p: 'rot', k: [[0, -360], [1, 0]] }, { p: 'scale', k: [[0, 0], [1, 1]] }] },
        { id: 'bounceIn', name: 'Bounce In', t: [{ p: 'scale', k: [[0, 0], [0.45, 1.18], [0.65, 0.9], [0.82, 1.05], [1, 1]] }] },
        { id: 'dropIn', name: 'Drop In', t: [{ p: 'pos', k: [[0, [0, -1.6]], [0.55, [0, 0], 'L'], [0.75, [0, -0.25]], [0.9, [0, 0], 'L'], [0.96, [0, -0.06]], [1, [0, 0]]] }, { p: 'opacity', k: [[0, 0], [0.2, 1]] }] },
        { id: 'elastic', name: 'Elastic', t: [{ p: 'pos', k: [[0, [-1, 0]], [0.55, [0.12, 0]], [0.75, [-0.05, 0]], [0.9, [0.02, 0]], [1, [0, 0]]] }, { p: 'opacity', k: [[0, 0], [0.3, 1]] }] },
        { id: 'flipH', name: 'Flip H', t: [{ p: 'scale', k: [[0, [0, 1]], [1, [1, 1]]] }] },
        { id: 'flipV', name: 'Flip V', t: [{ p: 'scale', k: [[0, [1, 0]], [1, [1, 1]]] }] },
        { id: 'stretch', name: 'Stretch', t: [{ p: 'scale', k: [[0, [1.5, 0.4]], [0.55, [0.85, 1.15]], [0.8, [1.05, 0.95]], [1, [1, 1]]] }, { p: 'opacity', k: [[0, 0], [0.3, 1]] }] },
        { id: 'swing', name: 'Swing', t: [{ p: 'rot', k: [[0, -30], [0.45, 14], [0.7, -6], [0.88, 2], [1, 0]] }, { p: 'opacity', k: [[0, 0], [0.3, 1]] }] },
        { id: 'whipLeft', name: 'Whip Left', t: [{ p: 'pos', unit: 'w', k: [[0, [0.7, 0]], [1, [0, 0]]] }, { p: 'dirblur', angle: 90, k: [[0, 120], [0.8, 0]] }, { p: 'opacity', k: [[0, 0], [0.25, 1]] }] },
        { id: 'whipRight', name: 'Whip Right', t: [{ p: 'pos', unit: 'w', k: [[0, [-0.7, 0]], [1, [0, 0]]] }, { p: 'dirblur', angle: 90, k: [[0, 120], [0.8, 0]] }, { p: 'opacity', k: [[0, 0], [0.25, 1]] }] },
        { id: 'wipeRight', name: 'Wipe →', t: [{ p: 'wipe', angle: 270, k: [[0, 100], [1, 0]] }] },
        { id: 'wipeUp', name: 'Wipe ↑', t: [{ p: 'wipe', angle: 180, k: [[0, 100], [1, 0]] }] }
    ];

    var LOOPS = [
        { id: 'pulse', name: 'Pulse', css: '0%,100%{transform:scale(1)}50%{transform:scale(1.12)}', dur: 1 },
        { id: 'heartbeat', name: 'Heartbeat', css: '0%,24%,100%{transform:scale(1)}11%{transform:scale(1.16)}33%{transform:scale(1.1)}44%{transform:scale(1)}', dur: 1.1 },
        { id: 'float', name: 'Float', css: '0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}', dur: 1.6 },
        { id: 'shake', name: 'Shake', css: '0%,100%{transform:translate(0,0)}20%{transform:translate(-3px,1px)}40%{transform:translate(3px,-2px)}60%{transform:translate(-2px,2px)}80%{transform:translate(2px,-1px)}', dur: 0.35 },
        { id: 'spin', name: 'Spin', css: 'from{transform:rotate(0)}to{transform:rotate(360deg)}', dur: 1.4, linear: true },
        { id: 'swing', name: 'Swing', css: '0%,100%{transform:rotate(-14deg)}50%{transform:rotate(14deg)}', dur: 1.2 },
        { id: 'blink', name: 'Blink', css: '0%,49%{opacity:1}50%,100%{opacity:.15}', dur: 0.8, linear: true },
        { id: 'jelly', name: 'Jelly', css: '0%,100%{transform:scale(1.08,.92)}50%{transform:scale(.92,1.08)}', dur: 0.7 }
    ];

    var EASES = { expo: { o: 15, i: 85 }, snappy: { o: 5, i: 95 }, smooth: { o: 33.3, i: 33.3 }, linear: { linear: true } };

    /* ---------- CSS preview built from the same tracks ---------- */
    function valueAt(keys, f) {
        if (f <= keys[0][0]) { return keys[0][1]; }
        for (var i = 1; i < keys.length; i++) {
            if (f <= keys[i][0]) {
                var a = keys[i - 1], b = keys[i], u = (f - a[0]) / Math.max(1e-6, b[0] - a[0]);
                if (a[1] instanceof Array) { return [a[1][0] + (b[1][0] - a[1][0]) * u, a[1][1] + (b[1][1] - a[1][1]) * u]; }
                return a[1] + (b[1] - a[1]) * u;
            }
        }
        return keys[keys.length - 1][1];
    }

    function frameCSS(p, f) {
        var tx = 0, ty = 0, rot = 0, sx = 1, sy = 1, op = 1, blur = 0, clip = '';
        p.t.forEach(function (tr) {
            var v = valueAt(tr.k, f);
            if (tr.p === 'opacity') { op = v; }
            else if (tr.p === 'scale') { if (v instanceof Array) { sx = v[0]; sy = v[1]; } else { sx = sy = v; } }
            else if (tr.p === 'rot') { rot = v; }
            else if (tr.p === 'pos') { var u = tr.unit === 'w' ? 60 : 16; tx = v[0] * u; ty = v[1] * u; }
            else if (tr.p === 'blur' || tr.p === 'dirblur') { blur = v / 12; }
            else if (tr.p === 'wipe') { clip = tr.angle === 180 ? 'inset(' + v + '% 0 0 0)' : 'inset(0 ' + v + '% 0 0)'; }
        });
        var r = function (x) { return Math.round(x * 1000) / 1000; };
        return 'transform:translate(' + r(tx) + 'px,' + r(ty) + 'px) rotate(' + r(rot) + 'deg) scale(' + r(sx) + ',' + r(sy) + ');opacity:' + r(op) +
            ';filter:blur(' + r(blur) + 'px)' + (clip ? ';clip-path:' + clip + ';-webkit-clip-path:' + clip : ';clip-path:inset(0 0 0 0);-webkit-clip-path:inset(0 0 0 0)');
    }

    function fractions(p) {
        var set = {};
        p.t.forEach(function (tr) { tr.k.forEach(function (k) { set[k[0]] = true; }); });
        set[0] = set[1] = true;
        return Object.keys(set).map(Number).sort(function (a, b) { return a - b; });
    }

    // in: animation in the first 55% then hold · out: hold then the reversed animation · both: in, hold, out
    function keyframes(p, mode) {
        var fr = fractions(p), out = [];
        var ease = 'animation-timing-function:cubic-bezier(.2,.8,.25,1)';
        var put = function (pct, f) { out.push(Math.round(pct * 100) / 100 + '%{' + frameCSS(p, f) + ';' + ease + '}'); };
        if (mode === 'in') { fr.forEach(function (f) { put(f * 55, f); }); put(100, 1); }
        else if (mode === 'out') { put(0, 1); fr.slice().reverse().forEach(function (f) { put(45 + (1 - f) * 55, f); }); }
        else { fr.forEach(function (f) { put(f * 35, f); }); fr.slice().reverse().forEach(function (f) { put(65 + (1 - f) * 35, f); }); }
        return '@keyframes mv-' + p.id + '-' + mode + '{' + out.join('') + '}';
    }

    function buildStyles() {
        var css = [];
        PRESETS.forEach(function (p) { ['in', 'out', 'both'].forEach(function (m) { css.push(keyframes(p, m)); }); });
        LOOPS.forEach(function (l) { css.push('@keyframes mvl-' + l.id + '{' + l.css + '}'); });
        var st = document.getElementById('mvStyles');
        if (!st) { st = document.createElement('style'); st.id = 'mvStyles'; document.head.appendChild(st); }
        st.textContent = css.join('\n');
    }

    /* ---------- UI ---------- */
    function mode() { return MK.segValue(MK.$('#mvMode'), 'data-v') || 'in'; }
    function num(id, d) { var v = parseFloat(MK.$(id).value); return isNaN(v) ? d : v; }

    function tile(id, name, kind) {
        var b = document.createElement('button');
        b.className = 'mv-tile';
        b.dataset.id = id;
        b.dataset.kind = kind;
        b.innerHTML = '<div class="mv-stage"><i class="mv-box"></i></div><span>' + MK.esc(name) + '</span>';
        return b;
    }

    function setAnim(b, on) {
        var box = b.querySelector('.mv-box');
        if (!on) { box.style.animation = ''; return; }
        if (b.dataset.kind === 'loop') {
            var l = LOOPS.filter(function (x) { return x.id === b.dataset.id; })[0];
            box.style.animation = 'mvl-' + l.id + ' ' + l.dur + 's ' + (l.linear ? 'linear' : 'ease-in-out') + ' infinite';
        } else {
            box.style.animation = 'mv-' + b.dataset.id + '-' + mode() + ' 1.7s infinite';
        }
    }

    function opts() {
        var e = MK.$('#mvEase').value;
        var o = {
            mode: mode(), dur: num('#mvDur', 0.6), ease: EASES[e] || EASES.expo, dist: num('#mvDist', 200),
            strength: num('#mvStr', 100) / 100, stagger: num('#mvStag', 0), at: MK.$('#mvAt').value
        };
        MK.settings.motion = { mode: o.mode, dur: o.dur, ease: e, dist: o.dist, str: num('#mvStr', 100), stag: o.stagger, at: o.at, amt: num('#mvAmt', 100), speed: num('#mvSpeed', 1) };
        MK.saveSettings();
        return o;
    }

    function applyPreset(b) {
        var p = PRESETS.filter(function (x) { return x.id === b.dataset.id; })[0];
        var o = opts();
        o.tracks = p.t;
        return MK.run(b, 'motion.apply', o, function (r) { return MK.t('mv.done', { name: p.name, n: r.count }); });
    }

    function applyLoop(b) {
        opts();
        var l = LOOPS.filter(function (x) { return x.id === b.dataset.id; })[0];
        return MK.run(b, 'motion.loop', { kind: l.id, amount: num('#mvAmt', 100) / 100, speed: num('#mvSpeed', 1) },
            function (r) { return MK.t('mv.done', { name: l.name, n: r.count }); });
    }

    MK.initMotion = function () {
        buildStyles();
        var s = MK.settings.motion || {};
        if (s.dur) { MK.$('#mvDur').value = s.dur; }
        if (s.ease) { MK.$('#mvEase').value = s.ease; }
        if (s.dist) { MK.$('#mvDist').value = s.dist; }
        if (s.str) { MK.$('#mvStr').value = s.str; }
        if (s.stag !== undefined) { MK.$('#mvStag').value = s.stag; }
        if (s.at) { MK.$('#mvAt').value = s.at; }
        if (s.amt) { MK.$('#mvAmt').value = s.amt; }
        if (s.speed) { MK.$('#mvSpeed').value = s.speed; }
        if (s.mode) { MK.$$('#mvMode button').forEach(function (x) { x.classList.toggle('active', x.dataset.v === s.mode); }); }
        MK.seg(MK.$('#mvMode'));

        var grid = MK.$('#mvGrid'), lg = MK.$('#mvLoops');
        PRESETS.forEach(function (p) { grid.appendChild(tile(p.id, p.name, 'in')); });
        LOOPS.forEach(function (l) { lg.appendChild(tile(l.id, l.name, 'loop')); });
        MK.$('#mvCount').textContent = PRESETS.length + ' + ' + LOOPS.length;
        MK.$$('#tab-motion .mv-tile').forEach(function (b) {
            b.addEventListener('mouseenter', function () { setAnim(b, true); });
            b.addEventListener('mouseleave', function () { setAnim(b, false); });
            b.addEventListener('click', function () { if (b.dataset.kind === 'loop') { applyLoop(b); } else { applyPreset(b); } });
        });
        MK.$('#mvClear').onclick = function () {
            MK.run(this, 'motion.clear', { keys: MK.$('#mvClearKeys').checked });
        };
    };

    // exposed for tests
    MK._motion = { PRESETS: PRESETS, LOOPS: LOOPS, EASES: EASES, keyframes: keyframes, valueAt: valueAt };
})(window);
