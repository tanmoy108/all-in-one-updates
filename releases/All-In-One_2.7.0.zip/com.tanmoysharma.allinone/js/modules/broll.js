/* All In One — B-Roll: Pixabay / Pexels search → download → import */
(function (w) {
    'use strict';
    var MK = w.MK;

    var st = { page: 1, query: '', items: [], loading: false };
    var TAGS = ['nature', 'city night', 'people', 'office', 'technology', 'coffee', 'ocean', 'abstract', 'food', 'Bangladesh', 'business', 'sky'];

    function type() { return MK.segValue(MK.$('#brType'), 'data-v') || 'image'; }
    function provider() { return MK.$('#brProvider').value; }
    function orient() { return MK.$('#brOrient').value; }

    function keyOrNotice() {
        var p = provider(), k = MK.settings.keys[p];
        var n = MK.$('#brKeyNotice');
        if (!k) {
            n.innerHTML = MK.esc(MK.t('b.needKey', { name: p === 'pexels' ? 'Pexels' : 'Pixabay' })) + ' <a href="#" id="brOpenSettings">⚙</a>';
            n.classList.remove('hidden');
            MK.$('#brOpenSettings').onclick = function (e) { e.preventDefault(); MK.showTab('settings'); };
            return null;
        }
        n.classList.add('hidden');
        return k;
    }

    function pickPexelsVideo(files) {
        var mp4 = files.filter(function (f) { return /mp4/i.test(f.file_type || '') && f.link; });
        if (!mp4.length) { mp4 = files; }
        mp4.sort(function (a, b) { return Math.abs((Math.min(a.width, a.height) || 0) - 1080) - Math.abs((Math.min(b.width, b.height) || 0) - 1080); });
        return mp4[0];
    }

    function search(k, page) {
        var q = encodeURIComponent(st.query), o = orient(), t = type();
        if (provider() === 'pixabay') {
            if (t === 'image') {
                var po = o === 'all' ? 'all' : o;
                return MK.http.get('https://pixabay.com/api/?key=' + encodeURIComponent(k) + '&q=' + q + '&image_type=photo&safesearch=true&per_page=30&page=' + page + '&orientation=' + po)
                    .then(function (r) {
                        return { total: r.totalHits, items: (r.hits || []).map(function (h) {
                            return { id: 'pixabay_' + h.id, thumb: h.webformatURL || h.previewURL, url: h.largeImageURL || h.webformatURL, w: h.imageWidth, h: h.imageHeight, ext: (/\.(\w+)(\?|$)/.exec(h.largeImageURL || '') || [0, 'jpg'])[1], by: h.user, page: h.pageURL };
                        }) };
                    });
            }
            return MK.http.get('https://pixabay.com/api/videos/?key=' + encodeURIComponent(k) + '&q=' + q + '&safesearch=true&per_page=30&page=' + page)
                .then(function (r) {
                    var items = (r.hits || []).map(function (h) {
                        var v = h.videos || {};
                        var best = (v.large && v.large.url) ? v.large : (v.medium && v.medium.url ? v.medium : v.small);
                        var th = (v.medium && v.medium.thumbnail) || (v.small && v.small.thumbnail) || (v.tiny && v.tiny.thumbnail) || '';
                        return { id: 'pixabay_v' + h.id, thumb: th, url: best ? best.url : '', w: best ? best.width : 0, h: best ? best.height : 0, ext: 'mp4', dur: h.duration, by: h.user, page: h.pageURL, video: true };
                    }).filter(function (i) { return i.url; });
                    if (o !== 'all') { items = items.filter(function (i) { return o === 'vertical' ? i.h > i.w : i.w >= i.h; }); }
                    return { total: r.totalHits, items: items };
                });
        }
        var po2 = o === 'horizontal' ? '&orientation=landscape' : (o === 'vertical' ? '&orientation=portrait' : '');
        var H = { Authorization: k };
        if (t === 'image') {
            return MK.http.get('https://api.pexels.com/v1/search?query=' + q + '&per_page=30&page=' + page + po2, H).then(function (r) {
                return { total: r.total_results, items: (r.photos || []).map(function (p) {
                    return { id: 'pexels_' + p.id, thumb: p.src.medium, url: p.src.large2x || p.src.original, w: p.width, h: p.height, ext: 'jpg', by: p.photographer, page: p.url };
                }) };
            });
        }
        return MK.http.get('https://api.pexels.com/videos/search?query=' + q + '&per_page=24&page=' + page + po2, H).then(function (r) {
            return { total: r.total_results, items: (r.videos || []).map(function (v) {
                var f = pickPexelsVideo(v.video_files || []) || {};
                return { id: 'pexels_v' + v.id, thumb: v.image, url: f.link, w: f.width, h: f.height, ext: 'mp4', dur: v.duration, by: v.user && v.user.name, page: v.url, video: true };
            }).filter(function (i) { return i.url; }) };
        });
    }

    function dur(s) { s = Math.round(s || 0); return Math.floor(s / 60) + ':' + (s % 60 < 10 ? '0' : '') + (s % 60); }

    function render(items, append) {
        var grid = MK.$('#brGrid');
        grid.classList.toggle('vertical', orient() === 'vertical');
        if (!append) { grid.innerHTML = ''; }
        items.forEach(function (it) {
            var card = document.createElement('div');
            card.className = 'lcard';
            card.innerHTML = '<div class="thumb"></div><div class="meta"><span>' + MK.esc(it.by || '') + '</span><span style="flex:none">' + (it.w ? it.w + '×' + it.h : '') + '</span></div><div class="state"></div>' +
                (it.video ? '<span class="badge">▶ ' + dur(it.dur) + '</span>' : '');
            card.querySelector('.thumb').style.backgroundImage = 'url("' + it.thumb + '")';
            card.title = it.page || '';
            card.addEventListener('click', function () { get(it, card); });
            grid.appendChild(card);
        });
    }

    function get(it, card) {
        if (card.classList.contains('loading')) { return; }
        card.classList.add('loading');
        var stEl = card.querySelector('.state');
        stEl.textContent = MK.t('b.downloading');
        MK.host('broll.getDownloadDir', {}).then(function (dir) {
            var dest = MK.paths.join(dir, it.id + '.' + it.ext);
            if (MK.fs.exists(dest) && MK.fs.size(dest) > 0) { return dest; }
            return MK.http.download(it.url, dest + '.part', function (f) { stEl.textContent = Math.round(f * 100) + '%'; }).then(function () {
                MK.require('fs').renameSync(dest + '.part', dest);
                return dest;
            });
        }).then(function (path) {
            return MK.host('broll.importFile', { path: path, addToComp: MK.$('#brAdd').checked, fit: MK.$('#brFit').value, duration: +MK.$('#brDur').value || 3 });
        }).then(function (r) {
            card.classList.remove('loading'); card.classList.add('done');
            stEl.textContent = '✓';
            MK.toast(MK.t('ok.imported', { name: r.name }));
            setTimeout(function () { card.classList.remove('done'); }, 1500);
        }, function (e) {
            card.classList.remove('loading');
            MK.fail(e);
        });
    }

    function run(btn, append) {
        var k = keyOrNotice();
        if (!k) { return; }
        st.query = MK.$('#brQuery').value.trim();
        if (!st.query) { return; }
        st.page = append ? st.page + 1 : 1;
        MK.busy(btn, function () {
            return search(k, st.page).then(function (r) {
                render(r.items, append);
                if (!append && !r.items.length) { MK.$('#brGrid').innerHTML = '<div class="empty" style="grid-column:1/-1">' + MK.esc(MK.t('b.none')) + '</div>'; }
                MK.$('#brMore').classList.toggle('hidden', !r.items.length || st.page * 24 >= (r.total || 0));
            });
        });
    }

    MK.initBroll = function () {
        MK.seg(MK.$('#brType'), function () { if (st.query) { run(MK.$('#brGo')); } });
        MK.$('#brGo').onclick = function () { run(this); };
        MK.$('#brQuery').addEventListener('keydown', function (e) { if (e.key === 'Enter') { run(MK.$('#brGo')); } });
        MK.$('#brMore').onclick = function () { run(this, true); };
        MK.$('#brProvider').addEventListener('change', function () { keyOrNotice(); if (st.query) { run(MK.$('#brGo')); } });
        MK.$('#brOrient').addEventListener('change', function () { if (st.query) { run(MK.$('#brGo')); } });
        var tr = MK.$('#brTags');
        TAGS.forEach(function (t) {
            var b = document.createElement('button');
            b.className = 'chip';
            b.textContent = t;
            b.onclick = function () { MK.$('#brQuery').value = t; run(MK.$('#brGo')); };
            tr.appendChild(b);
        });
        MK.tabs.onShow.broll = keyOrNotice;
    };
})(window);
