/* All In One — Quick tab additions: new / edit composition, shape builder with live controls, safe-zone guides */
(function (w) {
    'use strict';
    var MK = w.MK;

    var COMP_PRESETS = [
        ['Reels 9:16', 1080, 1920], ['YouTube 16:9', 1920, 1080], ['Square 1:1', 1080, 1080], ['Post 4:5', 1080, 1350],
        ['4K 16:9', 3840, 2160], ['4K 9:16', 2160, 3840], ['Thumbnail', 1280, 720]
    ];

    function num(id, d) { var v = parseFloat(MK.$(id).value); return isNaN(v) ? d : v; }

    function compArgs() {
        return {
            name: MK.$('#kName').value.trim(), width: num('#kW', 1080), height: num('#kH', 1920), fps: num('#kFps', 30),
            duration: num('#kDur', 15), bg: MK.hexToRgb01(MK.$('#kBg').value)
        };
    }
    function fillComp(i) {
        if (!i) { return; }
        MK.$('#kName').value = i.name;
        MK.$('#kW').value = i.width; MK.$('#kH').value = i.height;
        var fs = MK.$('#kFps'), v = String(i.fps), found = false;
        for (var k = 0; k < fs.options.length; k++) { if (Math.abs(parseFloat(fs.options[k].value) - i.fps) < 0.01) { fs.selectedIndex = k; found = true; } }
        if (!found) { var o = document.createElement('option'); o.value = o.textContent = v; fs.appendChild(o); fs.value = v; }
        MK.$('#kDur').value = i.duration;
        MK.$('#kBg').value = i.bg;
        markPreset();
    }
    function markPreset() {
        var W = num('#kW', 0), H = num('#kH', 0);
        MK.$$('#kCompPresets .chip').forEach(function (c) { c.classList.toggle('active', +c.dataset.w === W && +c.dataset.h === H); });
    }

    function shapeArgs(type) {
        return {
            type: type, w: num('#kSW', 600), h: num('#kSH', 600), round: num('#kSR', 40), points: num('#kSP', 5),
            fillOn: MK.$('#kSFillOn').checked, fill: MK.hexToRgb01(MK.$('#kSFill').value),
            sw: num('#kSSw', 0), stroke: MK.hexToRgb01(MK.$('#kSStroke').value), live: MK.$('#kSLive').checked
        };
    }

    function saveShape() {
        MK.settings.shape = {
            w: MK.$('#kSW').value, h: MK.$('#kSH').value, r: MK.$('#kSR').value, p: MK.$('#kSP').value, fillOn: MK.$('#kSFillOn').checked,
            fill: MK.$('#kSFill').value, sw: MK.$('#kSSw').value, stroke: MK.$('#kSStroke').value, live: MK.$('#kSLive').checked
        };
        MK.saveSettings();
    }

    MK.initCreate = function () {
        /* ---- composition ---- */
        var box = MK.$('#kCompPresets');
        COMP_PRESETS.forEach(function (p) {
            var b = document.createElement('button');
            b.className = 'chip small';
            b.textContent = p[0];
            b.dataset.w = p[1]; b.dataset.h = p[2];
            b.onclick = function () {
                MK.$('#kW').value = p[1]; MK.$('#kH').value = p[2];
                if (!MK.$('#kName').value.trim() || /^(Comp|Reels|YouTube|Square|Post|4K|Thumbnail)\b/.test(MK.$('#kName').value)) { MK.$('#kName').value = p[0].replace(/[:\s]+/g, ' ').trim(); }
                markPreset();
            };
            box.appendChild(b);
        });
        ['#kW', '#kH'].forEach(function (s) { MK.$(s).addEventListener('input', markPreset); });
        markPreset();
        MK.$('#kSwap').onclick = function () { var a = MK.$('#kW').value; MK.$('#kW').value = MK.$('#kH').value; MK.$('#kH').value = a; markPreset(); };
        MK.$('#kNew').onclick = function () {
            MK.run(this, 'create.newComp', compArgs(), function (r) { return MK.t('k.made', { name: r.name, w: r.width, h: r.height }); });
        };
        MK.$('#kRead').onclick = function () {
            MK.busy(this, function () { return MK.host('create.readComp', {}).then(fillComp); });
        };
        MK.$('#kEdit').onclick = function () {
            var a = compArgs();
            a.keepCenter = MK.$('#kKeepCenter').checked;
            a.scope = MK.$('#kScope').checked ? 'project' : 'active';
            MK.run(this, 'create.editComp', a, function (r) { if (r.info) { fillComp(r.info); } return MK.t('k.edited', { n: r.count }); });
        };

        /* ---- shapes ---- */
        var s = MK.settings.shape;
        if (s) {
            MK.$('#kSW').value = s.w; MK.$('#kSH').value = s.h; MK.$('#kSR').value = s.r; MK.$('#kSP').value = s.p;
            MK.$('#kSFillOn').checked = s.fillOn !== false; MK.$('#kSFill').value = s.fill || '#ff2d55';
            MK.$('#kSSw').value = s.sw; MK.$('#kSStroke').value = s.stroke || '#ffffff'; MK.$('#kSLive').checked = s.live !== false;
        }
        MK.$$('#kShapeTypes [data-shape]').forEach(function (b) {
            b.onclick = function () {
                saveShape();
                MK.run(b, 'create.shape', shapeArgs(b.dataset.shape), function (r) { return MK.t(r.live ? 'k.shapeLive' : 'k.shapeMade', { name: r.name }); });
            };
        });
        MK.$('#kSApply').onclick = function () {
            saveShape();
            var a = shapeArgs('');
            a.live = false;
            a.doSize = MK.$('#kSDoSize').checked; a.doRound = MK.$('#kSDoRound').checked;
            a.doFill = MK.$('#kSDoFill').checked; a.doStroke = MK.$('#kSDoStroke').checked;
            MK.run(this, 'create.editShape', a);
        };
        MK.$('#kSLink').onclick = function () {
            MK.run(this, 'create.editShape', { live: true }, function (r) { return MK.t('k.linked', { n: r.count }); });
        };

        /* ---- safe zones ---- */
        var z = MK.settings.zone || {};
        if (z.id) { MK.$('#kZone').value = z.id; }
        if (z.thirds !== undefined) { MK.$('#kThirds').checked = z.thirds; MK.$('#kCenter').checked = z.center; }
        MK.$('#kZoneAdd').onclick = function () {
            var a = { zone: MK.$('#kZone').value, thirds: MK.$('#kThirds').checked, center: MK.$('#kCenter').checked, opacity: num('#kZoneOp', 35) };
            MK.settings.zone = { id: a.zone, thirds: a.thirds, center: a.center };
            MK.saveSettings();
            MK.run(this, 'create.safeZone', a, function (r) { return MK.t('k.zoneMade', { name: r.zone }); });
        };
        MK.$('#kZoneDel').onclick = function () { MK.run(this, 'create.removeSafeZones', {}); };
    };
})(window);
