/* All In One — Sound effects: Freesound search (free API key), your own sound folders, the Downloads folder.
   Pixabay has no sound-effects API, so its button opens the Pixabay sound page; downloads show up under "Downloads". */
(function (w) {
    'use strict';
    var MK = w.MK;

    var AUDIO = /\.(wav|mp3|aif|aiff|m4a|aac|ogg|flac)$/i;
    var TAGS = ['whoosh', 'swoosh', 'pop', 'click', 'impact', 'riser', 'ding', 'notification', 'typing', 'camera shutter', 'glitch', 'cash', 'transition', 'magic', 'boom', 'applause', 'laugh', 'swipe', 'error', 'success'];
    var state = { src: 'online', items: [], page: 1, next: null, q: '' };
    var player = null, playingBtn = null;

    function sfxDir() { return MK.paths.join(MK.paths.data, 'SFX'); }
    function fmtDur(s) { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
    function safe(s) { return String(s).replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, ' ').trim().slice(0, 70) || 'sound'; }
    function licShort(l) {
        l = String(l || '');
        if (/publicdomain\/zero|Creative Commons 0/i.test(l)) { return 'CC0'; }
        if (/by-nc/i.test(l) || /Noncommercial/i.test(l)) { return 'CC BY-NC'; }
        if (/\/by\//i.test(l) || /Attribution/i.test(l)) { return 'CC BY'; }
        if (/sampling/i.test(l)) { return 'Sampling+'; }
        return l ? 'CC' : '';
    }

    /* ---------- sources ---------- */
    function freesound(q, page) {
        var key = MK.settings.keys.freesound;
        if (!key) { var e = new Error(MK.t('sfx.noKey')); e.noKey = true; return Promise.reject(e); }
        var filter = 'duration:[0 TO 30]' + (MK.$('#sfxCC0').checked ? ' license:"Creative Commons 0"' : '');
        var qs = '?query=' + encodeURIComponent(q || 'whoosh') + '&page=' + page + '&page_size=30&sort=score' +
            '&fields=' + encodeURIComponent('id,name,previews,duration,license,username') + '&filter=' + encodeURIComponent(filter);
        var H = { Authorization: 'Token ' + key };
        return MK.http.get('https://freesound.org/apiv2/search/' + qs, H).catch(function (err) {
            if (err.status === 404) { return MK.http.get('https://freesound.org/apiv2/search/text/' + qs, H); }
            throw err;
        }).then(function (r) {
            var list = (r && r.results) || [];
            return {
                next: r && r.next ? page + 1 : null,
                items: list.map(function (x) {
                    var pv = x.previews || {};
                    return {
                        id: 'fs' + x.id, name: x.name, dur: x.duration, url: pv['preview-hq-mp3'] || pv['preview-lq-mp3'],
                        meta: [fmtDur(x.duration), licShort(x.license), x.username].filter(Boolean).join(' · '),
                        file: MK.paths.join(sfxDir(), 'Freesound', x.id + ' ' + safe(String(x.name).replace(AUDIO, '')) + '.mp3'),
                        credit: x.username ? '"' + x.name + '" by ' + x.username + ' (freesound.org/s/' + x.id + ') — ' + licShort(x.license) : ''
                    };
                })
            };
        });
    }

    function scan(dir, depth, out) {
        if (out.length > 3000) { return; }
        MK.fs.list(dir).forEach(function (n) {
            if (n.charAt(0) === '.') { return; }
            var p = MK.paths.join(dir, n);
            if (AUDIO.test(n)) { out.push(p); }
            else if (depth > 0 && MK.fs.isDir(p)) { scan(p, depth - 1, out); }
        });
    }
    function localItems(paths, q) {
        var words = String(q || '').toLowerCase().split(/\s+/).filter(Boolean);
        return paths.filter(function (p) {
            var n = p.toLowerCase();
            return words.every(function (wd) { return n.indexOf(wd) >= 0; });
        }).map(function (p) {
            var name = p.split(/[\\/]/).pop();
            return { id: p, name: name.replace(AUDIO, ''), url: MK.fs.fileUrl(p), file: p, local: true, meta: name.split('.').pop().toUpperCase() + ' · ' + p.split(/[\\/]/).slice(-2, -1)[0] };
        });
    }
    function library(q) {
        var dirs = [sfxDir()].concat(MK.settings.sfxFolders || []);
        var all = [];
        dirs.forEach(function (d) { scan(d, 4, all); });
        return localItems(all, q);
    }
    function downloads(q) {
        if (!MK.hasNode) { return []; }
        var dir = MK.paths.join(MK.paths.home, 'Downloads');
        var fs = MK.require('fs');
        var files = MK.fs.list(dir).filter(function (n) { return AUDIO.test(n); }).map(function (n) {
            var p = MK.paths.join(dir, n), t = 0;
            try { t = fs.statSync(p).mtime.getTime(); } catch (e) {}
            return { p: p, t: t };
        }).sort(function (a, b) { return b.t - a.t; }).slice(0, 80).map(function (x) { return x.p; });
        return localItems(files, q);
    }

    /* ---------- list ---------- */
    function stop() {
        if (player) { try { player.pause(); } catch (e) {} }
        if (playingBtn) { playingBtn.classList.remove('on'); playingBtn = null; }
    }
    function play(btn, url) {
        if (playingBtn === btn) { stop(); return; }
        stop();
        if (!player) { player = new Audio(); player.addEventListener('ended', stop); }
        player.src = url;
        player.volume = 0.9;
        var pr = player.play();
        if (pr && pr.catch) { pr.catch(function () { stop(); MK.toast(MK.t('sfx.noPreview'), 'warn'); }); }
        playingBtn = btn;
        btn.classList.add('on');
    }

    function render(append) {
        var box = MK.$('#sfxList');
        if (!append) { box.innerHTML = ''; }
        if (!state.items.length) {
            var q = MK.$('#sfxQuery').value.trim();
            box.innerHTML = '<div class="empty">' + MK.esc(state.src === 'online' ? MK.t('sfx.none') : (q ? MK.t('sfx.noneQuery', { q: q }) : MK.t('sfx.noneLocal'))) + '</div>';
            return;
        }
        var start = append ? box.querySelectorAll('.sfx-item').length : 0;
        state.items.slice(start).forEach(function (it) {
            var row = document.createElement('div');
            row.className = 'sfx-item';
            row.innerHTML = '<button class="sfx-play" title="Preview">' + MK.icon('play') + '</button>' +
                '<div class="sfx-meta"><b></b><small></small></div><button class="btn sm sfx-add">' + MK.icon('plus') + '<span>' + MK.esc(MK.t('sfx.add')) + '</span></button>';
            row.querySelector('b').textContent = it.name;
            row.querySelector('b').title = it.name;
            row.querySelector('small').textContent = it.meta || '';
            row.querySelector('.sfx-play').onclick = function () { play(this, it.url); };
            row.querySelector('.sfx-add').onclick = function () { add(this, it); };
            box.appendChild(row);
        });
        MK.$('#sfxMore').classList.toggle('hidden', !(state.src === 'online' && state.next));
    }

    function search(more) {
        stop();
        var q = MK.$('#sfxQuery').value.trim();
        var notice = MK.$('#sfxNotice');
        notice.classList.add('hidden');
        if (state.src !== 'online') {
            state.items = state.src === 'library' ? library(q) : downloads(q);
            state.next = null;
            render(false);
            return Promise.resolve();
        }
        if (!more) { state.page = 1; state.items = []; }
        state.q = q;
        return MK.busy(MK.$('#sfxGo'), function () {
            return freesound(q, state.page).then(function (r) {
                state.items = state.items.concat(r.items);
                state.next = r.next;
                render(!!more);
            }).catch(function (e) {
                if (e.noKey) {
                    notice.innerHTML = MK.esc(MK.t('sfx.noKey')) + ' <a href="#" data-url="https://freesound.org/apiv2/apply">freesound.org/apiv2/apply ↗</a>';
                    notice.classList.remove('hidden');
                    state.items = [];
                    render(false);
                    return;
                }
                throw e;
            });
        });
    }

    function add(btn, it) {
        stop();
        var at = MK.$('#sfxAt').value, vol = parseFloat(MK.$('#sfxVol').value) || 0;
        return MK.busy(btn, function () {
            var ready = (it.local || MK.fs.exists(it.file)) ? Promise.resolve() : MK.http.download(it.url, it.file).then(function (r) {
                if (r && r.status >= 400) { throw new Error('HTTP ' + r.status); }
            });
            return ready.then(function () {
                return MK.host('sfx.place', { path: it.file, volume: vol, at: at });
            }).then(function (r) {
                MK.toast(MK.t('sfx.added', { name: r.name, n: r.count }));
                if (it.credit) { MK.settings.sfxCredits = (MK.settings.sfxCredits || []).concat([it.credit]).slice(-200); MK.saveSettings(); }
            });
        });
    }

    MK.initSfx = function () {
        // Media tab: B-Roll | Sound FX
        MK.seg(MK.$('#mediaSub'), function (b) {
            MK.$$('#tab-broll .sub').forEach(function (s) { s.classList.toggle('active', s.id === 'sub-' + b.dataset.sub); });
            if (b.dataset.sub === 'sfx' && !MK.$('#sfxList').children.length) { search(false).catch(MK.fail); }
            if (b.dataset.sub !== 'sfx') { stop(); }
        });
        MK.seg(MK.$('#sfxSrc'), function (b) { state.src = b.dataset.v; search(false).catch(MK.fail); });
        var tags = MK.$('#sfxTags');
        TAGS.forEach(function (t) {
            var c = document.createElement('button');
            c.className = 'chip small';
            c.textContent = t;
            c.onclick = function () { MK.$('#sfxQuery').value = t; search(false).catch(MK.fail); };
            tags.appendChild(c);
        });
        MK.$('#sfxGo').onclick = function () { search(false).catch(MK.fail); };
        MK.$('#sfxNotice').addEventListener('click', function (e) {
            var a = e.target.closest ? e.target.closest('[data-url]') : null;
            if (a) { e.preventDefault(); MK.openURL(a.getAttribute('data-url')); }
        });
        MK.$('#sfxQuery').addEventListener('keydown', function (e) { if (e.key === 'Enter') { search(false).catch(MK.fail); } });
        MK.$('#sfxMore').onclick = function () { state.page++; search(true).catch(MK.fail); };
        MK.$('#sfxCC0').addEventListener('change', function () { if (state.src === 'online') { search(false).catch(MK.fail); } });
        MK.$('#sfxPixabay').onclick = function () {
            var q = MK.$('#sfxQuery').value.trim();
            MK.openURL('https://pixabay.com/sound-effects/' + (q ? 'search/' + encodeURIComponent(q) + '/' : ''));
            MK.toast(MK.t('sfx.pixabayTip'));
        };
        MK.$('#sfxAddFolder').onclick = function () {
            MK.busy(this, function () {
                return MK.host('app.chooseFolder', { title: 'Choose a folder with sound effects' }).then(function (p) {
                    if (!p) { return; }
                    var list = MK.settings.sfxFolders || [];
                    if (list.indexOf(p) < 0) { list.push(p); }
                    MK.settings.sfxFolders = list;
                    MK.saveSettings();
                    MK.$$('#sfxSrc button').forEach(function (x) { x.classList.toggle('active', x.dataset.v === 'library'); });
                    state.src = 'library';
                    return search(false);
                });
            });
        };
        MK.$('#sfxOpenDir').onclick = function () {
            try { MK.fs.mkdirp(sfxDir()); } catch (e) {}
            MK.host('app.openFolder', { path: state.src === 'downloads' ? MK.paths.join(MK.paths.home, 'Downloads') : sfxDir() }).catch(MK.fail);
        };
        var v = MK.settings.sfx || {};
        if (v.vol !== undefined) { MK.$('#sfxVol').value = v.vol; }
        if (v.at) { MK.$('#sfxAt').value = v.at; }
        ['#sfxVol', '#sfxAt'].forEach(function (s) {
            MK.$(s).addEventListener('change', function () { MK.settings.sfx = { vol: MK.$('#sfxVol').value, at: MK.$('#sfxAt').value }; MK.saveSettings(); });
        });
    };

    MK._sfx = { licShort: licShort, localItems: localItems, state: state };
})(window);
