/* All In One — Quick Tools panel logic */
(function (w) {
    'use strict';
    var MK = w.MK;

    function frames() { return parseFloat(MK.$('#qSeqFrames').value) || 0; }

    var actions = {
        addText: function (b) { return MK.run(b, 'quick.addText', {}); },
        addSolid: function (b) {
            return MK.modal({
                title: MK.t('q.solidTitle'),
                html: '<label>' + MK.t('q.name') + '<input type="text" name="name" value="Solid"></label>' +
                      '<label>' + MK.t('q.color') + '<input type="color" name="color" value="#1a1a1f"></label>'
            }).then(function (r) {
                if (!r) { return; }
                return MK.run(b, 'quick.addSolid', { name: r.name, color: MK.hexToRgb01(r.color) });
            });
        },
        addAdjust: function (b) { return MK.run(b, 'quick.addSolid', { adjustment: true, color: [1, 1, 1] }); },
        addNull: function (b) { return MK.run(b, 'quick.addNull', { parent: MK.$('#qNullParent').checked }); },
        addCamera: function (b) { return MK.run(b, 'quick.addCamera', {}); },
        precompose: function (b) { return MK.run(b, 'quick.precompose', {}, function (r) { return MK.t('ok.precomp', { name: r.name }); }); },
        unprecompose: function (b) { return MK.run(b, 'quick.unprecompose', { keep: false }, function (r) { return MK.t('ok.unprecomp', { n: r.count }); }); },
        trueDuplicate: function (b) { return MK.run(b, 'quick.trueDuplicate', {}); },

        splitChar: function (b) { return MK.run(b, 'quick.splitText', { by: 'char' }); },
        splitWord: function (b) { return MK.run(b, 'quick.splitText', { by: 'word' }); },
        splitLine: function (b) { return MK.run(b, 'quick.splitText', { by: 'line' }); },
        caseUpper: function (b) { return MK.run(b, 'quick.textCase', { mode: 'upper' }); },
        caseLower: function (b) { return MK.run(b, 'quick.textCase', { mode: 'lower' }); },
        caseTitle: function (b) { return MK.run(b, 'quick.textCase', { mode: 'title' }); },
        caseSentence: function (b) { return MK.run(b, 'quick.textCase', { mode: 'sentence' }); },
        rename: function (b) {
            return MK.modal({
                title: MK.t('q.renameTitle'),
                html: '<label>' + MK.t('q.renameBase') + '<input type="text" name="base" value="Layer"></label>' +
                      '<label>' + MK.t('q.renameStart') + '<input type="number" name="start" value="1"></label>'
            }).then(function (r) {
                if (!r || !r.base) { return; }
                return MK.run(b, 'quick.rename', { base: r.base, start: r.start, pad: 2 });
            });
        },

        trimIn: function (b) { return MK.run(b, 'quick.trim', { side: 'in' }); },
        trimOut: function (b) { return MK.run(b, 'quick.trim', { side: 'out' }); },
        splitAt: function (b) { return MK.run(b, 'quick.splitAtPlayhead', {}); },
        toPlayhead: function (b) { return MK.run(b, 'quick.moveToPlayhead', {}); },
        seqStagger: function (b) { return MK.run(b, 'quick.sequence', { frames: frames(), mode: 'stagger', reverse: MK.$('#qSeqRev').checked }); },
        seqChain: function (b) { return MK.run(b, 'quick.sequence', { frames: frames(), mode: 'end', reverse: MK.$('#qSeqRev').checked }); },

        alignLeft: function (b) { return MK.run(b, 'quick.align', { h: 'left' }); },
        alignCenter: function (b) { return MK.run(b, 'quick.align', { h: 'center' }); },
        alignRight: function (b) { return MK.run(b, 'quick.align', { h: 'right' }); },
        alignTop: function (b) { return MK.run(b, 'quick.align', { v: 'top' }); },
        alignMiddle: function (b) { return MK.run(b, 'quick.align', { v: 'middle' }); },
        alignBottom: function (b) { return MK.run(b, 'quick.align', { v: 'bottom' }); },
        fit: function (b) { return MK.run(b, 'quick.fit', { mode: 'fit' }); },
        fill: function (b) { return MK.run(b, 'quick.fit', { mode: 'fill' }); },
        fitW: function (b) { return MK.run(b, 'quick.fit', { mode: 'width' }); },
        fitH: function (b) { return MK.run(b, 'quick.fit', { mode: 'height' }); },
        flipH: function (b) { return MK.run(b, 'quick.flip', { axis: 'h' }); },
        flipV: function (b) { return MK.run(b, 'quick.flip', { axis: 'v' }); },

        exBounce: function (b) { return exprRun(b, 'bounce'); },
        exWiggle: function (b) { return exprRun(b, 'wiggle'); },
        exLoop: function (b) { return exprRun(b, 'loop'); },
        exPing: function (b) { return exprRun(b, 'pingpong'); },
        exRemove: function (b) { return MK.run(b, 'quick.removeExpressions', {}); },
        fxOn: function (b) { return MK.run(b, 'quick.toggleEffects', { on: true }); },
        fxOff: function (b) { return MK.run(b, 'quick.toggleEffects', { on: false }); },

        organize: function (b) {
            return MK.run(b, 'quick.organizeProject', { removeUnused: MK.$('#qRemoveUnused').checked }, function (r) {
                return MK.t('ok.organize', { moved: r.moved, removed: r.removed });
            });
        }
    };

    function exprRun(b, type) {
        return MK.run(b, 'quick.applyExpression', { type: type }, function (r) {
            if (r.errors && r.errors.length) { return MK.t('a.exprErr', { e: r.errors[0] }); }
            return MK.t('a.exprApplied', { n: r.count });
        });
    }

    MK.initQuick = function () {
        MK.$$('#tab-quick [data-q]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var fn = actions[btn.dataset.q];
                if (fn) { fn(btn); }
            });
        });
        MK.$$('#anchorGrid button').forEach(function (btn) {
            btn.addEventListener('click', function () {
                MK.run(btn, 'quick.anchor', { x: parseFloat(btn.dataset.ax), y: parseFloat(btn.dataset.ay) });
            });
        });
    };
})(window);
