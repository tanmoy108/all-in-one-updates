/* All In One — Captions: transcribe (Gemini / Groq / AssemblyAI), chunk, edit, style, create layers, SRT */
(function (w) {
    'use strict';
    var MK = w.MK;

    var state = { source: null, words: [], caps: [] };

    var STYLES = {
        'Reels Pop': { font: 'Arial-BoldMT', size: 86, yPct: 72, fill: '#ffffff', stroke: 8, strokeColor: '#000000', anim: 'pop', upper: true, shadow: false, highlight: true, hlColor: '#ffd21a', hlMode: 'current', hlScale: 112, tracking: 0 },
        'Clean': { font: 'Arial-BoldMT', size: 68, yPct: 82, fill: '#ffffff', stroke: 0, strokeColor: '#000000', anim: 'fade', upper: false, shadow: true, highlight: false, hlColor: '#ffd21a', hlMode: 'current', hlScale: 100, tracking: 0 },
        'Karaoke': { font: 'Arial-BoldMT', size: 74, yPct: 80, fill: '#ffffff', stroke: 4, strokeColor: '#101010', anim: 'none', upper: false, shadow: false, highlight: true, hlColor: '#31d0ff', hlMode: 'progressive', hlScale: 100, tracking: 0 },
        'Bold Yellow': { font: 'Arial-BoldMT', size: 90, yPct: 70, fill: '#ffd21a', stroke: 7, strokeColor: '#000000', anim: 'bounce', upper: true, shadow: false, highlight: false, hlColor: '#ffffff', hlMode: 'current', hlScale: 100, tracking: 20 },
        'Bangla': { font: 'HindSiliguri-Bold', size: 80, yPct: 78, fill: '#ffffff', stroke: 6, strokeColor: '#000000', anim: 'pop', upper: false, shadow: false, highlight: true, hlColor: '#ff3b5c', hlMode: 'current', hlScale: 108, tracking: 0 },
        'Minimal': { font: 'Arial-BoldMT', size: 54, yPct: 88, fill: '#f2f2f2', stroke: 0, strokeColor: '#000000', anim: 'fade', upper: false, shadow: true, highlight: false, hlColor: '#ffd21a', hlMode: 'current', hlScale: 100, tracking: 0 }
    };
    var SKEYS = ['font', 'size', 'yPct', 'fill', 'stroke', 'strokeColor', 'anim', 'upper', 'shadow', 'highlight', 'hlColor', 'hlMode', 'hlScale', 'tracking'];

    /* ---------- helpers ---------- */
    function srtTime(t) {
        t = Math.max(0, t);
        var h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = Math.floor(t % 60), ms = Math.round((t - Math.floor(t)) * 1000);
        if (ms === 1000) { ms = 999; }
        var p = function (n, l) { n = String(n); while (n.length < l) { n = '0' + n; } return n; };
        return p(h, 2) + ':' + p(m, 2) + ':' + p(s, 2) + ',' + p(ms, 3);
    }
    function toComp(t) {
        var src = state.source;
        if (!src || src.type !== 'layer') { return t; }
        return src.startTime + t * (src.stretch / 100);
    }
    function key(name) {
        var k = MK.settings.keys[name];
        if (!k) { throw new Error(MK.t('err.noKey', { name: { groq: 'Groq', assemblyai: 'AssemblyAI', gemini: 'Google Gemini' }[name] || name })); }
        return k;
    }

    /* ---------- transcription ---------- */
    function groq(path, bar) {
        var k = key('groq');
        var fs = MK.require('fs'), pth = MK.require('path');
        var size = MK.fs.size(path);
        if (size > 25 * 1024 * 1024) { throw new Error(MK.t('c.tooBig', { mb: (size / 1048576).toFixed(1) })); }
        MK.progress(bar, null, MK.t('c.uploading', { name: 'Groq' }));
        var fields = [['model', MK.$('#capModel').value], ['response_format', 'verbose_json'], ['temperature', '0'],
            ['timestamp_granularities[]', 'word'], ['timestamp_granularities[]', 'segment']];
        var lang = MK.$('#capLang').value;
        if (lang) { fields.push(['language', lang]); }
        var file = { field: 'file', name: pth.basename(path), buffer: fs.readFileSync(path) };
        return MK.http.multipart('https://api.groq.com/openai/v1/audio/transcriptions', fields, file, { Authorization: 'Bearer ' + k }, 600000)
            .then(function (r) {
                var words = (r.words || []).map(function (x) { return { w: String(x.word).trim(), s: +x.start, e: +x.end }; }).filter(function (x) { return x.w; });
                if (!words.length && r.segments) { words = wordsFromSegments(r.segments.map(function (s) { return { text: s.text, s: s.start, e: s.end }; })); }
                return words;
            });
    }

    function assembly(path, bar) {
        var k = key('assemblyai');
        var fs = MK.require('fs');
        MK.progress(bar, null, MK.t('c.uploading', { name: 'AssemblyAI' }));
        var H = { Authorization: k };
        return MK.http.postBinary('https://api.assemblyai.com/v2/upload', fs.readFileSync(path), H, 900000)
            .then(function (up) {
                var body = { audio_url: up.upload_url, punctuate: true, format_text: true };
                var lang = MK.$('#capLang').value;
                if (lang) { body.language_code = lang; } else { body.language_detection = true; }
                return MK.http.postJSON('https://api.assemblyai.com/v2/transcript', body, H);
            })
            .then(function (job) {
                var t0 = Date.now();
                var poll = function () {
                    return MK.sleep(2500).then(function () { return MK.http.get('https://api.assemblyai.com/v2/transcript/' + job.id, H); }).then(function (r) {
                        if (r.status === 'completed') { return r; }
                        if (r.status === 'error') { throw new Error(r.error || 'AssemblyAI error'); }
                        MK.progress(bar, null, MK.t('c.waiting', { s: Math.round((Date.now() - t0) / 1000) }));
                        return poll();
                    });
                };
                return poll();
            })
            .then(function (r) {
                var want = MK.$('#capLang').value;
                if (!want && r.language_code && /^hi/.test(r.language_code)) { MK.toast(MK.t('c.gotHindi'), 'warn'); }
                return (r.words || []).map(function (x) { return { w: String(x.text).trim(), s: x.start / 1000, e: x.end / 1000 }; }).filter(function (x) { return x.w; });
            });
    }

    /* ---------- Gemini (audio understanding, segment timestamps) ---------- */
    var GEM = 'https://generativelanguage.googleapis.com';
    var MIME = { mp3: 'audio/mp3', wav: 'audio/wav', aac: 'audio/aac', m4a: 'audio/aac', ogg: 'audio/ogg', flac: 'audio/flac', aif: 'audio/aiff', aiff: 'audio/aiff',
        mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', avi: 'video/x-msvideo', mpg: 'video/mpeg', mpeg: 'video/mpeg', wmv: 'video/wmv', '3gp': 'video/3gpp', mkv: 'video/x-matroska' };
    var LANG_NAME = { bn: 'Bangla (Bengali script বাংলা — never Hindi/Devanagari, never romanized, never translated)', en: 'English', hi: 'Hindi (Devanagari)', ur: 'Urdu (Arabic script)', ar: 'Arabic', es: 'Spanish' };
    var CHUNK = 180, OVERLAP = 2;

    function mmss(t) { t = Math.max(0, Math.round(t)); return ('0' + Math.floor(t / 60)).slice(-2) + ':' + ('0' + (t % 60)).slice(-2); }

    function gemPrompt(lang, win) {
        return 'Transcribe every spoken word in this audio for video captions.\n' +
            '- Language: ' + (lang ? LANG_NAME[lang] || lang : 'the original spoken language, written in its normal script (Bangla in Bengali script, not Hindi). Do not translate') + '.\n' +
            '- Write exactly what is said. English words spoken inside Bangla speech stay in English letters.\n' +
            '- Split the speech into short segments of 1 to 6 words that follow natural pauses.\n' +
            '- For every segment give "s" = start and "e" = end in seconds from the beginning of this audio (two decimals, e.g. 12.34) and "t" = the text.\n' +
            '- Times must increase and segments must not overlap. Do not skip speech. Ignore music and sound effects.\n' +
            (win ? '- Only transcribe the speech between ' + mmss(win[0]) + ' and ' + mmss(win[1]) + ' of the file (times are still measured from the start of the file).\n' : '') +
            '- If nobody speaks, return an empty array [].';
    }

    function gemModel() { return MK.$('#capGemModel').value || 'gemini-flash-latest'; }

    function gemCall(part, lang, win, tries) {
        var body = {
            contents: [{ role: 'user', parts: [part, { text: gemPrompt(lang, win) }] }],
            generationConfig: {
                temperature: 0, responseMimeType: 'application/json',
                responseSchema: { type: 'ARRAY', items: { type: 'OBJECT', properties: { s: { type: 'NUMBER' }, e: { type: 'NUMBER' }, t: { type: 'STRING' } }, required: ['s', 'e', 't'] } }
            }
        };
        return MK.http.postJSON(GEM + '/v1beta/models/' + encodeURIComponent(gemModel()) + ':generateContent', body, { 'x-goog-api-key': key('gemini') }, 600000)
            .then(function (r) { return parseGem(r); }, function (err) {
                tries = tries || 0;
                if ((err.status === 429 || err.status === 503 || err.status === 500) && tries < 2) {
                    return MK.sleep(err.status === 429 ? 20000 : 5000).then(function () { return gemCall(part, lang, win, tries + 1); });
                }
                throw err;
            });
    }

    function parseGem(r) {
        var cand = r && r.candidates && r.candidates[0];
        if (!cand) { throw new Error((r && r.promptFeedback && r.promptFeedback.blockReason) ? 'Gemini: ' + r.promptFeedback.blockReason : 'Gemini: empty reply'); }
        var txt = ((cand.content && cand.content.parts) || []).map(function (p) { return p.text || ''; }).join('').trim();
        txt = txt.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '');
        var arr;
        try { arr = JSON.parse(txt); } catch (e) {
            // reply cut off (very long audio): keep every complete segment
            var cut = txt.lastIndexOf('}');
            try { arr = JSON.parse(txt.slice(0, cut + 1) + ']'); } catch (e2) { throw new Error('Gemini: could not read the transcript'); }
        }
        if (!(arr instanceof Array)) { arr = arr && arr.segments ? arr.segments : []; }
        return arr.map(function (x) { return { text: String(x.t || x.text || '').trim(), s: parseFloat(x.s), e: parseFloat(x.e) }; })
            .filter(function (x) { return x.text && !isNaN(x.s); });
    }

    // segments → words: spread each segment's time over its words by length
    function segWords(segs, offset, lo, hi) {
        var out = [];
        segs.sort(function (a, b) { return a.s - b.s; });
        segs.forEach(function (sg, i) {
            var s = sg.s, e = isNaN(sg.e) || sg.e <= s ? (segs[i + 1] ? segs[i + 1].s : s + 0.4 * sg.text.split(/\s+/).length) : sg.e;
            if (lo !== undefined && (s < lo || s >= hi)) { return; }
            var toks = sg.text.split(/\s+/).filter(Boolean);
            var total = toks.reduce(function (a, t) { return a + t.length + 1; }, 0), acc = 0;
            toks.forEach(function (t) {
                var ws = s + (e - s) * acc / total;
                acc += t.length + 1;
                out.push({ w: t, s: offset + ws, e: offset + s + (e - s) * acc / total });
            });
        });
        return out;
    }

    function gemUpload(path, mime, bar) {
        var fs = MK.require('fs'), Buffer = MK.require('buffer').Buffer;
        var size = MK.fs.size(path);
        if (size > 1900 * 1048576) { throw new Error(MK.t('c.tooBig', { mb: (size / 1048576).toFixed(0) })); }
        MK.progress(bar, null, MK.t('c.uploading', { name: 'Gemini' }));
        var H = { 'x-goog-api-key': key('gemini') };
        var meta = Buffer.from(JSON.stringify({ file: { display_name: 'aio-captions' } }), 'utf8');
        return MK.http.raw({ url: GEM + '/upload/v1beta/files', method: 'POST', headers: Object.assign({
            'X-Goog-Upload-Protocol': 'resumable', 'X-Goog-Upload-Command': 'start', 'X-Goog-Upload-Header-Content-Length': String(size),
            'X-Goog-Upload-Header-Content-Type': mime, 'Content-Type': 'application/json' }, H) }, meta)
            .then(function (r) {
                var up = r.headers && (r.headers['x-goog-upload-url'] || r.headers['X-Goog-Upload-URL']);
                if (!up) { throw new Error('Gemini upload: ' + (r.body ? r.body.toString('utf8').slice(0, 200) : 'HTTP ' + r.status)); }
                return MK.http.raw({ url: up, method: 'POST', timeout: 1800000, headers: Object.assign({ 'X-Goog-Upload-Offset': '0', 'X-Goog-Upload-Command': 'upload, finalize' }, H) }, fs.readFileSync(path));
            })
            .then(function (r) {
                var data = JSON.parse(r.body.toString('utf8'));
                if (r.status >= 400 || !data.file) { throw new Error('Gemini upload: ' + ((data.error && data.error.message) || r.status)); }
                var file = data.file, t0 = Date.now();
                var wait = function () {
                    if (file.state === 'ACTIVE' || !file.state) { return file; }
                    if (file.state === 'FAILED') { throw new Error('Gemini could not process the file'); }
                    MK.progress(bar, null, MK.t('c.waiting', { s: Math.round((Date.now() - t0) / 1000) }));
                    return MK.sleep(2500).then(function () { return MK.http.get(GEM + '/v1beta/' + file.name, H); }).then(function (f) { file = f; return wait(); });
                };
                return wait();
            });
    }

    /* ---------- WAV / AIFF → 16 kHz mono WAV pieces in plain JS (no ffmpeg) ---------- */
    function pcmInfo(file) {
        var fs = MK.require('fs'), Buffer = MK.require('buffer').Buffer;
        var fd = fs.openSync(file, 'r');
        var size = fs.fstatSync(fd).size;
        var rd = function (pos, len) { var b = Buffer.alloc(len); fs.readSync(fd, b, 0, len, pos); return b; };
        var h = rd(0, 12), id = h.toString('latin1', 0, 4), kind = h.toString('latin1', 8, 12);
        var info = { fd: fd, size: size, be: false, float: false }, pos = 12;
        try {
            if (id === 'RIFF' && kind === 'WAVE') {
                while (pos + 8 <= size) {
                    var ch = rd(pos, 8), cid = ch.toString('latin1', 0, 4), clen = ch.readUInt32LE(4);
                    if (cid === 'fmt ') {
                        var fm = rd(pos + 8, Math.min(clen, 40)), tag = fm.readUInt16LE(0);
                        info.channels = fm.readUInt16LE(2); info.rate = fm.readUInt32LE(4); info.bits = fm.readUInt16LE(14);
                        if (tag === 0xFFFE && clen >= 26) { tag = fm.readUInt16LE(24); }
                        if (tag !== 1 && tag !== 3) { throw new Error('Unsupported WAV encoding (' + tag + ')'); }
                        info.float = tag === 3;
                    } else if (cid === 'data') {
                        info.data = pos + 8; info.bytes = Math.min(clen || size, size - pos - 8);
                        break;
                    }
                    pos += 8 + clen + (clen & 1);
                }
            } else if (id === 'FORM' && (kind === 'AIFF' || kind === 'AIFC')) {
                info.be = true;
                while (pos + 8 <= size) {
                    var c2 = rd(pos, 8), cid2 = c2.toString('latin1', 0, 4), clen2 = c2.readUInt32BE(4);
                    if (cid2 === 'COMM') {
                        var cm = rd(pos + 8, Math.min(clen2, 26));
                        info.channels = cm.readUInt16BE(0); info.bits = cm.readUInt16BE(6);
                        // 80-bit extended sample rate
                        var ex = cm.readUInt16BE(8) & 0x7FFF, hi = cm.readUInt32BE(10), lo = cm.readUInt32BE(14);
                        info.rate = Math.round((hi * 4294967296 + lo) * Math.pow(2, ex - 16383 - 63));
                        if (kind === 'AIFC' && clen2 >= 22) {
                            var comp = cm.toString('latin1', 18, 22);
                            if (comp === 'sowt') { info.be = false; }
                            else if (/^fl32$/i.test(comp)) { info.float = true; }
                            else if (comp !== 'NONE') { throw new Error('Unsupported AIFF-C audio (' + comp + ')'); }
                        }
                    } else if (cid2 === 'SSND') {
                        var off = rd(pos + 8, 4).readUInt32BE(0);
                        info.data = pos + 16 + off; info.bytes = Math.min(clen2 - 8 - off, size - info.data);
                        break;
                    }
                    pos += 8 + clen2 + (clen2 & 1);
                }
            } else { throw new Error('NOT_PCM'); }
            if (!info.data || !info.channels || !info.rate || !info.bits) { throw new Error('Could not read the audio file'); }
        } catch (e) { fs.closeSync(fd); throw e; }
        info.frameBytes = info.channels * info.bits / 8;
        info.frames = Math.floor(info.bytes / info.frameBytes);
        info.duration = info.frames / info.rate;
        return info;
    }

    // one piece [t0, t1) as a 16 kHz mono 16-bit WAV (averaging = simple low-pass + downmix)
    function pcmChunk(info, t0, t1) {
        var fs = MK.require('fs'), Buffer = MK.require('buffer').Buffer;
        var R = 16000;
        var f0 = Math.max(0, Math.floor(t0 * info.rate)), f1 = Math.min(info.frames, Math.ceil(t1 * info.rate));
        var n = Math.max(0, f1 - f0), fb = info.frameBytes, ch = info.channels, by = info.bits / 8;
        var raw = Buffer.alloc(n * fb);
        if (n) { fs.readSync(info.fd, raw, 0, raw.length, info.data + f0 * fb); }
        var be = info.be, bits = info.bits, fl = info.float, wav = !be && !fl && bits === 8;
        // 1) down-mix to mono floats
        var mono = new Float32Array(n), i, c, j;
        if (bits === 16 && !fl) {
            // fast path (After Effects renders 16-bit): typed-array read
            if (be) { raw.swap16(); }
            var i16 = new Int16Array(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.length));
            for (i = 0, j = 0; i < n; i++) { var sum16 = 0; for (c = 0; c < ch; c++) { sum16 += i16[j++]; } mono[i] = sum16 / (ch * 32768); }
        } else {
            var smp = function (o) {
                if (fl) { return be ? raw.readFloatBE(o) : raw.readFloatLE(o); }
                if (bits === 24) { return (be ? raw.readIntBE(o, 3) : raw.readIntLE(o, 3)) / 8388608; }
                if (bits === 32) { return (be ? raw.readInt32BE(o) : raw.readInt32LE(o)) / 2147483648; }
                return wav ? (raw[o] - 128) / 128 : raw.readInt8(o) / 128;
            };
            for (i = 0; i < n; i++) { var sm = 0; for (c = 0; c < ch; c++) { sm += smp(i * fb + c * by); } mono[i] = sm / ch; }
        }
        // 2) average down to 16 kHz (simple low-pass + decimation)
        var outN = Math.floor(n * R / info.rate), ratio = info.rate / R;
        var pcm = new Int16Array(outN);
        for (var k = 0; k < outN; k++) {
            var a = Math.floor(k * ratio), b = Math.min(n, Math.max(a + 1, Math.floor((k + 1) * ratio)));
            var acc = 0;
            for (i = a; i < b; i++) { acc += mono[i]; }
            var v = Math.round(acc / (b - a) * 32767);
            pcm[k] = v > 32767 ? 32767 : (v < -32768 ? -32768 : v);
        }
        // 3) 16-bit mono WAV
        var out = Buffer.alloc(44 + outN * 2);
        out.write('RIFF', 0, 'latin1'); out.writeUInt32LE(36 + outN * 2, 4); out.write('WAVE', 8, 'latin1'); out.write('fmt ', 12, 'latin1');
        out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20); out.writeUInt16LE(1, 22); out.writeUInt32LE(R, 24); out.writeUInt32LE(R * 2, 28);
        out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34); out.write('data', 36, 'latin1'); out.writeUInt32LE(outN * 2, 40);
        var pb = Buffer.from(pcm.buffer);
        if (!new Uint8Array(new Uint16Array([1]).buffer)[0]) { pb.swap16(); } // big-endian machine: WAV is little-endian
        pb.copy(out, 44);
        return out;
    }

    MK._pcm = { info: pcmInfo, chunk: pcmChunk };

    // 3-minute pieces (2 s overlap) of a WAV/AIFF file → words
    function gemPieces(info, lang, bar) {
        var dur = info.duration, starts = [];
        for (var b = 0; b < Math.max(dur, 0.1); b += CHUNK) { starts.push(b); }
        var words = [], i = 0;
        var next = function () {
            if (i >= starts.length) { return Promise.resolve(words); }
            var last = i === starts.length - 1;
            var b0 = starts[i], b1 = last ? dur : starts[i + 1];
            var cs = Math.max(0, b0 - OVERLAP), ce = Math.min(dur, b1 + OVERLAP);
            MK.progress(bar, i / starts.length, MK.t('c.gemPart', { i: i + 1, n: starts.length }));
            i++;
            return MK.sleep(30).then(function () {
                var data = pcmChunk(info, cs, ce).toString('base64');
                return gemCall({ inline_data: { mime_type: 'audio/wav', data: data } }, lang);
            }).then(function (segs) {
                words = words.concat(segWords(segs, cs, b0 - cs, last ? Infinity : b1 - cs));
                return next();
            });
        };
        return next();
    }

    function gemini(path, bar) {
        key('gemini');
        var lang = MK.$('#capLang').value;
        var ext = String(path).split('.').pop().toLowerCase();
        var FF = MK.ffmpeg;
        var ff = FF && FF.find();
        if (ff) {
            // small mono MP3, cut into 3-minute pieces → accurate times, no upload limits
            var tmp = MK.paths.join(MK.paths.temp, 'cap_' + Date.now());
            MK.fs.mkdirp(tmp);
            var mp3 = MK.paths.join(tmp, 'all.mp3');
            MK.progress(bar, null, MK.t('c.preparing'));
            return FF.run(['-y', '-i', path, '-vn', '-ac', '1', '-ar', '16000', '-b:a', '48k', mp3]).then(function () { return FF.probe(mp3); }).then(function (dur) {
                var starts = [];
                for (var b = 0; b < Math.max(dur, 0.1); b += CHUNK) { starts.push(b); }
                var words = [], i = 0;
                var next = function () {
                    if (i >= starts.length) { return words; }
                    var b0 = starts[i], b1 = starts[i + 1] === undefined ? dur + 1 : starts[i + 1];
                    var cs = Math.max(0, b0 - OVERLAP), part = MK.paths.join(tmp, 'p' + i + '.mp3');
                    MK.progress(bar, i / starts.length, MK.t('c.gemPart', { i: i + 1, n: starts.length }));
                    i++;
                    return FF.run(['-y', '-ss', String(cs), '-t', String(b1 - cs + OVERLAP), '-i', mp3, '-c', 'copy', part]).then(function () {
                        var data = MK.require('fs').readFileSync(part).toString('base64');
                        return gemCall({ inline_data: { mime_type: 'audio/mp3', data: data } }, lang);
                    }).then(function (segs) {
                        words = words.concat(segWords(segs, cs, b0 - cs, b1 - cs));
                        return next();
                    });
                };
                return next();
            });
        }
        var lang2 = lang;
        var fsx = MK.require('fs');
        var direct = /^(wav|aif|aiff|aifc)$/.test(ext);
        var tmpOut = MK.paths.join(MK.paths.temp, 'cap_audio_' + Date.now());
        var prepared;
        if (direct) { prepared = Promise.resolve({ path: path, temp: false }); }
        else {
            MK.fs.mkdirp(MK.paths.temp);
            MK.progress(bar, null, MK.t('c.extracting'));
            prepared = MK.host('captions.renderAudio', { path: path, out: tmpOut }, { timeout: 1800000 }).then(function (r) { return { path: r.path, temp: true }; });
        }
        return prepared.then(function (p) {
            var info = null;
            var done = function () {
                try { if (info) { fsx.closeSync(info.fd); } } catch (e) {}
                try { if (p.temp) { fsx.unlinkSync(p.path); } } catch (e2) {}
            };
            try { info = pcmInfo(p.path); } catch (e3) { done(); throw e3; }
            return gemPieces(info, lang2, bar).then(function (w) { done(); return w; }, function (err) { done(); throw err; });
        }).catch(function (err) {
            // could not get PCM audio (no audio template, odd format…): send the original file to Gemini instead
            if (/NO_AUDIO_IN_FILE|FILE_MISSING|^Gemini|API key|HTTP|quota|429/i.test(err.message || '') || err.status) { throw err; }
            console.warn('AE audio render failed, uploading the file instead:', err);
            return gemDirect(path, ext, bar, lang2);
        });
    }

    // fallback: the whole file inline (small audio) or through the Gemini Files API
    function gemDirect(path, ext, bar, lang) {
        var mime = MIME[ext] || 'audio/mp3';
        var src = state.source || {};
        var size = MK.fs.size(path);
        var dur = src.duration || 0;
        var part0 = (size < 14 * 1048576 && /^audio/.test(mime))
            ? Promise.resolve({ inline_data: { mime_type: mime, data: MK.require('fs').readFileSync(path).toString('base64') } })
            : gemUpload(path, mime, bar).then(function (f) { return { file_data: { mime_type: f.mimeType || mime, file_uri: f.uri } }; });
        return part0.then(function (part) {
            if (!(dur > CHUNK * 1.5)) {
                MK.progress(bar, null, MK.t('c.gemThinking'));
                return gemCall(part, lang).then(function (segs) { return segWords(segs, 0); });
            }
            var words = [], b = 0, n = Math.ceil(dur / CHUNK);
            var next = function () {
                if (b >= dur) { return words; }
                var b0 = b, b1 = Math.min(dur, b + CHUNK);
                b = b1;
                MK.progress(bar, b0 / dur, MK.t('c.gemPart', { i: Math.round(b0 / CHUNK) + 1, n: n }));
                return gemCall(part, lang, [b0, b1]).then(function (segs) { words = words.concat(segWords(segs, 0, b0, b1)); return next(); });
            };
            return next();
        });
    }

    function wordsFromSegments(segs) {
        var out = [];
        segs.forEach(function (sg) {
            var toks = String(sg.text).trim().split(/\s+/).filter(Boolean);
            var dur = Math.max(0.05, sg.e - sg.s), step = dur / Math.max(1, toks.length);
            toks.forEach(function (t, i) { out.push({ w: t, s: sg.s + i * step, e: sg.s + (i + 1) * step }); });
        });
        return out;
    }

    /* ---------- chunking ---------- */
    function chunk(words, maxWords, maxChars, lines) {
        var out = [], cur = [];
        var limitW = maxWords * lines, limitC = maxChars * lines;
        var flush = function () { if (cur.length) { out.push(cur); cur = []; } };
        words.forEach(function (wd) {
            if (cur.length) {
                var len = cur.map(function (x) { return x.w; }).join(' ').length + 1 + wd.w.length;
                var gap = wd.s - cur[cur.length - 1].e;
                // let a sentence-ending word join a full caption instead of standing alone
                var tail = /[.!?।…]["'”’)]*$/.test(wd.w) && gap <= 0.75 && cur.length <= limitW && len <= limitC + 8;
                if (!tail && (cur.length >= limitW || len > limitC || gap > 0.75)) { flush(); }
            }
            cur.push(wd);
            if (/[.!?।…]["'”’)]*$/.test(wd.w)) { flush(); }
            else if (/[,;:]["'”’)]*$/.test(wd.w) && cur.length >= Math.max(2, Math.ceil(limitW * 0.6))) { flush(); }
        });
        flush();
        var caps = out.map(function (ws) {
            var text = ws.map(function (x) { return x.w; }).join(' ');
            if (lines > 1 && text.length > maxChars && ws.length > 1) {
                var best = 1, bestDiff = 1e9;
                for (var i = 1; i < ws.length; i++) {
                    var a = ws.slice(0, i).map(function (x) { return x.w; }).join(' ').length;
                    var d = Math.abs(a - (text.length - a));
                    if (d < bestDiff) { bestDiff = d; best = i; }
                }
                text = ws.slice(0, best).map(function (x) { return x.w; }).join(' ') + '\r' + ws.slice(best).map(function (x) { return x.w; }).join(' ');
            }
            return { start: toComp(ws[0].s), end: toComp(ws[ws.length - 1].e), text: text, words: ws.map(function (x) { return [toComp(x.s), toComp(x.e)]; }) };
        });
        // close tiny gaps so captions don't flicker, enforce a minimum duration
        for (var j = 0; j < caps.length; j++) {
            var c = caps[j], next = caps[j + 1];
            if (next && next.start - c.end < 0.35) { c.end = next.start; }
            if (c.end - c.start < 0.35) { c.end = next ? Math.min(next.start, c.start + 0.35) : c.start + 0.35; }
            if (c.words.length) { c.words[c.words.length - 1][1] = Math.max(c.words[c.words.length - 1][1], c.end); }
        }
        return caps;
    }

    function rechunk() {
        if (!state.words.length) { return; }
        state.caps = chunk(state.words, +MK.$('#capWords').value || 4, +MK.$('#capChars').value || 28, +MK.$('#capLines').value || 1);
        renderList();
    }

    // keep word timings in sync after a manual edit
    function retime(cap) {
        var toks = cap.text.split(/\s+/).filter(Boolean);
        if (toks.length === cap.words.length) { return; }
        var dur = cap.end - cap.start, step = dur / Math.max(1, toks.length);
        cap.words = toks.map(function (t, i) { return [cap.start + i * step, cap.start + (i + 1) * step]; });
    }

    // one caption on screen at a time: sorted, no overlaps, nothing shorter than 2 frames
    function sanitize(caps) {
        var out = caps.filter(function (c) { return c && String(c.text).trim(); }).map(function (c) {
            return { start: Math.max(0, +c.start), end: +c.end, text: c.text, words: (c.words || []).slice(0) };
        }).sort(function (a, b) { return a.start - b.start; });
        for (var i = 0; i < out.length; i++) {
            var c = out[i], nx = out[i + 1];
            if (nx && c.end > nx.start) { c.end = nx.start; }
            if (c.end - c.start < 0.07) { c.end = c.start + 0.07; if (nx && nx.start < c.end) { nx.start = c.end; } }
            c.words = c.words.map(function (wd) { return [Math.max(c.start, Math.min(wd[0], c.end)), Math.max(c.start, Math.min(wd[1], c.end))]; });
        }
        return out;
    }

    /* ---------- list UI ---------- */
    function renderList() {
        var box = MK.$('#capList');
        box.innerHTML = '';
        MK.$('#capCount').textContent = state.caps.length ? state.caps.length + ' ×' : '';
        var frag = document.createDocumentFragment();
        state.caps.forEach(function (c, i) {
            var row = document.createElement('div');
            row.className = 'cap-item';
            row.innerHTML = '<input class="tn" type="number" step="0.05" min="0" title="Start (s)"><input class="tn" type="number" step="0.05" min="0" title="End (s)">' +
                '<input class="tx" type="text"><span class="x" title="Delete">✕</span>';
            var ins = row.querySelectorAll('input');
            var sIn = ins[0], eIn = ins[1], inp = ins[2];
            sIn.value = c.start.toFixed(2); eIn.value = c.end.toFixed(2);
            inp.value = c.text.replace(/\r/g, ' / ');
            inp.addEventListener('change', function () { c.text = inp.value.replace(/\s*\/\s*/g, '\r').trim(); retime(c); });
            // editing a time re-spreads the word timings inside the new range
            var setTimes = function () {
                var s = parseFloat(sIn.value), e = parseFloat(eIn.value);
                if (isNaN(s) || isNaN(e) || e <= s) { sIn.value = c.start.toFixed(2); eIn.value = c.end.toFixed(2); return; }
                var os = c.start, od = c.end - c.start, nd = e - s;
                c.words = c.words.map(function (wd) { return [s + (wd[0] - os) / od * nd, s + (wd[1] - os) / od * nd]; });
                c.start = s; c.end = e;
            };
            sIn.addEventListener('change', setTimes);
            eIn.addEventListener('change', setTimes);
            sIn.addEventListener('focus', function () { MK.host('app.seek', { time: c.start + 0.01 }).catch(function () {}); });
            row.querySelector('.x').addEventListener('click', function () { state.caps.splice(i, 1); renderList(); });
            frag.appendChild(row);
        });
        box.appendChild(frag);
    }

    function setSource(src) {
        state.source = src;
        var box = MK.$('#capSource');
        box.classList.toggle('set', !!src);
        box.textContent = src ? (src.type === 'layer' ? MK.t('c.layerSrc', { name: src.name }) + '  ·  ' : '') + src.path : MK.t('c.noSource');
    }

    /* ---------- SRT ---------- */
    function parseSRT(txt) {
        var blocks = txt.replace(/\r\n?/g, '\n').split(/\n\s*\n/);
        var ts = function (s) { var m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(s); return m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000 : 0; };
        var caps = [];
        blocks.forEach(function (b) {
            var lines = b.trim().split('\n');
            var tl = -1;
            for (var i = 0; i < lines.length; i++) { if (lines[i].indexOf('-->') >= 0) { tl = i; break; } }
            if (tl < 0) { return; }
            var parts = lines[tl].split('-->');
            var text = lines.slice(tl + 1).join('\r').replace(/<[^>]+>/g, '').trim();
            if (!text) { return; }
            var cap = { start: ts(parts[0]), end: ts(parts[1]), text: text, words: [] };
            retime(cap);
            caps.push(cap);
        });
        return caps;
    }

    function buildSRT() {
        return state.caps.map(function (c, i) {
            return (i + 1) + '\n' + srtTime(c.start) + ' --> ' + srtTime(c.end) + '\n' + c.text.replace(/\r/g, '\n') + '\n';
        }).join('\n');
    }

    /* ---------- style ---------- */
    function readStyle() {
        var s = {};
        SKEYS.forEach(function (k) {
            var el = MK.$('#cs-' + k);
            s[k] = el.type === 'checkbox' ? el.checked : el.value;
        });
        MK.settings.captions.style = s;
        return s;
    }
    function writeStyle(s) {
        SKEYS.forEach(function (k) {
            var el = MK.$('#cs-' + k);
            if (s[k] === undefined) { return; }
            if (el.type === 'checkbox') { el.checked = !!s[k]; } else { el.value = s[k]; }
        });
        updatePreview();
    }
    function updatePreview() {
        var s = readStyle();
        var el = MK.$('#capPreview span');
        var words = ['Your', 'caption', 'here'];
        el.innerHTML = words.map(function (wd, i) {
            var t = s.upper ? wd.toUpperCase() : wd;
            // a scaled word needs side margins or it covers the spaces next to it
            var k = (+s.hlScale || 100) / 100, m = Math.max(0, (k - 1) * t.length * 0.3);
            return (s.highlight && i === 1) ? '<b style="color:' + s.hlColor + ';display:inline-block;margin:0 ' + m.toFixed(2) + 'em;transform:scale(' + k + ')">' + t + '</b>' : t;
        }).join(' ');
        el.style.color = s.fill;
        el.style.webkitTextStroke = (+s.stroke > 0) ? Math.min(3, s.stroke / 3) + 'px ' + s.strokeColor : '';
        el.style.paintOrder = 'stroke fill';
        el.style.textShadow = s.shadow ? '0 3px 8px rgba(0,0,0,.8)' : '';
        el.style.letterSpacing = ((+s.tracking || 0) / 1000) + 'em';
        el.style.fontSize = Math.max(14, Math.min(30, s.size / 3.2)) + 'px';
        var fcss = el.getAttribute('data-font');
        el.style.fontFamily = ''; el.style.fontWeight = ''; el.style.fontStyle = '';
        if (fcss) { fcss.split(';').forEach(function (d) { var kv = d.split(':'); if (kv.length > 1) { el.style.setProperty(kv[0].trim(), kv.slice(1).join(':').trim()); } }); }
    }

    function style01(s) {
        return {
            font: s.font.trim(), size: +s.size, yPct: +s.yPct, fill: MK.hexToRgb01(s.fill), stroke: +s.stroke, strokeColor: MK.hexToRgb01(s.strokeColor),
            anim: s.anim, upper: s.upper, shadow: s.shadow, highlight: s.highlight, hlColor: MK.hexToRgb01(s.hlColor), hlMode: s.hlMode, hlScale: +s.hlScale, tracking: +s.tracking
        };
    }

    var fontsLoaded = false, showFont = function () {};
    // the font list is read from After Effects only when the Captions tab is first opened
    function loadFonts() {
        if (fontsLoaded) { return; }
        fontsLoaded = true;
        MK.fonts.list().then(function () { showFont(); }).catch(function () {});
    }

    /* ---------- init ---------- */
    MK.initCaptions = function () {
        // style presets
        var sbox = MK.$('#capStyles');
        Object.keys(STYLES).forEach(function (name) {
            var b = document.createElement('button');
            b.className = 'chip';
            b.textContent = name;
            b.onclick = function () { MK.$$('#capStyles .chip').forEach(function (x) { x.classList.remove('active'); }); b.classList.add('active'); writeStyle(STYLES[name]); MK.saveSettings(); };
            sbox.appendChild(b);
        });
        writeStyle(MK.settings.captions.style || STYLES['Reels Pop']);
        SKEYS.forEach(function (k) {
            var el = MK.$('#cs-' + k);
            el.addEventListener('input', updatePreview);
            el.addEventListener('change', function () { updatePreview(); MK.saveSettings(); });
        });
        // v2.1: Bangla by default (auto-detect often hears Bangla as Hindi)
        if (MK.settings.captions.langV !== 2) {
            if (!MK.settings.captions.lang) { MK.settings.captions.lang = 'bn'; }
            MK.settings.captions.langV = 2;
            if (!MK.settings.captions.provider || MK.settings.captions.provider === 'groq' && !MK.settings.keys.groq) { MK.settings.captions.provider = 'gemini'; }
            MK._needSave = true;
        }
        MK.$('#capProvider').value = MK.settings.captions.provider || 'gemini';
        if (MK.settings.captions.lang !== undefined) { MK.$('#capLang').value = MK.settings.captions.lang; }
        if (MK.settings.captions.gemModel) { MK.$('#capGemModel').value = MK.settings.captions.gemModel; }
        if (MK.settings.captions.out) { MK.$('#capOut').value = MK.settings.captions.out; }
        var provHint = function () {
            var p = MK.$('#capProvider').value, l = MK.$('#capLang').value;
            MK.$('#capModelWrap').classList.toggle('show', p === 'groq');
            MK.$('#capGemWrap').classList.toggle('show', p === 'gemini');
            var h = '';
            if (p === 'assemblyai' && (l === 'bn' || !l)) { h = MK.t(l ? 'c.hintAsmBn' : 'c.hintAuto'); }
            else if (!l) { h = MK.t('c.hintAuto'); }
            else if (p === 'gemini') { h = MK.t('c.hintGemini'); }
            var el = MK.$('#capHint');
            el.textContent = h;
            el.classList.toggle('hidden', !h);
        };
        MK.$('#capProvider').addEventListener('change', provHint);
        MK.$('#capLang').addEventListener('change', provHint);
        provHint();

        // font picker
        var fontBtn = MK.$('#csFontBtn');
        showFont = function () {
            var ps = MK.$('#cs-font').value, f = MK.fonts.find(ps);
            fontBtn.textContent = f ? f.name : (ps || 'Arial-BoldMT');
            fontBtn.setAttribute('style', f ? MK.fonts.css(f) : '');
            MK.$('#capPreview span').setAttribute('data-font', f ? MK.fonts.css(f) : '');
            updatePreview();
        };
        fontBtn.onclick = function () {
            MK.fonts.pick(MK.$('#cs-font').value).then(function (f) {
                if (!f) { return; }
                MK.$('#cs-font').value = f.ps;
                showFont();
                MK.saveSettings();
            });
        };
        showFont();

        MK.$('#capUseLayer').onclick = function () {
            MK.busy(this, function () {
                return MK.host('captions.getSourceInfo', {}).then(function (r) {
                    setSource({ type: 'layer', path: r.path, name: r.name, startTime: r.startTime, stretch: r.stretch, duration: r.duration });
                });
            });
        };
        MK.$('#capChoose').onclick = function () {
            MK.busy(this, function () {
                return MK.host('app.chooseFile', { title: 'Choose audio / video', filter: 'Media:*.mp3;*.wav;*.m4a;*.aac;*.mp4;*.mov;*.webm;*.flac;*.ogg' }).then(function (p) {
                    if (p) { setSource({ type: 'file', path: p, name: p.split(/[\\/]/).pop(), startTime: 0, stretch: 100 }); }
                });
            });
        };
        MK.$('#capSrtIn').onclick = function () {
            MK.busy(this, function () {
                return MK.host('app.chooseFile', { title: 'Choose SRT', filter: 'Subtitles:*.srt' }).then(function (p) {
                    if (!p) { return; }
                    state.words = [];
                    state.caps = parseSRT(MK.fs.readText(p));
                    renderList();
                    MK.toast(MK.t('ok.count', { n: state.caps.length }));
                });
            });
        };

        MK.$('#capTranscribe').onclick = function () {
            var bar = MK.$('#capProgress');
            MK.settings.captions.provider = MK.$('#capProvider').value;
            MK.settings.captions.lang = MK.$('#capLang').value;
            MK.settings.captions.gemModel = MK.$('#capGemModel').value;
            MK.saveSettings();
            MK.busy(this, function () {
                if (!state.source) { return MK.host('captions.getSourceInfo', {}).then(function (r) { setSource({ type: 'layer', path: r.path, name: r.name, startTime: r.startTime, stretch: r.stretch, duration: r.duration }); return go(); }); }
                return go();
            }).then(function () { MK.progressHide(bar); });
            function go() {
                MK.progress(bar, null, MK.t('c.reading'));
                var pv = MK.$('#capProvider').value;
                var run = pv === 'assemblyai' ? assembly : (pv === 'gemini' ? gemini : groq);
                return Promise.resolve().then(function () { return run(state.source.path, bar); }).then(function (words) {
                    words.sort(function (a, b) { return a.s - b.s; });
                    if (!words.length) { MK.toast(MK.t('c.noSpeech'), 'warn'); }
                    state.words = words;
                    MK.toast(MK.t('c.got', { n: words.length }));
                    rechunk();
                });
            }
        };

        MK.$('#capRechunk').onclick = rechunk;
        ['#capWords', '#capChars', '#capLines'].forEach(function (s) { MK.$(s).addEventListener('change', rechunk); });
        MK.$('#capWordMode').onclick = function () {
            if (!state.words.length) { return; }
            MK.$('#capWords').value = 1; MK.$('#capLines').value = 1;
            rechunk();
        };
        MK.$('#capClear').onclick = function () { state.caps = []; state.words = []; renderList(); };

        MK.$('#capCreate').onclick = function () {
            if (!state.caps.length) { MK.toast(MK.t('c.noCaps'), 'warn'); return; }
            var st = style01(readStyle());
            MK.settings.captions.out = MK.$('#capOut').value;
            MK.saveSettings();
            var bar = MK.$('#capProgress');
            var all = sanitize(state.caps), size = 25, made = 0, warns = [];
            var report = function () {
                MK.progressHide(bar);
                var fw = warns.filter(function (x) { return /^FONT_MISSING:/.test(x); })[0];
                if (fw) { var p = fw.slice(13).split('>'); MK.toast(MK.t('c.fontMissing', { want: p[0], got: p[1] }), 'warn'); }
                else { MK.toast(MK.t('ok.captions', { n: made })); }
            };
            var btn = this, single = MK.$('#capOut').value === 'single', replace = false;
            // captions already in this comp? creating again on top of them is what makes captions overlap
            var ask = function () {
                return MK.host('captions.listExisting', {}).then(function (r) {
                    if (!r || !r.count) { return true; }
                    return MK.choose({
                        title: MK.t('c.existTitle', { n: r.count }), sub: MK.t('c.existSub'),
                        options: [{ value: 'replace', label: MK.t('c.replace'), small: MK.t('c.replaceSmall') }, { value: 'keep', label: MK.t('c.keep'), small: MK.t('c.keepSmall') }]
                    }).then(function (ch) {
                        if (!ch) { return false; }
                        replace = ch.value === 'replace';
                        return true;
                    });
                });
            };
            ask().then(function (go) {
                if (!go) { return; }
                if (single) {
                    MK.busy(btn, function () {
                        MK.progress(bar, null, MK.t('c.creating', { i: all.length, n: all.length }));
                        return MK.host('captions.createSingle', { captions: all, style: st, replace: replace }).then(function (r) { made = r.count; warns = r.warnings || []; report(); });
                    }).then(function () { MK.progressHide(bar); });
                    return;
                }
                createLayers();
            }).catch(MK.fail);
            function createLayers() {
            MK.busy(btn, function () {
                var i = 0;
                var next = function () {
                    if (i >= all.length) { report(); return; }
                    MK.progress(bar, i / all.length, MK.t('c.creating', { i: Math.min(all.length, i + size), n: all.length }));
                    var batch = all.slice(i, i + size);
                    var startNum = i + 1;
                    i += size;
                    var first = startNum === 1;
                    return MK.host('captions.create', { captions: batch, style: st, startNum: startNum, replace: first && replace }).then(function (r) { made += r.count; warns = warns.concat(r.warnings || []); return next(); });
                };
                return next();
            }).then(function () { MK.progressHide(bar); });
            }
        };
        MK.$('#capRemove').onclick = function () { MK.run(this, 'captions.removeAll', {}); };
        MK.$('#capSrtOut').onclick = function () {
            if (!state.caps.length) { MK.toast(MK.t('c.noCaps'), 'warn'); return; }
            MK.busy(this, function () {
                return MK.host('app.chooseSave', { title: 'Save SRT', name: 'captions.srt', filter: 'Subtitles:*.srt' }).then(function (p) {
                    if (!p) { return; }
                    if (!/\.srt$/i.test(p)) { p += '.srt'; }
                    MK.fs.writeText(p, buildSRT());
                    MK.toast(MK.t('ok.srt'));
                });
            });
        };
        MK.tabs.onShow.captions = loadFonts;
    };

    // exposed for tests
    MK._cap = { chunk: chunk, parseSRT: parseSRT, buildSRT: buildSRT, state: state, srtTime: srtTime, sanitize: sanitize, segWords: segWords, parseGem: parseGem, gemPrompt: gemPrompt };
})(window);
