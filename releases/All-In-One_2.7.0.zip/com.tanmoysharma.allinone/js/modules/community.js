/* All In One — Community links (WhatsApp community / channel, Facebook page) + one-time-ish popup */
(function (w) {
    'use strict';
    var MK = w.MK;

    function links() {
        var L = (MK.config && MK.config.links) || {};
        var out = [];
        if (L.whatsappCommunity) { out.push({ key: 'wa', url: L.whatsappCommunity, label: MK.t('com.wa'), main: true }); }
        if (L.whatsappChannel) { out.push({ key: 'channel', url: L.whatsappChannel, label: MK.t('com.channel') }); }
        if (L.facebook) { out.push({ key: 'fb', url: L.facebook, label: MK.t('com.fb') }); }
        return out;
    }

    function blocked() {
        // never stack on top of another popup or the startup splash
        return !!(document.querySelector('.choice-overlay, .community-overlay') || !MK.$('#modal').classList.contains('hidden') ||
                  !MK.$('#boot').classList.contains('gone'));
    }

    MK.showCommunity = function (force) {
        var list = links();
        if (!list.length) { return; }
        if (!force && (MK.settings.communityPopup === false || MK.settings.communityNever)) { return; }
        var ov = document.createElement('div');
        ov.className = 'choice-overlay community-overlay';
        var main = list.filter(function (l) { return l.main; })[0];
        var rest = list.filter(function (l) { return !l.main; });
        ov.innerHTML = '<div class="choice-box community-box" role="dialog" aria-modal="true">' +
            '<div class="community-badge">' + MK.icon('spark') + '</div>' +
            '<div class="choice-title">' + MK.esc(MK.t('com.title')) + '</div>' +
            '<div class="choice-sub wrap">' + MK.esc(MK.t('com.sub')) + '</div>' +
            (main ? '<button class="btn primary full" data-url="' + MK.esc(main.url) + '">' + MK.esc(main.label) + '</button>' : '') +
            (rest.length ? '<div class="row gap community-links">' + rest.map(function (l) {
                return '<button class="btn sm grow" data-url="' + MK.esc(l.url) + '">' + MK.esc(l.label) + '</button>';
            }).join('') + '</div>' : '') +
            '<label class="check"><input type="checkbox" class="com-never"><span>' + MK.esc(MK.t('com.never')) + '</span></label>' +
            '<button type="button" class="btn sm choice-cancel">' + MK.esc(MK.t('com.later')) + '</button></div>';
        document.body.appendChild(ov);
        MK.lockScroll(true);
        var close = function () {
            if (ov.querySelector('.com-never').checked) { MK.settings.communityNever = true; MK.saveSettings(); syncSettings(); }
            MK.lockScroll(false);
            ov.classList.remove('show');
            setTimeout(function () { if (ov.parentNode) { ov.parentNode.removeChild(ov); } }, 160);
        };
        ov.addEventListener('click', function (e) {
            var b = e.target.closest ? e.target.closest('[data-url]') : null;
            if (b) { MK.openURL(b.getAttribute('data-url')); MK.settings.communityNever = true; MK.saveSettings(); close(); return; }
            if (e.target === ov || e.target.classList.contains('choice-cancel')) { close(); }
        });
        setTimeout(function () { ov.classList.add('show'); }, 10);
    };

    function syncSettings() {
        var chk = MK.$('#communityPopupChk');
        if (chk) { chk.checked = MK.settings.communityPopup !== false && !MK.settings.communityNever; }
    }

    MK.initCommunity = function () {
        var list = links();
        if (!list.length) { return; }
        MK.$('#communityGroup').classList.remove('hidden');
        MK.$('#communityLinks').innerHTML = list.map(function (l) {
            return '<button class="btn sm grow" data-url="' + MK.esc(l.url) + '">' + MK.esc(l.label) + '</button>';
        }).join('');
        MK.$$('#communityLinks [data-url]').forEach(function (b) { b.onclick = function () { MK.openURL(b.dataset.url); }; });
        syncSettings();
        MK.$('#communityPopupChk').addEventListener('change', function () {
            MK.settings.communityPopup = this.checked;
            if (this.checked) { MK.settings.communityNever = false; }
            MK.saveSettings();
        });
    };

    // called once the panel is ready; waits for other popups to close
    MK.scheduleCommunity = function () {
        if (!links().length || MK.settings.communityPopup === false || MK.settings.communityNever) { return; }
        var tries = 0;
        var tick = function () {
            if (blocked()) { if (++tries < 40) { setTimeout(tick, 1500); } return; }
            MK.showCommunity();
        };
        setTimeout(tick, 2000);
    };
})(window);
