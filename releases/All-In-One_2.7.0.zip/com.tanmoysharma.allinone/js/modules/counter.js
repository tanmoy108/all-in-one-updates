/* All In One — Text ▸ Counter (0 → 2019 / ০ → ২০১৯) */
(function (w) {
    'use strict';
    var MK = w.MK;
    var BN = '০১২৩৪৫৬৭৮৯';
    var DIG = { bn: BN, hi: '०१२३४५६७८९', ar: '٠١٢٣٤٥٦٧٨٩', en: '' };
    var SEP = { none: ['', 0], comma: [',', 3], bd: [',', 2], dot: ['.', 3], space: [' ', 3], apos: ["'", 3], custom: null };

    function ascii(s) {
        return String(s || '').replace(/[০-৯]/g, function (d) { return String(BN.indexOf(d)); }).replace(/[०-९]/g, function (d) { return String(DIG.hi.indexOf(d)); })
            .replace(/[٠-٩]/g, function (d) { return String(DIG.ar.indexOf(d)); }).replace(/−/g, '-');
    }
    function parse(raw) {
        raw = String(raw || '');
        var m = /-?[0-9]+(?:,[0-9]+)*(?:\.[0-9]+)?/.exec(ascii(raw));
        if (!m) { return null; }
        var clean = m[0].replace(/,/g, ''), dot = clean.indexOf('.');
        var g = m[0].replace(/^-/, '').split('.')[0].split(',');
        return {
            pre: raw.substring(0, m.index), suf: raw.substring(m.index + m[0].length),
            num: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0,
            sep: m[0].indexOf(',') < 0 ? 0 : (g.length > 2 && g[g.length - 2].length === 2 ? 2 : 1),
            bn: /[০-৯]/.test(raw.substr(m.index, m[0].length)),
            script: /[০-৯]/.test(raw.substr(m.index, m[0].length)) ? 'bn' : (/[०-९]/.test(raw.substr(m.index, m[0].length)) ? 'hi' : (/[٠-٩]/.test(raw.substr(m.index, m[0].length)) ? 'ar' : 'en'))
        };
    }
    var EASE = {
        linear: function (p) { return p; },
        out: function (p) { return 1 - Math.pow(1 - p, 3); },
        inout: function (p) { return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; },
        expo: function (p) { return p >= 1 ? 1 : 1 - Math.pow(2, -10 * p); },
        back: function (p) { var k = 1.70158; return 1 + (k + 1) * Math.pow(p - 1, 3) + k * Math.pow(p - 1, 2); }
    };
    function grp(t, n, ch) { var r = ''; while (t.length > n) { r = ch + t.substring(t.length - n) + r; t = t.substring(0, t.length - n); } return t + r; }
    function fmt(v, o) {
        var neg = v < 0; if (neg) { v = -v; }
        var s = v.toFixed(o.dec), d = s.indexOf('.'), ip = s, fp = '';
        if (d >= 0) { ip = s.substring(0, d); fp = s.substring(d); }
        while (ip.length < o.width) { ip = '0' + ip; }
        if (o.grp === 3) { ip = grp(ip, 3, o.ch); } else if (o.grp === 2 && ip.length > 3) { ip = grp(ip.substring(0, ip.length - 3), 2, o.ch) + o.ch + ip.substring(ip.length - 3); }
        if (fp) { fp = (o.ch === '.' ? ',' : '.') + fp.substring(1); }
        s = (neg && Number(s) !== 0 ? '-' : '') + ip + fp;
        if (o.digs) { s = s.replace(/[0-9]/g, function (c) { return o.digs.charAt(+c); }); }
        return o.pre + s + o.suf;
    }

    function val(id) { return MK.$('#cn-' + id).value; }
    function args() {
        return {
            from: val('from'), to: val('to'), duration: parseFloat(val('duration')) || 2,
            ease: val('ease'), digits: val('digits'), sep: val('sep'), sepChar: val('sepChar'), decimals: val('decimals'),
            prefix: val('prefix'), suffix: val('suffix'), at: val('at'), pad: MK.$('#cn-pad').checked
        };
    }
    // the same decisions the host makes, for the live preview
    function previewOpts(a) {
        var info = parse(a.to || MK._cnLayerText || '২০১৯') || parse('2019');
        var to = info.num, from = parseFloat(ascii(a.from).replace(/[,\s']/g, '')) || 0;
        var o = {
            from: from, to: to,
            dec: a.decimals === 'auto' ? info.dec : +a.decimals,
            sepTmp: (function () {
                var m = a.sep === 'custom' ? [a.sepChar || '', 3] : (SEP[a.sep] || (info.sep === 2 ? [',', 2] : info.sep === 1 ? [',', 3] : ['', 0]));
                return { ch: m[0], grp: m[0] ? m[1] : 0 };
            })(),
            digs: DIG[a.digits === 'auto' ? info.script : a.digits] || '',
            pre: a.prefix !== '' ? a.prefix : info.pre, suf: a.suffix !== '' ? a.suffix : info.suf,
            width: a.pad ? String(Math.floor(Math.abs(to))).length : 0
        };
        o.ch = o.sepTmp.ch; o.grp = o.sepTmp.grp;
        return o;
    }

    var t0 = 0;
    function loop(ts) {
        if (MK.tabs.current === 'text' && MK.$('#sub-counter').classList.contains('active')) {
            var a = args(), o = previewOpts(a);
            if (!t0) { t0 = ts; }
            var el = (ts - t0) / 1000, d = Math.max(0.05, a.duration);
            if (el > d + 1.2) { t0 = ts; el = 0; }
            var p = (EASE[a.ease] || EASE.out)(Math.min(1, el / d));
            MK.$('#cnPreview').textContent = fmt(o.from + (o.to - o.from) * p, o);
        }
        w.requestAnimationFrame(loop);
    }
    function restart() { t0 = 0; }

    function setDur(d, from) {
        d = Math.max(0.05, Math.round(d * 100) / 100);
        if (from !== 'num') { MK.$('#cn-duration').value = d; }
        if (from !== 'range') { MK.$('#cnDurRange').value = Math.min(10, d); }
        MK.$$('#cnSpeed button').forEach(function (b) { b.classList.toggle('active', +b.dataset.d === d); });
        MK.settings.counter = Object.assign(MK.settings.counter || {}, { duration: d });
        restart();
    }

    function readLayer(btn, quiet) {
        return MK.host('counter.readSelected', {}).then(function (r) {
            if (r && r.num !== undefined) {
                MK._cnLayerText = r.text;
                restart();
                if (!quiet) { MK.$('#cn-to').value = r.text.replace(/^[^0-9০-৯\-]*/, '').replace(/[^0-9০-৯.,]*$/, ''); MK.toast(r.text); }
            } else if (!quiet) { MK.toast(MK.t(r ? 'cn.read.none' : 'err.NO_TEXT_LAYER'), 'warn'); }
        }).catch(function (e) { if (!quiet) { MK.fail(e); } });
    }

    MK.initCounter = function () {
        var saved = MK.settings.counter || {};
        ['ease', 'digits', 'sep', 'decimals', 'at'].forEach(function (k) { if (saved[k]) { MK.$('#cn-' + k).value = saved[k]; } });
        var showCustom = function () { MK.$('#cn-sepChar').classList.toggle('hidden', val('sep') !== 'custom'); };
        MK.$('#cn-sep').addEventListener('change', showCustom); showCustom();
        MK.$$('[data-cn-pre]').forEach(function (b) { b.onclick = function () { MK.$('#cn-prefix').value = b.dataset.cnPre; restart(); }; });
        MK.$$('[data-cn-suf]').forEach(function (b) { b.onclick = function () { MK.$('#cn-suffix').value = b.dataset.cnSuf; restart(); }; });
        MK.$('#cnSwap').onclick = function () { var p = MK.$('#cn-prefix').value; MK.$('#cn-prefix').value = MK.$('#cn-suffix').value; MK.$('#cn-suffix').value = p; restart(); };
        ['from', 'to', 'prefix', 'suffix', 'ease', 'digits', 'sep', 'sepChar', 'decimals', 'at', 'pad'].forEach(function (k) {
            MK.$('#cn-' + k).addEventListener('input', function () {
                restart();
                if (/ease|digits|sep|decimals|at/.test(k)) { MK.settings.counter = Object.assign(MK.settings.counter || {}, (function () { var o = {}; o[k] = val(k); return o; })()); MK.saveSettings(); }
            });
            MK.$('#cn-' + k).addEventListener('change', restart);
        });
        MK.$$('#cnSpeed button').forEach(function (b) { b.addEventListener('click', function () { setDur(+b.dataset.d); MK.saveSettings(); }); });
        MK.$('#cnDurRange').addEventListener('input', function () { setDur(+this.value, 'range'); });
        MK.$('#cnDurRange').addEventListener('change', function () { MK.saveSettings(); });
        MK.$('#cn-duration').addEventListener('input', function () { var d = parseFloat(this.value); if (d > 0) { setDur(d, 'num'); } });
        MK.$('#cn-duration').addEventListener('change', function () { MK.saveSettings(); });
        setDur(saved.duration || 2);

        MK.$('#cnApply').onclick = function () {
            MK.run(this, 'counter.apply', args(), function (r) { return r.created ? MK.t('cn.okNew') : MK.t('cn.ok', { n: r.count }); });
        };
        MK.$('#cnRemove').onclick = function () { MK.run(this, 'counter.remove', {}); };
        MK.$('#cnRead').onclick = function () { readLayer(this, false); };
        MK.$$('#textSeg button').forEach(function (b) {
            b.addEventListener('click', function () { if (b.dataset.sub === 'counter') { restart(); readLayer(null, true); } });
        });
        w.requestAnimationFrame(loop);
    };

    MK._counter = { parse: parse, fmt: fmt };
})(window);
