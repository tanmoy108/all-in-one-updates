/* All In One — v2.6 extras: expression library, crop comp, gradient lock, paste image, remove BG,
   text highlight, silence cutter. Strings for this module are registered here (EN + বাংলা). */
(function (w) {
    'use strict';
    var MK = w.MK;

    /* ---------- strings ---------- */
    var EN = {
        'xx.more': 'More tools', 'xx.crop': 'Crop Comp', 'xx.grad': 'Gradient Lock', 'xx.paste': 'Paste Image', 'xx.rmbg': 'Remove BG',
        'xx.hl': 'Highlight', 'xx.silence': 'Silence Cut', 'xx.exprLib': '📚 Expression library', 'xx.moreHint': 'Crop the comp to the selected layers · a gradient that follows the layer · paste an image or file from the clipboard · remove an image background · animated highlight behind text · cut the silent parts of a voice layer.',
        'xx.pad': 'Padding (px)', 'xx.cropMode': 'Apply to', 'xx.thisComp': 'This comp', 'xx.newComp': 'A copy of the comp', 'xx.cropOk': 'Comp is now {w}×{h}',
        'xx.c1': 'Colour 1', 'xx.c2': 'Colour 2', 'xx.type': 'Type', 'xx.linear': 'Linear', 'xx.radial': 'Radial', 'xx.angle': 'Angle',
        'xx.gradHint': 'The gradient stays fitted to the layer even when the text or shape changes size. Edit the colours later in Effect Controls.',
        'xx.pasteNone': 'The clipboard has no image or file.', 'xx.pasteOk': '{n} item(s) pasted',
        'xx.rmbgKey': 'Add your free remove.bg key in ⚙ Settings first.', 'xx.size': 'Quality', 'xx.preview': 'Preview (free, up to 0.25 MP)', 'xx.full': 'Full size (uses credits)',
        'xx.rmbgWork': 'Removing background…', 'xx.rmbgOk': 'Background removed ✓',
        'xx.style': 'Style', 'xx.box': 'Box', 'xx.marker': 'Marker', 'xx.underline': 'Underline', 'xx.color': 'Colour', 'xx.dir': 'Direction',
        'xx.fromLeft': 'From left', 'xx.fromRight': 'From right', 'xx.fromCenter': 'From centre', 'xx.dur': 'Duration (s)', 'xx.at': 'Start at',
        'xx.layerStart': 'Layer start', 'xx.playhead': 'Playhead',
        'xx.thr': 'Silence below (dB)', 'xx.minSil': 'Min silence (s)', 'xx.keepPad': 'Keep around speech (s)', 'xx.close': 'Close the gaps (ripple)',
        'xx.analyzing': 'Listening to the audio…', 'xx.silFound': 'Found {n} silent part(s), {s}s in total. Cut them?', 'xx.silNone': 'No silence longer than {m}s found.',
        'xx.silOk': 'Cut into {n} piece(s)', 'xx.apply': 'Apply', 'xx.search': 'Search expressions…', 'xx.all': 'All',
        'xx.exprHint': 'Select a property in the timeline (e.g. Position), then click an expression.', 'xx.exprOk': 'Added to {n} propert(ies)',
        'err.NO_IMAGE_LAYER': 'Select an image layer (PNG / JPG).', 'err.NOTHING_TO_KEEP': 'The whole layer is silent.'
    };
    var BN = {
        'xx.more': 'আরও টুল', 'xx.crop': 'কম্প ক্রপ', 'xx.grad': 'গ্রেডিয়েন্ট লক', 'xx.paste': 'ছবি পেস্ট', 'xx.rmbg': 'BG রিমুভ',
        'xx.hl': 'হাইলাইট', 'xx.silence': 'নীরবতা কাটুন', 'xx.exprLib': '📚 এক্সপ্রেশন লাইব্রেরি', 'xx.moreHint': 'সিলেক্টেড লেয়ারের মাপে কম্প ক্রপ · লেয়ারের সাথে মানিয়ে চলা গ্রেডিয়েন্ট · ক্লিপবোর্ড থেকে ছবি বা ফাইল পেস্ট · ছবির ব্যাকগ্রাউন্ড মুছুন · টেক্সটের পেছনে অ্যানিমেটেড হাইলাইট · ভয়েস লেয়ারের নীরব অংশ কেটে ফেলুন।',
        'xx.pad': 'চারপাশে ফাঁকা (px)', 'xx.cropMode': 'কোথায়', 'xx.thisComp': 'এই কম্পে', 'xx.newComp': 'কম্পের একটা কপিতে', 'xx.cropOk': 'কম্প এখন {w}×{h}',
        'xx.c1': 'রং ১', 'xx.c2': 'রং ২', 'xx.type': 'ধরন', 'xx.linear': 'লিনিয়ার', 'xx.radial': 'রেডিয়াল', 'xx.angle': 'কোণ',
        'xx.gradHint': 'টেক্সট বা শেপের সাইজ বদলালেও গ্রেডিয়েন্ট লেয়ারের মাপেই থাকবে। রং পরে Effect Controls থেকে বদলানো যায়।',
        'xx.pasteNone': 'ক্লিপবোর্ডে কোনো ছবি বা ফাইল নেই।', 'xx.pasteOk': '{n}টি পেস্ট হয়েছে',
        'xx.rmbgKey': 'আগে ⚙ Settings-এ ফ্রি remove.bg কি দিন।', 'xx.size': 'কোয়ালিটি', 'xx.preview': 'প্রিভিউ (ফ্রি, ০.২৫ MP পর্যন্ত)', 'xx.full': 'পূর্ণ সাইজ (ক্রেডিট লাগে)',
        'xx.rmbgWork': 'ব্যাকগ্রাউন্ড মোছা হচ্ছে…', 'xx.rmbgOk': 'ব্যাকগ্রাউন্ড মোছা হয়েছে ✓',
        'xx.style': 'স্টাইল', 'xx.box': 'বক্স', 'xx.marker': 'মার্কার', 'xx.underline': 'আন্ডারলাইন', 'xx.color': 'রং', 'xx.dir': 'দিক',
        'xx.fromLeft': 'বাম থেকে', 'xx.fromRight': 'ডান থেকে', 'xx.fromCenter': 'মাঝ থেকে', 'xx.dur': 'সময় (সে.)', 'xx.at': 'শুরু হবে',
        'xx.layerStart': 'লেয়ারের শুরুতে', 'xx.playhead': 'প্লেহেডে',
        'xx.thr': 'এর নিচে নীরব (dB)', 'xx.minSil': 'কমপক্ষে নীরবতা (সে.)', 'xx.keepPad': 'কথার আগে-পরে রাখুন (সে.)', 'xx.close': 'ফাঁকগুলো জুড়ে দিন',
        'xx.analyzing': 'অডিও শোনা হচ্ছে…', 'xx.silFound': '{n}টি নীরব অংশ পাওয়া গেছে, মোট {s} সে.। কেটে ফেলবো?', 'xx.silNone': '{m} সে.-এর বেশি কোনো নীরবতা পাওয়া যায়নি।',
        'xx.silOk': '{n}টি টুকরো হয়েছে', 'xx.apply': 'প্রয়োগ', 'xx.search': 'এক্সপ্রেশন খুঁজুন…', 'xx.all': 'সব',
        'xx.exprHint': 'টাইমলাইনে একটা প্রপার্টি (যেমন Position) সিলেক্ট করে এক্সপ্রেশনে ক্লিক করুন।', 'xx.exprOk': '{n}টি প্রপার্টিতে দেওয়া হয়েছে',
        'err.NO_IMAGE_LAYER': 'একটা ছবির লেয়ার (PNG / JPG) সিলেক্ট করুন।', 'err.NOTHING_TO_KEEP': 'পুরো লেয়ারটাই নীরব।'
    };
    function reg(en, bn) {
        Object.keys(en).forEach(function (k) { MK._msg.en[k] = en[k]; if (bn[k]) { MK._msg.bn[k] = bn[k]; MK._bn[k] = bn[k]; } });
    }
    reg(EN, BN);
    MK.regStrings = reg;

    function esc(s) { return MK.esc(String(s === undefined || s === null ? '' : s)); }
    function bn() { return MK.lang() === 'bn'; }
    function sel(name, opts, cur) { return '<select name="' + name + '">' + opts.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === cur ? ' selected' : '') + '>' + esc(MK.t(o[1])) + '</option>'; }).join('') + '</select>'; }
    function fld(label, html) { return '<label>' + esc(MK.t(label)) + html + '</label>'; }
    function rgb(hex) { return MK.hexToRgb01(hex); }
    var cfg = function () { return (MK.settings.extra = MK.settings.extra || {}); };

    /* ======================= EXPRESSION LIBRARY ======================= */
    // p: params [key, label EN, label BN, default]; c(p) → code
    var X = [
        { id: 'wiggle', cat: 'Motion', n: 'Wiggle', b: 'এলোমেলো নড়াচড়া', d: 'Random shake / drift on any property.', db: 'যেকোনো প্রপার্টিতে এলোমেলো কাঁপুনি।',
            p: [['f', 'Times / sec', 'প্রতি সেকেন্ডে', 2], ['a', 'Amount', 'পরিমাণ', 30]], c: function (p) { return 'wiggle(' + p.f + ', ' + p.a + ')'; } },
        { id: 'wiggleX', cat: 'Motion', n: 'Wiggle X only', b: 'শুধু X-এ কাঁপুনি', d: 'Horizontal shake, Y stays.', db: 'শুধু আড়াআড়ি কাঁপবে।',
            p: [['f', 'Times / sec', 'প্রতি সেকেন্ডে', 3], ['a', 'Amount', 'পরিমাণ', 25]], c: function (p) { return 'var w = wiggle(' + p.f + ', ' + p.a + ');\n[w[0], value[1]]'; } },
        { id: 'loopWiggle', cat: 'Motion', n: 'Seamless wiggle loop', b: 'লুপ হওয়া উইগল', d: 'Wiggle that loops perfectly (for GIFs / loops).', db: 'নিখুঁতভাবে লুপ হয় (GIF/লুপের জন্য)।',
            p: [['f', 'Times / sec', 'প্রতি সেকেন্ডে', 2], ['a', 'Amount', 'পরিমাণ', 30], ['l', 'Loop length (s)', 'লুপের দৈর্ঘ্য (সে.)', 3]],
            c: function (p) { return 'var f = ' + p.f + ', a = ' + p.a + ', L = ' + p.l + ', t = time % L;\nvar w1 = wiggle(f, a, 1, 0.5, t), w2 = wiggle(f, a, 1, 0.5, t - L);\nlinear(t, 0, L, w1, w2)'; } },
        { id: 'inertia', cat: 'Motion', n: 'Inertial bounce', b: 'ইনার্শিয়াল বাউন্স', d: 'Overshoots and settles after every keyframe.', db: 'প্রতিটা কিফ্রেমের পর একটু বেশি গিয়ে থিতু হয়।',
            p: [['a', 'Amount', 'পরিমাণ', 0.06], ['f', 'Speed', 'গতি', 2.5], ['d', 'Settle', 'থামার গতি', 6]],
            c: function (p) { return 'var amp = ' + p.a + ', freq = ' + p.f + ', decay = ' + p.d + ';\nvar n = 0;\nif (numKeys > 0) { n = nearestKey(time).index; if (key(n).time > time) { n--; } }\nif (n > 0) {\n  var t = time - key(n).time;\n  var v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n  value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t);\n} else { value; }'; } },
        { id: 'loopCycle', cat: 'Loop', n: 'Loop (cycle)', b: 'লুপ (বারবার)', d: 'Repeat the keyframes forever.', db: 'কিফ্রেমগুলো বারবার চলবে।', c: function () { return 'loopOut("cycle")'; } },
        { id: 'loopPing', cat: 'Loop', n: 'Loop (ping-pong)', b: 'লুপ (আসা-যাওয়া)', d: 'Play forward, then backward.', db: 'সামনে, তারপর উল্টো দিকে।', c: function () { return 'loopOut("pingpong")'; } },
        { id: 'loopOffset', cat: 'Loop', n: 'Loop (keep adding)', b: 'লুপ (বাড়তেই থাকবে)', d: 'Each loop continues from the last value (e.g. endless rotation).', db: 'প্রতি লুপ আগের জায়গা থেকে চলবে (যেমন অবিরাম ঘোরা)।', c: function () { return 'loopOut("offset")'; } },
        { id: 'loopIn', cat: 'Loop', n: 'Loop before first key', b: 'প্রথম কিফ্রেমের আগেও লুপ', d: 'Loop also before the first keyframe.', db: 'প্রথম কিফ্রেমের আগের অংশেও লুপ।', c: function () { return 'loopIn("cycle") + loopOut("cycle") - value'; } },
        { id: 'spin', cat: 'Motion', n: 'Spin forever', b: 'অবিরাম ঘোরা', d: 'Rotation: degrees per second.', db: 'রোটেশন: প্রতি সেকেন্ডে কত ডিগ্রি।',
            p: [['s', 'Degrees / sec', 'ডিগ্রি / সেকেন্ড', 90]], c: function (p) { return 'value + time * ' + p.s; } },
        { id: 'pendulum', cat: 'Motion', n: 'Pendulum swing', b: 'দোলনার মতো দোলা', d: 'Rotation: swings and slowly stops.', db: 'রোটেশন: দোল খেয়ে ধীরে থামে।',
            p: [['a', 'Angle', 'কোণ', 25], ['f', 'Swings / sec', 'দোল / সেকেন্ড', 1], ['d', 'Slow down', 'ধীর হওয়া', 0.5]],
            c: function (p) { return 'var t = time - inPoint;\nvalue + ' + p.a + ' * Math.sin(' + p.f + ' * t * 2 * Math.PI) / Math.exp(' + p.d + ' * t)'; } },
        { id: 'float', cat: 'Motion', n: 'Float up & down', b: 'ভেসে থাকা (উপর-নিচ)', d: 'Position: gentle hover.', db: 'পজিশন: আলতো ভেসে থাকা।',
            p: [['a', 'Height (px)', 'উচ্চতা (px)', 15], ['s', 'Cycles / sec', 'প্রতি সেকেন্ডে', 0.5]], c: function (p) { return 'value + [0, ' + p.a + ' * Math.sin(time * ' + p.s + ' * 2 * Math.PI)]'; } },
        { id: 'orbit', cat: 'Motion', n: 'Orbit in a circle', b: 'বৃত্তে ঘোরা', d: 'Position: moves around a circle.', db: 'পজিশন: বৃত্তাকারে ঘুরবে।',
            p: [['r', 'Radius (px)', 'ব্যাসার্ধ (px)', 120], ['s', 'Turns / sec', 'পাক / সেকেন্ড', 0.25]], c: function (p) { return 'var a = time * ' + p.s + ' * 2 * Math.PI;\nvalue + [Math.cos(a) * ' + p.r + ', Math.sin(a) * ' + p.r + ']'; } },
        { id: 'pulse', cat: 'Scale', n: 'Pulse', b: 'পালস (বড়-ছোট)', d: 'Scale: breathes bigger / smaller.', db: 'স্কেল: শ্বাসের মতো বড়-ছোট।',
            p: [['a', 'Amount %', 'পরিমাণ %', 8], ['s', 'Pulses / sec', 'প্রতি সেকেন্ডে', 1]], c: function (p) { return 'value * (1 + ' + p.a + ' / 100 * Math.sin(time * ' + p.s + ' * 2 * Math.PI))'; } },
        { id: 'heart', cat: 'Scale', n: 'Heartbeat', b: 'হার্টবিট', d: 'Scale: double beat.', db: 'স্কেল: হৃদস্পন্দনের মতো দুই ধাক্কা।',
            p: [['b', 'Beats / min', 'বিট / মিনিট', 72], ['a', 'Amount %', 'পরিমাণ %', 12]],
            c: function (p) { return 'var T = 60 / ' + p.b + ', ph = (time % T) / T;\nvar k = Math.exp(-ph * 18) + 0.6 * Math.exp(-Math.pow((ph - 0.22) * 14, 2));\nvalue * (1 + ' + p.a + ' / 100 * k)'; } },
        { id: 'squash', cat: 'Scale', n: 'Squash & stretch', b: 'চ্যাপ্টা-লম্বা (জেলি)', d: 'Scale: jelly wobble when the layer starts.', db: 'স্কেল: লেয়ার শুরুতে জেলির মতো দোলে।',
            p: [['a', 'Amount', 'পরিমাণ', 0.15], ['f', 'Speed', 'গতি', 3], ['d', 'Settle', 'থামার গতি', 4]],
            c: function (p) { return 'var t = Math.max(0, time - inPoint), s = ' + p.a + ' * Math.sin(' + p.f + ' * t * 2 * Math.PI) / Math.exp(' + p.d + ' * t);\nvalue + [value[0] * s, -value[1] * s]'; } },
        { id: 'fadeIO', cat: 'Opacity', n: 'Fade in & out', b: 'ফেড ইন ও আউট', d: 'Opacity: fades at the layer start and end.', db: 'অপাসিটি: লেয়ারের শুরু ও শেষে ফেড।',
            p: [['d', 'Fade (s)', 'ফেড (সে.)', 0.5]], c: function (p) { return 'var d = ' + p.d + ';\nMath.min(linear(time, inPoint, inPoint + d, 0, value), linear(time, outPoint - d, outPoint, value, 0))'; } },
        { id: 'flicker', cat: 'Opacity', n: 'Flicker', b: 'ঝিলমিল', d: 'Opacity: random flicker like a broken light.', db: 'অপাসিটি: নষ্ট বাতির মতো ঝিলমিল।',
            p: [['r', 'Flickers / sec', 'প্রতি সেকেন্ডে', 12], ['c', 'Chance %', 'সম্ভাবনা %', 30]], c: function (p) { return 'seedRandom(Math.floor(time * ' + p.r + '), true);\nrandom(100) < ' + p.c + ' ? value * 0.2 : value'; } },
        { id: 'blink', cat: 'Opacity', n: 'Blink', b: 'জ্বলা-নেভা', d: 'Opacity: on / off.', db: 'অপাসিটি: চালু / বন্ধ।',
            p: [['r', 'Blinks / sec', 'প্রতি সেকেন্ডে', 2]], c: function (p) { return 'Math.floor((time - inPoint) * ' + p.r + ' * 2) % 2 == 0 ? value : 0'; } },
        { id: 'step', cat: 'Time', n: 'Stop-motion (choppy)', b: 'স্টপ-মোশন (খটখটে)', d: 'Any property: updates only N times per second.', db: 'সেকেন্ডে মাত্র N বার আপডেট হবে।',
            p: [['f', 'FPS', 'FPS', 8]], c: function (p) { return 'posterizeTime(' + p.f + ');\nvalueAtTime(time)'; } },
        { id: 'delay', cat: 'Time', n: 'Follow the layer above', b: 'উপরের লেয়ারকে অনুসরণ', d: 'Position: copies the layer above, a few frames later.', db: 'পজিশন: উপরের লেয়ারকে কয়েক ফ্রেম পরে অনুসরণ করে।',
            p: [['d', 'Delay (frames)', 'দেরি (ফ্রেম)', 4]], c: function (p) { return 'var L = thisComp.layer(index - 1);\nL.transform.position.valueAtTime(time - ' + p.d + ' * thisComp.frameDuration)'; } },
        { id: 'lookAt', cat: 'Motion', n: 'Point at the layer above', b: 'উপরের লেয়ারের দিকে তাকানো', d: 'Rotation: always faces the layer above.', db: 'রোটেশন: সবসময় উপরের লেয়ারের দিকে ঘুরে থাকে।',
            p: [['o', 'Offset °', 'অফসেট °', 0]], c: function (p) { return 'var v = thisComp.layer(index - 1).toComp([0, 0]) - toComp(anchorPoint);\nradiansToDegrees(Math.atan2(v[1], v[0])) + ' + p.o; } },
        { id: 'center', cat: 'Motion', n: 'Stay centred', b: 'সবসময় মাঝখানে', d: 'Position: comp centre, even if the comp size changes.', db: 'পজিশন: কম্পের মাপ বদলালেও মাঝখানে থাকে।', c: function () { return '[thisComp.width / 2, thisComp.height / 2]'; } },
        { id: 'type', cat: 'Text', n: 'Typewriter', b: 'টাইপরাইটার', d: 'Source Text: types out letter by letter with a cursor.', db: 'সোর্স টেক্সট: অক্ষর অক্ষর করে টাইপ হয়, কার্সর সহ।',
            p: [['s', 'Letters / sec', 'অক্ষর / সেকেন্ড', 15], ['c', 'Cursor (1 = on)', 'কার্সর (১ = চালু)', 1]],
            c: function (p) { return 'var txt = String(value), n = Math.max(0, Math.floor((time - inPoint) * ' + p.s + '));\nvar cur = ' + (p.c ? 1 : 0) + ' && (n < txt.length || Math.floor(time * 2) % 2 == 0) ? "|" : "";\ntxt.substr(0, n) + cur'; } },
        { id: 'countdown', cat: 'Text', n: 'Countdown timer', b: 'কাউন্টডাউন টাইমার', d: 'Source Text: mm:ss counting down.', db: 'সোর্স টেক্সট: mm:ss উল্টো গোনা।',
            p: [['s', 'Start (seconds)', 'শুরু (সেকেন্ড)', 60]], c: function (p) { return 'var r = Math.max(0, ' + p.s + ' - (time - inPoint)), m = Math.floor(r / 60), s = Math.floor(r % 60);\n(m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s'; } },
        { id: 'stopwatch', cat: 'Text', n: 'Stopwatch', b: 'স্টপওয়াচ', d: 'Source Text: mm:ss.ff counting up.', db: 'সোর্স টেক্সট: mm:ss.ff সামনে গোনা।',
            c: function () { return 'var t = Math.max(0, time - inPoint), m = Math.floor(t / 60), s = Math.floor(t % 60), f = Math.floor((t % 1) * 100);\n(m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s + "." + (f < 10 ? "0" : "") + f'; } },
        { id: 'upper', cat: 'Text', n: 'ALL CAPS (live)', b: 'সব বড় হাতের (লাইভ)', d: 'Source Text: always upper case.', db: 'সোর্স টেক্সট: সবসময় বড় হাতের অক্ষর।', c: function () { return 'String(value).toUpperCase()'; } },
        { id: 'hue', cat: 'Colour', n: 'Rainbow colour cycle', b: 'রংধনুর মতো রং ঘোরা', d: 'Colour property: hue keeps rotating.', db: 'রঙের প্রপার্টি: রং ঘুরতে থাকে।',
            p: [['s', 'Cycles / sec', 'প্রতি সেকেন্ডে', 0.2]], c: function (p) { return 'var h = rgbToHsl(value);\nh[0] = (h[0] + time * ' + p.s + ') % 1;\nhslToRgb(h)'; } },
        { id: 'randColor', cat: 'Colour', n: 'Random colour per layer', b: 'প্রতি লেয়ারে আলাদা রং', d: 'Colour property: each layer gets its own colour.', db: 'রঙের প্রপার্টি: প্রতিটা লেয়ার আলাদা রং পাবে।',
            p: [['s', 'Saturation 0-1', 'স্যাচুরেশন ০-১', 0.75], ['l', 'Lightness 0-1', 'উজ্জ্বলতা ০-১', 0.55]], c: function (p) { return 'seedRandom(index, true);\nhslToRgb([random(), ' + p.s + ', ' + p.l + ', 1])'; } },
        { id: 'scaleDist', cat: 'Scale', n: 'Bigger near the centre', b: 'মাঝখানে গেলে বড়', d: 'Scale: grows as the layer gets near the comp centre (for carousels).', db: 'স্কেল: কম্পের মাঝে এলে বড় হয় (ক্যারোসেলের জন্য)।',
            p: [['m', 'Max %', 'সর্বোচ্চ %', 130], ['r', 'Range (px)', 'দূরত্ব (px)', 600]],
            c: function (p) { return 'var d = length(toComp(anchorPoint), [thisComp.width / 2, thisComp.height / 2]);\nvalue * linear(d, 0, ' + p.r + ', ' + p.m + ' / 100, 1)'; } }
    ];
    var CATS = ['Motion', 'Loop', 'Scale', 'Opacity', 'Time', 'Text', 'Colour'];
    var CAT_BN = { Motion: 'নড়াচড়া', Loop: 'লুপ', Scale: 'স্কেল', Opacity: 'অপাসিটি', Time: 'সময়', Text: 'টেক্সট', Colour: 'রং' };

    function applyExpr(x, btn) {
        var go = function (p) {
            return MK.run(btn, 'quick.applyExpression', { code: '// All In One - ' + x.id + '\n' + x.c(p || {}) }, function (r) {
                if (r.errors && r.errors.length) { MK.toast(r.errors[0], 'warn'); return ''; }
                return MK.t('xx.exprOk', { n: r.count });
            });
        };
        if (!x.p) { return go(); }
        var saved = (cfg().expr || {})[x.id] || {};
        return MK.modal({
            title: bn() ? x.b : x.n, okText: MK.t('xx.apply'),
            html: '<p class="hint">' + esc(bn() ? x.db : x.d) + '</p>' + x.p.map(function (q) {
                return '<label>' + esc(bn() ? q[2] : q[1]) + '<input type="number" step="any" name="' + q[0] + '" value="' + (saved[q[0]] !== undefined ? saved[q[0]] : q[3]) + '"></label>';
            }).join('')
        }).then(function (r) {
            if (!r) { return; }
            var p = {};
            x.p.forEach(function (q) { var v = parseFloat(r[q[0]]); p[q[0]] = isNaN(v) ? q[3] : v; });
            cfg().expr = cfg().expr || {}; cfg().expr[x.id] = p; MK.saveSettings();
            return go(p);
        });
    }

    function exprLibrary() {
        var ov = document.createElement('div');
        ov.className = 'choice-overlay font-overlay';
        ov.innerHTML = '<div class="choice-box font-box xl-box"><div class="choice-title">' + esc(MK.t('xx.exprLib')) + '</div>' +
            '<input type="search" class="font-search" placeholder="' + esc(MK.t('xx.search')) + '">' +
            '<div class="tag-row xl-cats"></div><div class="font-list xl-list"></div>' +
            '<div class="row between"><span class="hint">' + esc(MK.t('xx.exprHint')) + '</span><button class="btn sm choice-cancel">' + esc(MK.t('ui.cancel')) + '</button></div></div>';
        document.body.appendChild(ov);
        MK.lockScroll(true);
        setTimeout(function () { ov.classList.add('show'); }, 10);
        var cat = '', input = ov.querySelector('.font-search'), list = ov.querySelector('.xl-list'), cats = ov.querySelector('.xl-cats');
        var close = function () { MK.lockScroll(false); ov.classList.remove('show'); setTimeout(function () { if (ov.parentNode) { ov.parentNode.removeChild(ov); } }, 160); };
        var drawCats = function () {
            cats.innerHTML = '';
            [''].concat(CATS).forEach(function (c) {
                var b = document.createElement('button');
                b.className = 'chip small' + (c === cat ? ' active' : '');
                b.textContent = c ? (bn() ? CAT_BN[c] : c) : MK.t('xx.all');
                b.onclick = function () { cat = c; drawCats(); draw(); };
                cats.appendChild(b);
            });
        };
        var draw = function () {
            var q = input.value.trim().toLowerCase();
            list.innerHTML = '';
            X.filter(function (x) { return (!cat || x.cat === cat) && (!q || (x.n + ' ' + x.b + ' ' + x.d + ' ' + x.db + ' ' + x.id).toLowerCase().indexOf(q) >= 0); }).forEach(function (x) {
                var b = document.createElement('button');
                b.className = 'font-row xl-row';
                b.innerHTML = '<span class="fr-sample"></span><small></small>';
                b.querySelector('.fr-sample').textContent = bn() ? x.b : x.n;
                b.querySelector('small').textContent = (bn() ? x.db : x.d) + '  ·  ' + (bn() ? CAT_BN[x.cat] : x.cat);
                b.onclick = function () { close(); applyExpr(x, null); };
                list.appendChild(b);
            });
        };
        input.addEventListener('input', draw);
        ov.querySelector('.choice-cancel').onclick = close;
        ov.addEventListener('click', function (e) { if (e.target === ov) { close(); } });
        drawCats(); draw();
        setTimeout(function () { input.focus(); }, 30);
    }

    /* ======================= QUICK EXTRAS ======================= */
    function cropComp(b) {
        var c = cfg();
        return MK.modal({
            title: MK.t('xx.crop'),
            html: fld('xx.pad', '<input type="number" name="pad" value="' + (c.cropPad === undefined ? 0 : c.cropPad) + '" min="0">') +
                fld('xx.cropMode', sel('mode', [['this', 'xx.thisComp'], ['new', 'xx.newComp']], c.cropMode || 'this'))
        }).then(function (r) {
            if (!r) { return; }
            c.cropPad = parseFloat(r.pad) || 0; c.cropMode = r.mode; MK.saveSettings();
            return MK.run(b, 'ex.cropComp', { pad: c.cropPad, mode: r.mode }, function (x) { return MK.t('xx.cropOk', { w: x.w, h: x.h }); });
        });
    }
    function gradLock(b) {
        var c = cfg().grad || { c1: '#ff4d6d', c2: '#5b4bff', type: 'linear', angle: 0 };
        return MK.modal({
            title: MK.t('xx.grad'),
            html: '<div class="form two">' + fld('xx.c1', '<input type="color" name="c1" value="' + c.c1 + '">') + fld('xx.c2', '<input type="color" name="c2" value="' + c.c2 + '">') +
                fld('xx.type', sel('type', [['linear', 'xx.linear'], ['radial', 'xx.radial']], c.type)) + fld('xx.angle', '<input type="number" name="angle" value="' + c.angle + '">') + '</div>' +
                '<p class="hint">' + esc(MK.t('xx.gradHint')) + '</p>'
        }).then(function (r) {
            if (!r) { return; }
            cfg().grad = r; MK.saveSettings();
            return MK.run(b, 'ex.gradientLock', { c1: rgb(r.c1), c2: rgb(r.c2), type: r.type, angle: parseFloat(r.angle) || 0 });
        });
    }

    // clipboard → files (image saved as PNG, or files copied in Explorer / Finder)
    function readClipboard() {
        var cp = MK.require('child_process'), path = MK.require('path');
        var dir = MK.paths.join(MK.paths.data, 'Pasted');
        MK.fs.mkdirp(dir);
        var out = path.join(dir, 'Pasted ' + new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19) + '.png');
        if (MK.isWin) {
            var ps = [
                'Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing;',
                '$f = [System.Windows.Forms.Clipboard]::GetFileDropList(); if ($f -and $f.Count -gt 0) { foreach ($x in $f) { "FILE:" + $x }; exit }',
                '$d = [System.Windows.Forms.Clipboard]::GetDataObject(); $o = $env:AIO_OUT;',
                'if ($d -and $d.GetDataPresent("PNG")) { $s = $d.GetData("PNG"); $fs = [IO.File]::Create($o); $s.Position = 0; $s.CopyTo($fs); $fs.Close(); "IMG:" + $o; exit }',
                '$img = [System.Windows.Forms.Clipboard]::GetImage(); if ($img) { $img.Save($o, [System.Drawing.Imaging.ImageFormat]::Png); "IMG:" + $o } else { "NONE" }'
            ].join(' ');
            var env = Object.assign({}, (typeof process !== 'undefined' && process.env) ? process.env : MK.require('process').env, { AIO_OUT: out });
            var txt = cp.execFileSync('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', ps], { encoding: 'utf8', windowsHide: true, timeout: 15000, env: env });
            return txt.split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return /^(FILE|IMG):/.test(l); }).map(function (l) { return l.replace(/^(FILE|IMG):/, ''); });
        }
        try {
            var f = cp.execFileSync('/usr/bin/osascript', ['-e', 'POSIX path of (the clipboard as «class furl»)'], { encoding: 'utf8', timeout: 8000 }).trim();
            if (f) { return [f]; }
        } catch (e) {}
        try {
            cp.execFileSync('/usr/bin/osascript', ['-e', 'set p to POSIX file "' + out.replace(/"/g, '') + '"', '-e', 'set f to open for access p with write permission', '-e', 'write (the clipboard as «class PNGf») to f', '-e', 'close access f'], { timeout: 8000 });
            if (MK.fs.size(out) > 0) { return [out]; }
        } catch (e2) {}
        return [];
    }
    function pasteImage(b) {
        return MK.busy(b, function () {
            var files = readClipboard().filter(function (f) { return MK.fs.exists(f) && !MK.fs.isDir(f); });
            if (!files.length) { MK.toast(MK.t('xx.pasteNone'), 'warn'); return; }
            return files.reduce(function (p, f) {
                return p.then(function () { return MK.host('broll.importFile', { path: f, addToComp: true, fit: 'none', bin: 'Pasted', duration: 5 }); });
            }, Promise.resolve()).then(function () { MK.toast(MK.t('xx.pasteOk', { n: files.length })); });
        });
    }

    function multipartBody(fields, file) {
        var Buf = MK.require('buffer').Buffer, boundary = '----AIO' + Date.now().toString(16), parts = [];
        fields.forEach(function (f) { parts.push(Buf.from('--' + boundary + '\r\nContent-Disposition: form-data; name="' + f[0] + '"\r\n\r\n' + f[1] + '\r\n', 'utf8')); });
        parts.push(Buf.from('--' + boundary + '\r\nContent-Disposition: form-data; name="' + file.field + '"; filename="' + file.name.replace(/"/g, '') + '"\r\nContent-Type: ' + file.type + '\r\n\r\n', 'utf8'));
        parts.push(file.buffer);
        parts.push(Buf.from('\r\n--' + boundary + '--\r\n', 'utf8'));
        return { body: Buf.concat(parts), type: 'multipart/form-data; boundary=' + boundary };
    }
    function removeBg(b) {
        var key = ((MK.settings.keys || {}).removebg || '').trim();
        if (!key) { MK.toast(MK.t('xx.rmbgKey'), 'warn'); MK.showTab('settings'); return; }
        return MK.modal({ title: MK.t('xx.rmbg'), html: fld('xx.size', sel('size', [['preview', 'xx.preview'], ['auto', 'xx.full']], cfg().rmbgSize || 'preview')) }).then(function (r) {
            if (!r) { return; }
            cfg().rmbgSize = r.size; MK.saveSettings();
            return MK.busy(b, function () {
                var fs = MK.require('fs'), path = MK.require('path');
                return MK.host('ex.readSelImage', {}).then(function (img) {
                    MK.toast(MK.t('xx.rmbgWork'));
                    var ext = (/\.(png|jpe?g|webp)$/i.exec(img.path) || ['', 'jpg'])[1].toLowerCase();
                    var mp = multipartBody([['size', r.size], ['format', 'png']], { field: 'image_file', name: path.basename(img.path), type: ext === 'png' ? 'image/png' : 'image/jpeg', buffer: fs.readFileSync(img.path) });
                    return MK.http.raw({ url: 'https://api.remove.bg/v1.0/removebg', method: 'POST', headers: { 'X-Api-Key': key, 'Content-Type': mp.type }, timeout: 180000 }, mp.body).then(function (res) {
                        if (res.status !== 200) {
                            var msg = res.body.toString('utf8'); try { var j = JSON.parse(msg); msg = (j.errors && j.errors[0] && (j.errors[0].title + (j.errors[0].detail ? ': ' + j.errors[0].detail : ''))) || msg; } catch (e) {}
                            throw new Error('remove.bg: ' + msg);
                        }
                        var dir = path.dirname(img.path), out = path.join(dir, path.basename(img.path).replace(/\.[^.]+$/, '') + '_nobg.png');
                        try { fs.writeFileSync(out, res.body); } catch (e2) {
                            dir = MK.paths.join(MK.paths.data, 'Remove BG'); MK.fs.mkdirp(dir);
                            out = path.join(dir, path.basename(img.path).replace(/\.[^.]+$/, '') + '_nobg.png'); fs.writeFileSync(out, res.body);
                        }
                        return MK.host('ex.replaceLayerSource', { index: img.index, path: out });
                    });
                }).then(function (x) { if (x) { MK.toast(MK.t('xx.rmbgOk')); } });
            });
        });
    }

    function highlight(b) {
        var c = cfg().hl || { style: 'box', color: '#ffd400', dir: 'left', dur: 0.5, at: 'start', pad: 12 };
        return MK.modal({
            title: MK.t('xx.hl'),
            html: '<div class="form two">' + fld('xx.style', sel('style', [['box', 'xx.box'], ['marker', 'xx.marker'], ['underline', 'xx.underline']], c.style)) +
                fld('xx.color', '<input type="color" name="color" value="' + c.color + '">') +
                fld('xx.dir', sel('dir', [['left', 'xx.fromLeft'], ['right', 'xx.fromRight'], ['center', 'xx.fromCenter']], c.dir)) +
                fld('xx.dur', '<input type="number" name="dur" step="0.1" min="0.05" value="' + c.dur + '">') +
                fld('xx.at', sel('at', [['start', 'xx.layerStart'], ['playhead', 'xx.playhead']], c.at)) +
                fld('xx.pad', '<input type="number" name="pad" value="' + c.pad + '">') + '</div>'
        }).then(function (r) {
            if (!r) { return; }
            cfg().hl = r; MK.saveSettings();
            return MK.run(b, 'ex.textHighlight', { style: r.style, color: rgb(r.color), dir: r.dir, duration: parseFloat(r.dur) || 0.5, at: r.at, pad: parseFloat(r.pad) });
        });
    }

    /* ---------- silence cutter ---------- */
    // windows of 20 ms → dB; returns silent ranges in source seconds
    function findSilence(info, t0, t1, thrDb, minSil) {
        var win = 0.02, out = [], start = -1, chunk = 30;
        for (var c0 = t0; c0 < t1; c0 += chunk) {
            var c1 = Math.min(t1, c0 + chunk), wav = MK._pcm.chunk(info, c0, c1), n = (wav.length - 44) >> 1, per = Math.round(16000 * win);
            for (var i = 0; i < n; i += per) {
                var acc = 0, m = Math.min(n, i + per);
                for (var j = i; j < m; j++) { var v = wav.readInt16LE(44 + j * 2) / 32768; acc += v * v; }
                var db = 20 * Math.log(Math.sqrt(acc / Math.max(1, m - i)) + 1e-9) / Math.LN10, t = c0 + i / 16000;
                if (db < thrDb) { if (start < 0) { start = t; } }
                else if (start >= 0) { if (t - start >= minSil) { out.push([start, t]); } start = -1; }
            }
        }
        if (start >= 0 && t1 - start >= minSil) { out.push([start, t1]); }
        return out;
    }
    function silenceCut(b) {
        var c = cfg().sil || { thr: -38, min: 0.5, pad: 0.12, close: true };
        return MK.modal({
            title: MK.t('xx.silence'),
            html: '<div class="form two">' + fld('xx.thr', '<input type="number" name="thr" step="1" value="' + c.thr + '">') +
                fld('xx.minSil', '<input type="number" name="min" step="0.05" min="0.1" value="' + c.min + '">') +
                fld('xx.keepPad', '<input type="number" name="pad" step="0.02" min="0" value="' + c.pad + '">') + '</div>' +
                '<label class="check"><input type="checkbox" name="close"' + (c.close ? ' checked' : '') + '><span>' + esc(MK.t('xx.close')) + '</span></label>'
        }).then(function (r) {
            if (!r) { return; }
            var o = { thr: parseFloat(r.thr) || -38, min: Math.max(0.1, parseFloat(r.min) || 0.5), pad: Math.max(0, parseFloat(r.pad) || 0), close: !!r.close };
            cfg().sil = o; MK.saveSettings();
            return MK.busy(b, function () {
                var fs = MK.require('fs'), path = MK.require('path'), src, tmp = null, info = null;
                MK.toast(MK.t('xx.analyzing'));
                return MK.host('captions.getSourceInfo', {}).then(function (s) {
                    src = s;
                    if (s.stretch < 0) { throw new Error('Reversed layers are not supported.'); }
                    MK.fs.mkdirp(MK.paths.temp);
                    var out = path.join(MK.paths.temp, 'aio-sil-' + Date.now());
                    if (MK.ffmpeg && MK.ffmpeg.find()) {
                        tmp = out + '.wav';
                        return MK.ffmpeg.run(['-y', '-i', s.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', tmp], s.duration).then(function () { return tmp; });
                    }
                    return MK.host('captions.renderAudio', { path: s.path, out: out }, { timeout: 1800000 }).then(function (x) { tmp = x.path; return tmp; });
                }).then(function (file) {
                    info = MK._pcm.info(file);
                    var k = 100 / (src.stretch || 100);
                    var toSrc = function (t) { return (t - src.startTime) * k; }, toComp = function (t) { return src.startTime + t / k; };
                    var s0 = Math.max(0, toSrc(src.inPoint)), s1 = Math.min(info.duration, toSrc(src.outPoint));
                    var sil = findSilence(info, s0, s1, o.thr, o.min);
                    try { fs.closeSync(info.fd); } catch (e) {}
                    try { fs.unlinkSync(tmp); } catch (e2) {}
                    // keep = everything between silences, padded
                    var keep = [], pos = s0, removed = 0;
                    sil.forEach(function (g) {
                        var a = g[0] + o.pad, z = g[1] - o.pad;
                        if (z - a < 0.05) { return; }
                        if (a > pos) { keep.push([toComp(pos), toComp(a)]); }
                        removed += (z - a) / k; pos = z;
                    });
                    if (pos < s1) { keep.push([toComp(pos), toComp(s1)]); }
                    if (keep.length < 2 && removed < 0.05) { MK.toast(MK.t('xx.silNone', { m: o.min }), 'warn'); return; }
                    return MK.modal({ title: MK.t('xx.silence'), html: '<p>' + esc(MK.t('xx.silFound', { n: sil.length, s: removed.toFixed(1) })) + '</p>', okText: MK.t('xx.apply') }).then(function (ok) {
                        if (!ok) { return; }
                        return MK.host('ex.cutSilence', { keep: keep, close: o.close }).then(function (x) { MK.toast(MK.t('xx.silOk', { n: x.count })); });
                    });
                }, function (e) { if (tmp) { try { fs.unlinkSync(tmp); } catch (e3) {} } throw e; });
            });
        });
    }

    MK.initExtra = function () {
        var map = { xCrop: cropComp, xGrad: gradLock, xPaste: pasteImage, xRmbg: removeBg, xHl: highlight, xSil: silenceCut };
        Object.keys(map).forEach(function (id) { var el = MK.$('#' + id); if (el) { el.onclick = function () { var r = map[id](this); if (r && r.catch) { r.catch(MK.fail); } }; } });
        MK.$('#xExprLib').onclick = exprLibrary;
    };

    MK._extra = { X: X, findSilence: findSilence, multipartBody: multipartBody, readClipboard: readClipboard, exprLibrary: exprLibrary };
})(window);
