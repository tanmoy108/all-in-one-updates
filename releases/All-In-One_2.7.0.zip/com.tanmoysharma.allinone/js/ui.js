/* All In One — UI helpers: icons, toast, modal, tabs, busy state */
(function (w) {
    'use strict';
    var MK = w.MK;

    var P = {
        gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
        bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
        type: '<path d="M4 7V5h16v2M9 19h6M12 5v14"/>',
        curve: '<path d="M3 21C9 21 8 3 21 3"/><circle cx="3" cy="21" r="1.5"/><circle cx="21" cy="3" r="1.5"/>',
        cc: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 10.5a2 2 0 1 0 0 3M17 10.5a2 2 0 1 0 0 3"/>',
        film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
        spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
        square: '<rect x="4" y="4" width="16" height="16" rx="2"/>',
        adjust: '<circle cx="12" cy="12" r="8"/><path d="M12 4v16" /><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor" stroke="none"/>',
        'null': '<rect x="5" y="5" width="14" height="14" rx="1" stroke-dasharray="3 2"/><path d="M12 9v6M9 12h6"/>',
        camera: '<path d="M4 8h3l2-2h6l2 2h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
        stack: '<path d="M12 3 3 8l9 5 9-5z"/><path d="M3 13l9 5 9-5"/>',
        unstack: '<path d="M12 3 3 8l9 5 9-5z"/><path d="M3 15l9 5 9-5" stroke-dasharray="2 2"/>',
        copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
        split: '<path d="M4 6h5M4 12h5M4 18h5M15 6h5M15 12h5M15 18h5"/><path d="M12 3v18" stroke-dasharray="2 2"/>',
        pen: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M14 6l4 4"/>',
        trimIn: '<path d="M8 4v16M8 12h12M16 8l4 4-4 4"/>',
        trimOut: '<path d="M16 4v16M16 12H4M8 8l-4 4 4 4"/>',
        cut: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12"/>',
        playhead: '<path d="M12 3v18"/><path d="M8 3h8l-4 4z" fill="currentColor"/>',
        alignL: '<path d="M4 3v18M8 7h10v4H8zM8 14h6v4H8z"/>',
        alignC: '<path d="M12 3v18M7 7h10v4H7zM9 14h6v4H9z"/>',
        alignR: '<path d="M20 3v18M6 7h10v4H6zM10 14h6v4h-6z"/>',
        alignT: '<path d="M3 4h18M7 8v10h4V8zM14 8v6h4V8z"/>',
        alignM: '<path d="M3 12h18M7 7v10h4V7zM14 9v6h4V9z"/>',
        alignB: '<path d="M3 20h18M7 6v10h4V6zM14 10v6h4v-6z"/>',
        flipH: '<path d="M12 3v18" stroke-dasharray="2 2"/><path d="M9 7 4 12l5 5zM15 7l5 5-5 5z"/>',
        flipV: '<path d="M3 12h18" stroke-dasharray="2 2"/><path d="M7 9l5-5 5 5zM7 15l5 5 5-5z"/>',
        folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
        replay: '<path d="M4 12a8 8 0 1 0 2.3-5.7"/><path d="M4 4v5h5"/>',
        play: '<path d="M7 4l13 8-13 8z"/>',
        plus: '<path d="M12 5v14M5 12h14"/>',
        layer: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/>',
        file: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/>',
        wave: '<path d="M3 12h2M7 8v8M11 5v14M15 8v8M19 10v4M21 12h0"/>',
        search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
        send: '<path d="M4 12 20 4l-6 16-3-7z"/>',
        trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
        star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
        wrench: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.2L3 17.8V21h3.2l6.3-6.3a4 4 0 0 0 5.2-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
        trimBelow: '<rect x="4" y="5" width="12" height="5" rx="1"/><rect x="4" y="14" width="16" height="5" rx="1"/><path d="M16 10v4M20 10v4" stroke-dasharray="2 2"/>',
        shuffle: '<path d="M3 7h4l10 10h4M17 7h4M3 17h4l2.5-2.5M14.5 9.5 17 7"/><path d="M19 5l2 2-2 2M19 15l2 2-2 2"/>',
        invert: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 20 20 4"/><path d="M4 4h8l-8 8z" fill="currentColor" stroke="none"/>',
        crop: '<path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/>',
        gradient: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 15 15 3M3 21 21 3M9 21 21 9" opacity=".6"/>',
        paste: '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="M9 12l2 2 4-4"/>',
        cutout: '<circle cx="12" cy="8" r="3.5"/><path d="M5 21c1-4 4-6 7-6s6 2 7 6"/><path d="M3 3h4M17 3h4M3 3v4M21 3v4" stroke-dasharray="2 2"/>',
        marker: '<path d="M4 20h7"/><path d="M14 4l6 6-8 8H6v-6z"/>',
        box: '<path d="M12 3 3 7.5v9L12 21l9-4.5v-9z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
        grid: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
        layout: '<rect x="3" y="8" width="5" height="8" rx="1"/><rect x="10" y="8" width="5" height="8" rx="1"/><rect x="17" y="8" width="4" height="8" rx="1"/>',
        layoutV: '<rect x="8" y="3" width="8" height="5" rx="1"/><rect x="8" y="10" width="8" height="5" rx="1"/><rect x="8" y="17" width="8" height="4" rx="1"/>',
        circleL: '<circle cx="12" cy="12" r="7" stroke-dasharray="2 3"/><circle cx="12" cy="5" r="2"/><circle cx="19" cy="12" r="2"/><circle cx="12" cy="19" r="2"/><circle cx="5" cy="12" r="2"/>',
        dice: '<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1.2" fill="currentColor"/><circle cx="15" cy="15" r="1.2" fill="currentColor"/><circle cx="15" cy="9" r="1.2" fill="currentColor"/><circle cx="9" cy="15" r="1.2" fill="currentColor"/>',
        capButt: '<path d="M4 12h12" stroke-width="6" stroke-linecap="butt"/><path d="M16 6v12"/>',
        capRound: '<path d="M5 12h11" stroke-width="6" stroke-linecap="round"/><path d="M19 6v12"/>',
        capSquare: '<path d="M6 12h10" stroke-width="6" stroke-linecap="square"/><path d="M20 6v12"/>',
        trimPath: '<path d="M4 18C7 6 17 6 20 18" stroke-dasharray="14 40"/><circle cx="4" cy="18" r="1.5"/>',
        vector: '<path d="M12 4 4 20h16z"/><circle cx="12" cy="4" r="1.5"/><circle cx="4" cy="20" r="1.5"/><circle cx="20" cy="20" r="1.5"/>',
        explode: '<rect x="9" y="9" width="6" height="6" rx="1"/><path d="M4 4l3 3M20 4l-3 3M4 20l3-3M20 20l-3-3"/>',
        merge: '<path d="M6 4v5a6 6 0 0 0 6 6h0a6 6 0 0 0 6-6V4"/><path d="M12 15v5"/>',
        broom: '<path d="M14 4l6 6M12 6l6 6-7 7-6-6z"/><path d="M5 13l-2 8 8-2"/>',
        ball: '<circle cx="12" cy="7" r="3.5"/><path d="M4 21h16M8 17h8" stroke-dasharray="2 2"/>',
        loop: '<path d="M17 3l3 3-3 3"/><path d="M4 12V9a3 3 0 0 1 3-3h13M7 21l-3-3 3-3"/><path d="M20 12v3a3 3 0 0 1-3 3H4"/>',
        magnet: '<path d="M6 4v8a6 6 0 0 0 12 0V4h-4v8a2 2 0 0 1-4 0V4z"/>',
        link: '<circle cx="5" cy="17" r="2"/><circle cx="12" cy="7" r="2"/><circle cx="19" cy="15" r="2"/><path d="M6.2 15.4 10.8 8.6M13.6 8.2l4 5.4"/>',
        glass: '<rect x="4" y="5" width="16" height="14" rx="4"/><path d="M8 9c1-1.5 3-2 4.5-1.5"/>',
        drop: '<path d="M12 3c4 5 6 8 6 11a6 6 0 0 1-12 0c0-3 2-6 6-11z"/><path d="M9.5 14a2.5 2.5 0 0 0 2.5 2.5"/>',
        glitch: '<path d="M3 6h10M7 10h14M3 14h12M9 18h12"/>',
        vignette: '<rect x="3" y="4" width="18" height="16" rx="2"/><ellipse cx="12" cy="12" rx="6" ry="5" stroke-dasharray="2 2"/>',
        export: '<path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/>',
        mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
        motion: '<rect x="11" y="7" width="10" height="10" rx="2.5"/><path d="M3 9h5M2 12h6M3 15h5"/>',
        shRect: '<rect x="4" y="6" width="16" height="12"/>',
        shRound: '<rect x="4" y="6" width="16" height="12" rx="4"/>',
        shEllipse: '<ellipse cx="12" cy="12" rx="8" ry="6.5"/>',
        shTri: '<path d="M12 4 21 19H3z"/>',
        shPoly: '<path d="M12 3l8 5v8l-8 5-8-5V8z"/>',
        shLine: '<path d="M4 18 20 6"/>',
        shArrow: '<path d="M3 12h15M13 6l6 6-6 6"/>',
        safe: '<rect x="6" y="3" width="12" height="18" rx="2"/><rect x="8" y="7" width="8" height="8" stroke-dasharray="2 1.5"/>',
        speaker: '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a7.5 7.5 0 0 1 0 11"/>'
    };

    MK.icon = function (name) {
        return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (P[name] || '') + '</svg>';
    };

    MK.renderIcons = function (root) {
        var els = (root || document).querySelectorAll('[data-icon]');
        for (var i = 0; i < els.length; i++) {
            var el = els[i];
            if (el.querySelector('svg.ic')) { continue; }
            el.insertAdjacentHTML('afterbegin', MK.icon(el.getAttribute('data-icon')));
        }
    };

    MK.copy = function (text) {
        try { if (navigator.clipboard && w.isSecureContext) { navigator.clipboard.writeText(text).catch(function () {}); return; } } catch (e) {}
        var ta = document.createElement('textarea');
        ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); } catch (e2) {}
        document.body.removeChild(ta);
    };

    // flexbox gap support (missing in Chromium < 84, i.e. AE 2019-2021)
    MK.checkFlexGap = function () {
        var d = document.createElement('div');
        d.style.cssText = 'display:flex;flex-direction:column;row-gap:1px;position:absolute;visibility:hidden';
        d.appendChild(document.createElement('div')); d.appendChild(document.createElement('div'));
        document.body.appendChild(d);
        var ok = d.scrollHeight === 1;
        document.body.removeChild(d);
        if (!ok) { document.body.classList.add('no-flex-gap'); }
    };

    MK.$ = function (sel, root) { return (root || document).querySelector(sel); };
    MK.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

    MK.esc = function (s) {
        return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    };

    /* ---------- toast ---------- */
    var toastTimer = null;
    MK.toast = function (text, kind) {
        var el = MK.$('#toast');
        el.textContent = text;
        el.className = 'toast show ' + (kind || '');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { el.className = 'toast ' + (kind || ''); }, kind === 'err' ? 5200 : 2600);
    };
    MK.fail = function (e) { console.error(e); MK.toast(MK.errText(e), 'err'); };

    /* ---------- modal ---------- */
    MK.modal = function (opts) {
        return new Promise(function (resolve) {
            var m = MK.$('#modal');
            m.querySelector('.modal-title').textContent = opts.title || '';
            var body = m.querySelector('.modal-body');
            body.innerHTML = opts.html || '';
            var actions = m.querySelector('.modal-actions');
            actions.innerHTML = '';
            var close = function (val) { m.classList.add('hidden'); MK.lockScroll(false); document.removeEventListener('keydown', onKey); resolve(val); };
            var collect = function () {
                var out = {};
                MK.$$('[name]', body).forEach(function (inp) { out[inp.name] = inp.type === 'checkbox' ? inp.checked : inp.value; });
                return out;
            };
            var cancel = document.createElement('button');
            cancel.className = 'btn sm';
            cancel.textContent = MK.t('ui.cancel');
            cancel.onclick = function () { close(null); };
            var ok = document.createElement('button');
            ok.className = 'btn sm primary';
            ok.textContent = opts.okText || MK.t('ui.ok');
            ok.onclick = function () { close(collect()); };
            actions.appendChild(cancel);
            actions.appendChild(ok);
            var onKey = function (e) {
                if (e.key === 'Escape') { close(null); }
                if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { close(collect()); }
            };
            document.addEventListener('keydown', onKey);
            m.classList.remove('hidden');
            MK.lockScroll(true);
            var first = body.querySelector('input, select');
            if (first) { setTimeout(function () { first.focus(); if (first.select) { first.select(); } }, 30); }
        });
    };

    // big-button choice popup (used for IN / OUT / IN+OUT)
    MK.choose = function (opts) {
        return new Promise(function (resolve) {
            var ov = document.createElement('div');
            ov.className = 'choice-overlay';
            ov.innerHTML = '<div class="choice-box" role="dialog" aria-modal="true">' +
                '<div class="choice-title">' + MK.esc(opts.title) + '</div>' +
                (opts.sub ? '<div class="choice-sub">' + MK.esc(opts.sub) + '</div>' : '') +
                '<div class="choice-row">' + opts.options.map(function (o) {
                    return '<button type="button" class="choice-btn" data-v="' + MK.esc(o.value) + '">' + MK.esc(o.label) + (o.small ? '<small>' + MK.esc(o.small) + '</small>' : '') + '</button>';
                }).join('') + '</div>' +
                (opts.remember ? '<label class="check"><input type="checkbox" class="choice-remember"><span>' + MK.esc(opts.remember) + '</span></label>' : '') +
                '<button type="button" class="btn sm choice-cancel">' + MK.esc(MK.t('ui.cancel')) + '</button></div>';
            document.body.appendChild(ov);
            MK.lockScroll(true);
            var done = function (v) {
                document.removeEventListener('keydown', key);
                MK.lockScroll(false);
                ov.classList.remove('show');
                setTimeout(function () { if (ov.parentNode) { ov.parentNode.removeChild(ov); } }, 160);
                resolve(v);
            };
            var key = function (e) { if (e.key === 'Escape') { done(null); } };
            document.addEventListener('keydown', key);
            ov.addEventListener('click', function (e) {
                if (e.target === ov || e.target.classList.contains('choice-cancel')) { return done(null); }
                var b = e.target.closest ? e.target.closest('.choice-btn') : null;
                if (!b) { return; }
                var rem = ov.querySelector('.choice-remember');
                done({ value: b.getAttribute('data-v'), remember: !!(rem && rem.checked) });
            });
            setTimeout(function () { ov.classList.add('show'); }, 10);
        });
    };

    // freeze the page behind a popup so the mouse wheel doesn't scroll it
    MK.lockScroll = function (on) {
        MK._locks = Math.max(0, (MK._locks || 0) + (on ? 1 : -1));
        document.body.classList.toggle('popup-open', MK._locks > 0);
    };

    MK.prompt = function (title, label, value) {
        return MK.modal({
            title: title,
            html: '<label>' + MK.esc(label) + '<input type="text" name="v" value="' + MK.esc(value || '') + '"></label>'
        }).then(function (r) { return r ? r.v : null; });
    };

    /* ---------- busy wrapper: disables the button while a promise runs ---------- */
    MK.busy = function (btn, fn) {
        if (btn && btn.classList.contains('busy')) { return Promise.resolve(); }
        if (btn) { btn.classList.add('busy'); }
        var done = function () { if (btn) { btn.classList.remove('busy'); } };
        var p;
        try { p = Promise.resolve(fn()); } catch (e) { p = Promise.reject(e); }
        return p.then(function (v) { done(); return v; }, function (e) { done(); MK.fail(e); });
    };

    MK.progress = function (el, frac, text) {
        if (!el) { return; }
        el.classList.remove('hidden');
        el.classList.toggle('indeterminate', frac === null || frac === undefined);
        el.querySelector('div').style.width = (frac === null || frac === undefined) ? '' : Math.round(frac * 100) + '%';
        el.querySelector('span').textContent = text || '';
    };
    MK.progressHide = function (el) { if (el) { el.classList.add('hidden'); } };

    /* ---------- colors ---------- */
    MK.hexToRgb01 = function (hex) {
        var h = String(hex).replace('#', '');
        if (h.length === 3) { h = h.split('').map(function (c) { return c + c; }).join(''); }
        var n = parseInt(h, 16);
        return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
    };

    /* ---------- tabs ---------- */
    MK.tabs = { current: 'quick', onShow: {} };
    MK.showTab = function (id) {
        MK.$$('#tabs button').forEach(function (b) { b.classList.toggle('active', b.dataset.tab === id); });
        MK.$$('main > .tab').forEach(function (s) { s.classList.toggle('active', s.id === 'tab-' + id); });
        MK.tabs.current = id;
        if (MK.tabs.onShow[id]) { try { MK.tabs.onShow[id](); } catch (e) { console.error(e); } }
    };

    // segmented control helper
    MK.seg = function (root, onChange) {
        MK.$$('button', root).forEach(function (b) {
            b.addEventListener('click', function () {
                MK.$$('button', root).forEach(function (x) { x.classList.toggle('active', x === b); });
                if (onChange) { onChange(b); }
            });
        });
    };
    MK.segValue = function (root, attr) {
        var b = MK.$('button.active', root);
        return b ? b.getAttribute(attr) : null;
    };

    // run a host call and toast the result
    MK.run = function (btn, fn, args, okMsg) {
        return MK.busy(btn, function () {
            return MK.host(fn, args).then(function (r) {
                if (r && r.warnings && r.warnings.length) { MK.toast(MK.t('warn.some', { w: r.warnings.join(' · ') }), 'warn'); }
                else if (typeof okMsg === 'function') { MK.toast(okMsg(r)); }
                else { MK.toast(okMsg || (r && r.count !== undefined ? MK.t('ok.count', { n: r.count }) : MK.t('ok.done'))); }
                return r;
            });
        });
    };
})(window);
