All In One - bundled text presets
--------------------------------------
Put .ffx After Effects animation presets in this folder (sub-folders become
categories in the panel). Users can also add their own presets from the panel
("Add .ffx"); those are copied to:  Documents/All In One/Text Presets

Optional preview next to a preset: same file name with .gif / .png / .jpg / .mp4
(e.g. "Bounce In.ffx" + "Bounce In.mp4"). Otherwise press "Make previews" in the
panel and All In One renders frame previews inside After Effects.
