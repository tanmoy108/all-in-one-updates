/* All In One — light overlays + camera FX (ExtendScript, ES3).
   Everything is built from native AE layers/effects with expression controls, so it stays editable
   and needs no footage files. */
MKH.looks = (function () {
    var U = MKH.util;
    var X = {};

    function fx(L, mn, name) { var e = L.property('ADBE Effect Parade').addProperty(mn); if (name) { e.name = name; } return e; }
    // property by match name, falling back to English display names
    function P(group, keys) {
        for (var i = 0; i < keys.length; i++) {
            try { var p = group.property(keys[i]); if (p) { return p; } } catch (e) {}
        }
        return null;
    }
    function setP(group, keys, v) { var p = P(group, keys); if (p) { try { p.setValue(v); } catch (e) {} } return p; }
    function slider(L, name, v) { var e = fx(L, 'ADBE Slider Control', name); e.property(1).setValue(v); return e; }
    function uniqueName(c, base) {
        var taken = {}, n = 2, name = base;
        for (var i = 1; i <= c.numLayers; i++) { taken[c.layer(i).name] = true; }
        while (taken[name]) { name = base + ' ' + n++; }
        return name;
    }
    function hex(h) {
        h = String(h || '#4a7dff').replace('#', '');
        var n = parseInt(h, 16);
        return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
    }
    // time span + stacking: above the topmost selected layer, else on top, over the whole comp
    function placement(c) {
        var s = c.selectedLayers, top = null;
        for (var i = 0; i < s.length; i++) { if (!top || s[i].index < top.index) { top = s[i]; } }
        return { above: top, inP: top ? top.inPoint : 0, outP: top ? top.outPoint : c.duration };
    }
    function place(L, pl) {
        try { if (pl.above) { L.moveBefore(pl.above); } } catch (e) {}
        try { L.inPoint = Math.max(0, pl.inP); L.outPoint = Math.max(L.inPoint + 0.04, pl.outP); } catch (e) {}
    }
    var BLEND = { screen: BlendingMode.SCREEN, add: BlendingMode.ADD, overlay: BlendingMode.OVERLAY, soft: BlendingMode.SOFT_LIGHT };

    /* ---------- light overlay: soft drifting light blobs on a shape layer ---------- */
    X.lightOverlay = function (a) {
        var c = U.comp(), pl = placement(c), w = c.width, h = c.height;
        var L = c.layers.addShape();
        L.name = uniqueName(c, 'AIO Light ' + (a.name || ''));
        L.label = 9;
        var root = L.property('ADBE Root Vectors Group');
        // controls the user can edit later
        var col = fx(L, 'ADBE Color Control', 'Light Color');
        col.property(1).setValue(hex(a.color));
        slider(L, 'Intensity', Math.max(0, parseFloat(a.intensity) || 80));
        slider(L, 'Speed', Math.max(0.05, parseFloat(a.speed) || 1));
        slider(L, 'Spread', 100);
        // blobs: [x, y, sizeW, sizeH, mix-to-white, freqX, freqY, phase]
        var B = [
            [-0.32, -0.22, 0.75, 0.62, 0.0, 0.31, 0.23, 0.0],
            [0.30, 0.18, 0.62, 0.55, 0.35, 0.19, 0.27, 2.1],
            [0.05, 0.36, 0.48, 0.40, 0.65, 0.41, 0.17, 4.2],
            [-0.08, -0.40, 0.36, 0.30, 0.15, 0.23, 0.37, 1.3]
        ];
        for (var i = 0; i < B.length; i++) {
            var b = B[i];
            var g = root.addProperty('ADBE Vector Group');
            g.name = 'Light ' + (i + 1);
            var gc = g.property('ADBE Vectors Group');
            var el = gc.addProperty('ADBE Vector Shape - Ellipse');
            el.property('ADBE Vector Ellipse Size').expression =
                'var s = effect("Spread")("Slider") / 100;\n[' + Math.round(b[2] * w) + ' * s, ' + Math.round(b[3] * h) + ' * s];';
            var fill = gc.addProperty('ADBE Vector Graphic - Fill');
            fill.property('ADBE Vector Fill Color').expression =
                'var c = effect("Light Color")("Color"), m = ' + b[4] + ';\n[c[0] + (1 - c[0]) * m, c[1] + (1 - c[1]) * m, c[2] + (1 - c[2]) * m, 1];';
            var tr = g.property('ADBE Vector Transform Group');
            tr.property('ADBE Vector Position').expression =
                'var sp = effect("Speed")("Slider"), t = time * sp;\n' +
                '[' + Math.round(b[0] * w) + ' + Math.sin(t * ' + b[5] + ' + ' + b[7] + ') * ' + Math.round(w * 0.22) + ', ' +
                Math.round(b[1] * h) + ' + Math.cos(t * ' + b[6] + ' + ' + b[7] + ') * ' + Math.round(h * 0.18) + '];';
            tr.property('ADBE Vector Group Opacity').expression =
                'var t = time * effect("Speed")("Slider");\n55 + 45 * Math.sin(t * ' + (0.6 + i * 0.27).toFixed(2) + ' + ' + b[7] + ');';
        }
        var blur = fx(L, 'ADBE Gaussian Blur 2', 'Soft');
        setP(blur, ['ADBE Gaussian Blur 2-0001', 'Blurriness'], Math.round(Math.min(w, h) * 0.18));
        setP(blur, ['ADBE Gaussian Blur 2-0003', 'Repeat Edge Pixels'], 1);
        L.property('ADBE Transform Group').property('ADBE Opacity').expression = 'effect("Intensity")("Slider");';
        L.blendingMode = BLEND[a.blend] || BlendingMode.SCREEN;
        place(L, pl);
        L.selected = true;
        return { name: L.name };
    };

    /* ---------- camera FX: adjustment layer with Motion Tile + Transform ---------- */
    var DIRS = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] };
    X.cameraFx = function (a) {
        var c = U.comp(), pl = placement(c), w = c.width, h = c.height;
        var dir = String(a.dir || 'left'), type = String(a.type || 'drift');
        var speed = Math.max(0.1, parseFloat(a.speed) || 1);
        var L = c.layers.addSolid([1, 1, 1], uniqueName(c, 'AIO Camera ' + dir), w, h, c.pixelAspect, c.duration);
        L.adjustmentLayer = true;
        L.label = 14;
        slider(L, 'Speed', speed);
        slider(L, 'Shake', a.shake ? 6 : 0);
        slider(L, 'Zoom %/s', 4);
        var tile = fx(L, 'ADBE Tile', 'Edges');
        setP(tile, ['ADBE Tile-0004', 'Output Width'], 300);
        setP(tile, ['ADBE Tile-0005', 'Output Height'], 300);
        setP(tile, ['ADBE Tile-0006', 'Mirror Edges'], 1);
        var T = fx(L, 'ADBE Geometry2', 'Camera');
        var pos = P(T, ['ADBE Geometry2-0002', 'Position']);
        var scl = P(T, ['ADBE Geometry2-0011', 'Scale']);
        setP(T, ['ADBE Geometry2-0009', "Use Composition's Shutter Angle"], 0);
        setP(T, ['ADBE Geometry2-0010', 'Shutter Angle'], type === 'whip' ? 360 : 180);
        var shake = 'var sh = effect("Shake")("Slider");\nvar n = sh > 0 ? sub(wiggle(1.6 * effect("Speed")("Slider"), sh * thisComp.height / 1080), value) : [0, 0];\n';
        var d = DIRS[dir];

        if (type === 'whip') {
            // fast whip pan centered on the playhead (a transition between two shots)
            var dur = 0.5 / speed, t0 = Math.max(0, c.time - dur / 2);
            L.inPoint = 0; L.outPoint = c.duration;
            L.inPoint = t0; L.outPoint = Math.min(c.duration, t0 + dur);
            try { if (pl.above) { L.moveBefore(pl.above); } } catch (e) {}
            if (d) {
                var center = [w / 2, h / 2], far = [w / 2 + d[0] * w, h / 2 + d[1] * h];
                pos.setValueAtTime(t0, center);
                pos.setValueAtTime(t0 + dur, far);
                ease(pos, 85);
            } else {
                var z0 = dir === 'zoomout' ? 300 : 100, z1 = dir === 'zoomout' ? 100 : 300;
                scl.setValueAtTime(t0, z0);
                scl.setValueAtTime(t0 + dur, z1);
                ease(scl, 85);
            }
            L.motionBlur = true;
            try { c.motionBlur = true; } catch (e) {}
        } else {
            place(L, pl);
            var tt = 'var t = time - inPoint, sp = effect("Speed")("Slider");\n';
            if (d) {
                pos.expression = tt + shake + 'add(add(value, mul([' + d[0] + ', ' + d[1] + '], sp * 60 * (thisComp.height / 1080) * t)), n);';
            } else {
                pos.expression = tt + shake + 'add(value, n);';
            }
            if (dir === 'zoomin') {
                scl.expression = tt + 'value + effect("Zoom %/s")("Slider") * sp * t;';
            } else if (dir === 'zoomout') {
                scl.expression = tt + 'value + effect("Zoom %/s")("Slider") * sp * Math.max(0, (outPoint - inPoint) - t);';
            }
        }
        L.selected = true;
        return { name: L.name };
    };
    function ease(prop, infl) {
        try {
            var dims = prop.value instanceof Array ? prop.value.length : 1, e = [];
            for (var i = 0; i < dims; i++) { e.push(new KeyframeEase(0, infl)); }
            for (var k = 1; k <= prop.numKeys; k++) { prop.setTemporalEaseAtKey(k, e, e); }
        } catch (er) {}
    }

    return X;
})();
