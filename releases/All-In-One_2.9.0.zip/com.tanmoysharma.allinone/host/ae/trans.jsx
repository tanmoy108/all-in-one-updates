/* All In One — transition library (ExtendScript, ES3).
   readTransition: turns the selected layer (effects, transform, keyframes, eases, expressions, markers)
   into plain data, with every time relative to its "cut" point.
   apply: rebuilds it as a new layer with the cut on the playhead. */
MKH.trans = (function () {
    var U = MKH.util;
    var X = {};

    function cutOf(L) {
        // a layer marker whose comment contains "cut", else the middle of the layer
        try {
            var m = L.property('ADBE Marker');
            for (var i = 1; i <= m.numKeys; i++) {
                if (/cut/i.test(m.keyValue(i).comment)) { return m.keyTime(i); }
            }
            if (m.numKeys === 1) { return m.keyTime(1); }
        } catch (e) {}
        return (L.inPoint + L.outPoint) / 2;
    }
    function isSpatial(p) {
        var t = p.propertyValueType;
        return t === PropertyValueType.TwoD_SPATIAL || t === PropertyValueType.ThreeD_SPATIAL;
    }
    function easeArr(a) {
        var o = [];
        for (var i = 0; i < a.length; i++) { o.push([a[i].speed, a[i].influence]); }
        return o;
    }
    function skippable(p) {
        var t = p.propertyValueType;
        if (t === PropertyValueType.NO_VALUE || t === PropertyValueType.CUSTOM_VALUE ||
            t === PropertyValueType.MARKER || t === PropertyValueType.SHAPE || t === PropertyValueType.TEXT_DOCUMENT) { return true; }
        try { if (p.dimensionsSeparated) { return true; } } catch (e) {}
        try { if (p.isSeparationFollower && !p.separationLeader.dimensionsSeparated) { return true; } } catch (e2) {}
        return false;
    }

    function serProp(p, t0) {
        if (skippable(p)) { return null; }
        var o = { mn: p.matchName, i: p.propertyIndex };
        var keyed = p.numKeys > 0, ex = false;
        try { ex = p.expressionEnabled && p.expression !== ''; } catch (e) {}
        var mod = true;
        try { mod = p.isModified; } catch (e3) {}
        if (!keyed && !ex && !mod) { return null; }
        if (isSpatial(p)) { o.sp = 1; }
        if (keyed) {
            o.k = [];
            for (var k = 1; k <= p.numKeys; k++) {
                var key = { t: p.keyTime(k) - t0, v: p.keyValue(k), ii: p.keyInInterpolationType(k), oi: p.keyOutInterpolationType(k) };
                try { key.ei = easeArr(p.keyInTemporalEase(k)); key.eo = easeArr(p.keyOutTemporalEase(k)); } catch (e4) {}
                try { key.tc = p.keyTemporalContinuous(k); key.ab = p.keyTemporalAutoBezier(k); } catch (e5) {}
                if (o.sp) {
                    try { key.si = p.keyInSpatialTangent(k); key.so = p.keyOutSpatialTangent(k); key.sc = p.keySpatialContinuous(k); key.sa = p.keySpatialAutoBezier(k); key.rv = p.keyRoving(k); } catch (e6) {}
                }
                o.k.push(key);
            }
        } else {
            o.v = p.value;
        }
        if (ex) { o.x = p.expression; }
        return o;
    }
    function serGroup(g, t0) {
        var kids = [];
        for (var i = 1; i <= g.numProperties; i++) {
            var p = g.property(i), s = null;
            try {
                s = (p.propertyType === PropertyType.PROPERTY) ? serProp(p, t0) : serGroup(p, t0);
            } catch (e) { s = null; }
            if (s) { kids.push(s); }
        }
        if (!kids.length) { return null; }
        return { mn: g.matchName, i: g.propertyIndex, g: kids };
    }

    X.readTransition = function (a) {
        var c = U.comp(), L = U.sel(c)[0];
        if (!(L instanceof AVLayer) && !(L instanceof ShapeLayer)) { throw new Error('Select an adjustment or solid layer'); }
        var t0 = cutOf(L);
        var out = {
            w: c.width, h: c.height, fps: c.frameRate,
            name: L.name, cut: 0, inP: L.inPoint - t0, outP: L.outPoint - t0,
            adjust: !!L.adjustmentLayer, blend: L.blendingMode, motionBlur: !!L.motionBlur,
            color: [0, 0, 0], effects: [], transform: null, markers: [], warnings: []
        };
        try { if (L.source && L.source.mainSource && L.source.mainSource.color) { out.color = L.source.mainSource.color; } } catch (e) {}
        try { if (!(L.source && L.source.mainSource instanceof SolidSource)) { out.warnings.push('notSolid'); } } catch (e1) {}
        var fxp = L.property('ADBE Effect Parade');
        for (var i = 1; i <= fxp.numProperties; i++) {
            var ef = fxp.property(i);
            var s = serGroup(ef, t0) || { g: [] };
            out.effects.push({ mn: ef.matchName, name: ef.name, on: ef.enabled, g: s.g });
        }
        var tr = serGroup(L.property('ADBE Transform Group'), t0);
        if (tr) { out.transform = tr.g; }
        try {
            var m = L.property('ADBE Marker');
            for (var k = 1; k <= m.numKeys; k++) { out.markers.push({ t: m.keyTime(k) - t0, c: m.keyValue(k).comment }); }
        } catch (e2) {}
        if (a && a.thumb) {
            try { c.saveFrameToPng(t0, new File(a.thumb)); } catch (e3) {}
        }
        return out;
    };

    /* ---------- apply ---------- */
    function ease(list) {
        var o = [];
        for (var i = 0; i < list.length; i++) { o.push(new KeyframeEase(list[i][0], Math.max(0.1, Math.min(100, list[i][1])))); }
        return o;
    }
    function scaleVal(v, sp, sx, sy) {
        if (!sp || !(v instanceof Array)) { return v; }
        var o = v.slice(0);
        o[0] = v[0] * sx; if (o.length > 1) { o[1] = v[1] * sy; }
        return o;
    }
    function findKid(g, d) {
        var p = null;
        try { p = g.property(d.mn); } catch (e) {}
        try { var q = g.property(d.i); if (q && q.matchName === d.mn) { p = q; } } catch (e2) {}
        return p;
    }
    function applyProp(p, d, t0, sx, sy, warn) {
        try {
            if (d.k) {
                while (p.numKeys > 0) { p.removeKey(1); }
                for (var k = 0; k < d.k.length; k++) { p.setValueAtTime(t0 + d.k[k].t, scaleVal(d.k[k].v, d.sp, sx, sy)); }
                for (k = 0; k < d.k.length; k++) {
                    var K = d.k[k], idx = p.nearestKeyIndex(t0 + K.t);
                    if (d.sp && K.si) { try { p.setSpatialTangentsAtKey(idx, scaleVal(K.si, 1, sx, sy), scaleVal(K.so, 1, sx, sy)); p.setSpatialContinuousAtKey(idx, K.sc); p.setSpatialAutoBezierAtKey(idx, K.sa); } catch (e1) {} }
                    try { if (K.ei) { p.setTemporalEaseAtKey(idx, ease(K.ei), ease(K.eo)); } } catch (e2) {}
                    try { p.setInterpolationTypeAtKey(idx, K.ii, K.oi); } catch (e3) {}
                    try { p.setTemporalContinuousAtKey(idx, K.tc); p.setTemporalAutoBezierAtKey(idx, K.ab); } catch (e4) {}
                }
                for (k = 0; k < d.k.length; k++) { if (d.k[k].rv) { try { p.setRovingAtKey(p.nearestKeyIndex(t0 + d.k[k].t), true); } catch (e5) {} } }
            } else if (d.v !== undefined) {
                p.setValue(scaleVal(d.v, d.sp, sx, sy));
            }
            if (d.x) { p.expression = d.x; }
        } catch (e) { warn.push(d.mn); }
    }
    function applyGroup(g, kids, t0, sx, sy, warn) {
        for (var i = 0; i < kids.length; i++) {
            var d = kids[i], p = findKid(g, d);
            if (!p) { warn.push(d.mn); continue; }
            if (d.g) { applyGroup(p, d.g, t0, sx, sy, warn); } else { applyProp(p, d, t0, sx, sy, warn); }
        }
    }

    X.apply = function (a) {
        var c = U.comp(), T = a.data, t0 = c.time, warn = [];
        var sx = c.width / (T.w || c.width), sy = c.height / (T.h || c.height);
        var above = null, s = c.selectedLayers;
        for (var i = 0; i < s.length; i++) { if (!above || s[i].index < above.index) { above = s[i]; } }
        var L = c.layers.addSolid(T.color || [0, 0, 0], a.name || T.name || 'Transition', c.width, c.height, c.pixelAspect, c.duration);
        if (T.adjust !== false) { L.adjustmentLayer = true; }
        try { if (above) { L.moveBefore(above); } } catch (e) {}
        var inP = Math.max(0, t0 + T.inP), outP = Math.min(c.duration, t0 + T.outP);
        try { L.inPoint = inP; L.outPoint = Math.max(outP, inP + 1 / c.frameRate); } catch (e1) {}
        // effects
        var fxp = L.property('ADBE Effect Parade');
        for (i = 0; i < T.effects.length; i++) {
            var E = T.effects[i], ef = null;
            try { ef = fxp.addProperty(E.mn); } catch (e2) { warn.push(E.name); continue; }
            try { ef.name = E.name; } catch (e3) {}
            applyGroup(ef, E.g || [], t0, sx, sy, warn);
            try { ef.enabled = E.on !== false; } catch (e4) {}
        }
        if (T.transform) { applyGroup(L.property('ADBE Transform Group'), T.transform, t0, sx, sy, warn); }
        try { L.blendingMode = T.blend; } catch (e5) {}
        if (T.motionBlur) { L.motionBlur = true; try { c.motionBlur = true; } catch (e6) {} }
        try {
            var m = L.property('ADBE Marker');
            for (i = 0; i < (T.markers || []).length; i++) { m.setValueAtTime(t0 + T.markers[i].t, new MarkerValue(T.markers[i].c || '')); }
        } catch (e7) {}
        L.selected = true;
        return { name: L.name, warnings: warn };
    };

    return X;
})();
