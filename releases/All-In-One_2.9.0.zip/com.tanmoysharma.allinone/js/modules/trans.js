/* All In One — transition library (panel side). Saved next to the project library, so a
   Google Drive library folder shares transitions between PCs too. */
(function (w) {
    'use strict';
    var MK = w.MK;
    var EN = {
        'tr.title': 'Transition library', 'tr.save': 'Save selected layer as transition', 'tr.name': 'Name',
        'tr.hint': 'Save: select the transition layer (a layer marker named "Cut" marks the cut, else its middle is used). Use: put the playhead on the cut between two clips and click a card.',
        'tr.empty': 'No transitions saved yet.', 'tr.saved': 'Saved: {n}', 'tr.added': 'Added: {n}', 'tr.del': 'Delete "{n}"?',
        'tr.warn': 'Added, but {n} settings could not be copied: {l}', 'tr.notSolid': 'Note: this layer is not a solid/adjustment layer — only its effects and transform are saved.'
    };
    var BN = {
        'tr.title': 'ট্রানজিশন লাইব্রেরি', 'tr.save': 'সিলেক্ট করা লেয়ার ট্রানজিশন হিসেবে সেভ', 'tr.name': 'নাম',
        'tr.hint': 'সেভ: ট্রানজিশন লেয়ারটা সিলেক্ট করুন ("Cut" নামের লেয়ার মার্কার থাকলে সেটাই কাট পয়েন্ট, না থাকলে লেয়ারের মাঝখান)। ব্যবহার: দুই ক্লিপের কাটে প্লেহেড রেখে কার্ডে ক্লিক করুন।',
        'tr.empty': 'এখনো কোনো ট্রানজিশন সেভ করা নেই।', 'tr.saved': 'সেভ হয়েছে: {n}', 'tr.added': 'বসানো হয়েছে: {n}', 'tr.del': '"{n}" মুছে ফেলবেন?',
        'tr.warn': 'বসেছে, কিন্তু {n}টা সেটিং কপি হয়নি: {l}', 'tr.notSolid': 'খেয়াল করুন: এটা সলিড/অ্যাডজাস্টমেন্ট লেয়ার না — শুধু ইফেক্ট আর ট্রান্সফর্ম সেভ হলো।'
    };
    if (MK.regStrings) { MK.regStrings(EN, BN); }

    function path() { return MK.require('path'); }
    function dir() {
        var root = (MK._proj && MK._proj.root) ? MK._proj.root() : MK.paths.join(MK.paths.data, 'Projects');
        return path().join(root, '_Transitions');
    }
    function list() {
        var d = dir();
        return MK.fs.list(d).filter(function (f) { return /\.json$/i.test(f); }).map(function (f) {
            var o = MK.fs.readJSON(path().join(d, f), null);
            if (o) { o.file = path().join(d, f); o.thumb = path().join(d, f.replace(/\.json$/i, '.png')); }
            return o;
        }).filter(Boolean).sort(function (a, b) { return (b.added || 0) - (a.added || 0); });
    }
    function render() {
        var g = MK.$('#trGrid');
        if (!g || !MK.hasNode) { return; }
        var items = list();
        g.innerHTML = '';
        MK.$('#trEmpty').classList.toggle('hidden', items.length > 0);
        items.forEach(function (it) {
            var b = document.createElement('div');
            b.className = 'tr-card';
            var th = MK.fs.exists(it.thumb) ? 'background-image:url(\'' + MK.fs.fileUrl(it.thumb) + '?' + (it.added || 0) + '\')' : '';
            b.innerHTML = '<div class="tr-thumb" style="' + th + '"></div><div class="tr-name"><span>' + MK.esc(it.name) + '</span><small>' +
                (it.dur ? it.dur.toFixed(2) + 's' : '') + '</small></div><button class="tr-del" title="Delete">×</button>';
            b.onclick = function (e) {
                if (e.target.classList.contains('tr-del')) { return del(it); }
                MK.busy(b, function () {
                    return MK.host('trans.apply', { data: it.data, name: it.name }).then(function (r) {
                        if (r.warnings && r.warnings.length) { MK.toast(MK.t('tr.warn', { n: r.warnings.length, l: r.warnings.slice(0, 4).join(', ') }), 'warn'); }
                        else { MK.toast(MK.t('tr.added', { n: r.name })); }
                    });
                });
            };
            g.appendChild(b);
        });
    }
    function del(it) {
        MK.modal({ title: MK.t('tr.del', { n: it.name }), html: '' }).then(function (r) {
            if (!r) { return; }
            var fs = MK.require('fs');
            try { fs.unlinkSync(it.file); } catch (e) {}
            try { fs.unlinkSync(it.thumb); } catch (e2) {}
            render();
        });
    }
    function save(btn) {
        MK.busy(btn, function () {
            var d = dir(), id = Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
            MK.fs.mkdirp(d);
            var thumb = path().join(d, id + '.png');
            return MK.host('trans.readTransition', { thumb: thumb }).then(function (data) {
                return MK.prompt(MK.t('tr.save'), MK.t('tr.name'), data.name).then(function (name) {
                    if (name === null) { try { MK.require('fs').unlinkSync(thumb); } catch (e) {} return; }
                    name = String(name || data.name).trim() || 'Transition';
                    MK.fs.writeJSON(path().join(d, id + '.json'), { id: id, name: name, added: Date.now(), dur: data.outP - data.inP, data: data });
                    MK.toast(MK.t('tr.saved', { n: name }));
                    if (data.warnings && data.warnings.indexOf('notSolid') >= 0) { MK.toast(MK.t('tr.notSolid'), 'warn'); }
                    setTimeout(render, 800); // the thumbnail is written a moment later
                });
            });
        });
    }
    MK.initTrans = function () {
        MK.$('#trSave').onclick = function () { save(this); };
        MK.$('#trRefresh').onclick = render;
        var prev = MK.tabs.onShow.motion;
        MK.tabs.onShow.motion = function () { if (prev) { prev(); } render(); };
        render();
    };
    MK.transDir = dir;
})(window);
