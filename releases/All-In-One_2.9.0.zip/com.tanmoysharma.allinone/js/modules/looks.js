/* All In One — light overlays + camera FX (panel side) */
(function (w) {
    'use strict';
    var MK = w.MK;
    var LIGHTS = [
        ['Blue', '#2f6bff'], ['Cyan', '#18d6ff'], ['Purple', '#9b4dff'], ['Green', '#2bff88'],
        ['Orange', '#ff7a1f'], ['Pink', '#ff3d9a'], ['Gold', '#ffc93d'], ['Warm white', '#ffe6c4']
    ];
    var EN = {
        'lk.light': 'Light overlays', 'lk.custom': 'Custom color', 'lk.blend': 'Blend', 'lk.intensity': 'Intensity %', 'lk.add': 'ADD', 'lk.addCustom': 'Custom',
        'lk.lightHint': 'Adds an editable light layer above the selected layer (or on top). Change color, speed and spread later in Effect Controls.',
        'lk.camera': 'Camera FX', 'lk.dir': 'Direction', 'lk.speed': 'Speed', 'lk.type': 'Type', 'lk.shake': 'Handheld shake', 'lk.apply': 'Add camera FX',
        'lk.left': 'Left', 'lk.right': 'Right', 'lk.up': 'Up', 'lk.down': 'Down', 'lk.zoomin': 'Zoom in', 'lk.zoomout': 'Zoom out', 'lk.still': 'Handheld (shake only)',
        'lk.drift': 'Smooth move', 'lk.whip': 'Whip transition (at playhead)',
        'lk.camHint': 'Adds an adjustment layer that moves everything below it. Edges are mirrored, so no black borders.',
        'lk.added': 'Added: {n}'
    };
    var BN = {
        'lk.light': 'লাইট ওভারলে', 'lk.custom': 'নিজের রং', 'lk.blend': 'ব্লেন্ড', 'lk.intensity': 'তীব্রতা %', 'lk.add': 'যোগ', 'lk.addCustom': 'নিজের রং',
        'lk.lightHint': 'সিলেক্ট করা লেয়ারের উপরে (না থাকলে সবার উপরে) একটা এডিটযোগ্য লাইট লেয়ার বসে। রং, স্পিড, ছড়ানো পরে Effect Controls থেকে বদলানো যায়।',
        'lk.camera': 'ক্যামেরা FX', 'lk.dir': 'দিক', 'lk.speed': 'স্পিড', 'lk.type': 'ধরন', 'lk.shake': 'হাতে ধরা কাঁপুনি', 'lk.apply': 'ক্যামেরা FX যোগ করুন',
        'lk.left': 'বামে', 'lk.right': 'ডানে', 'lk.up': 'উপরে', 'lk.down': 'নিচে', 'lk.zoomin': 'জুম ইন', 'lk.zoomout': 'জুম আউট', 'lk.still': 'শুধু কাঁপুনি',
        'lk.drift': 'ধীরে নড়া', 'lk.whip': 'হুইপ ট্রানজিশন (প্লেহেডে)',
        'lk.camHint': 'একটা অ্যাডজাস্টমেন্ট লেয়ার বসে, তার নিচের সবকিছু নড়ে। কিনারা মিরর হয়, তাই কালো বর্ডার আসে না।',
        'lk.added': 'যোগ হয়েছে: {n}'
    };
    if (MK.regStrings) { MK.regStrings(EN, BN); }

    function cfg() { return (MK.settings.looks = MK.settings.looks || {}); }
    function save() {
        var c = cfg();
        c.blend = MK.$('#lkBlend').value; c.intensity = MK.$('#lkInt').value; c.color = MK.$('#lkColor').value;
        c.dir = MK.$('#camDir').value; c.speed = MK.$('#camSpeed').value; c.type = MK.$('#camType').value; c.shake = MK.$('#camShake').checked;
        MK.saveSettings();
    }
    function mix(hex, m) {
        var n = parseInt(String(hex).replace('#', ''), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
        var f = function (v) { return Math.round(v + (255 - v) * m); };
        return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')';
    }
    function tint(el, color) { el.style.setProperty('--lk', color); el.style.setProperty('--lk2', mix(color, 0.35)); el.style.setProperty('--lk3', mix(color, 0.65)); }
    function card(name, color, label) {
        var b = document.createElement('button');
        b.className = 'lk-card';
        tint(b, color);
        b.innerHTML = '<div class="lk-prev"><i></i><i></i><i></i></div><div class="lk-name"><span>' + MK.esc(label || name) + '</span><span class="lk-add">' + MK.esc(MK.t('lk.add')) + '</span></div>';
        b.onclick = function () { addLight(b, name, color); };
        return b;
    }
    function render() {
        var g = MK.$('#lkGrid');
        if (!g) { return; }
        g.innerHTML = '';
        LIGHTS.forEach(function (l) { g.appendChild(card(l[0], l[1])); });
        var cc = MK.$('#lkColor').value;
        var c = card('Custom', cc, MK.t('lk.addCustom'));
        c.id = 'lkCustomCard';
        g.appendChild(c);
    }
    function addLight(btn, name, color) {
        if (name === 'Custom') { color = MK.$('#lkColor').value; }
        MK.busy(btn, function () {
            return MK.host('looks.lightOverlay', { name: name, color: color, blend: MK.$('#lkBlend').value, intensity: MK.$('#lkInt').value, speed: 1 })
                .then(function (r) { MK.toast(MK.t('lk.added', { n: r.name })); });
        });
    }
    MK.initLooks = function () {
        var c = cfg();
        if (c.blend) { MK.$('#lkBlend').value = c.blend; }
        if (c.intensity) { MK.$('#lkInt').value = c.intensity; }
        if (c.color) { MK.$('#lkColor').value = c.color; }
        if (c.dir) { MK.$('#camDir').value = c.dir; }
        if (c.speed) { MK.$('#camSpeed').value = c.speed; }
        if (c.type) { MK.$('#camType').value = c.type; }
        MK.$('#camShake').checked = !!c.shake;
        ['#lkBlend', '#lkInt', '#camDir', '#camSpeed', '#camType', '#camShake'].forEach(function (s) { MK.$(s).addEventListener('change', save); });
        MK.$('#lkColor').addEventListener('input', function () { var k = MK.$('#lkCustomCard'); if (k) { tint(k, this.value); } });
        MK.$('#lkColor').addEventListener('change', save);
        MK.$('#camApply').onclick = function () {
            var btn = this;
            MK.busy(btn, function () {
                return MK.host('looks.cameraFx', { dir: MK.$('#camDir').value, speed: MK.$('#camSpeed').value, type: MK.$('#camType').value, shake: MK.$('#camShake').checked })
                    .then(function (r) { MK.toast(MK.t('lk.added', { n: r.name })); });
            });
        };
        render();
        (MK.onLang = MK.onLang || []).push(render);
    };
})(window);
