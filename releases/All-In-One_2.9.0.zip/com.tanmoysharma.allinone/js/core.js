/* All In One — panel core: CEP bridge, Node access, storage, HTTP */
(function (w) {
    'use strict';
    var MK = w.MK = w.MK || {};
    var cep = w.__adobe_cep__ || null;

    MK.version = '2.9.0';
    MK.inCEP = !!cep;
    MK.isWin = /Windows/i.test(navigator.userAgent) || /^Win/.test(navigator.platform || '');

    /* ---------- Node.js ---------- */
    var nreq = null;
    try { nreq = (w.cep_node && w.cep_node.require) || (typeof w.require === 'function' ? w.require : null); } catch (e) { nreq = null; }
    MK.hasNode = !!nreq;
    var Buf = function () { return (typeof w.Buffer !== 'undefined') ? w.Buffer : MK.require('buffer').Buffer; };
    MK.require = function (m) {
        if (!nreq) { throw new Error('Node.js is not available in this panel'); }
        return nreq(m);
    };

    /* ---------- paths ---------- */
    MK.systemPath = function (type) {
        if (!cep) { return ''; }
        var p = decodeURI(cep.getSystemPath(type));
        return MK.isWin ? p.replace(/^file:\/\/\//, '') : p.replace(/^file:\/\//, '');
    };
    MK.extRoot = MK.systemPath('extension');

    MK.paths = (function () {
        var home = '', docs = '';
        try { home = MK.require('os').homedir(); docs = MK.require('path').join(home, 'Documents'); } catch (e) {}
        var join = function () {
            var parts = Array.prototype.slice.call(arguments);
            try { return MK.require('path').join.apply(null, parts); } catch (e) { return parts.join('/'); }
        };
        var data = join(docs || home || '.', 'All In One');
        return {
            join: join,
            home: home,
            data: data,
            settings: join(data, 'settings.json'),
            presets: join(data, 'Text Presets'),
            previews: join(data, 'Previews'),
            builder: join(data, 'builder-presets.json'),
            ease: join(data, 'ease-presets.json'),
            temp: join(data, 'temp'),
            bundledPresets: MK.extRoot ? join(MK.extRoot, 'presets', 'text') : ''
        };
    })();

    /* ---------- tiny fs helpers ---------- */
    MK.fs = {
        mkdirp: function (dir) {
            var fs = MK.require('fs'), path = MK.require('path');
            if (fs.existsSync(dir)) { return dir; }
            MK.fs.mkdirp(path.dirname(dir));
            try { fs.mkdirSync(dir); } catch (e) { if (!fs.existsSync(dir)) { throw e; } }
            return dir;
        },
        exists: function (p) { try { return MK.require('fs').existsSync(p); } catch (e) { return false; } },
        readJSON: function (p, def) {
            try { return JSON.parse(MK.require('fs').readFileSync(p, 'utf8')); } catch (e) { return def; }
        },
        writeJSON: function (p, obj) {
            MK.fs.mkdirp(MK.require('path').dirname(p));
            MK.require('fs').writeFileSync(p, JSON.stringify(obj, null, 2), 'utf8');
        },
        readText: function (p) { return MK.require('fs').readFileSync(p, 'utf8'); },
        writeText: function (p, s) {
            MK.fs.mkdirp(MK.require('path').dirname(p));
            MK.require('fs').writeFileSync(p, s, 'utf8');
        },
        list: function (dir) { try { return MK.require('fs').readdirSync(dir); } catch (e) { return []; } },
        isDir: function (p) { try { return MK.require('fs').statSync(p).isDirectory(); } catch (e) { return false; } },
        size: function (p) { try { return MK.require('fs').statSync(p).size; } catch (e) { return 0; } },
        fileUrl: function (p) { return 'file:///' + String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:'); }
    };

    /* ---------- one-time migration from the old "UBD Motion Kit" data folder ---------- */
    (function migrateOldData() {
        if (!MK.hasNode) { return; }
        try {
            var fs = MK.require('fs'), path = MK.require('path');
            var oldDir = path.join(path.dirname(MK.paths.data), 'UBD Motion Kit');
            if (fs.existsSync(MK.paths.data) || !fs.existsSync(oldDir)) { return; }
            var copy = function (src, dst) {
                if (fs.statSync(src).isDirectory()) {
                    MK.fs.mkdirp(dst);
                    fs.readdirSync(src).forEach(function (n) { copy(path.join(src, n), path.join(dst, n)); });
                } else { fs.writeFileSync(dst, fs.readFileSync(src)); }
            };
            ['settings.json', 'builder-presets.json', 'ease-presets.json', 'Text Presets'].forEach(function (n) {
                var src = path.join(oldDir, n);
                if (fs.existsSync(src)) { copy(src, path.join(MK.paths.data, n)); }
            });
        } catch (e) { console.error('migration', e); }
    })();

    /* ---------- settings ---------- */
    var DEFAULTS = {
        lang: 'en',
        theme: 'aurora',
        communityPopup: true,
        keys: { groq: '', gemini: '', assemblyai: '', pixabay: '', pexels: '', freesound: '' },
        ai: { provider: 'gemini', geminiModel: 'gemini-flash-latest', groqModel: '' },
        captions: {},
        presetFolders: []
    };
    MK.settings = (function () {
        var s = MK.hasNode ? MK.fs.readJSON(MK.paths.settings, null) : null;
        if (!s) { try { s = JSON.parse(w.localStorage.getItem('mk.settings') || 'null'); } catch (e) { s = null; } }
        s = s || {};
        for (var k in DEFAULTS) {
            if (!(k in s)) { s[k] = JSON.parse(JSON.stringify(DEFAULTS[k])); }
            else if (typeof DEFAULTS[k] === 'object' && !Array.isArray(DEFAULTS[k])) {
                for (var j in DEFAULTS[k]) { if (!(j in s[k])) { s[k][j] = DEFAULTS[k][j]; } }
            }
        }
        return s;
    })();
    // v1.1.0: Aurora Glass becomes the default once for everybody (they can switch back in Settings)
    if (MK.settings.themeV !== 1) { MK.settings.theme = 'aurora'; MK.settings.themeV = 1; MK._needSave = true; }
    MK.applyTheme = function (name) {
        MK.settings.theme = name === 'classic' ? 'classic' : 'aurora';
        document.documentElement.setAttribute('data-theme', MK.settings.theme);
    };
    MK.applyTheme(MK.settings.theme);

    MK.saveSettings = function () {
        try {
            if (MK.hasNode) { MK.fs.writeJSON(MK.paths.settings, MK.settings); }
            else { w.localStorage.setItem('mk.settings', JSON.stringify(MK.settings)); }
        } catch (e) { console.error(e); }
    };

    /* ---------- host (ExtendScript) bridge ---------- */
    MK.host = function (fn, args, opts) {
        var p = new Promise(function (resolve, reject) {
            if (!cep) {
                if (MK.mockHost) { return MK.mockHost(fn, args).then(resolve, reject); }
                return reject(new Error('NOT_IN_AE'));
            }
            var payload = encodeURIComponent(JSON.stringify(args || {}));
            cep.evalScript('MK_call(' + JSON.stringify(fn) + ',"' + payload + '")', function (r) {
                if (r === 'EvalScript error.' || r === undefined || r === null) { return reject(new Error('HOST_ERROR')); }
                var o;
                try { o = JSON.parse(r); } catch (e) { return reject(new Error('Bad host reply: ' + String(r).slice(0, 200))); }
                if (o && o.ok) { resolve(o.data); } else { reject(new Error((o && o.error) || 'Unknown host error')); }
            });
        });
        return (opts && opts.timeout) ? MK.withTimeout(p, opts.timeout) : p;
    };

    // reject with NO_REPLY if After Effects doesn't answer in time (busy, modal dialog open, …)
    MK.withTimeout = function (p, ms) {
        return new Promise(function (resolve, reject) {
            var t = setTimeout(function () { reject(new Error('NO_REPLY')); }, ms);
            p.then(function (v) { clearTimeout(t); resolve(v); }, function (e) { clearTimeout(t); reject(e); });
        });
    };

    MK.loadHost = function (ms) {
        var p = new Promise(function (resolve, reject) {
            if (!cep) { return resolve({ mock: true }); }
            cep.evalScript('MK_load(' + JSON.stringify(MK.extRoot) + ')', function (r) {
                var o;
                try { o = JSON.parse(r); } catch (e) { return reject(new Error('Host bootstrap failed: ' + r)); }
                if (!o.ok) { return reject(new Error(o.error)); }
                // host modules added by a later update are not in the MK_load list that After Effects
                // read at start-up, so load them from here — no restart needed after an update
                MK.loadExtraHost().then(function () { resolve(o.data); }, function () { resolve(o.data); });
            });
        });
        return ms ? MK.withTimeout(p, ms) : p;
    };

    var BASE_HOST = ['util', 'quick', 'ease', 'text', 'captions', 'broll', 'ai', 'tools', 'export', 'create', 'motion', 'sfx', 'counter', 'projects', 'check', 'extra'];
    MK.loadExtraHost = function () {
        var files = [];
        try {
            files = MK.require('fs').readdirSync(MK.require('path').join(MK.extRoot, 'host', 'ae'))
                .filter(function (f) { return /\.jsx$/i.test(f) && BASE_HOST.indexOf(f.replace(/\.jsx$/i, '')) < 0; });
        } catch (e) { return Promise.resolve(); }
        return files.reduce(function (p, f) {
            return p.then(function () {
                return new Promise(function (res) {
                    var full = (MK.extRoot + '/host/ae/' + f).replace(/\\/g, '/');
                    cep.evalScript('(function(){try{$.evalFile(new File(' + JSON.stringify(full) + '));return "ok";}catch(e){return "ERR "+e;}})()', function (r) {
                        if (r !== 'ok') { console.warn('host module', f, r); }
                        res();
                    });
                });
            });
        }, Promise.resolve());
    };

    MK.openURL = function (url) {
        try {
            if (w.cep && w.cep.util && w.cep.util.openURLInDefaultBrowser) { w.cep.util.openURLInDefaultBrowser(url); return; }
        } catch (e) {}
        try {
            var cp = MK.require('child_process');
            if (MK.isWin) { cp.exec('start "" "' + url + '"'); } else { cp.exec('open "' + url + '"'); }
        } catch (e2) { w.open(url, '_blank'); }
    };

    /* ---------- HTTP via Node (no CORS problems inside CEP) ---------- */
    function nodeRequest(opts, bodyBuf, redirects) {
        return new Promise(function (resolve, reject) {
            var url = new URL(opts.url);
            var lib = MK.require(url.protocol === 'http:' ? 'http' : 'https');
            var headers = Object.assign({ 'User-Agent': 'All-In-One/' + MK.version }, opts.headers || {});
            if (bodyBuf) { headers['Content-Length'] = bodyBuf.length; }
            var req = lib.request({
                method: opts.method || 'GET', hostname: url.hostname, port: url.port || undefined,
                path: url.pathname + url.search, headers: headers
            }, function (res) {
                if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && (redirects || 0) < 6) {
                    res.resume();
                    var next = new URL(res.headers.location, opts.url).toString();
                    return resolve(nodeRequest(Object.assign({}, opts, { url: next, method: 'GET' }), null, (redirects || 0) + 1));
                }
                if (opts.toFile) {
                    if (res.statusCode >= 400) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
                    var fs = MK.require('fs');
                    MK.fs.mkdirp(MK.require('path').dirname(opts.toFile));
                    var total = parseInt(res.headers['content-length'] || '0', 10), got = 0;
                    var out = fs.createWriteStream(opts.toFile);
                    res.on('data', function (chunk) { got += chunk.length; if (opts.onProgress && total) { opts.onProgress(got / total); } });
                    res.pipe(out);
                    out.on('finish', function () { out.close(function () { resolve({ status: res.statusCode, file: opts.toFile }); }); });
                    out.on('error', reject);
                    return;
                }
                var chunks = [];
                res.on('data', function (c) { chunks.push(c); });
                res.on('end', function () {
                    resolve({ status: res.statusCode, headers: res.headers, body: Buf().concat(chunks) });
                });
            });
            req.on('error', reject);
            req.setTimeout(opts.timeout || 120000, function () { req.destroy(new Error('Request timed out')); });
            if (bodyBuf) { req.write(bodyBuf); }
            req.end();
        });
    }

    function parseReply(r) {
        var txt = r.body ? r.body.toString('utf8') : '';
        var data = null;
        try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = null; }
        if (r.status >= 400) {
            var msg = (data && ((data.error && (data.error.message || data.error)) || data.message)) || txt.slice(0, 300) || ('HTTP ' + r.status);
            if (typeof msg !== 'string') { msg = JSON.stringify(msg); }
            var err = new Error(msg);
            err.status = r.status;
            throw err;
        }
        return data !== null ? data : txt;
    }

    MK.http = {
        get: function (url, headers) {
            return nodeRequest({ url: url, headers: headers }).then(parseReply);
        },
        postJSON: function (url, obj, headers, timeout) {
            var buf = Buf().from(JSON.stringify(obj), 'utf8');
            return nodeRequest({ url: url, method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}), timeout: timeout }, buf).then(parseReply);
        },
        postBinary: function (url, buf, headers, timeout) {
            return nodeRequest({ url: url, method: 'POST', headers: Object.assign({ 'Content-Type': 'application/octet-stream' }, headers || {}), timeout: timeout }, buf).then(parseReply);
        },
        multipart: function (url, fields, file, headers, timeout) {
            var boundary = '----MKBoundary' + Date.now().toString(16) + Math.random().toString(16).slice(2);
            var parts = [];
            var add = function (s) { parts.push(Buf().from(s, 'utf8')); };
            (fields || []).forEach(function (f) {
                add('--' + boundary + '\r\nContent-Disposition: form-data; name="' + f[0] + '"\r\n\r\n' + f[1] + '\r\n');
            });
            if (file) {
                add('--' + boundary + '\r\nContent-Disposition: form-data; name="' + file.field + '"; filename="' + file.name.replace(/"/g, '') + '"\r\nContent-Type: ' + (file.type || 'application/octet-stream') + '\r\n\r\n');
                parts.push(file.buffer);
                add('\r\n');
            }
            add('--' + boundary + '--\r\n');
            var body = Buf().concat(parts);
            return nodeRequest({ url: url, method: 'POST', headers: Object.assign({ 'Content-Type': 'multipart/form-data; boundary=' + boundary }, headers || {}), timeout: timeout || 300000 }, body).then(parseReply);
        },
        download: function (url, dest, onProgress) {
            return nodeRequest({ url: url, toFile: dest, onProgress: onProgress, timeout: 300000 });
        },
        // full response (status, headers, body Buffer) for protocols that need headers, e.g. resumable uploads
        raw: function (opts, bodyBuf) { return nodeRequest(opts, bodyBuf || null); }
    };

    MK.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
})(window);
