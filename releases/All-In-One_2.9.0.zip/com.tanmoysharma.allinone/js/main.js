/* All In One — startup */
(function (w) {
    'use strict';
    var MK = w.MK;

    /* ---------- startup splash ---------- */
    var boot = {
        msg: function (m, sub) {
            MK.$('#bootMsg').textContent = m || '';
            MK.$('#bootSub').textContent = sub || '';
        },
        fail: function (m, sub) {
            MK.$('#boot').classList.add('error');
            MK.$('#bootSpin').classList.add('hidden');
            MK.$('#bootRetry').classList.remove('hidden');
            boot.msg(m, sub);
        },
        hide: function () {
            var el = MK.$('#boot');
            el.classList.add('fade');
            setTimeout(function () { el.classList.add('gone'); }, 350);
        }
    };

    function connect() {
        var el = MK.$('#boot');
        el.classList.remove('error', 'fade', 'gone');
        MK.$('#bootSpin').classList.remove('hidden');
        MK.$('#bootRetry').classList.add('hidden');
        boot.msg(MK.t('boot.connecting'));
        var slow = setTimeout(function () { boot.msg(MK.t('boot.connecting'), MK.t('boot.firstRun')); }, 3500);
        var ms = (MK.config && MK.config.bootTimeoutMs) || 30000;
        return MK.loadHost(ms).then(function (info) {
            clearTimeout(slow);
            MK.$('#hostInfo').textContent = info && info.version ? 'After Effects ' + info.version : (info && info.mock ? 'Browser preview (no After Effects)' : '');
            boot.hide();
            pollInfo();
            if (!MK._polling) { MK._polling = setInterval(pollInfo, 2500); }
            if (MK.scheduleCommunity) { MK.scheduleCommunity(); }
        }, function (e) {
            clearTimeout(slow);
            console.error(e);
            if (e && e.message === 'NO_REPLY') { boot.fail(MK.t('boot.noReply'), MK.t('boot.noReplySub')); }
            else { boot.fail(MK.t('boot.error'), (e && e.message) || String(e)); }
        });
    }

    /* ---------- settings tab ---------- */
    function initSettings() {
        MK.$$('[data-key]').forEach(function (inp) {
            inp.value = MK.settings.keys[inp.dataset.key] || '';
            inp.addEventListener('change', function () {
                MK.settings.keys[inp.dataset.key] = inp.value.trim();
                MK.saveSettings();
                MK.toast(MK.t('ok.saved'));
            });
        });
        MK.$('#showKeys').addEventListener('change', function () {
            var on = this.checked;
            MK.$$('[data-key]').forEach(function (i) { i.type = on ? 'text' : 'password'; });
        });
        MK.$$('.key-row [data-url]').forEach(function (a) {
            a.addEventListener('click', function (e) { e.preventDefault(); MK.openURL(a.dataset.url); });
        });
        MK.$('#openData').onclick = function () { MK.fs.mkdirp(MK.paths.data); MK.host('app.openFolder', { path: MK.paths.data }).catch(MK.fail); };
        MK.$('#openPresets').onclick = function () { MK.fs.mkdirp(MK.paths.presets); MK.host('app.openFolder', { path: MK.paths.presets }).catch(MK.fail); };
        MK.$('#dataPath').textContent = MK.paths.data;
        MK.$('#verLbl').textContent = 'v' + MK.version;
        MK.$('#settingsBtn').onclick = function () { MK.showTab(MK.tabs.current === 'settings' ? (MK._lastTab || 'quick') : 'settings'); };
        MK.$('#settingsClose').onclick = function () { MK.showTab(MK._lastTab || 'quick'); };

        var ts = MK.$('#themeSel');
        ts.value = MK.settings.theme;
        ts.addEventListener('change', function () { MK.applyTheme(ts.value); MK.saveSettings(); });
        var ls = MK.$('#langSel');
        ls.value = MK.lang();
        ls.addEventListener('change', function () { setLang(ls.value); });
    }

    function setLang(l) {
        MK.settings.lang = l === 'bn' ? 'bn' : 'en';
        MK.saveSettings();
        MK.applyLang();
        MK.$('#langBtn').textContent = MK.lang() === 'bn' ? 'EN' : 'বাং';
        MK.$('#langSel').value = MK.lang();
        (MK.onLang || []).forEach(function (f) { try { f(); } catch (e) { console.error(e); } });
    }

    function pollInfo() {
        if (document.hidden) { return; }
        MK.host('app.info', {}, { timeout: 8000 }).then(function (i) {
            var el = MK.$('#compInfo');
            if (i.comp) {
                el.textContent = i.comp.name + (i.selected ? '  ·  ' + i.selected + ' sel' : '');
                el.title = i.comp.width + '×' + i.comp.height + ' · ' + (Math.round(i.comp.fps * 100) / 100) + ' fps · ' + i.comp.duration.toFixed(2) + 's';
            } else { el.textContent = '—'; }
        }).catch(function () {});
    }

    /* ---------- soft glow that follows the mouse (Aurora theme only) ---------- */
    function initCursorGlow() {
        var el = MK.$('#mkCursor');
        if (!el) { return; }
        var R = 130, tx = 0, ty = 0, x = 0, y = 0, raf = 0;
        var step = function () {
            raf = 0;
            x += (tx - x) * 0.25; y += (ty - y) * 0.25;
            el.style.transform = 'translate3d(' + (x - R) + 'px,' + (y - R) + 'px,0)';
            if (Math.abs(tx - x) > 0.5 || Math.abs(ty - y) > 0.5) { raf = w.requestAnimationFrame(step); }
        };
        document.addEventListener('mousemove', function (e) {
            if (MK.settings.theme !== 'aurora') { return; }
            tx = e.clientX; ty = e.clientY;
            el.classList.add('on');
            if (!raf) { raf = w.requestAnimationFrame(step); }
        });
        document.addEventListener('mouseleave', function () { el.classList.remove('on'); });
    }

    function start() {
        MK.checkFlexGap();
        MK.renderIcons();
        MK.applyLang();
        boot.msg(MK.t('boot.starting'));
        MK.$('#langBtn').textContent = MK.lang() === 'bn' ? 'EN' : 'বাং';

        MK.$$('#tabs button').forEach(function (b) {
            b.addEventListener('click', function () { MK._lastTab = b.dataset.tab; MK.showTab(b.dataset.tab); });
        });
        MK.$('#langBtn').onclick = function () { setLang(MK.lang() === 'bn' ? 'en' : 'bn'); };
        MK.$('#bootRetry').onclick = connect;

        var inits = ['initQuick', 'initCreate', 'initMotion', 'initEase', 'initText', 'initCaptions', 'initBroll', 'initSfx', 'initAI', 'initCommunity', 'initTools', 'initCounter', 'initYT', 'initProjects', 'initCheck', 'initExtra', 'initIcons','initLooks','initTrans','initUpdate'];
        var crashed = [];
        inits.forEach(function (fn) {
            try { if (MK[fn]) { MK[fn](); } } catch (e) { console.error(fn, e); crashed.push(fn.replace('init', '') + ': ' + e.message); }
        });
        try { initSettings(); } catch (e2) { crashed.push('Settings: ' + e2.message); }
        initCursorGlow();
        MK.renderIcons();
        MK.applyLang();
        if (MK._needSave) { MK.saveSettings(); }

        if (MK.hasNode) {
            try { MK.fs.mkdirp(MK.paths.presets); MK.fs.mkdirp(MK.paths.previews); } catch (e3) { console.warn(e3); }
        }
        if (crashed.length) { MK.toast(MK.t('boot.partial') + ' ' + crashed.join(' · '), 'err'); }
        connect();
    }

    w.addEventListener('error', function (e) {
        // a crash before the splash is gone should be visible, not a frozen spinner
        var b = document.getElementById('boot');
        if (b && !b.classList.contains('gone') && MK.t) { boot.fail(MK.t('boot.error'), e.message || String(e)); }
    });

    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', start); } else { start(); }
})(window);
